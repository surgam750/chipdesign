# RTL3307 Resume V1.3 — 最终交付首页（证据版）

**版本状态：V1.3 为唯一选定候选。此包包含当前源码/脚本、验证数据、用户提供的服务器截图及历史工程。它不是赛事官方验收通过证明。**

## 第一优先级：源码在哪

- `CURRENT_SOURCE_AND_TOOLS/RTL3307_Timing_TargetFix_V1/payload/`：当前活动 RTL、testbench、驱动、12任务数据、工具及冻结配置。此次文件与之前归档逐字一致。
- `CURRENT_SOURCE_AND_TOOLS/RTL3307_Timing_Resume_V1_2/`、`RTL3307_Timing_Resume_V1_3/`：从 TargetFix 到最终综合网表的两段增量优化脚本；V1.3 并不是一个另行修改的 RTL 文件。
- `CURRENT_SOURCE_AND_TOOLS/RTL3307_V13_Downstream_V1/`：Formality 与 PT-PX 运行代码。
- `CURRENT_SOURCE_AND_TOOLS/RTL3307_V13_PPA_Readout_V2/`：面积、功耗、精度只读查看器。
- `ORIGINAL_ARCHIVES/RTL3307_V13_Current_AllFiles_20261119.zip`：之前整理的**完整工程档案**，保留完整原目录、数值模型和全部历史文件；该历史包内 README 的旧数字，以本首页和 `FINAL_METRICS.json` 为准。
- `ORIGINAL_ARCHIVES/RTL3307_V13_Numeric_Recheck_20261119.zip`：数值重跑工具和冻结样本，原包不改字节。

## 当前主要数据及来源

| 指标 | 结果 | 证据类别 / 限制 |
|---|---:|---|
| 12任务 RTL 功能 | 544,214 拍，304,128 个输出，0 不一致 | 服务器 RTL 回归截图；属于 TargetFix 祖先 RTL / V1.3 相同冻结源，非新门级仿真 |
| SoC 级吞吐 | 3,307.5224 任务/秒 | `150e6 * 12 / 544214` 的确定计算值，不是工具打印的直接字段 |
| 600样本软件精度 | 最大层 NRMSE 0.033317850017% | 服务器上新的 W12 冻结模型软件复算截图；**非**组委会私有集、**非**门级仿真 |
| LEC | Verification SUCCEEDED, 79683 pass, 0 fail | V1.3 Formality 原生截图；自动设置、SRAM黑盒和RTL解释消息仍需保留 |
| STA | 七角已报告 setup=0、max_transition=0 | V1.3 PrimeTime 结果；数据 hold、removal、untested 和未约束项未闭合；不是完整 timing pass |
| TT5 平均功耗 | 54.669664 mW, 16.527052 uJ/task | V1.3 PTPX averaged / SAIF / 12任务；库表及活动告警仍在 |
| 七角等权均值 | 90.710053 mW, 27.422333 uJ/task | 从七角 PTPX 截图的数值算术平均；**不是官方评分口径** |
| 面积已分离小计 | 0.39588272 mm² | V1.3 DC库单元面积按归属相加；不是官方最终申报精确面积 |
| 保守库面积上界 | 0.54918618 mm² | 含大量非加速器标准单元的保守统计上界；非布局面积 |

## 必须强调的争议：0.0333% 与 0.5079% 不应混用

新上传的两份说明出现冲突：其中一份声称 V1.3 是 PC16，并称 0.0333% 仅属于另一个未综合的 W12 版本。
**实际在本包当前 `kwt_dot64.v` 中，`w_lane` 为 `signed [11:0]`；`kwt_wset.v` 是 48 个 W12 packed words；冻结任务 manifest 的 `format` 明确写成 `X16_W12_PACKED`，并使用 W12 的 `FORMAT_FREEZE` SHA256。** V1.3 所用 RTL 祖先是这个 TargetFix 源包。因此不能仅凭那段相反说明把 V1.3 说成 PC16。
但 0.03331785% 仍然只是**相同冻结 W12 数值格式的 600公开样本软件误差**；不是“V1.3 600 样本门级仿真 NRMSE”。提交时请明确层级。

## 功耗完整七角 (每角 12任务)

| PVT | mW | uJ/任务 | 审查项 |
|---|---:|---:|---:|
| FF0 | 65.010547 | 19.653179 | 9 项/角，未消除 |
| FF1 | 68.786905 | 20.794800 | 9 项/角，未消除 |
| FF2 | 255.370242 | 77.200351 | 9 项/角，未消除 |
| SS3 | 44.134613 | 13.342227 | 9 项/角，未消除 |
| SS4 | 54.917596 | 16.602004 | 9 项/角，未消除 |
| TT5 | 54.669664 | 16.527052 | 9 项/角，未消除 |
| TT6 | 92.080807 | 27.836723 | 9 项/角，未消除 |
| **等权均值** | **90.710053** | **27.422333** | 补充对照，不是官方工况 |

FF2 总功耗 255.370 mW 明显偏高；原始截图可核实其 leakage=184.648 mW。**本包不自行删除异常值或修正功耗**，仍需看库模型和活动覆盖。

## 未完成 / 不可宣称完成

1. 七角仍存在数据 hold 和每角 5 条 removal；SS3 最差 removal −0.260416627 ns。原始 PMU、`reset_n_catch` 复位路径和赛题允许范围尚须复核；未以 `false_path` 隐藏。
2. 每角 setup/hold 各 11,968 项 untested，并出现未约束最大延迟端点 26 个。`setup=0` 是**已检查范围内零条违例**，不是全部检查通过。
3. 功耗 9 项/角需要审阅：活动直接标注不足、SRAM边界活动、工具 check_power 和部分表范围等。三类 SRAM 已确认包含非零宏功耗，不是“SRAM 全为0”。
4. V1.3 真正综合网表、DDC、SVF、原生 `.rpt`、PTPX 84个原生 task 报告、服务器新跑的 `testing_result.json` 尚未通过文件形式传给本次整理环境；这里只有用户提供的**真实服务器截图**。`ORIGINAL_ARCHIVES/` 和 `EVIDENCE_SCREENSHOTS/` 不能替代这些文件作可重放网表。
5. 对 ITCM 宏适配是否落入赛题许可范围，官方答复未明确专项许可。现有通路应遵守 32bit 原 System Bus、共享512KB SRAM、真实装载与完整写回。

## 快速操作（不需重新跑 EDA）

- 先直接阅读 `FINAL_METRICS.json` 或 `FINAL_METRICS.csv` 和 `EVIDENCE_INDEX.md`，以及关键截图。
- 如果必须在原服务器再核对数值：上传 `SERVER_READONLY_CHECK/final_check_v13_server.py` 到 `~/Desktop/`，运行 `python3 -B ~/Desktop/final_check_v13_server.py`。它只读已有的七角功耗 `summary.json` 和 W12 精度 `testing_result.json`，打印简短可截图摘要；不跑 EDA、不写入文件。
- 若需要原生网表/报告备份：解压 `ORIGINAL_ARCHIVES/RTL3307_V13_Current_AllFiles_20261119.zip` 后在原服务器执行其 `server_tools/collect_current_v13.py --pack`（独立归档）；**不要**混为已包含在本包中的实际服务器字节。

## 安装/复现边界

历史工程含多个候选。**仅以 CURRENT_SOURCE_AND_TOOLS/ 中指定的当前源链为正式候选**，不要混入 HoldMin、PostEq、BANKWEN 或 PC16 旧基线。实际厂商 EDA、许可证以及服务器宏库路径不随本包分发；其他账户恢复需检查绝对路径/库适配。所有旧材料及截图都是可追溯证据，不是逐个自动验收证明。
