# 精度复核：服务器独立复算回执（2026-11-19 01:59）

## 一、结论

服务器上新起目录独立跑了一遍冻结 W12 的 600 样本评估，结果**与本地报告逐位相同**。

```
FROZEN_W12_RETEST status=PASS samples=600 layers=12
MAX_NRMSE_PERCENT=0.033317850017; WORST_LAYER_ZERO_BASED=10
SATURATED=0; CLIPPED=0
```

- `status=PASS`：评估器自身判定通过
- `samples=600, layers=12`：覆盖完整，未抽样、未跳层
- **`MAX_NRMSE_PERCENT=0.033317850017`**：与 `numerics/NUMERIC_REPORT.md` 第 16 行原文完全一致
- `SATURATED=0; CLIPPED=0`：12 层 × 600 样本全无溢出、全无截断
- 门槛 3% → 实测为其 **1.11%**，低约 1.95 个数量级

## 二、产物位置与哈希

| 项 | 值 |
|---|---|
| run 目录 | `/storage1/2026contest/server3/s3_33usr/Desktop/kwt_runs/V13_W12_ACCURACY_RERUN_20261119_015941_c17aa9` |
| 结果文件 | 该 run 下 `numerics/testing_result.json` |
| REPORT_SHA256 | `ab5cbc1dbcbc1dbe077b0b7f6e7d7a90a45e77a04f20deea83b80b2dcc652949b6e163591`（以屏幕为准，如需精确值请重跑 `sha256sum` 该文件） |
| 控制台日志 | 同 run 下 `accuracy_console.log` |

## 三、执行环境（为什么之前跑不起来）

服务器是 **Python 3.6.8**，且**无外网**（`pip install` 报 `Name or service not known`）。缺三个包，全部由本地下载官方 wheel 后经 FTP 上传离线安装：

| 包 | 版本 | 大小 (字节) | sha256（与 PyPI 官方一致） | 为什么需要 |
|---|---|---|---|---|
| numpy | 1.19.5 | 13,391,355 | `8b5e972b43c8fc27d56550b4120fe6257fdc15f9301914380b27f74856299fea` | 全流程数值计算；1.19.5 是支持 py3.6 的最后一版 |
| dataclasses | 0.8 | 19,041 | `0201d89fa866f68c8ebd9d08ee6ff50c0b255f8ec63a71c16fda7af82bb887bf` | 3.7 才进标准库；`pc16.py` / `metrics.py` / `evaluate_formats.py` 均 `from dataclasses import dataclass` |
| scipy | 1.5.4 | 25,879,680 | `368c0f69f93186309e1b4beb8e26d51dd6f5010b79264c0f1e9ca00cd92ea8c9` | `encoder_reference.py:8` 模块级 `from scipy.special import erf`；1.5.4 是支持 py3.6 的最后一版 |

**tensorflow 不需要装。** `kwt_full_reference.py` 第 91 行的 `import tensorflow as tf` 位于 `build_official_tf_reference()` 函数体内，而评估链路调用的是同文件的 `kwt_full_reference()`（纯 numpy 实现），那条分支从不执行。

### 安装命令（离线）

```bash
python3 -m pip install --user --no-index "$HOME/Desktop/numpy-1.19.5-cp36-cp36m-manylinux1_x86_64.whl"
python3 -m pip install --user --no-index "$HOME/Desktop/dataclasses-0.8-py3-none-any.whl"
python3 -m pip install --user --no-index --no-deps "$HOME/Desktop/scipy-1.5.4-cp36-cp36m-manylinux1_x86_64.whl"
```

scipy 那条必须带 `--no-deps`：它元数据声明 `numpy>=1.14.5`，而 `--no-index` 下 pip 无法解析该依赖会直接失败；numpy 已装好，跳过解析即可。

### 运行命令

```bash
python3 -B "$HOME/Desktop/RTL3307_V13_Numeric_Recheck_20261119/rerun_v13_w12_accuracy.py" \
        --source "$HOME/Desktop/RTL3307_V13_Numeric_Recheck_20261119/numerics"
```

`--source` 必须显式给：脚本默认指向 `$HOME/RTL3307_V13_Current_AllFiles_20261119/reference_engineering/RTL3307/numerics`，该目录未上传。

## 四、引用口径（这一节最重要）

**0.0333% 不是交付配置的数，不能拿去替换 PPT 里的 0.5079%。**

| 精度数 | 属于哪个配置 | 状态 | 能否上 PPT |
|---|---|---|---|
| **0.0333%** | X16 / **W12_PACKED**（12 bit 权重打包） | 仅软件数值评估；**综合、STA、功耗、门级仿真全未跑** | ❌ 不能当交付指标；只能作"已识别的下一步" |
| **0.5079%** | PC16（当前交付版 V1.3 所在配置） | 12 层 RTL 逐位一致 304,128 点；已综合、已 STA、已 LEC | ✅ 交付口径 |

两者相差约 15 倍，**答辩时若被问"你精度多少"，必须说 0.5079%**，否则评审核对综合报告会认为前后矛盾。

### 0.0333% 可以怎么用（原话模板）

> 在冻结的公开 600 样本上，X16/W12 打包格式的最大层 NRMSE 为 0.0333%（门槛 3%），12 层零饱和零截断，已在服务器上独立复算确认。该格式的 RTL 已就绪，综合与时序评估留待后续。**这不是组委会私有评测集，也不是门级仿真。**

## 五、边界声明（脚本自己打印的，不是我加的）

运行时输出最后一行原文：

```
COMPLETE: fresh on-server frozen-W12 software evaluation;
NOT committee private 600, NOT V1.3 gate simulation
```

三句话记住：

1. **不是组委会那 600 条私有评测集** —— 是公开冻结样本
2. **不是 V1.3 的门级仿真** —— 是软件数值评估
3. **不是新算法** —— 用的是归档的 `evaluate_frozen.py`，一个数没改

## 六、这一轮为什么能跑通（排障路径备查）

| 现象 | 原因 | 处理 |
|---|---|---|
| `RECHECK_STOPPED=NumPy is not installed` | py3.6 无 numpy，且服务器无外网 | 本地下 cp36 wheel → FTP 上传 → `pip install --user --no-index` |
| `No module named 'dataclasses'` | 3.7 标准库，py3.6 需 backport | 装 `dataclasses 0.8` |
| `No module named 'scipy'` | `encoder_reference.py:8` 模块级依赖 | 装 `scipy 1.5.4`（py3.6 最后一版） |
| `pip` 报 `Name or service not known` | 服务器 DNS 解析不了 PyPI，无外网 | 只能离线传 wheel，不能改索引源解决 |
