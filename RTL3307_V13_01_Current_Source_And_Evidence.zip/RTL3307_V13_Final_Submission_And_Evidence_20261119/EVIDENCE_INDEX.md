# 结果证据目录（截图证据≠原生EDA二进制）

所有截图均来自用户在对话中上传的服务器终端图片或者最新附件。原文件不作修改；在本包内仅按证据用途改为 ASCII 名称。不要从截图推断没有打印的指标。

| 文件 | 可证明的内容 |
|---|---|
| `accuracy_rerun_pass.png` | 服务器 `FROZEN_W12_RETEST status=PASS`、600样本、12层、NRMSE和报告路径 |
| `throughput_rtl_pass.jpg` | 服务器 RTL 回归 12任务、544214拍、304128输出 |
| `seven_corner_power_part1.png` | FF0、FF1、FF2 三角和 TT5 等七角 PTPX第一屏 |
| `seven_corner_power_part2.png` | 七角 PTPX其余角和完毕标记 |
| `ff2_leakage_breakdown.png` | FF2 `leakage_W` 很高的原生 JSON 输出 |
| `removal_endpoint_audit.png` | 各角五个 Removal 归属及 PMU 原复位链身份 |
| `lec_79683_zero_fail.png` | `Verification SUCCEEDED` 和 79683 比较点通过的原生输出 |
| `sta_v13_seven_corner.png` | V1.3七角 setup/transition 等时序回执 |
| `area_tt5_grouping.png` | 面积分组与保守上界来源 |
| `tt5_power_macro_models.png` | 三类 SRAM 具有非零 PTPX 宏功耗 |
| `accuracy_and_throughput_upload.zip` | 用户最新完整精度排障链（含截图与原始两份md），未篡改 |

`ORIGINAL_ARCHIVES` 中旧目录还包含63张较早阶段截图。不要拿旧候选的结果替换V1.3。

### PTPX九项/角

最新七角每角均有`issues=9`，大致包括原生check_power待审、部分直接活动缺失和三类宏边界活动/模型确认。现有原生结果已证明 SRAM 功耗为正；但其他警告未消除，不能把`issues=9`写成0。FF2功耗中泄漏高，保留为额外审阅项。

### 数值格式说明冲突

`accuracy_and_throughput_upload.zip`中的附文一处断言 V1.3 为 PC16、W12没有综合，与 `CURRENT_SOURCE_AND_TOOLS/RTL3307_Timing_TargetFix_V1/payload/frozen/rtl/accel/kwt_dot64.v` 的 `signed [11:0] w_lane` 和 `frozen/data/tasks/validation/manifest.json` 中 `X16_W12_PACKED` 不符。这里以当前提交源文件标识为准，并按软件评测/RTL功能/门级LEC三种范围分别报告。
