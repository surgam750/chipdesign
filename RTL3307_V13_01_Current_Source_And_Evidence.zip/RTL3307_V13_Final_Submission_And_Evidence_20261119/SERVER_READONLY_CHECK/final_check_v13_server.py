#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only V1.3 power and numeric report identities. No EDA, no mutations.
Usage: python3 -B ~/Desktop/final_check_v13_server.py
"""
from __future__ import print_function
from pathlib import Path
import json, hashlib, sys
ROOT=Path.home()/'Desktop'/'kwt_runs'
EXPECTED='13b0f9a378d46c3c91958ec9c68bc1a97a9e874211866aa63cb7c73477719b19'
CORNERS=['FF0','FF1','FF2','SS3','SS4','TT5','TT6']

def one(pattern):
    found=sorted(ROOT.glob(pattern))
    if len(found)!=1:
        raise RuntimeError('Expected exactly one run for %s, found %d' % (pattern,len(found)))
    return found[0]

def read(p):
    if not p.is_file():raise RuntimeError('Missing '+str(p))
    return json.loads(p.read_text(encoding='utf-8'))

def main():
    print('V13_FINAL_READ_ONLY | existing server data, NO EDA')
    power=one('R2RTL3307_V13_POWER_20261119_010243_*')
    acc=one('V13_W12_ACCURACY_RERUN_20261119_015941_*')
    s=read(power/'summary.json')
    sha=s.get('netlist_sha256')
    print('NETLIST_SHA256=%s MATCH=%s' % (sha,str(sha==EXPECTED)))
    if sha!=EXPECTED:raise RuntimeError('Power result wrong netlist!')
    d=s.get('corners',{})
    if set(d.keys())!=set(CORNERS):raise RuntimeError('Seven-corner identity mismatch: '+','.join(sorted(d.keys())))
    ps=[];es=[]
    for c in CORNERS:
        row=d[c]
        p=float(row['duration_weighted_power_W']['total_W'])*1000
        e=float(row['mean_task_energy_uJ'])
        n=len(row.get('issues',[]))
        # Tool job/window count was 12 for each corner in native output.
        w=row.get('windows',[])
        print('%s power_mW=%.6f energy_uJ=%.6f issues=%d windows=%s'% (c,p,e,n, len(w) if isinstance(w,list) else 'UNKNOWN'))
        ps.append(p);es.append(e)
    print('AVERAGE_EQUAL_WEIGHT mW=%.6f uJ=%.6f' %(sum(ps)/7,sum(es)/7))
    n=read(acc/'numerics'/'testing_result.json')
    print('NUMERIC_STATUS=%s SAMPLES=%s LAYERS=%s MAX_NRMSE_PERCENT=%s'% (
          n.get('status'),n.get('samples','UNKNOWN'), (len(n['layers']) if isinstance(n.get('layers'),list) else n.get('layers','UNKNOWN')),
          n.get('max_nrmse_percent','UNKNOWN')))
    print('NUMERIC_REPORT_SHA256=%s'%hashlib.sha256((acc/'numerics'/'testing_result.json').read_bytes()).hexdigest())
    print('RUNS_MATCHED power=%s accuracy=%s'%(power.name,acc.name))
    print('DONE: printed original values and arithmetic mean; NOT acceptance')
    return 0
if __name__=='__main__':
    try: sys.exit(main())
    except Exception as e:
        print('READ_ONLY_FAILED:',str(e))
        sys.exit(1)
