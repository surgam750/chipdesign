"""SYNTHETIC controller/report tests. No licensed tool or native measurement."""
import argparse
from collections import Counter
import contextlib
import io
import json
from pathlib import Path
import runpy
import sys
import tempfile
import unittest

ap = argparse.ArgumentParser(add_help=False)
ap.add_argument('--parent-package', required=True)
args, rest = ap.parse_known_args()
sys.argv = [sys.argv[0]] + rest
BASE = Path(__file__).resolve().parents[1]
runner = runpy.run_path(str(BASE / 'run_resume.py'))
support = runpy.run_path(str(BASE / 'report_support.py'))
parent = Path(args.parent_package).resolve()
parse = runpy.run_path(str(parent / 'verification/support/sta_marked_rows.py'))['parse_text']
paths = runpy.run_path(str(parent / 'verification/support/native_path_views.py'))['native_paths']
CONSTRAINTS = '''SYNTHETIC NOT A NATIVE MEASUREMENT
Report : constraint -all_violators
max_delay/setup ('hfclk' group)
u_kwt_accel/q/D 6.0 6.1 -0.1 (VIOLATED)
min_delay/hold ('hfclk' group)
u_e203_dtcm_ram/ram/D[0] 0.4 0.2 -0.2 (VIOLATED)
removal ('async_default' group)
u_sirv_pmu/reset/SDN 0.8 0.0 -0.8 (VIOLATED)
max_transition
u_kwt_accel/sel 0.3 0.6 -0.3 (VIOLATED)
'''
PATH = '''SYNTHETIC NOT A NATIVE MEASUREMENT
Startpoint: first/Q
Endpoint: gate/EN
Path Group: clock_gating_default
Path Type: max
clock gating setup time 0.0
data required time 0.0
data arrival time 0.0
slack (MET) 0.000000000
Startpoint: must_not_mix/Q
Endpoint: second/D
library setup time -0.1
slack (MET) 0.25
'''


def put(folder, name, text):
    path = folder / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')


def fixture(folder, constraints=CONSTRAINTS):
    put(folder, 'constraints.rpt', constraints)
    put(folder, 'timing.tsv', 'delay_type\tworst_slack_ns\nmax\t0.0\nmin\t-0.8\n')
    put(folder, 'setup.rpt', PATH)
    put(folder, 'coverage.rpt', 'Type of Check Total Met Violated Untested\nsetup 10 8 (80%) 1 (10%) 1 (10%)\nhold 10 8 (80%) 1 (10%) 1 (10%)\n')


class ResumeTests(unittest.TestCase):
    def test_native_failure_keeps_error_before_long_stack_tail(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            script = base / 'synthetic_failure.sh'
            error = 'NATIVE_ERROR: Unexpected waveform shape: hfclk raw={{0 1 2 3}}'
            lines = ["printf '%s\\n' 'RESUME_CLOCK_WAVEFORM_RAW phase=inherited name=hfclk raw={{0 1 2 3}}'",
                     "printf '%s\\n' '" + error + "'"]
            lines += ["printf '%%s\\n' 'SYNTHETIC_STACK_LINE_%d'" % i for i in range(25)]
            lines += ['exit 1']
            script.write_text('\n'.join(lines) + '\n')
            ctx = {'driver': {'tcl': lambda value: '{}'},
                   'config': {'tools': {'DC': '/bin/sh', 'LC': '/bin/sh'}}}
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                with self.assertRaisesRegex(ValueError, 'Native tool failed'):
                    runner['invoke'](ctx, 'DC', script, base / 'native', {}, 10, ())
            text = output.getvalue()
            self.assertIn(error, text)
            self.assertIn('RESUME_NATIVE_WAVEFORM_CONTEXT', text)
            self.assertIn('RESUME_NATIVE_LOG_TAIL', text)
            self.assertNotIn(error, text.split('RESUME_NATIVE_LOG_TAIL', 1)[1])

    def test_typed_reports_zero_query_and_partial_never_fabricate_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            fixture(folder)
            row = support['corner_report'](folder, parse, paths)
            self.assertEqual(row['status'], 'PARSED_MARKED_ROWS')
            self.assertEqual(row['typed']['hold']['worst_marked_native'], '-0.2')
            self.assertEqual(row['typed']['removal']['worst_marked_native'], '-0.8')
            self.assertEqual(row['query_slack_native']['max'], '0.0')
            self.assertEqual(row['first_max_sample']['checks'], ['clock_gating_setup'])
            self.assertEqual(row['first_max_sample']['end'], 'gate/EN')
            self.assertEqual(row['untested'], {'setup': 1, 'hold': 1})
            fixture(folder, 'Report : constraint -all_violators\nmax_skew\nu/a -0.1 (VIOLATED)\nmax_transition\n(VIOLATED)\n')
            row = support['corner_report'](folder, parse, paths)
            self.assertEqual(row['status'], 'PARTIAL_PARSE')
            self.assertEqual(row['unparsed_count'], 1)
            self.assertEqual(row['unknown_section_count'], 1)
            self.assertIsNone(row['typed']['setup']['count'])
            self.assertEqual(row['typed']['setup']['worst_marked_native'], 'UNKNOWN')

    def test_isolated_success_native_failure_and_parent_change_states(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            original = base / 'parent'
            put(original, 'dc_soc/design.v', 'module old; endmodule\n')
            lock = original / 'dc_soc/design.v'
            original_bytes = lock.read_bytes()
            ctx = {'run': original, 'result': original, 'package': original,
                   'config': {}, 'dc_values': {}, 'pt_values': {c: {} for c in runner['CORNERS']},
                   'parse': parse, 'native_paths': paths,
                   'driver': {'PT_FILES': ('constraints.rpt', 'timing.tsv', 'setup.rpt', 'coverage.rpt'),
                              'MACROS': {'SYNTHETIC': 1},
                              'area': lambda p: {'total_um2': 1, 'macros': {'SYNTHETIC': 1}}},
                   'parent': {'corners': {c: {'counts': Counter()} for c in runner['CORNERS']}}}
            for mode in ('success', 'native_failure', 'parent_change'):
                lock.write_bytes(original_bytes)
                ctx['locked'] = runner['snapshot']({str(lock): runner['sha'](lock)})
                output = base / mode
                output.mkdir()
                calls = []
                def stub(context, name, script, folder, values, timeout, required, marker=None):
                    calls.append(name)
                    folder.mkdir(parents=True)
                    if name == 'DC' and mode == 'native_failure':
                        raise ValueError('SYNTHETIC DC failure')
                    for filename in required:
                        put(folder, filename, 'SYNTHETIC output\n')
                    if name == 'DC':
                        put(folder, 'design.v', 'module changed; endmodule\n')
                        if mode == 'parent_change':
                            lock.write_text('changed parent\n')
                    else:
                        fixture(folder)
                    return {'folder': str(folder), 'files': {str(p): runner['sha'](p) for p in folder.iterdir()}}
                with contextlib.redirect_stdout(io.StringIO()):
                    state = runner['execute'](ctx, output, 4, 10, support, stub)
                self.assertFalse(state['acceptance'])
                self.assertFalse(state['signoff_achieved'])
                self.assertEqual(calls.count('DC'), 1)
                if mode == 'success':
                    self.assertEqual(state['status'], 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED')
                    self.assertEqual(calls.count('PT'), 7)
                    self.assertEqual(lock.read_bytes(), original_bytes)
                    self.assertTrue(state['netlist_body_changed'])
                    self.assertEqual(len(state['svf_chain']), 2)
                else:
                    self.assertEqual(state['status'], 'RESUME_FAILED_NO_ACCEPTANCE')
                    self.assertEqual(calls.count('PT'), 0)
                    if mode == 'parent_change':
                        self.assertFalse(state['original_consumed_inputs_unchanged'])
                self.assertEqual(json.loads((output / 'state.json').read_text())['status'], state['status'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
