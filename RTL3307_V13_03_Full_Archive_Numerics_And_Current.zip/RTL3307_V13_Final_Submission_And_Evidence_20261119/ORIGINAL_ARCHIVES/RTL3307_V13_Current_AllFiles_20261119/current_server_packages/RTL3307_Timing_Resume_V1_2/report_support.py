"""Read existing reports; typed marked rows are not unique physical paths."""
from __future__ import print_function
import csv
import math
import re
from collections import Counter
from pathlib import Path

CORNERS = ('FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT5', 'TT6')
KINDS = ('setup', 'hold', 'removal', 'transition')


def dc_markers(path, parse):
    text = Path(path).read_text(encoding='utf-8')
    parsed = parse(text, str(path))
    valid = (parsed.get('marker_accounting_ok') and parsed.get('all_violators_option_visible') and
             parsed.get('status') in ('PARSED_ROWS', 'NO_MARKED_ROWS') and
             not parsed.get('unparsed_count') and not parsed.get('unknown_section_count') and
             not parsed.get('warnings'))
    return {'raw_violated_lines': sum('VIOLATED' in s for s in text.splitlines()),
            'typed_marked_counts': dict(Counter(r['kind'] for r in parsed.get('records', []))) if valid else 'UNKNOWN',
            'parser_status': parsed.get('status'), 'unparsed': parsed.get('unparsed_count'),
            'unknown_sections': parsed.get('unknown_section_count'),
            'scope': 'EXISTING_MARKED_ROW_PARSER_ONLY_NO_DC_TIMING_CLOSURE'}


def corner_report(folder, parse, native_paths):
    folder = Path(folder)
    parsed = parse((folder / 'constraints.rpt').read_text(encoding='utf-8'), str(folder))
    valid = (parsed.get('status') in ('PARSED_ROWS', 'NO_MARKED_ROWS') and
             parsed.get('marker_accounting_ok') and parsed.get('all_violators_option_visible') and
             not parsed.get('unparsed_count') and not parsed.get('unknown_section_count') and
             not parsed.get('warnings'))
    records = parsed.get('records', [])
    result = {'status': 'PARSED_MARKED_ROWS' if valid else 'PARTIAL_PARSE',
              'raw_marker_count': parsed.get('raw_marker_count'),
              'unparsed_count': parsed.get('unparsed_count'),
              'unknown_section_count': parsed.get('unknown_section_count'),
              'warnings': parsed.get('warnings'), 'typed': {}}
    for kind in KINDS:
        selected = [r for r in records if r.get('kind') == kind]
        worst = min(selected, key=lambda r: r['slack']) if selected else None
        result['typed'][kind] = {'count': len(selected) if valid else None,
                                'worst_marked_native': worst['slack_text'] if valid and worst else
                                ('NO_MARKED_ROW' if valid else 'UNKNOWN'),
                                'object': worst.get('object') if valid and worst else None}
    result['other_kinds'] = dict(Counter(r['kind'] for r in records if r['kind'] not in KINDS)) if valid else None
    with (folder / 'timing.tsv').open() as stream:
        rows = list(csv.DictReader(stream, delimiter='\t'))
    if len(rows) != 2 or {r.get('delay_type') for r in rows} != {'max', 'min'}:
        raise ValueError('Invalid timing.tsv: ' + str(folder))
    result['query_slack_native'] = {r['delay_type']: r['worst_slack_ns'] for r in rows}
    if not all(math.isfinite(float(v)) for v in result['query_slack_native'].values()):
        raise ValueError('Nonfinite native query slack')
    paths = native_paths((folder / 'setup.rpt').read_text(encoding='utf-8').splitlines())
    result['first_max_sample'] = ({k: paths[0].get(k) for k in
                                  ('status', 'start', 'end', 'group', 'checks', 'slack_text')}
                                 if paths else {'status': 'NO_STARTPOINT'})
    coverage = (folder / 'coverage.rpt').read_text(encoding='utf-8').splitlines()
    result['coverage_rows'] = [line.strip() for line in coverage if re.match(
        r'^\s*(?:setup|hold|recovery|removal|clock_gating_setup|clock_gating_hold)\s+\d+', line)]
    result['untested'] = {}
    for line in result['coverage_rows']:
        m = re.match(r'^(\w+)\s+\d+\s+\d+\s+\([^)]*\)\s+\d+\s+\([^)]*\)\s+(\d+)\s+\([^)]*\)', line)
        if m:
            result['untested'][m.group(1)] = int(m.group(2))
    result['coverage_review'] = 'REQUIRED_NO_AUTOMATIC_WAIVERS'
    return result


def netlist_body(path):
    text = Path(path).read_text(encoding='utf-8', errors='replace')
    return re.sub(r'\s+', '', re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', text))


def summary_lines(report, parent):
    lines = ['RESUME_REPORTS | NOT TIMING PASS | LEC/POWER PENDING',
             'OUTPUT=' + report['output'], 'STATUS=' + report['status']]
    for key in ('error', 'input_integrity_error'):
        if report.get(key):
            lines.append(key.upper() + '=' + str(report[key]))
    for corner, error in sorted(report.get('errors', {}).items()):
        lines.append('ERROR[' + corner + ']=' + str(error))
    for corner in CORNERS:
        row = report['corners'].get(corner)
        if not row:
            lines.append(corner + ' MISSING_OR_FAILED; no zero substituted')
            continue
        values = row['query_slack_native']
        cells = ['%s=%s/%s' % (k, row['typed'][k]['count'] if row['typed'][k]['count'] is not None else 'UNKNOWN',
                               row['typed'][k]['worst_marked_native']) for k in KINDS]
        lines.append('%s max=%s min=%s %s' % (corner, values['max'], values['min'], row['status']))
        lines.append('  ' + ' '.join(cells) + ' untested(setup/hold)=%s/%s' %
                     (row['untested'].get('setup', 'UNKNOWN'), row['untested'].get('hold', 'UNKNOWN')) +
                     ' other=' + str(row['other_kinds']))
    for phase, row in sorted(report.get('dc_markers', {}).items()):
        lines.append('DC_%s raw_VIOLATED_lines=%s typed=%s parse=%s unparsed=%s unknown=%s' %
                     (phase, row['raw_violated_lines'], row['typed_marked_counts'], row['parser_status'],
                      row['unparsed'], row['unknown_sections']))
    for corner in ('SS3', 'SS4'):
        row = report['corners'].get(corner)
        if row:
            old = parent['corners'][corner]['counts']
            lines.append('%s old->new marked counts: %s' % (corner, ' '.join('%s:%s->%s' %
                (kind, old[kind], row['typed'][kind]['count']) for kind in KINDS)))
    for corner in ('SS4', 'TT5', 'TT6'):
        if corner in report['corners']:
            p = report['corners'][corner]['first_max_sample']
            lines.append('%s FIRST_MAX check=%s slack=%s end=%s' %
                         (corner, ','.join(p.get('checks') or []) or 'UNKNOWN', p.get('slack_text', 'UNKNOWN'),
                          p.get('end', 'UNKNOWN')))
    lines.append('NETLIST_BODY_CHANGED=%s; comment/whitespace comparison only, not equivalence' % report.get('netlist_body_changed'))
    if report.get('area'):
        lines.append('TT5_SOC_LIBRARY_AREA_UM2=%s MACROS=%s' %
                     (report['area']['total_um2'], report['area']['macros']))
    lines.append('Counts are marked rows, not path deltas; query min may be removal; no marked rows is not coverage PASS.')
    return lines
