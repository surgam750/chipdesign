#!/usr/bin/env python3
"""Resume one sealed TARGETFIX DDC; Python 3.6+, no RTL rebuild or LC run."""
from __future__ import print_function
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import signal
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PARENT_MANIFEST_SHA = '97429656aed87f3768e1dc475b8f5a46494f696655b636e11e04316a96dd49e8'
PARENT_READER_SHA = '51611dd4e0850737fcf0bfe320f266f2562f0ae7d0bf2c7aac376871eb3156d8'
PARENT_RUN = '~/Desktop/kwt_runs/R2RTL3307_TCM128_TARGETFIX_V1_20261118_193123_mueo2wme'
CORNERS = ('FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT5', 'TT6')
DC_FILES = ('pre_library_binding.rpt', 'pre_emitted.sdc', 'pre_operating_conditions.rpt',
            'pre_clocks.rpt', 'pre_constraints.rpt', 'pre_setup.rpt', 'pre_hold.rpt',
            'library_binding.rpt', 'check_design.rpt', 'check_timing.rpt', 'operating_conditions.rpt',
            'clocks.rpt', 'constraints.rpt', 'setup.rpt', 'hold.rpt', 'area.rpt', 'reference.rpt',
            'cells.tsv', 'design.v', 'design.ddc', 'emitted.sdc', 'incremental.svf')
ERROR = re.compile(r'(^\s*(Error:|Fatal:|NATIVE_ERROR:)|unresolved reference|unable to resolve|creating black box|license checkout failed)', re.M | re.I)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def bundle_check():
    manifest = load(HERE / 'resume_manifest.json')['files']
    needed = {'run_resume.py', 'report_support.py', 'native/dc_resume.tcl', 'native/common.tcl'}
    require(needed.issubset(manifest), 'Incomplete resume bundle manifest')
    for name, digest in manifest.items():
        p = HERE / name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and
                p.resolve() == p.absolute() and sha(p) == digest, 'Resume bundle changed: ' + name)
    return {str(HERE / name): digest for name, digest in manifest.items()}


def snapshot(expected):
    result = {}
    for name, digest in expected.items():
        p = Path(name).expanduser().absolute()
        require(p.is_file() and sha(p) == digest, 'Parent/input binding mismatch: ' + str(p))
        result[str(p)] = {'resolved': str(p.resolve()), 'sha256': digest}
    return result


def verify_snapshot(records):
    for name, record in records.items():
        p = Path(name)
        require(p.is_file() and str(p.resolve()) == record['resolved'] and sha(p) == record['sha256'],
                'Original input changed: ' + name)


def inside(child, parent):
    try:
        Path(child).resolve().relative_to(Path(parent).resolve())
        return True
    except ValueError:
        return False


def prepare(parent_run, parent_package, bundle):
    run = Path(parent_run).expanduser().resolve()
    package = Path(parent_package).expanduser().resolve()
    require(sha(package / 'payload/payload_manifest.json') == PARENT_MANIFEST_SHA,
            'Not the sealed TARGETFIX parent package')
    require(sha(package / 'show_result.py') == PARENT_READER_SHA, 'Parent reader changed')
    reader = runpy.run_path(str(package / 'show_result.py'))
    parent = reader['bound_summary'](run)
    result = run / 'payload/result'
    config = load(result / 'resolved_config.json')
    require(Path(config['out']).resolve() == result, 'Parent config output path mismatch')
    driver_path = package / 'payload/native/driver.py'
    manifest = load(package / 'payload/payload_manifest.json')['files']
    require(sha(driver_path) == manifest['native/driver.py'], 'Parent native driver changed')
    driver = runpy.run_path(str(driver_path))
    driver['verify_inputs'](config)
    receipt_files = {}
    for receipt in load(result / 'receipts.json'):
        for name, digest in receipt['files'].items():
            require(name not in receipt_files or receipt_files[name] == digest, 'Conflicting parent receipt')
            receipt_files[name] = digest
    expected = dict(bundle)
    expected.update(config['input_snapshot'])
    expected.update(config['library_hashes'])
    for relative in ('dc_soc/design.ddc', 'dc_soc/design.svf', 'dc_soc/design.v',
                     'dc_soc/emitted.sdc', 'dc_soc/config.tcl'):
        p = result / relative
        require(str(p) in receipt_files, 'Parent native file has no sealed receipt: ' + relative)
        expected[str(p)] = receipt_files[str(p)]
    for relative in ('state.json', 'metrics.json', 'receipts.json', 'prepared.json', 'resolved_config.json', 'sysbus.sdc'):
        expected[str(result / relative)] = sha(result / relative)
    for name, digest in manifest.items():
        expected[str(package / 'payload' / name)] = digest
    expected[str(package / 'payload/payload_manifest.json')] = PARENT_MANIFEST_SHA
    expected[str(package / 'show_result.py')] = PARENT_READER_SHA
    expected[str(package / 'verification/support/native_path_views.py')] = reader['PATH_HELPER_SHA']
    expected[str(package / 'verification/support/sta_marked_rows.py')] = reader['PARSER_SHA']
    for corner in CORNERS:
        for name in ('constraints.rpt', 'setup.rpt', 'coverage.rpt'):
            p = result / 'sta' / corner / name
            expected[str(p)] = parent['metrics']['timing'][corner]['reports'][name]
    for name in ('DC', 'PT', 'LC'):
        p = Path(config['tools'][name])
        expected.setdefault(str(p), sha(p))
    locked = snapshot(expected)
    dc_values = driver['dc_values'](config)
    dc_values.update(resume_ddc=str(result / 'dc_soc/design.ddc'), setup_margin=0.30, hold_margin=0.05)
    pt_values = {corner: driver['values'](config, corner) for corner in CORNERS}
    helper = runpy.run_path(str(package / 'verification/support/native_path_views.py'))
    parser = runpy.run_path(str(package / 'verification/support/sta_marked_rows.py'))
    return {'run': run, 'package': package, 'result': result, 'config': config, 'driver': driver,
            'parent': parent, 'locked': locked, 'dc_values': dc_values, 'pt_values': pt_values,
            'parse': parser['parse_text'], 'native_paths': helper['native_paths']}


def invoke(context, tool_name, script, folder, values, timeout, required, marker=None):
    folder.mkdir(parents=True, exist_ok=False)
    config_file = folder / 'config.tcl'
    config_file.write_text('set cfg %s\n' % context['driver']['tcl'](values), encoding='utf-8')
    config_sha = sha(config_file)
    config = context['config']
    command = [config['tools'][tool_name], '-f', str(script)]
    invocation = {'command': command, 'config_sha256': config_sha, 'timeout_seconds': timeout}
    save(folder / 'invocation.json', invocation)
    env = os.environ.copy()
    env['KWT_NATIVE_CONFIG'] = str(config_file)
    env['SYNOPSYS_LC_ROOT'] = str(Path(config['tools']['LC']).parent.parent)
    print('RESUME_NATIVE_RUNNING ' + str(folder), flush=True)
    with (folder / 'tool.log').open('w') as stream:
        process = subprocess.Popen(command, cwd=str(folder), env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=(os.name == 'posix'))
        try:
            process.wait(timeout=timeout)
        except BaseException:
            if os.name == 'posix':
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
            process.wait()
            raise
    log = (folder / 'tool.log').read_text(errors='replace')
    successful = (process.returncode == 0 and not ERROR.search(log) and
                  log.splitlines().count('NATIVE_TOOL_DONE') == 1 and
                  (not marker or log.splitlines().count(marker) == 1))
    if not successful:
        errors = [line for line in log.splitlines() if ERROR.search(line)]
        if errors:
            print('RESUME_NATIVE_ERROR_LINES (at most 6 lines/4096 chars):\n' +
                  '\n'.join(errors[:6])[:4096], flush=True)
        wave_lines = [line for line in log.splitlines() if line.startswith('RESUME_CLOCK_WAVEFORM_')]
        if wave_lines:
            print('RESUME_NATIVE_WAVEFORM_CONTEXT:\n' + '\n'.join(wave_lines[-4:])[:4096], flush=True)
        print('RESUME_NATIVE_LOG_TAIL (at most 15 lines/8192 chars):\n' +
              '\n'.join(log[-8192:].splitlines()[-15:]), flush=True)
    require(successful, 'Native tool failed or missing success marker (exit=%s): %s' %
            (process.returncode, folder / 'tool.log'))
    require(sha(config_file) == config_sha and load(folder / 'invocation.json') == invocation,
            'Native configuration changed')
    receipt = {'folder': str(folder), 'files': {}}
    for name in tuple(required) + ('config.tcl', 'invocation.json', 'tool.log'):
        p = folder / name
        require(p.is_file() and p.stat().st_size > 0, 'Missing native output: ' + str(p))
        if p.suffix in ('.rpt', '.log'):
            require(not ERROR.search(p.read_text(errors='replace')), 'Error inside native report: ' + str(p))
        receipt['files'][str(p)] = sha(p)
    return receipt


def execute(context, output, jobs, timeout, support, tool_call=invoke):
    state = {'status': 'RESUME_RUNNING', 'parent_run': str(context['run']), 'output': str(output),
             'signoff_achieved': False, 'acceptance': False, 'started': time.time(),
             'setup_margin': 0.30, 'hold_margin': 0.05, 'eval_sdc': str(context['result'] / 'sysbus.sdc'),
             'corners': {}, 'errors': {}}
    receipts = []
    save(output / 'input_snapshot.json', context['locked'])
    save(output / 'state.json', state)
    try:
        verify_snapshot(context['locked'])
        receipt = tool_call(context, 'DC', HERE / 'native/dc_resume.tcl', output / 'dc_soc',
                            context['dc_values'], timeout, DC_FILES,
                            'RESUME_DDC_INCREMENTAL_COMPLETE_NOT_TIMING_PASS')
        receipts.append(receipt)
        save(output / 'receipts.json', receipts)
        verify_snapshot(context['locked'])
        for name, digest in receipt['files'].items():
            require(sha(name) == digest, 'New DC output changed before STA: ' + name)
        state['dc_markers'] = {phase: support['dc_markers'](output / 'dc_soc' / name, context['parse'])
                               for phase, name in (('before', 'pre_constraints.rpt'), ('after', 'constraints.rpt'))}
        state['emitted_sdc_evidence'] = {name: sha(output / 'dc_soc' / name)
                                       for name in ('pre_emitted.sdc', 'emitted.sdc')}
        state['emitted_sdc_equality_assessed'] = False
        state['svf_chain'] = [str(context['result'] / 'dc_soc/design.svf'), str(output / 'dc_soc/incremental.svf')]
        state['lec_status'] = 'PENDING_ORIGINAL_RTL_THROUGH_PARENT_AND_INCREMENTAL_SVF_CHAIN'
        state['netlist_body_changed'] = support['netlist_body'](output / 'dc_soc/design.v') != support['netlist_body'](context['result'] / 'dc_soc/design.v')
        state['status'] = 'RESUME_STA_RUNNING'
        save(output / 'state.json', state)
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            futures = {}
            for corner in CORNERS:
                values = dict(context['pt_values'][corner])
                values['netlist'] = str(output / 'dc_soc/design.v')
                futures[pool.submit(tool_call, context, 'PT', context['package'] / 'payload/native/sta.tcl',
                                    output / 'sta' / corner, values, timeout,
                                    context['driver']['PT_FILES'])] = corner
            for future in as_completed(futures):
                corner = futures[future]
                try:
                    receipts.append(future.result())
                    state['corners'][corner] = support['corner_report'](output / 'sta' / corner,
                                                                       context['parse'], context['native_paths'])
                except Exception as error:
                    state['errors'][corner] = str(error)
                save(output / 'receipts.json', receipts)
                save(output / 'state.json', state)
        verify_snapshot(context['locked'])
        for receipt in receipts:
            for name, digest in receipt['files'].items():
                require(sha(name) == digest, 'New native output changed: ' + name)
        if 'TT5' in state['corners']:
            state['area'] = context['driver']['area'](output / 'sta/TT5/cells.tsv')
            require(state['area']['macros'] == context['driver']['MACROS'], 'Macro inventory changed')
        complete = (set(state['corners']) == set(CORNERS) and not state['errors'] and
                    all(r['status'] == 'PARSED_MARKED_ROWS' for r in state['corners'].values()))
        state['status'] = 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED' if complete else 'RESUME_INCOMPLETE_REVIEW_REQUIRED'
        state['original_consumed_inputs_unchanged'] = True
    except BaseException as error:
        state['status'] = 'RESUME_FAILED_NO_ACCEPTANCE'
        state['error'] = str(error)
        try:
            verify_snapshot(context['locked'])
            state['original_consumed_inputs_unchanged'] = True
        except Exception as changed:
            state['original_consumed_inputs_unchanged'] = False
            state['input_integrity_error'] = str(changed)
    finally:
        state['finished'] = time.time()
        save(output / 'receipts.json', receipts)
        state['receipts_sha256'] = sha(output / 'receipts.json')
        save(output / 'state.json', state)
        lines = support['summary_lines'](state, context['parent'])
        (output / 'summary.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
        print('\n'.join(lines), flush=True)
    return state


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent-run', default=PARENT_RUN)
    parser.add_argument('--parent-package', default='~/RTL3307_Timing_TargetFix_V1')
    parser.add_argument('--jobs', type=int, default=4)
    parser.add_argument('--timeout', type=int, default=1200, help='Per native tool timeout; not a completion-time promise')
    parser.add_argument('--check-only', action='store_true', help='Verify parent and inputs; no EDA or writes')
    parser.add_argument('--self-check', action='store_true', help='Verify delivered source hashes only')
    args = parser.parse_args(argv)
    require(1 <= args.jobs <= 7 and args.timeout > 0, 'Invalid jobs or timeout')
    bundle = bundle_check()
    if args.self_check:
        print('RESUME_BUNDLE_HASHES_MATCH; no parent or EDA queried')
        return 0
    started = time.time()
    context = prepare(args.parent_run, args.parent_package, bundle)
    print('PARENT_INPUTS_VERIFIED seconds=%.1f run=%s' % (time.time() - started, context['run']), flush=True)
    if args.check_only:
        print('CHECK_ONLY_COMPLETE; no EDA or files written')
        return 0
    base = Path('~/Desktop/kwt_runs').expanduser().resolve()
    require(not inside(base, context['run']) and not inside(base, context['package']), 'Output base overlaps parent')
    base.mkdir(parents=True, exist_ok=True)
    prefix = 'R2RTL3307_RESUME_V1_2_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '_'
    output = Path(tempfile.mkdtemp(prefix=prefix, dir=str(base)))
    support = runpy.run_path(str(HERE / 'report_support.py'))
    state = execute(context, output, args.jobs, args.timeout, support)
    return 0 if state['status'] == 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED' else 2


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print('RESUME_STOPPED_NO_ACCEPTANCE: ' + str(error), file=sys.stderr)
        sys.exit(2)
