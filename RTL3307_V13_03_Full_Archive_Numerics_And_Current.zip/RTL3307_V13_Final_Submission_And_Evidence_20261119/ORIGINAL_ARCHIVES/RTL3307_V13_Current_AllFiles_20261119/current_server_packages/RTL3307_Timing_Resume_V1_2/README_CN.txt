RTL3307 Timing Resume V1.2 — 从 TARGETFIX 已保存 DDC 继续优化

这是一个新的时序候选运行工具，不是已经通过时序的网表。

本次修正（V1.2）
原生V1.1已确认属性返回 waveform={{0 3.33333}}。它是单层包装且数字只有
6位有效数字；与预期3.3333333335直接按1e-6ns比较会误停。
V1.2只对waveform下降沿追加显示精度等价检查：原严格数值比较先执行，
不通过时要求原值为6..17位有效数字的有限十进制/科学记数，按原值明示
精度格式化expected，并与未舍入的actual数值比较；不得先舍入actual。
覆盖hfclk的3.33333与lfclk的15258.8；不设置统一大容差，不重建时钟。
周期、上升沿、setup/hold uncertainty及max_transition仍用原严格数值检查。
缺值、异常结构、非数字、相邻错误值、较高精度下明确不一致的值仍会停止。
日志区分DISPLAY_MATCH与严格匹配；有限位表示不能证明底层边沿逐位相同，
因此父DDC/SDC的原始身份校验、时钟保持代码和原七角评测仍然必需。
优化设置、RTL、约束、库和宏不变。新结果前缀为R2RTL3307_RESUME_V1_2_。

运行
1. 将整个 RTL3307_Timing_Resume_V1_2 文件夹放到服务器用户目录 ~ 下。
2. 保留原 ~/RTL3307_Timing_TargetFix_V1 文件夹和已完成的 TARGETFIX run。
3. 执行：
   python3 -B ~/RTL3307_Timing_Resume_V1_2/run_resume.py --jobs 4

默认精确父运行：
~/Desktop/kwt_runs/R2RTL3307_TCM128_TARGETFIX_V1_20261118_193123_mueo2wme
如上述位置不同，仅显式指定 --parent-run 和 --parent-package；不要选择另一个候选代替。
--self-check 只检查本交付文件；--check-only 验证原运行输入，不启动 EDA。

本次实际执行
- 校验 TARGETFIX 的交付清单、原运行、DDC、原网表、SDC、库与报告绑定。
- 创建独立目录，读取原 dc_soc/design.ddc，进行一次
  compile_ultra -incremental -no_autoungroup。
- 只恢复五项可排序成本的相对次序：max_transition、max_fanout、
  max_capacitance、max_delay、min_delay。不是恢复所有隐含项的声明。
- 保留原综合 max_transition 0.25 ns、setup uncertainty 0.30 ns、
  hold uncertainty 0.05 ns；set_fix_hold 覆盖 hfclk、lfclk。
- 新网表重新运行全部七角 PT，仍使用原评测 SDC、150 MHz hfclk、原 I/O 预算和库。
- 输出原生 DC 前/后报告、独立 receipts、state.json 和紧凑 summary.txt。
- 不重新运行 LC、RTL analyze/elaborate 或初次映射，不更改 RTL、CEN 周期、
  存储容量、宏数量、任务维度、MAC 数值规则和平台数据通路。

耗时
省去重复 LC/RTL 展开不代表已测得某个分钟数。默认每个原生工具进程超时为
1200 秒，--timeout 可明确调整；这是超时预算，不是整体完成时间保证。
工具失败只使新运行失败，完整错误和原生日志保留在新目录。不要用旧报告填新报告。

结果判断
summary 中 setup/hold/removal/transition 是原生 VIOLATED 标记行数，不是独立路径数。
max/min 是原生路径查询模式；min 可能是 removal，max=0 可能对应锁存器路径。
解析不完整、缺文件、未覆盖检查保留为 UNKNOWN/待审查，不推断为零或通过。
新状态 COMPLETE 只表示七角报告完成；acceptance 和 signoff_achieved 不会自动置真。
若 setup、hold、removal、电气或覆盖率仍有问题，本候选仍未闭合。

等价与后续
增量 SVF 只覆盖父 mapped DDC 到新结果；保存父 design.svf 与新增 incremental.svf
的有序来源。RTL 到新增量网表的等价检查、功耗和最终冻结配置评测仍待完成。
不能直接用旧 fresh-run 的单 SVF Formality 入口宣称新增量网表已通过等价。
原 RTL 仿真结果仅说明原 RTL 行为；不替代新增量网表的等价验证。

参数减少的核对结论
本版 MAC 是硬编码 2 列×64 路乘法，非一个可直接调小的 MAC_NUM 参数。
可以另设计为 2×32 路分时完成完整 64 项点积，但需要调度、部分和、valid、
bias/shift、输出打包、背压、异常和流水清空的配套修改与验证。
不得用减小 dim_k/dim_n/dim_m 少算规定任务的方法替代硬件并行度减少。
减少 MAC 不会直接移除当前平台 ITCM 的 A setup 和 D hold；本工具不做此结构改造。

修改前规则核对见 COMPLIANCE_PRECHECK.txt。
本地验证见 verification/；它们是脚本/流程桩验证，不是服务器原生 EDA 结果。
