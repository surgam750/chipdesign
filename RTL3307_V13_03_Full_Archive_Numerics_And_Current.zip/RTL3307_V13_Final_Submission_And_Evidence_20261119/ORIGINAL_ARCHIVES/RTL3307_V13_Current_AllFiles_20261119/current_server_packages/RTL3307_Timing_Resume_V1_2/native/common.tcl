source $env(KWT_NATIVE_CONFIG)
proc required {key} {global cfg; return [dict get $cfg $key]}
proc need {objects label} {
    if {[sizeof_collection $objects] == 0} {error "Missing $label"}
    return $objects
}
proc libraries {} {return [required libraries]}
proc setup_library {mode} {
    set_app_var search_path [concat $::search_path [required includes]]
    if {$mode eq "DC"} {
        set_app_var target_library [list [required standard]]
        set_app_var link_library [concat [list *] [libraries]]
    } elseif {$mode eq "PT"} {
        set_app_var link_path [concat [list *] [libraries]]
    } else {error "Unknown native tool mode $mode"}
}
proc apply_conditions {} {
    set_operating_conditions -library [required op_library] [required op_condition]
}
proc macro_check {} {
    dict for {name count} [required expected_macros] {
        set actual [sizeof_collection [get_cells -hierarchical -quiet -filter "ref_name == $name"]]
        if {$actual != $count} {error "Macro $name actual=$actual expected=$count"}
        puts "NATIVE_MACRO $name $actual"
    }
}
proc cell_area {path} {
    set f [open $path w]
    puts $f "instance\treference\tarea_um2"
    foreach_in_collection cell [get_cells -hierarchical -filter {is_hierarchical == false}] {
        set ref [get_attribute $cell ref_name]
        if {$ref in {**logic_0** **logic_1**}} {continue}
        set lib [get_lib_cells -quiet -of_objects $cell]
        if {[sizeof_collection $lib] != 1} {error "Unresolved/ambiguous physical cell $ref"}
        set area [get_attribute $lib area]
        if {![string is double -strict $area] || $area < 0} {error "Invalid area $ref"}
        puts $f "[get_object_name $cell]\t$ref\t$area"
    }
    close $f
}
proc finish {body} {
    if {[catch {uplevel 1 $body} problem]} {
        puts stderr "NATIVE_ERROR: $problem"
        puts stderr $::errorInfo
        exit 1
    }
    puts NATIVE_TOOL_DONE
    exit 0
}
