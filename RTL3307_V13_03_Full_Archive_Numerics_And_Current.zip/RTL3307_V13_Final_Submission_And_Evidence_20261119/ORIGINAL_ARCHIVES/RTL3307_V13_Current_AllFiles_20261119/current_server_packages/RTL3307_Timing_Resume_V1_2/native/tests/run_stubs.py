#!/usr/bin/env python3
"""Clock representation and control-flow regressions; no native EDA or timing claim."""
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
STUB = r"""
set search_path {}
set priority {max_delay min_delay max_transition max_fanout max_capacitance}
set compile_count 0
proc sizeof_collection {x} {return [llength $x]}
proc get_object_name {x} {return $x}
proc current_design {args} {return e203_soc_top}
proc all_clocks {} {return {hfclk lfclk}}
proc get_clocks {args} {return [lindex $args end]}
proc get_cells {args} {
    set f [lindex $args end]
    if {[regexp {ref_name == (\w+)} $f unused name]} {
        set n [dict get [dict create RAMSP128X16 1088 RAMSP4096X16 64 RAMSP8KX32 8] $name]
        return [lrepeat $n $name]
    }
    if {[string match {*false*} $f]} {return {std ram128 ram4096 ram8k}}
    return hier
}
proc db_for {cell} {
    global cfg
    set max [dict get $cfg maximum]
    switch $cell {
        std {return [dict get $max standard]}
        ram128 {return [dict get $max macros RAMSP128X16]}
        ram4096 {return [dict get $max macros RAMSP4096X16]}
        ram8k {return [dict get $max macros RAMSP8KX32]}
        default {error "Unknown cell $cell"}
    }
}
proc get_lib_cells {args} {
    if {[lsearch -exact $args -of_objects] >= 0} {return "lc:[db_for [lindex $args end]]"}
    return "lc:[string range [lindex $args end] 0 end-4]"
}
proc get_libs {args} {return "lib:[lindex $args end]"}
proc compare_collections {a b} {return [expr {$a ne $b}]}
proc foreach_in_collection {name collection body} {
    upvar 1 $name item
    foreach item $collection {uplevel 1 $body}
}
proc get_attribute {object name} {
    global priority env
    if {$name eq "ref_name"} {return [dict get {std BUF ram128 RAMSP128X16 ram4096 RAMSP4096X16 ram8k RAMSP8KX32} $object]}
    switch $name {
        area {return 1.0}
        max_transition {return 0.25}
        cost_priority {return $priority}
        period {
            if {$object eq "hfclk"} {
                if {$env(RESUME_STUB_CASE) eq "clock_mismatch"} {return 7.0}
                return 6.666666508
            }
            return 30517.578125
        }
        waveform {
            if {$object eq "hfclk"} {set wave {0 3.333333254}} else {set wave {0 15258.7890625}}
            switch $env(RESUME_STUB_CASE) {
                success_wrapped {return [list $wave]}
                success_rounded_flat {return [list 0 [format %.6g [lindex $wave 1]]]}
                success_rounded_wrapped {return [list [list 0 [format %.6g [lindex $wave 1]]]]}
                success_scientific_wrapped {
                    if {$object eq "hfclk"} {return {{0 3.33333e0}}} else {return {{0 1.52588e4}}}
                }
                success_nine_digits_wrapped {return [list [list 0 [format %.9g [lindex $wave 1]]]]}
                wave_hf_near_wrong {if {$object eq "hfclk"} {return {{0 3.33334}}}}
                wave_lf_near_wrong {if {$object eq "lfclk"} {return {{0 15258.9}}}}
                wave_hf_low_precision {if {$object eq "hfclk"} {return {{0 3.33}}}}
                wave_lf_low_precision {if {$object eq "lfclk"} {return {{0 15259}}}}
                wave_hf_more_digits_wrong {if {$object eq "hfclk"} {return {{0 3.333331}}}}
                wave_lf_padded_wrong {if {$object eq "lfclk"} {return {{0 15258.800000}}}}
                wave_hf_padded_wrong {if {$object eq "hfclk"} {return {{0 3.333330}}}}
                wave_empty {return {}}
                wave_deep {return [list [list $wave]]}
                wave_four {return {0 1 2 3}}
                wave_multiple {return [list $wave $wave]}
                wave_bad_fall {return [list [list 0 1.0]]}
                wave_bad_rise {return [list [list 0.25 [lindex $wave 1]]]}
                wave_nan {return {0 NaN}}
                wave_inf {return {0 Inf}}
                wave_text {return {0 not_a_number}}
            }
            return $wave
        }
        setup_uncertainty {
            if {$env(RESUME_STUB_CASE) eq "setup_mismatch"} {return 0.30001}
            return 0.300000012
        }
        hold_uncertainty {
            if {$env(RESUME_STUB_CASE) eq "hold_mismatch"} {return 0.05001}
            return 0.050000001
        }
        default {error "Unexpected attribute $name"}
    }
}
proc set_app_var {args} {return 1}
proc set_svf {path} {
    puts "STUB_SVF $path"
    if {$path ne "-off"} {set f [open $path w]; puts $f "stub svf"; close $f}
    return 1
}
proc read_ddc {path} {puts "STUB_READ_DDC"; return 1}
proc link {} {return 1}
proc set_ungroup {args} {return 1}
proc set_fix_hold {args} {return 1}
proc set_cost_priority {value} {global priority; set priority $value; return 1}
proc compile_ultra {args} {
    global compile_count
    if {$args ne {-incremental -no_autoungroup}} {error "Unexpected compile options $args"}
    incr compile_count
    puts "STUB_COMPILE_CALL $compile_count"
    return 1
}
proc write {args} {set f [open [lindex $args end] w]; puts $f "stub design"; close $f; return 1}
proc write_sdc {path} {set f [open $path w]; puts $f "stub sdc"; close $f; return 1}
proc redirect {flag path body} {
    if {$flag ne "-file"} {error "Unexpected redirect"}
    set f [open $path w]; puts $f "stub report"; close $f
    return [uplevel 1 $body]
}
foreach cmd {check_design check_timing report_design report_clock report_constraint report_timing report_area report_reference} {
    proc $cmd {args} {return 1}
}
"""

def quote(value):
    return '{' + str(value).replace('\\','\\\\').replace('}','\\}').replace('{','\\{') + '}'

def main():
    receipts=[]
    cases = {
        'success': None,
        'success_wrapped': None,
        'success_rounded_flat': None,
        'success_rounded_wrapped': None,
        'success_scientific_wrapped': None,
        'success_nine_digits_wrapped': None,
        'wave_hf_near_wrong': 'hfclk fall edge unexpected',
        'wave_lf_near_wrong': 'lfclk fall edge unexpected',
        'wave_hf_low_precision': 'hfclk fall edge unexpected',
        'wave_lf_low_precision': 'lfclk fall edge unexpected',
        'wave_hf_more_digits_wrong': 'hfclk fall edge unexpected',
        'wave_lf_padded_wrong': 'lfclk fall edge unexpected',
        'wave_hf_padded_wrong': 'hfclk fall edge unexpected',
        'setup_mismatch': 'hfclk setup uncertainty unexpected',
        'hold_mismatch': 'hfclk hold uncertainty unexpected',
        'clock_mismatch': 'hfclk period unexpected',
        'wave_empty': 'Unexpected waveform shape',
        'wave_deep': 'Unexpected waveform shape',
        'wave_four': 'Unexpected waveform shape',
        'wave_multiple': 'hfclk rise edge unexpected',
        'wave_bad_fall': 'hfclk fall edge unexpected',
        'wave_bad_rise': 'hfclk rise edge unexpected',
        'wave_nan': 'hfclk fall edge unexpected',
        'wave_inf': 'hfclk fall edge unexpected',
        'wave_text': 'hfclk fall edge unexpected',
    }
    for case, error_text in cases.items():
        with tempfile.TemporaryDirectory(prefix='resume_tcl_') as tmp:
            folder=Path(tmp)
            libs=[]
            for name in ('std.db','128.db','4096.db','8k.db','parent.ddc'):
                path=folder/name; path.write_text('stub input\n'); libs.append(str(path))
            libwords=' '.join(quote(x) for x in libs[:4])
            maxexpr='[dict create standard %s macros [dict create RAMSP128X16 %s RAMSP4096X16 %s RAMSP8KX32 %s]]' % tuple(quote(x) for x in libs[:4])
            conf='set mx %s\nset cfg [dict create libraries [list %s] standard %s includes {} expected_macros {RAMSP128X16 1088 RAMSP4096X16 64 RAMSP8KX32 8} maximum $mx minimum $mx max_corner SS3 min_corner SS3 max_op {library STD condition SS3} min_op {library STD condition SS3} op_library STD op_condition SS3 resume_ddc %s setup_margin 0.3 hold_margin 0.05]\n' % (maxexpr,libwords,quote(libs[0]),quote(libs[4]))
            config=folder/'config.tcl'; config.write_text(conf)
            script=folder/'stub.tcl'
            script.write_text(STUB+'\nset env(KWT_NATIVE_CONFIG) '+quote(config)+'\nset env(RESUME_STUB_CASE) '+quote(case)+'\nsource '+quote(ROOT/'dc_resume.tcl')+'\n')
            proc=subprocess.run(['tclsh',str(script)],cwd=str(folder),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
            log=proc.stdout
            expected=error_text is None
            assert (proc.returncode==0)==expected, log
            assert log.count('STUB_COMPILE_CALL')==(1 if expected else 0),log
            assert log.count('RESUME_DDC_INCREMENTAL_COMPLETE_NOT_TIMING_PASS')==(1 if expected else 0),log
            assert log.count('NATIVE_TOOL_DONE')==(1 if expected else 0),log
            assert log.index('STUB_SVF incremental.svf') < log.index('STUB_READ_DDC'),log
            if expected:
                assert 'phase=post_compile' in log,log
                assert ('shape=SINGLETON_WRAPPED' if case.endswith('wrapped') else 'shape=FLAT') in log,log
                if 'rounded' in case:
                    assert 'label={hfclk fall edge}' in log and 'label={lfclk fall edge}' in log,log
                    assert 'observed=3.33333 ' in log and 'observed=15258.8 ' in log,log
                assert all((folder/name).is_file() for name in ('incremental.svf','design.v','design.ddc','emitted.sdc','pre_emitted.sdc','pre_constraints.rpt','constraints.rpt','pre_setup.rpt','pre_hold.rpt','setup.rpt','hold.rpt','library_binding.rpt','pre_library_binding.rpt','cells.tsv'))
            else:
                assert error_text in log,log
                assert not (folder/'design.ddc').exists(),log
            receipts.append({'case':case,'returncode':proc.returncode,'compile_calls':log.count('STUB_COMPILE_CALL'),'expected':True,'log':log})
    result={'status':'LOCAL_TCL_STUBS_PASS_NOT_NATIVE_EDA','dc_resume_sha256':hashlib.sha256((ROOT/'dc_resume.tcl').read_bytes()).hexdigest(),'common_sha256':hashlib.sha256((ROOT/'common.tcl').read_bytes()).hexdigest(),'cases':receipts}
    target=ROOT/'tests'/'receipt.json'; target.write_text(json.dumps(result,indent=2)+'\n')
    print(result['status']); print('cases='+str(len(receipts))); print(target)
if __name__=='__main__':
    main()
