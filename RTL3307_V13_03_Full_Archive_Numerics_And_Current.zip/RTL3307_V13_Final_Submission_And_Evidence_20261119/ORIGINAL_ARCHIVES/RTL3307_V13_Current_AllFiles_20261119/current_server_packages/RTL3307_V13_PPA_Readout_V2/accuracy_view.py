"""Read-only V1.3 ancestry/task binding and separately labelled historic accuracy.

Does not run EDA, a simulator, or the 600-sample evaluator. Python 3.6+.
"""
from __future__ import print_function
import json
import math
from pathlib import Path
import re

from show_power_models import bound, load, need, sha

HERE = Path(__file__).resolve().parent
HISTORY_SHA = 'dfe89ed8720961cd0520cd16d41b57d654eb18d76d8b349092263a9031d7cba9'
SOURCE = 'R2RTL3307_TCM128_TARGETFIX_V1_20261118_193123_mueo2wme'
TASK_SHA = '01d08a8d5204bf53ac65ff06d9e65f6812cebffa69bb5e38cd246f3b16b6a13d'


def history_data():
    value = load(bound(HERE / 'numeric_history.json', HISTORY_SHA))
    need(value['schema'] == 'RTL3307_HISTORICAL_NUMERIC_EVIDENCE_V1', 'Wrong numeric evidence schema')
    records = value['records']
    copies = {'numerics/testing_result.json': 'testing_result.json',
              'numerics/FORMAT_FREEZE.json': 'FORMAT_FREEZE.json',
              'reports/numerical_replay/numeric_verification.json': 'numeric_verification.json'}
    for original, name in copies.items():
        need(load(bound(HERE / 'accuracy_evidence' / name, records[original]['sha256'])) == records[original]['document'],
             'Historical numeric source copy differs: ' + original)
    testing = records['numerics/testing_result.json']['document']
    replay = records['reports/numerical_replay/numeric_verification.json']['document']
    freeze = records['numerics/FORMAT_FREEZE.json']
    need(freeze['document']['selected'] == 'X16_W12_PACKED' and
         testing['format_freeze_sha256'] == replay['format_freeze_sha256'] == freeze['sha256'] and
         replay['task_manifest_sha256'] == TASK_SHA, 'Historic format/task identities differ')
    need(testing['samples'] == 600 and len(testing['layers']) == 12 and testing['status'] == 'PASS',
         'Incomplete historic 600-sample record')
    need([x['layer'] for x in testing['layers']] == list(range(12)) and
         all(math.isfinite(x['nrmse_percent']) and x['nrmse_percent'] >= 0 and
             x['elements'] == 600 * 99 * 256 for x in testing['layers']), 'Invalid historic layer metrics')
    need(max(x['nrmse_percent'] for x in testing['layers']) == testing['max_nrmse_percent'],
         'Historic maximum differs from layer records')
    need(replay['status'] == 'NUMERIC_REPLAY_AND_CONVERSION_PASS' and
         replay['total_scalar_outputs'] == 304128 and len(replay['layers']) == 12 and
         all(x['mismatches'] == 0 and x['scalar_outputs_checked'] == 25344 and
             x['wpack_byte_identical'] is True and x['float_to_x16_identical'] is True
             for x in replay['layers']), 'Historic software replay incomplete')
    bounds = value['parameter_decode_bounds']
    need(len(bounds) == 12 and all(x['output_scale_count'] == 256 and
         math.isfinite(x['max_abs_decoded_int16']) and x['max_abs_decoded_int16'] > 0 and
         freeze['document']['params'][x['file']] == x['sha256'] for x in bounds),
         'Historic finite decode bounds/parameter identities differ')
    return value, testing, replay


def input_file(ctx, path, digest=None):
    path = Path(path)
    name = str(path)
    need(name in ctx['inputs'], 'Numeric input is absent from V1.3 power receipt: ' + name)
    actual = ctx['inputs'][name]
    need(digest is None or digest == actual, 'Numeric receipt hash mismatch: ' + name)
    need(ctx['config']['input_snapshot'].get(name) == actual,
         'Numeric input is not bound to the original synthesis source: ' + name)
    return bound(path, actual)


def scoped(root, relative):
    path = root / relative
    need(not Path(relative).is_absolute() and root.resolve() in path.resolve().parents,
         'Numeric source path escapes its frozen root')
    return path


def _functional_log(raw):
    need(not re.search(r'TEST_FAIL|Time Out !!!|\b(?:Fatal|FATAL|Error|ERROR)\b|\*\* Error', raw),
         'Functional simulator/CPU failure in saved log')
    need(len(re.findall(r'\bTEST_PASS\b', raw)) == 1, 'CPU completion missing/duplicated')
    records = re.findall(r'^KWT_TASK id=(\d+) layer=(\d+) cycles=(\d+) x_rsp=(\d+) w_rsp=(\d+) y_rsp=(\d+) checked=(\d+) mism=(\d+) PASS\s*$', raw, re.M)
    need(len(records) == 12 and len(re.findall(r'^KWT_TASK\b', raw, re.M)) == 12,
         'Need all twelve unique native task records')
    rows = [list(map(int, r)) for r in records]
    for i, row in enumerate(rows):
        need(row[:2] == [i, i] and row[2] > 0 and row[3:] == [3168, 6656, 12672, 12672, 0],
             'Functional task identity/count/mismatch differs')
    summaries = re.findall(r'^KWT_SOC_SUMMARY PASS tasks=(\d+) scalar_outputs=(\d+) cycles_sum=(\d+) placement=SYSTEMBUS32 mode=IRQ timing=LOAD_TO_LAST_WRITE_RSP loader_cmd=(\d+) loader_rsp=(\d+)\s*$', raw, re.M)
    # The frozen monitor prints an eighth field, max_queued. Its original native
    # validator consumes the first seven fields but does not anchor the line.
    # Preserve the complete actual format here; an omitted field is not accepted.
    fabrics = re.findall(r'^KWT_FABRIC_COUNTS accepted=(\d+) delivered=(\d+) responses=(\d+) pending=(\d+) contention_cycles=(\d+) outlet_stall_cycles=(\d+) master_stall_cycles=(\d+) max_queued=(\d+)\s*$', raw, re.M)
    summary_lines = len(re.findall(r'^KWT_SOC_SUMMARY\b', raw, re.M))
    fabric_lines = len(re.findall(r'^KWT_FABRIC_COUNTS\b', raw, re.M))
    need(len(summaries) == len(fabrics) == summary_lines == fabric_lines == 1,
         'Missing/duplicate native final accounting: summary parsed/raw=%d/%d; fabric parsed/raw=%d/%d' %
         (len(summaries), summary_lines, len(fabrics), fabric_lines))
    s, f = list(map(int, summaries[0])), list(map(int, fabrics[0]))
    need(s[:2] == [12, 304128] and s[2] == sum(r[2] for r in rows) and s[3] == s[4] > 0,
         'Functional summary differs from task records')
    need(f[0] == f[1] == f[2] > 0 and f[3] == 0 and f[4] > 0 and f[6] > 0,
         'Functional fabric incomplete/unexercised')
    return {'tasks': 12, 'scalar_outputs': 304128, 'cycles_sum': s[2],
            'loader_commands': s[3], 'loader_responses': s[4],
            'fabric': dict(zip(('accepted', 'delivered', 'responses', 'pending',
                               'contention_cycles', 'outlet_stall_cycles', 'master_stall_cycles'), f[:7]))}


def functional_log(raw):
    """Validate all native records, with useful saved-log context on failure."""
    try:
        return _functional_log(raw)
    except ValueError as error:
        selected = [(n, line) for n, line in enumerate(raw.splitlines(), 1)
                    if re.search(r'\b(?:KWT_SOC_SUMMARY|KWT_FABRIC_COUNTS|TEST_PASS|TEST_FAIL)\b', line)]
        excerpt = ['L%d %s' % (n, line[:600]) for n, line in selected[:6]]
        if len(selected) > 6:
            excerpt.append('Additional matching lines omitted=%d' % (len(selected) - 6))
        if not excerpt:
            excerpt = ['NO_NATIVE_FINAL_MARKER_FOUND']
        raise ValueError(str(error) + '\nSAVED_LOG_RAW_CONTEXT (no PASS inferred):\n' + '\n'.join(excerpt))


def accuracy_data(ctx):
    history, testing, replay = history_data()
    payload = ctx['config_path'].parent.parent
    need(payload.name == 'payload' and payload.parent.name == SOURCE,
         'Accuracy source is not the exact TargetFix ancestor')
    report, overlay = payload / 'reports', payload / 'work/soc'
    state = load(input_file(ctx, report / 'state.json'))
    need(state.get('status') == 'SERVER_SYSTEMBUS_FUNCTIONAL_RTL_PASS' and
         state.get('candidate_id') == 'RTL3307_TCM128_TARGETFIX_V1', 'Current ancestor RTL receipt is not PASS')
    manifest = load(input_file(ctx, payload / 'payload_manifest.json', state['payload_manifest_sha256']))
    need(manifest.get('candidate_id') == state['candidate_id'], 'Functional payload candidate differs')
    source = load(input_file(ctx, overlay / 'source_manifest.json', state['soc_manifest_sha256']))
    for relative, digest in source['after'].items():
        input_file(ctx, scoped(overlay, relative), digest)
    for name, key in [('sources.f', 'compiled_source_list_sha256'), ('tasks_12.txt', 'runtime_task_list_sha256')]:
        input_file(ctx, overlay / name, state[key])
    input_file(ctx, report / 'compile.log', state['compile_log_sha256'])
    input_file(ctx, payload / 'sw/out/t_linear_irq.verilog', state['firmware_sha256'])
    raw = input_file(ctx, report / 'simulation.log', state['log_sha256']).read_text(errors='replace')
    parsed = functional_log(raw)
    need(all(state.get(k) == v for k, v in parsed.items()), 'Functional state differs from native task log')
    tasks_root = payload / 'frozen/data/tasks/validation'
    tasks = load(input_file(ctx, tasks_root / 'manifest.json', state['task_manifest_sha256']))
    need(state['task_manifest_sha256'] == TASK_SHA == replay['task_manifest_sha256'] and
         tasks['format'] == 'X16_W12_PACKED' and tasks['split'] == 'validation' and
         tasks['format_freeze_sha256'] == replay['format_freeze_sha256'] and
         [t['layer'] for t in tasks['tasks']] == list(range(12)), 'Frozen numerical task identity changed')
    runtime, words = [], 0
    for task in tasks['tasks']:
        folder = scoped(tasks_root, task['directory'])
        meta = load(input_file(ctx, folder / 'meta.json', task['meta_sha256']))
        need(meta['layer'] == task['layer'] and [meta['M'], meta['K'], meta['N']] == [99, 64, 256] and
             meta['model_sha256'] == replay['model_sha256'] and
             meta['calibration_sha256'] == replay['format_freeze_sha256'], 'Task model/format/dimensions differ')
        need(set(meta['files']) == {'x.hex', 'wpack.hex', 'y_golden.hex'}, 'Unexpected task vector inventory')
        for name, expected in [('x.hex', 3168), ('wpack.hex', 6656), ('y_golden.hex', 12672)]:
            item = meta['files'][name]
            vector = input_file(ctx, folder / name, item['sha256'])
            tokens = vector.read_text(encoding='ascii').split()
            need(item['words'] == expected == len(tokens) and
                 all(re.fullmatch(r'[0-9a-fA-F]{8}', x) for x in tokens), 'Nonfinite/unknown/malformed task vector')
            if name == 'y_golden.hex':
                words += len(tokens)
        runtime.append('%d %s\n' % (task['layer'], folder.resolve().as_posix()))
    need((overlay / 'tasks_12.txt').read_text() == ''.join(runtime), 'Compiled runtime task list differs')
    harness_rel = 'tb/kwt/kwt_sysbus_harness.sv'
    harness = input_file(ctx, overlay / harness_rel, source['after'][harness_rel])
    need(source['after'][harness_rel] == manifest['files']['tb/kwt_sysbus_harness.sv'] and
         harness_rel in (overlay / 'sources.f').read_text().splitlines(), 'Output comparator is not compiled/bound')
    need('if (observed !== y_golden[index])' in harness.read_text() and words * 2 == 304128,
         'Known-bit comparison/output coverage cannot be established')
    return {'payload': payload, 'state': state, 'parsed': parsed, 'history': history,
            'testing': testing, 'replay': replay, 'known_scalar_outputs': words * 2,
            'historical_worst_layer': max(testing['layers'], key=lambda r: r['nrmse_percent'])['layer']}


def accuracy_page(ctx):
    data = accuracy_data(ctx)
    testing, replay = data['testing'], data['replay']
    return [
        '[4/4] NUMERICAL ACCURACY / FROZEN TASK BINDING | READ ONLY, NO RERUN',
        'V1.3 netlist=' + ctx['summary']['netlist_sha256'],
        'RTL functional source=' + data['payload'].parent.name,
        'Current ancestor: state/log/task vectors/compiled sources SHA256 MATCH power receipt.',
        'RTL tasks=12; checked INT16 outputs=304128; mismatches=0; known-bit comparisons=304128.',
        'RTL scope: behavioral memory functional run; not a new V1.3 gate or physical-macro simulation.',
        'FORMAT=X16_W12_PACKED; task split=validation; current task data match saved software replay.',
        'TASK_MANIFEST_SHA256=' + TASK_SHA,
        'FORMAT_FREEZE_SHA256=' + replay['format_freeze_sha256'],
        'FLOAT_MODEL_SHA256=' + replay['model_sha256'],
        'Stored software replay: 12 layers / 304128 outputs; mismatch=0; Wpack and X16 conversion MATCH.',
        'Software replay is separate from the bound RTL test above; no software model rerun here.',
        'HISTORICAL PUBLIC HELD-OUT evaluation: samples=600; layers=12; same format freeze.',
        'Maximum layer NRMSE=%.12f%%; zero-based layer=%d; undergraduate limit=3%%.' %
        (testing['max_nrmse_percent'], data['historical_worst_layer']),
        'Historical clipped=%d; saturated=%d; all stored layer metrics finite.' %
        (sum(sum(x['clipped'].values()) for x in testing['layers']), sum(x['saturated'] for x in testing['layers'])),
        'Known INT16 task outputs + hash-bound positive finite decode-scale bounds give finite decoded values.',
        'Historical report/source copies are bundled; full600 data availability on server is NOT checked.',
        'No new600-sample run, private committee evaluation, full-model Top-1, or awarded-score claim.',
        'LEC proves its scoped equivalence separately; it does not measure NRMSE or physical RAM behavior.',
        'SOURCE_FUNCTIONAL=' + str(data['payload'] / 'reports/state.json'),
        'SOURCE_HISTORICAL=accuracy_evidence/testing_result.json + numeric_verification.json',
    ]
