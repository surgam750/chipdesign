#!/usr/bin/env python3
"""Read-only V1.3 area appendix; no EDA, writes, or official area verdict.

Uses the same selected power-run identity as show_power_models.py. Library-area
groups and a deliberately conservative bound are calculated from the receipt-bound
TT5 cell inventory. Q&A Q4/Q10 and guide area rules reviewed before implementation.
Python 3.6+.
"""
from __future__ import print_function
import argparse
import csv
import math
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
from show_power_models import BASELINE, COUNTS, REFS, bound, close, context, load, need, select

BUDGET_UM2 = 2250000.0
OWNER_COUNTS = {'accelerator_local_sram': 64, 'cpu_itcm': 1024,
                'shared_512KiB_sram': 64, 'cpu_dtcm': 8}


def _input(ctx, path):
    path = Path(path)
    need(str(path) in ctx['inputs'], 'Area input absent from frozen power receipt: ' + str(path))
    return bound(path, ctx['inputs'][str(path)])


def _stage(ctx, baseline, receipts, stage, filename):
    folder = baseline / stage
    matches = [r for r in receipts if r.get('folder') == str(folder)]
    need(len(matches) == 1, 'Need one native area-related stage receipt: ' + str(folder))
    path = folder / filename
    digest = matches[0].get('files', {}).get(str(path))
    need(digest is not None and ctx['inputs'].get(str(path)) == digest,
         'Native stage and power-input area hashes disagree: ' + str(path))
    return bound(path, digest)


def _group(instance, reference):
    # Same complete, disjoint grouping order as the frozen native driver.
    if instance.startswith('u_kwt_accel/'):
        return 'accelerator_local_sram' if reference == 'RAMSP128X16' else 'accelerator_logic'
    if instance.startswith('u_kwt_shared_sram/'):
        return 'shared_512KiB_sram' if reference == 'RAMSP4096X16' else 'shared_controller_glue'
    if '/u_kwt_loader_dma/' in instance or instance.startswith('u_kwt_loader_dma/'):
        return 'loader_dma'
    if '/u_kwt_sysbus_arbiter/' in instance:
        return 'new_systembus_arbiter'
    if reference in ('RAMSP4KX64', 'RAMSP8KX32', 'RAMSP128X16'):
        return 'cpu_private_tcm'
    return 'platform_including_modified_ppi_irq'


def _macro_owner(instance, reference):
    if reference == 'RAMSP128X16':
        if instance.startswith('u_kwt_accel/'):
            return 'accelerator_local_sram'
        if '/u_e203_itcm_ram/' in instance:
            return 'cpu_itcm'
    if reference == 'RAMSP4096X16' and instance.startswith('u_kwt_shared_sram/'):
        return 'shared_512KiB_sram'
    if reference == 'RAMSP8KX32' and '/u_e203_dtcm_ram/' in instance:
        return 'cpu_dtcm'
    raise ValueError('Unexpected SRAM ownership: ' + reference + ' ' + instance)


def _mapped_bindings(path, config):
    maximum = config['corners']['SS3']
    names = {}
    with path.open(encoding='utf-8') as stream:
        reader = csv.DictReader(stream, delimiter='\t')
        need(reader.fieldnames == ['instance', 'reference', 'library_cell', 'library', 'expected_db'],
             'Unexpected native mapped-library inventory columns')
        for row in reader:
            name, ref = row.get('instance', ''), row.get('reference', '')
            need(name and ref and name not in names and None not in row,
                 'Missing/duplicate/unparsed native binding row')
            expected = maximum['macros'].get(ref, maximum['standard'])
            need(row.get('expected_db') == expected and row.get('library') and
                 row.get('library_cell', '').rsplit('/', 1)[-1] == ref,
                 'Unexpected mapped reference/library identity: ' + name)
            names[name] = ref
    need(names, 'Empty native mapped-library inventory')
    return names


def _macro_source_areas(ctx, per_reference):
    result = {}
    for ref in REFS:
        source = ctx['config']['macro_source_resolution']['TT5'][ref]
        path = Path(source['selected_original'])
        need(ctx['inputs'].get(str(path)) == source['sha256'],
             'SRAM area source hash differs from the frozen configuration: ' + ref)
        text = _input(ctx, path).read_text(encoding='utf-8', errors='replace')
        text = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', text)
        cells = re.findall(r'\bcell\s*\(\s*"?([\w.-]+)"?\s*\)', text)
        fields = re.findall(r'\barea\s*:\s*([-+0-9.eE]+)\s*;', text)
        value = float(fields[0]) if cells == [ref] and len(fields) == 1 else None
        if value is not None and (not math.isfinite(value) or value <= 0):
            value = None
        native = per_reference[ref]
        result[ref] = {'source': str(path), 'original_scalar': value,
                       'native_per_instance': native,
                       'match': None if value is None else close(value, native)}
    return result


def area_data(ctx):
    """Return receipt-checked library area and ownership; never writes files."""
    baseline = Path(ctx['summary']['baseline_run'])
    need(baseline.is_absolute() and baseline.match(BASELINE), 'Wrong area baseline')
    state = load(_input(ctx, baseline / 'state.json'))
    need(state.get('status') == 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED' and
         state.get('output') == str(baseline) and state.get('setup_margin') == .35 and
         state.get('hold_margin') == .05, 'Area baseline is not the frozen completed V1.3 run')
    receipt_path = baseline / 'receipts.json'
    need(ctx['inputs'].get(str(receipt_path)) == state.get('receipts_sha256'),
         'Area baseline receipt hash differs from its state')
    receipts = load(_input(ctx, receipt_path))
    netlist = _stage(ctx, baseline, receipts, 'dc_soc', 'design.v')
    need(str(netlist) == ctx['summary']['netlist'] and
         ctx['inputs'][str(netlist)] == ctx['summary']['netlist_sha256'],
         'Area and selected power result use different netlists')
    cell_path = _stage(ctx, baseline, receipts, 'sta/TT5', 'cells.tsv')
    mapped_path = _stage(ctx, baseline, receipts, 'dc_soc', 'library_binding.rpt')
    bindings = _mapped_bindings(mapped_path, ctx['config'])
    groups, names = {}, set()
    macro_counts = dict.fromkeys(REFS, 0)
    owners = {name: {'count': 0, 'area_values': []} for name in OWNER_COUNTS}
    per_reference = {}
    all_values, upper_values = [], []
    with cell_path.open(encoding='utf-8') as stream:
        reader = csv.DictReader(stream, delimiter='\t')
        need(reader.fieldnames == ['instance', 'reference', 'area_um2'],
             'Unexpected native TT5 cell-area columns')
        for row in reader:
            name, ref = row.get('instance', ''), row.get('reference', '')
            need(name and ref and name not in names and None not in row,
                 'Missing/duplicate/unparsed native cell-area row')
            need(bindings.get(name) == ref, 'PT area cell differs from the frozen DC mapping: ' + name)
            names.add(name)
            value = float(row['area_um2'])
            need(math.isfinite(value) and value >= 0, 'Unknown/nonfinite/negative cell area: ' + name)
            groups.setdefault(_group(name, ref), []).append(value)
            all_values.append(value)
            owner = None
            if ref in macro_counts:
                need(value > 0, 'SRAM macro has zero/nonpositive area: ' + name)
                owner = _macro_owner(name, ref)
                macro_counts[ref] += 1
                owners[owner]['count'] += 1
                owners[owner]['area_values'].append(value)
                if ref in per_reference:
                    need(close(per_reference[ref], value), 'One SRAM reference has inconsistent native area: ' + ref)
                else:
                    per_reference[ref] = value
            else:
                need(not re.match(r'(?:RAMSP|ROM|SRAM)\d', ref, re.I), 'Unexpected memory reference: ' + ref)
            # Keep every standard cell, even original CPU/peripheral logic. Only
            # verified platform memory macros are removed from this upper bound.
            if owner not in ('cpu_itcm', 'cpu_dtcm', 'shared_512KiB_sram'):
                upper_values.append(value)
    need(names and names == set(bindings), 'Native DC and TT5 leaf-cell inventories differ')
    need(macro_counts == COUNTS and {k: v['count'] for k, v in owners.items()} == OWNER_COUNTS,
         'SRAM macro inventory or ownership count mismatch')
    groups = {k: math.fsum(v) for k, v in groups.items()}
    total, upper = math.fsum(all_values), math.fsum(upper_values)
    saved = state.get('area', {})
    need(saved.get('macros') == COUNTS and set(saved.get('groups_um2', {})) == set(groups) and
         close(float(saved.get('total_um2', float('nan'))), total) and all(
             close(float(saved['groups_um2'][k]), v) for k, v in groups.items()),
         'Recomputed area differs from the frozen native summary')
    for value in owners.values():
        value['area_um2'] = math.fsum(value.pop('area_values'))
    excluded = math.fsum(owners[k]['area_um2'] for k in ('cpu_itcm', 'cpu_dtcm', 'shared_512KiB_sram'))
    need(close(total - excluded, upper), 'Area upper-bound partition failed')
    known = math.fsum(groups.get(k, 0.0) for k in
                     ('accelerator_logic', 'accelerator_local_sram', 'new_systembus_arbiter', 'shared_controller_glue'))
    need(all(k in groups for k in ('accelerator_logic', 'accelerator_local_sram',
                                  'new_systembus_arbiter', 'shared_controller_glue')),
         'Expected accelerator/interface area group is missing')
    return {'baseline': str(baseline), 'cells': str(cell_path), 'cell_count': len(names),
            'netlist_sha256': ctx['summary']['netlist_sha256'], 'groups_um2': groups,
            'owners': owners, 'macros': macro_counts, 'total_um2': total,
            'known_subtotal_um2': known, 'conservative_upper_um2': upper,
            'budget_um2': BUDGET_UM2, 'macro_source_area': _macro_source_areas(ctx, per_reference),
            'official_area_acceptance': False}


def area_page(ctx):
    row = area_data(ctx)
    lines = ['[3/4] V1.3 AREA / EXACT MACRO OWNERSHIP | READ ONLY, NO EDA',
             'RUN=' + Path(row['baseline']).name,
             'Native DC mapping + TT5 cells + state + power-input receipt hashes MATCH; leaves=%d' % row['cell_count'],
             'Area groups in um2 (library values):']
    for key, value in sorted(row['groups_um2'].items()):
        lines.append('  %s %.6f' % (key, value))
    lines.append('SOC_TOTAL=%.6f um2 = %.9f mm2; whole SoC is not the accelerator budget.' %
                 (row['total_um2'], row['total_um2'] / 1e6))
    lines.append('Accel+local SRAM+new arbiter+all shared glue=%.6f um2 = %.9f mm2; subtotal only.' %
                 (row['known_subtotal_um2'], row['known_subtotal_um2'] / 1e6))
    for key in ('accelerator_local_sram', 'cpu_itcm', 'shared_512KiB_sram', 'cpu_dtcm'):
        owner = row['owners'][key]
        lines.append('MACRO_OWNER %s n=%d area_um2=%.6f' % (key, owner['count'], owner['area_um2']))
    upper = row['conservative_upper_um2']
    lines.append('CONSERVATIVE_LIBRARY_UPPER=%.6f um2 = %.9f mm2; includes ALL SoC standard cells + accel-local SRAM.' %
                 (upper, upper / 1e6))
    lines.append('Budget=2.25 mm2; upper_below_budget=%s; native-library upper headroom=%.9f mm2.' %
                 (upper <= BUDGET_UM2, (BUDGET_UM2 - upper) / 1e6))
    lines.append('Upper excludes only verified shared512KiB and CPU ITCM/DTCM macros; mixed PPI/IRQ gates remain included.')
    checks = {k: ('MATCH' if v['match'] is True else 'MISMATCH' if v['match'] is False else 'UNKNOWN')
              for k, v in row['macro_source_area'].items()}
    lines.append('SRAM original Liberty area vs native instance area=' + str(checks))
    lines.append('Official macro-area data/scope still require review; this is not an exact official area or acceptance verdict.')
    return lines


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', help='Exact screenshot TT5 power result; defaults to its known timestamp')
    args = parser.parse_args(argv)
    print('\n'.join(area_page(context(select(args.run)))), flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, KeyError, OSError, TypeError) as error:
        print('AREA_READ_ONLY_FAILED: ' + str(error), file=sys.stderr, flush=True)
        sys.exit(1)
