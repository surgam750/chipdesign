#!/usr/bin/env python3
"""V2 read-only V1.3 accuracy and SRAM-model review; Python 3.6+."""
from __future__ import print_function
import argparse
import re
import sys

sys.dont_write_bytecode = True
import show_power_models as power


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', help='Exact existing V1.3 TT5 power run; default known timestamp')
    parser.add_argument('--section', choices=('all', 'accuracy', 'models'), default='all')
    parser.add_argument('--no-pause', action='store_true')
    args = parser.parse_args()
    print('READ_ONLY_V2: existing V1.3 records; no EDA, simulation or model conversion.', flush=True)
    ctx = power.context(power.select(args.run))
    pages, errors = [], []
    if args.section in ('all', 'accuracy'):
        try:
            from accuracy_view import accuracy_page
            pages.append(accuracy_page(ctx))
        except (ValueError, KeyError, OSError, TypeError, ImportError) as error:
            errors.append('ACCURACY')
            pages.append(['ACCURACY READ_ONLY_REVIEW', 'No result is inferred from missing records.', str(error)])
    if args.section in ('all', 'models'):
        try:
            from show_model_review import model_page
            pages.append(model_page(ctx))
        except (ValueError, KeyError, OSError, TypeError, ImportError) as error:
            errors.append('MODELS')
            pages.append(['MODEL READ_ONLY_REVIEW', 'No missing model is replaced by a zero or fabricated value.', str(error)])
    for index, lines in enumerate(pages, 1):
        lines = list(lines)
        title = re.sub(r'^\[\d+/\d+\]\s*', '', lines[0])
        lines[0] = '[%d/%d] %s' % (index, len(pages), title)
        print('\n'.join(lines), flush=True)
        if index < len(pages) and not args.no_pause:
            try:
                if input('[Enter] next page; any text then Enter stops: '):
                    print('READOUT_STOPPED; original reports unchanged.', flush=True)
                    return 0
            except EOFError:
                return 0
    if errors:
        print('READOUT_INCOMPLETE_SECTIONS=' + ','.join(errors), flush=True)
        return 2
    print('READOUT_COMPLETE; original reports unchanged; remaining power-model/activity issues require review.', flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, KeyError, OSError, TypeError) as error:
        print('READ_ONLY_STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
