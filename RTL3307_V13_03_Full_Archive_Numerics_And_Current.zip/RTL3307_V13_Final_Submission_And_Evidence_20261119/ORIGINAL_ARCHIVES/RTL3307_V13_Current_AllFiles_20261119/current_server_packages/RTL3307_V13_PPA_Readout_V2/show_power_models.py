#!/usr/bin/env python3
"""Read only the receipt-bound V1.3 TT5 power result and actual SRAM source models.

No EDA, library conversion, source/config edits, or power acceptance verdict.
Official Q&A Q4/Q10 and guide power measurement requirements reviewed first.
Python 3.6+. Two short screens; complete original reports remain on the server.
"""
from __future__ import print_function
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
PATTERN = 'R2RTL3307_V13_POWER_20261118_232754_*'
BASELINE = 'R2RTL3307_RESUME_V1_3_20261118_224036_*'
STATUS = 'V13_TASK_POWER_ESTIMATE_REVIEW_REQUIRED'
REFS = ('RAMSP128X16', 'RAMSP4096X16', 'RAMSP8KX32')
COUNTS = {'RAMSP128X16': 1088, 'RAMSP4096X16': 64, 'RAMSP8KX32': 8}
KEYS = ('internal_W', 'switching_W', 'leakage_W', 'total_W')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1048576), b''):
            result.update(data)
    return result.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def bound(path, digest):
    path = Path(path)
    need(path.is_absolute() and path.is_file() and sha(path) == digest,
         'Missing/changed consumed file: ' + str(path))
    return path


def close(a, b, relative=1e-8):
    return abs(a - b) <= max(1e-12, relative * max(abs(a), abs(b)))


def select(explicit=None):
    choices = [Path(explicit).expanduser()] if explicit else list(Path('~/Desktop/kwt_runs').expanduser().glob(PATTERN))
    need(len(choices) == 1, 'Need exactly one selected TT5 power result; found %d' % len(choices))
    path = choices[0].resolve()
    need(path.is_dir() and path.match(PATTERN), 'Wrong selected power run: ' + str(path))
    return path


def context(run):
    state = load(run / 'state.json')
    need(state.get('status') == STATUS and state.get('finished_jobs') == 12 and
         state.get('expected_jobs') == 12 and state.get('corners') == ['TT5'],
         'Selected power run is not the completed 12-window TT5 result')
    summary = load(bound(run / 'summary.json', state['summary_sha256']))
    receipt = load(bound(run / 'receipt.json', state['receipt_sha256']))
    need(summary.get('status') == STATUS and summary.get('jobs') == 12 and
         set(summary.get('corners', {})) == {'TT5'}, 'Power summary identity mismatch')
    net_sha = summary.get('netlist_sha256', '')
    need(re.fullmatch(r'[0-9a-f]{64}', net_sha) and net_sha == state.get('netlist_sha256'),
         'Power state/summary netlist hash mismatch')
    baseline = Path(summary['baseline_run'])
    need(baseline.match(BASELINE) and state['baseline_run'] == str(baseline), 'Wrong baseline timestamp')
    inputs = receipt['inputs']
    need(load(run / 'input_snapshot.json') == inputs, 'Power input snapshot differs from receipt')
    need(summary['netlist'] in inputs and inputs[summary['netlist']] == net_sha,
         'Netlist not bound in power receipt')
    need(Path(summary['netlist']) == baseline / 'dc_soc/design.v', 'Power netlist outside selected V1.3 baseline')
    bound(summary['netlist'], net_sha)
    baseline_state = load(baseline / 'state.json')
    need(baseline_state.get('status') == 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED' and
         baseline_state.get('setup_margin') == .35 and baseline_state.get('hold_margin') == .05,
         'Selected V1.3 baseline is incomplete or has unexpected margins')
    baseline_receipts = load(bound(baseline / 'receipts.json', baseline_state['receipts_sha256']))
    dc_receipts = [r for r in baseline_receipts if r.get('folder') == str(baseline / 'dc_soc')]
    need(len(dc_receipts) == 1 and dc_receipts[0]['files'].get(summary['netlist']) == net_sha,
         'Power netlist hash differs from original V1.3 native DC receipt')
    configs = [Path(p) for p in inputs if Path(p).name == 'resolved_config.json' and
               'R2RTL3307_TCM128_TARGETFIX_V1_20261118_193123_mueo2wme' in Path(p).parts]
    need(len(configs) == 1, 'Need one exact original resolved library configuration')
    cfg = load(bound(configs[0], inputs[str(configs[0])]))
    need(cfg.get('candidate_id') == 'RTL3307_TCM128_TARGETFIX_V1', 'Wrong original library config')
    stages = receipt['stages']
    need(set(stages) == {'TT5/task_%02d' % i for i in range(12)}, 'Power stage inventory mismatch')
    return {'run': run, 'summary': summary, 'receipt': receipt, 'inputs': inputs,
            'config': cfg, 'config_path': configs[0], 'row': summary['corners']['TT5']}


def stage_file(ctx, task, name):
    key = 'TT5/task_%02d' % task
    stages = ctx['receipt']['stages']
    need(name in stages[key], 'Native file is not receipt-bound: ' + key + '/' + name)
    path = ctx['run'] / key / name
    return bound(path, stages[key][name])


def macro_values(ctx):
    windows = ctx['row']['windows']
    need(len(windows) == 12 and [w['task'] for w in windows] == list(range(12)), 'Wrong task-window sequence')
    total_duration = sum(w['duration_ps'] for w in windows)
    need(total_duration > 0 and total_duration == ctx['row']['task_time_ps'], 'Task duration mismatch')
    weighted = {ref: dict.fromkeys(KEYS, 0.) for ref in REFS}
    positives = {ref: {'internal': 0, 'leakage': 0} for ref in REFS}
    for w in windows:
        task = w['task']
        rows = list(csv.DictReader(stage_file(ctx, task, 'macros.tsv').open(encoding='utf-8'), delimiter='\t'))
        counts = dict.fromkeys(REFS, 0)
        sums = {ref: dict.fromkeys(KEYS, 0.) for ref in REFS}
        names = set()
        for r in rows:
            ref = r['reference']
            need(ref in counts and r['instance'] not in names and r['lib_cell'].rsplit('/', 1)[-1] == ref,
                 'Native macro inventory/binding mismatch')
            names.add(r['instance'])
            counts[ref] += 1
            values = {k: float(r[k]) for k in KEYS}
            need(all(math.isfinite(v) for v in values.values()), 'Unknown/nonfinite macro native power')
            # Match the original native-attribute assessment (0.2% plus floor).
            # Retain the tighter tolerance only for re-summing the same saved rows.
            need(close(sum(values[k] for k in KEYS[:3]), values['total_W'], .002),
                 'Native macro power components differ')
            for k in KEYS:
                sums[ref][k] += values[k]
        need(counts == COUNTS, 'Macro native instance counts changed')
        for ref in REFS:
            saved = w['macro_classes_W'][ref]
            need(all(saved.get(k) is not None and close(float(saved[k]), sums[ref][k]) for k in KEYS),
                 'Native macro values disagree with saved summary: task %d %s' % (task, ref))
            positives[ref]['internal'] += int(sums[ref]['internal_W'] > 0)
            positives[ref]['leakage'] += int(sums[ref]['leakage_W'] > 0)
            for k in KEYS:
                weighted[ref][k] += sums[ref][k] * w['duration_ps'] / total_duration
    return weighted, positives


def library_info(ctx, ref):
    cfg, inputs = ctx['config'], ctx['inputs']
    source = cfg['macro_source_resolution']['TT5'][ref]
    lib = Path(source['selected_original'])
    db = Path(cfg['corners']['TT5']['macros'][ref])
    model = ctx['row']['models'][ref]
    need(str(lib) in inputs and str(db) in inputs and lib.suffix == '.lib' and db.suffix == '.db',
         'Selected Liberty/DB not captured by power receipt: ' + ref)
    need(inputs[str(lib)] == source['sha256'] == model['original_sha256'] and
         inputs[str(db)] == cfg['library_hashes'][str(db)] == model['db_sha256'],
         'Source/DB/model evidence hashes disagree: ' + ref)
    bound(lib, inputs[str(lib)])
    bound(db, inputs[str(db)])
    text = lib.read_text(encoding='utf-8', errors='replace')
    cleaned = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', text)
    terms = ('internal_power', 'rise_power', 'fall_power', 'cell_leakage_power', 'leakage_power',
             'default_cell_leakage_power', 'leakage_current', 'pg_current', 'dynamic_current',
             'memory_read', 'memory_write')
    counts = {term: len(re.findall(r'\b' + term + r'\b', cleaned)) for term in terms}
    cell_names = re.findall(r'\bcell\s*\(\s*"?([\w.-]+)"?\s*\)', cleaned)
    raw = []
    wanted = re.compile(r'\b(?:library|cell|nom_voltage|nom_temperature|voltage_unit|current_unit|leakage_power_unit|internal_power|rise_power|fall_power|cell_leakage_power|leakage_power|pg_current|dynamic_current)\b')
    for number, line in enumerate(text.splitlines(), 1):
        if wanted.search(line):
            raw.append('L%d %s' % (number, ' '.join(line.split())[:190]))
    return {'lib': str(lib), 'db': str(db), 'model': model, 'counts': counts,
            'cells': cell_names, 'raw': raw}


def pages(ctx):
    weighted, positives = macro_values(ctx)
    info = {ref: library_info(ctx, ref) for ref in REFS}
    first = ['[1/2] NATIVE SRAM POWER / EXACT INPUT PATHS | READ ONLY, NO EDA',
             'RUN=' + ctx['run'].name,
             'NETLIST_SHA256=' + ctx['summary']['netlist_sha256'],
             'STATE/SUMMARY/RECEIPT + consumed sources/native tables SHA256 MATCH',
             'Native macro family W are summed from macros.tsv and checked against every saved task.']
    first.append('TT5 design weighted_W=' + json.dumps(ctx['row']['duration_weighted_power_W'], sort_keys=True))
    first.append('SRAM duration-weighted mW: internal / switching / leakage / total; not coverage acceptance')
    for ref in REFS:
        first.append('%s x%d %.9g / %.9g / %.9g / %.9g; positive I/L windows=%d/%d of12' %
                     ((ref, COUNTS[ref]) + tuple(1000 * weighted[ref][k] for k in KEYS) +
                      (positives[ref]['internal'], positives[ref]['leakage'])))
    first.append('128X16: ITCM1024 + accel-local64; 4096X16: shared512KiB; 8KX32: DTCM.')
    for ref in REFS:
        row = info[ref]
        first.append(ref + ' LIB=' + row['lib'])
        first.append('  DB=' + row['db'])
        first.append('  saved_parser internal_groups=%s leakage_values=%s; cells=%s' %
                     (row['model']['internal_groups'], row['model']['leakage_values'], row['cells']))
        nonzero = {k: v for k, v in row['counts'].items() if v}
        first.append('  raw keyword counts=' + str(nonzero or {'all_selected_terms': 0}))
    first.append('Parser groups=0 alone is not native macro power=0; source/model completeness still requires review.')
    second = ['[2/2] RAW MODEL HEADER / POWER CHECK / ACTIVITY | existing exact run']
    for ref in REFS:
        raw = info[ref]['raw']
        second.append(ref + ' source raw matched lines=%d; first4:' % len(raw))
        second.extend(raw[:4] or ['NO_MATCHED_HEADER_OR_POWER_TERM'])
    units = stage_file(ctx, 0, 'units.rpt').read_text(errors='replace').splitlines()
    selected_units = [s.strip() for s in units if re.search(r'power|voltage|current|time_unit', s, re.I)]
    second.append('task00 UNITS: ' + ' | '.join(selected_units[:4]))
    checks = stage_file(ctx, 0, 'check_power.rpt').read_text(errors='replace').splitlines()
    important = [s.strip() for s in checks if re.search(r'warning|missing|unannotated|no.{0,24}(power|model|table)', s, re.I)]
    if not important:
        important = [s.strip() for s in checks if re.search(r'power|model|table', s, re.I)]
    second.append('task00 check_power raw matched=%d; first5:' % len(important))
    second.extend(important[:5] or ['NO_MATCHED_CHECK_POWER_LINE; original report retained'])
    sources = list(csv.DictReader(stage_file(ctx, 0, 'sources.tsv').open(encoding='utf-8'), delimiter='\t'))
    for category in ('hierarchical_net', 'register_output'):
        values = {r['source']: int(r['count']) for r in sources if r['category'] == category}
        second.append('task00 activity ' + category + '=' + str(values))
    second.append('issues=' + str(ctx['row']['issues']))
    second.append('SOURCE_CONFIG=' + str(ctx['config_path']))
    second.append('No edits, conversion, EDA or power PASS. Full native reports and all12 tasks unchanged.')
    return first, second


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', help='Exact screenshot power result; default known timestamp glob')
    parser.add_argument('--no-pause', action='store_true')
    args = parser.parse_args(argv)
    first, second = pages(context(select(args.run)))
    print('\n'.join(first), flush=True)
    if not args.no_pause:
        try:
            if input('[Enter] second page; any text then Enter exits: '):
                return 0
        except EOFError:
            return 0
    print('\n'.join(second), flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, KeyError, OSError, TypeError) as error:
        print('READ_ONLY_STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
