#!/usr/bin/env python3
"""Read-only source-model interpretation; preserves original reports and issue flags."""
from __future__ import print_function
import argparse
import importlib.util
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import liberty_reader

PREVIOUS_HASHES = {
    'show_power_models.py': '3cbe115bd5e5a565adb0277362b51efd8ab0db247992d1ef5c1c8328bbb3a2f5',
    'area_accuracy_view.py': '8d3f66c1036e2a1e8b7a167e37cc3e08ea00b31718f18b65e02b3dac0e077fa3',
}


def load_previous(package):
    import hashlib
    package = Path(package).expanduser().resolve()
    loaded = {}
    for name, expected in PREVIOUS_HASHES.items():
        path = package / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Previous receipt reader changed or missing: ' + str(path))
        modname = path.stem
        spec = importlib.util.spec_from_file_location(modname, str(path))
        module = importlib.util.module_from_spec(spec)
        sys.modules[modname] = module
        spec.loader.exec_module(module)
        loaded[modname] = module
    return loaded['show_power_models'], loaded['area_accuracy_view']


def read_models(ctx, power):
    result = {}
    for ref in power.REFS:
        info = power.library_info(ctx, ref)  # checks source/DB/model hashes first
        text = Path(info['lib']).read_text(encoding='utf-8', errors='replace')
        try:
            result[ref] = liberty_reader.analyze(text, ref)
        except (ValueError, KeyError, TypeError) as error:
            result[ref] = {'status': 'STRUCTURE_UNRESOLVED', 'error': str(error),
                           'raw_evidence': info['raw'][:3], 'keyword_counts': info['counts']}
    return result


def model_page(ctx, power=None, area=None):
    if power is None:
        power, area = load_previous(HERE)
    weighted, positives = power.macro_values(ctx)
    models = read_models(ctx, power)
    native_area = area.area_data(ctx) if area is not None else None
    lines = ['SOURCE MODEL / NATIVE POWER / AREA | READ ONLY, NO EDA',
             'RUN=' + ctx['run'].name,
             'Original .lib/.db and native task tables hash-checked; original issue flags remain unchanged.',
             'Native SRAM duration-weighted mW: internal / switching / leakage / total']
    for ref in power.REFS:
        lines.append('%s %.8g / %.8g / %.8g / %.8g; positive I,L=%d,%d of12' %
                     ((ref,) + tuple(weighted[ref][k] * 1000 for k in power.KEYS) +
                      (positives[ref]['internal'], positives[ref]['leakage'])))
    lines.append('Source syntax/table presence only; these are not tests of complete mode coverage:')
    for ref in power.REFS:
        row = models[ref]
        if row['status'] != 'STRUCTURE_PARSED_EXACT_CELL':
            lines.append(ref + ' STRUCTURE_UNRESOLVED: ' + row['error'][:180])
            lines.append('  raw: ' + ' | '.join(row['raw_evidence'])[:230])
            continue
        a = row['area']
        area_value = a.get('value_native')
        match = 'UNKNOWN'
        ref_area = 'UNKNOWN'
        if native_area and a['status'] == 'PARSED':
            ref_area = native_area['macro_source_area'][ref]['native_per_instance']
            # LC DB scalar storage can round the original decimal to float32.
            # This is a displayed numeric consistency check, not an area waiver.
            match = ('EXACT' if area_value == ref_area else
                     'ROUNDING_MATCH_1e-6_REL' if power.close(area_value, ref_area, 1e-6) else 'MISMATCH')
        lines.append('%s groups/tables=%d/%d nonzeroI=%s leakage=%d nonzeroL=%s unknown_tables/leaks=%d/%d' %
                     (ref, row['internal_groups'], row['internal_tables'], row['nonzero_internal_model'],
                      row['leakage_values'], row['nonzero_leakage_model'], row['unparsed_internal_tables'],
                      row['unparsed_leakage_values']))
        lines.append('  cell L%d area_raw=%s mapped=%s %s; legacy I/Lvalues=%s/%s' %
                     (row['cell_line'], a.get('raw', a['status']), ref_area, match,
                      row['legacy_probe'].get('internal_groups', 'UNKNOWN'), row['legacy_probe'].get('leakage_values', 'UNKNOWN')))
        modes = row['internal_modes'][:1] + row['leakage_modes'][:1]
        lines.append('  source mode examples: ' + ' | '.join(
            'L%d %s when=%s related_pin=%s' % (m['line'], m['header_raw'], m['when'], m['related_pin']) for m in modes)[:260])
        limitations = row['observed_legacy_limitations']
        if limitations:
            lines.append('  legacy limitation: ' + ';'.join(limitations)[:240])
    if native_area:
        lines.append('Library area known subtotal=%.9f / conservative upper=%.9f mm2; budget2.25; official area review remains.' %
                     (native_area['known_subtotal_um2'] / 1e6, native_area['conservative_upper_um2'] / 1e6))
    defaults = power.stage_file(ctx, 0, 'activity_defaults.rpt').read_text(errors='replace').splitlines()
    defaults = [s.strip() for s in defaults if re.search(r'power_default\w*', s) and s.strip()]
    lines.append('task00 power defaults (first2/%d): %s' % (len(defaults), ' | '.join(defaults[:2])[:250]))
    first = ctx['row']['windows'][0]
    for ref in power.REFS:
        families = first['macro_pin_sources'][ref]
        pieces = []
        for pin in ('CLK', 'CEN', 'GWEN', 'WEN'):
            values = families.get(pin)
            pieces.append(pin + '=' + ('UNKNOWN' if values is None else ','.join('%s:%s' % item for item in sorted(values.items()))))
        lines.append('task00 ' + ref + ' ' + ' '.join(pieces))
    lines.append('Activity provenance, clock domains and capacitance extrapolation still require review; no automatic power PASS.')
    return lines


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', help='Exact existing TT5 power result; default known timestamp')
    parser.add_argument('--previous-package', default='~/RTL3307_V13_PPA_Readout_V1')
    args = parser.parse_args(argv)
    power, area = load_previous(args.previous_package)
    ctx = power.context(power.select(args.run))
    print('\n'.join(model_page(ctx, power, area)), flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError, TypeError) as error:
        print('READ_ONLY_MODEL_STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
