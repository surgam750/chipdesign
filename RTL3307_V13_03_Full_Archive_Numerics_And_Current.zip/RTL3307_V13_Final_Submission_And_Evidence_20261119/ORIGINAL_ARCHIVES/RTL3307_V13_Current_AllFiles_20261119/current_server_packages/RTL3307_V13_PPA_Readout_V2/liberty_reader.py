"""Small read-only Liberty structural reader for source-model evidence (Python 3.6+).

Comments are recognized outside strings only. Quoted values, escaped newlines,
parenthesized and bare groups are retained with source lines. This is not a
Liberty semantic validator or a proof that all operating modes are characterized.
"""
import math
import re

NUMBER = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'


class LibertyError(ValueError):
    pass


def tokenize(text):
    tokens, i, line, size = [], 0, 1, len(text)
    while i < size:
        c = text[i]
        if c.isspace():
            line += int(c == '\n')
            i += 1
            continue
        if text.startswith('/*', i):
            end = text.find('*/', i + 2)
            if end < 0:
                raise LibertyError('Unclosed comment at line %d' % line)
            line += text.count('\n', i, end + 2)
            i = end + 2
            continue
        if text.startswith('//', i):
            end = text.find('\n', i + 2)
            i = size if end < 0 else end
            continue
        if c == '\\' and i + 1 < size and text[i + 1] in '\r\n':
            i += 1
            continue
        start, initial_line = i, line
        if c == '"':
            i += 1
            chars = []
            while i < size:
                c = text[i]
                if c == '"':
                    i += 1
                    break
                if c == '\\' and i + 1 < size:
                    following = text[i + 1]
                    if following == '\r' and i + 2 < size and text[i + 2] == '\n':
                        line += 1
                        i += 3
                        continue
                    if following == '\n':
                        line += 1
                        i += 2
                        continue
                    if following in ('"', '\\'):
                        chars.append(following)
                    else:
                        chars.extend(('\\', following))
                    i += 2
                    continue
                chars.append(c)
                line += int(c == '\n')
                i += 1
            else:
                raise LibertyError('Unclosed string at line %d' % initial_line)
            kind, value = 'string', ''.join(chars)
        elif c in '{}():;,':
            kind, value = 'punctuation', c
            i += 1
        else:
            while i < size and not text[i].isspace() and text[i] not in '{}():;,"':
                if text.startswith('/*', i) or text.startswith('//', i):
                    break
                i += 1
            if i == start:
                raise LibertyError('Unexpected token at line %d' % line)
            kind, value = 'word', text[start:i]
        tokens.append({'kind': kind, 'value': value, 'start': start, 'end': i, 'line': initial_line})
    return tokens


class Parser(object):
    def __init__(self, text):
        self.text, self.tokens, self.i = text, tokenize(text), 0

    def is_punct(self, value):
        return self.i < len(self.tokens) and self.tokens[self.i]['kind'] == 'punctuation' and self.tokens[self.i]['value'] == value

    def parenthesized(self):
        start = self.tokens[self.i]
        self.i += 1
        content, depth = [], 1
        while self.i < len(self.tokens):
            token = self.tokens[self.i]
            self.i += 1
            if token['kind'] == 'punctuation':
                if token['value'] == '(':
                    depth += 1
                elif token['value'] == ')':
                    depth -= 1
                    if depth == 0:
                        return content, token
            content.append(token)
        raise LibertyError('Unclosed arguments at line %d' % start['line'])

    def body(self, in_group=False):
        nodes = []
        while self.i < len(self.tokens):
            if self.is_punct('}'):
                if not in_group:
                    raise LibertyError('Unexpected closing brace at line %d' % self.tokens[self.i]['line'])
                closing = self.tokens[self.i]
                self.i += 1
                return nodes, closing
            if self.is_punct(';'):
                self.i += 1
                continue
            name = self.tokens[self.i]
            if name['kind'] not in ('word', 'string'):
                raise LibertyError('Expected group/attribute name at line %d' % name['line'])
            self.i += 1
            node = {'name': name['value'], 'line': name['line'], 'start': name['start']}
            args, last = [], name
            form = 'bare'
            if self.is_punct('('):
                args, last = self.parenthesized()
                form = 'parenthesized'
            if self.is_punct('{'):
                opening = self.tokens[self.i]
                self.i += 1
                children, closing = self.body(True)
                node.update(kind='group', args=args, children=children, header_form=form,
                            body_start=opening['end'], body_end=closing['start'], end=closing['end'],
                            header_raw=self.text[name['start']:opening['end']])
            elif form == 'parenthesized' and self.is_punct(';'):
                closing = self.tokens[self.i]
                self.i += 1
                node.update(kind='complex', args=args, end=closing['end'])
            elif form == 'bare' and self.is_punct(':'):
                self.i += 1
                values = []
                while self.i < len(self.tokens) and not self.is_punct(';'):
                    if self.is_punct('}') or self.is_punct('{'):
                        raise LibertyError('Unterminated attribute at line %d' % name['line'])
                    values.append(self.tokens[self.i])
                    self.i += 1
                if not self.is_punct(';'):
                    raise LibertyError('Unterminated attribute at line %d' % name['line'])
                closing = self.tokens[self.i]
                self.i += 1
                node.update(kind='attribute', values=values, end=closing['end'],
                            raw=self.text[values[0]['start']:values[-1]['end']] if values else '')
            else:
                raise LibertyError('Unsupported syntax after %s at line %d' % (name['value'], name['line']))
            nodes.append(node)
        if in_group:
            raise LibertyError('Unclosed group')
        return nodes, None


def parse(text):
    return Parser(text).body()[0]


def walk(nodes, parents=()):
    for node in nodes:
        yield node, parents
        if node['kind'] == 'group':
            for item in walk(node['children'], parents + (node,)):
                yield item


def arguments(group):
    return [t['value'] for t in group.get('args', []) if t['kind'] != 'punctuation' or t['value'] != ',']


def attributes(group, name):
    return [n for n in group['children'] if n['kind'] == 'attribute' and n['name'] == name]


def attribute_text(group, name):
    found = attributes(group, name)
    if len(found) != 1:
        return None
    return ' '.join(t['value'] for t in found[0]['values'])


def scalar(node):
    values = node.get('values', [])
    raw = node.get('raw', '')
    if len(values) != 1 or not re.fullmatch(NUMBER, values[0]['value'].strip()):
        return {'status': 'UNKNOWN_NONNUMERIC_OR_COMPOUND', 'raw': raw, 'line': node['line']}
    number = float(values[0]['value'])
    if not math.isfinite(number):
        return {'status': 'UNKNOWN_NONFINITE', 'raw': raw, 'line': node['line']}
    return {'status': 'PARSED', 'value_native': number, 'raw': raw, 'line': node['line']}


def numeric_attribute(group, name):
    found = attributes(group, name)
    if len(found) != 1:
        return {'status': 'ABSENT' if not found else 'AMBIGUOUS', 'count': len(found)}
    return scalar(found[0])


def table_values(node):
    pieces = []
    for token in node.get('args', []):
        if token['kind'] == 'punctuation' and token['value'] == ',':
            continue
        pieces.extend(x for x in re.split(r'[\s,]+', token['value'].strip()) if x)
    if not pieces or any(not re.fullmatch(NUMBER, p) for p in pieces):
        return {'status': 'UNKNOWN_NONNUMERIC_VALUES', 'line': node['line']}
    values = [float(p) for p in pieces]
    if not all(math.isfinite(v) for v in values):
        return {'status': 'UNKNOWN_NONFINITE_VALUES', 'line': node['line']}
    return {'status': 'PARSED', 'line': node['line'], 'count': len(values),
            'min': min(values), 'max': max(values), 'nonzero': any(v != 0 for v in values)}


def mode_context(group, parents):
    return {'when': attribute_text(group, 'when'), 'related_pin': attribute_text(group, 'related_pin'),
            'related_pg_pin': attribute_text(group, 'related_pg_pin'), 'line': group['line'],
            'scope': [{'group': p['name'], 'args': arguments(p)} for p in parents if p['name'] in ('bus', 'pin', 'pg_pin')],
            'header_form': group['header_form'], 'header_raw': ' '.join(group['header_raw'].split())[:200]}


def legacy_probe(text, cell_name):
    """Repeat the old structural algorithm for a diagnosed comparison only."""
    cleaned = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', text)
    def groups(data, keyword, cell=None):
        pattern = r'\b' + keyword + r'\s*\(\s*' + (r'"?' + re.escape(cell) + r'"?\s*' if cell else r'[^()]*') + r'\)\s*\{'
        for start in re.finditer(pattern, data):
            depth = 1
            for token in re.finditer(r'"(?:\\.|[^"\\])*"|[{}]', data[start.end():]):
                if token[0] == '{':
                    depth += 1
                elif token[0] == '}':
                    depth -= 1
                    if depth == 0:
                        yield data[start.end():start.end() + token.start()]
                        break
            else:
                raise LibertyError('Legacy unbalanced group ' + keyword)
    try:
        cells = list(groups(cleaned, 'cell', cell_name))
        if len(cells) != 1:
            return {'status': 'LEGACY_CELL_COUNT', 'count': len(cells)}
        body = cells[0]
        internal = list(groups(body, 'internal_power'))
        leakage = list(groups(body, 'leakage_power'))
        values = re.findall(r'\bcell_leakage_power\s*:\s*(' + NUMBER + r')\s*;', body)
        for group in leakage:
            values.extend(re.findall(r'\bvalue\s*:\s*(' + NUMBER + r')\s*;', group))
        return {'status': 'LEGACY_REPRODUCED', 'cell_body_chars': len(body),
                'internal_groups': len(internal), 'leakage_groups': len(leakage), 'leakage_values': len(values),
                'internal_keyword_tokens_in_body': len(re.findall(r'\binternal_power\b', body)),
                'leakage_keyword_tokens_in_body': len(re.findall(r'\bleakage_power\b', body))}
    except (LibertyError, ValueError) as error:
        return {'status': 'LEGACY_PARSE_ERROR', 'error': str(error)}


def analyze(text, cell_name):
    tree = parse(text)
    libraries = [n for n, p in walk(tree) if n['kind'] == 'group' and n['name'] == 'library' and not p]
    if len(libraries) != 1:
        raise LibertyError('Expected exactly one top-level library')
    library = libraries[0]
    selected = [(n, p) for n, p in walk(library['children'], (library,)) if n['kind'] == 'group' and
                n['name'] == 'cell' and arguments(n) == [cell_name]]
    if len(selected) != 1:
        raise LibertyError('Expected exactly one named cell: ' + cell_name)
    cell = selected[0][0]
    internal, leakage = [], []
    for node, parents in walk(cell['children'], (cell,)):
        if node['kind'] != 'group':
            continue
        if node['name'] == 'internal_power':
            entry = mode_context(node, parents)
            entry['tables'] = [dict(table_values(n), table_path=[p['name'] for p in scope if p['name'] in ('rise_power', 'fall_power')])
                               for n, scope in walk(node['children']) if n['kind'] == 'complex' and n['name'] == 'values']
            internal.append(entry)
        elif node['name'] == 'leakage_power':
            entry = mode_context(node, parents)
            entry['value'] = numeric_attribute(node, 'value')
            leakage.append(entry)
    tables = [t for group in internal for t in group['tables']]
    direct_leakage = numeric_attribute(cell, 'cell_leakage_power')
    leaks = [r['value'] for r in leakage]
    if direct_leakage['status'] == 'PARSED':
        leaks.append(direct_leakage)
    legacy = legacy_probe(text, cell_name)
    causes = []
    if any(g['header_form'] == 'bare' for g in internal + leakage):
        causes.append('BARE_POWER_GROUP_HEADERS_NOT_RECOGNIZED_BY_LEGACY_PARENTHESIS_REGEX')
    if any(v['status'] == 'PARSED' and v['raw'].lstrip().startswith('"') for v in leaks):
        causes.append('QUOTED_LEAKAGE_NUMBERS_NOT_RECOGNIZED_BY_LEGACY_UNQUOTED_NUMBER_REGEX')
    if legacy.get('internal_groups') != len(internal) and not causes:
        causes.append('STRUCTURAL_OR_STRING_HANDLING_DIFFERENCE_REQUIRES_HEADER_REVIEW')
    return {'status': 'STRUCTURE_PARSED_EXACT_CELL', 'cell': cell_name, 'cell_line': cell['line'],
            'library': arguments(library), 'cell_body_chars': cell['body_end'] - cell['body_start'],
            'area': numeric_attribute(cell, 'area'),
            'units': {k: attribute_text(library, k) for k in
                      ('time_unit', 'voltage_unit', 'current_unit', 'leakage_power_unit')},
            'nominal': {k: numeric_attribute(library, k) for k in ('nom_voltage', 'nom_temperature')},
            'default_cell_leakage_power': numeric_attribute(library, 'default_cell_leakage_power'),
            'cell_leakage_power': direct_leakage,
            'internal_groups': len(internal), 'internal_tables': len(tables),
            'unparsed_internal_tables': sum(t['status'] != 'PARSED' for t in tables),
            'internal_groups_without_tables': sum(not r['tables'] for r in internal),
            'nonzero_internal_model': any(t.get('nonzero', False) for t in tables),
            'leakage_groups': len(leakage), 'leakage_values': sum(v['status'] == 'PARSED' for v in leaks),
            'nonzero_leakage_model': any(v['status'] == 'PARSED' and v['value_native'] > 0 for v in leaks),
            'unparsed_leakage_values': sum(v['status'] != 'PARSED' for v in leaks),
            'internal_modes': internal, 'leakage_modes': leakage, 'legacy_probe': legacy,
            'observed_legacy_limitations': causes,
            'scope': 'Source table/scalar presence and syntax only; no DB equivalence, mode completeness or activity coverage PASS'}
