RTL3307 V1.3 功耗/面积/精度查看器 V2
2026-11-19

运行方法（下载到桌面）：
unzip -n ~/Desktop/RTL3307_V13_PPA_Readout_V2_20261119.zip -d ~
python3 -B ~/RTL3307_V13_PPA_Readout_V2/show_result.py

默认两页：第1页核对修正后的精度/功能日志；第2页核对SRAM源库模型与活动信息。
仅看第1页可加 --section accuracy。仅看第2页可加 --section models。
读取的仍是V1.3及其原有TT5功耗运行，不启动综合、STA、LEC、仿真或库转换。

一、本版修正的确定错误
真实testbench输出 KWT_FABRIC_COUNTS 时，最后一个字段为 max_queued。
第一版查看器匹配到 master_stall_cycles 后就要求行结束，漏掉这个字段，
导致正常格式报 Missing/duplicate native final accounting。
这是查看器的错误，不是设计精度或RTL功能失败的证据。
V2完整识别实际8个字段，保持原7字段状态对账，检查原始行唯一性，
原有日志SHA、来源绑定、12任务、304128输出及零mismatch检查仍保留。
出错时会附不超过6条原生日志上下文，避免只显示无法定位的摘要。
修正使用冻结testbench的实际$display格式生成fixture，并与原生runner解析结果比较。

二、最新截图已经确认的结果
TT5全SoC平均功耗：54.66966400880837 mW。
12任务平均单任务能耗：16.52705185780058 uJ（既有运行摘要）。
SRAM按类别、任务持续时间加权的总功耗：
  RAMSP128X16 x1088: 14.6147014 mW（ITCM1024 + 加速器本地64）
  RAMSP4096X16 x64: 10.6886931 mW（共享512KiB）
  RAMSP8KX32 x8:     0.173586089 mW（DTCM）
  合计：            25.476980589 mW，约占总功耗46.60%。
三类在全部12个任务中内部功耗与漏电均为正，不能再说SRAM被按0计算。
这些宏贡献已经包含于上述全SoC总值，不应重复相加。

源Liberty原文已经找到80/80/112处internal_power，以及各4处leakage_power。
旧internal_groups=0/leakage_values=0与实际源文件和原生功耗不符。
仅凭截图尚不能确定原解析失败的具体语法触发原因；V2采用新的只读解析，
并保留不识别时的原文证据。源文件有表和原生功耗为正不自动证明全部模式覆盖完整。

面积（当前库面积口径）：
  加速器逻辑：222177.2448 um2
  本地SRAM：171331.2656 um2
  新增仲裁器：587.3280 um2
  shared controller/glue全部：1786.8816 um2
  上述小计：395882.7200 um2 = 0.39588272 mm2
  全SoC：5794582.680384 um2 = 5.794582680384 mm2
  保留所有SoC标准单元、仅扣除确认的平台共享/CPU TCM宏后的保守上界：
  549186.1808 um2 = 0.5491861808 mm2
  对照2.25 mm2预算，上界占24.4083%，余量1.7008138192 mm2。
该上界包含原CPU/外设标准单元和未细分接口，因此当前库面积下已有充足预算余量。
正式面积表仍按新增加速器/接口/内部SRAM归属及官方宏面积数据整理。
旧页原Liberty面积比对UNKNOWN表示解析未确认，不等于宏没有计入面积。

三、功耗剩余事项及含义
task00的check_power：1422个out_of_range ramps、18696个out_of_range loads、
3个library cells without function。这些是功耗计算检查，不能直接当成setup/hold
违例数量。范围之外可能偏低也可能偏高，尚缺对象与范围明细，不能猜成全是SRAM。
missing_function影响活动传播，和missing_table是不同检查。
当前原生check_power没有加-verbose，若既有日志未保存对象明细，查看器不会编造对象。

task00 hierarchical_net条目292134，其中Default=17516，约6.00%；file=113535。
register_output条目23200，其中file=7656，propagated=15542，backward_implied=2。
传播/推导不是零活动；Default是工具默认值，须看实际设置及涉及引脚。
上述比例是条目数量比例，不是功耗误差比例，也不能用Default数量估算功耗补偿。
本版只核对原模型/原活动信息，不为清除警告修改约束、添造活动或填入功耗。

四、精度和LEC的范围
打包的历史公开600样本X16/W12报告最大层NRMSE=0.033317850017001466%，
12层均为有限记录，clipping/saturation=0；本科门槛为3%。
它不是组委会最终抽样，也不是本次新跑的600样本或完整模型Top-1。
软件重放12任务304128输出差异为0，任务身份与当前祖先RTL绑定；
第1页将用服务器既有原生仿真日志再次确认当前祖先RTL的逐位比较。
V1.3原生LEC曾显示79683个比较点通过、0失败；LEC、数值误差、时序与功耗覆盖
分别以各自证据判断，不能互相替代。

主要参考：用户提供的赛题指南/官方答疑Q4/Q5/Q10、最新四页服务器截图，
Synopsys PrimeTime Suite Tool Commands R-2020.09 的check_power定义，
https://studylib.net/doc/27140599/cmd
Synopsys PrimeTime PX User Guide M-2016.12 的活动来源定义，
https://studylib.net/doc/27144853/ug-px

本机验证仅覆盖查看器格式和证据校验，没有在本机运行Synopsys或新的仿真。
