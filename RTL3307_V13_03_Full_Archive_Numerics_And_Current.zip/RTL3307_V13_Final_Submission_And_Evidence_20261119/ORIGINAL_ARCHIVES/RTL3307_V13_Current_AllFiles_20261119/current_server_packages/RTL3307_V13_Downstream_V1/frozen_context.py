"""Read-only identity capture for the completed external Resume V1.3 run.

No synthesis, source/config rewriting, native-results substitution or timing verdict.
Python 3.6+. Official Q&A Q4/Q10 and guide measurement rules reviewed 2026-11-18.
"""
from __future__ import print_function
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PATTERN = 'R2RTL3307_RESUME_V1_3_20261118_224036_*'
PREVIOUS_PATTERN = 'R2RTL3307_RESUME_V1_2_20261118_212948_*'
SOURCE_NAME = 'R2RTL3307_TCM128_TARGETFIX_V1_20261118_193123_mueo2wme'
COMPLETE = 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED'
CORNERS = ('FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT5', 'TT6')
PARENT_MANIFEST_SHA = '97429656aed87f3768e1dc475b8f5a46494f696655b636e11e04316a96dd49e8'
PARENT_READER_SHA = '51611dd4e0850737fcf0bfe320f266f2562f0ae7d0bf2c7aac376871eb3156d8'
V13_CORE = {
    'run_resume.py': '1aadb02ba46ec46e97ed1bc286e49280d0b014f2b21338b121103b3d2a022383',
    'report_support.py': '3032bdb63f29070b86e4c4450e0914ac3abc1ff551f12f3389b9c367b229d0a6',
    'native/dc_resume.tcl': 'b0aa02a7de3a6777f5c8503fa543c5d06195671dfe89bcb1c92707c0da3a91e4',
    'native/common.tcl': '94b16f6203de39aeecb547ec523b4130025bcc41b959b2fb0f0519753388511e',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            result.update(chunk)
    return result.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    os.replace(str(temporary), str(path))


def inside(child, parent):
    try:
        Path(child).resolve().relative_to(Path(parent).resolve())
        return True
    except ValueError:
        return False


def select_run(explicit=None):
    paths = ([Path(explicit).expanduser()] if explicit else
             list(Path('~/Desktop/kwt_runs').expanduser().glob(PATTERN)))
    require(len(paths) == 1, 'Need exactly one completed V1.3 run; found %d' % len(paths))
    run = paths[0].resolve()
    require(run.is_dir() and run.match(PATTERN), 'Wrong V1.3 baseline: ' + str(run))
    return run


def bind(ctx, path, expected=None):
    path = Path(path).expanduser().absolute()
    name = str(path)
    require(path.is_file(), 'Missing bound input: ' + name)
    actual = sha(path)
    if expected is not None:
        require(actual == expected, 'Input/receipt hash mismatch: ' + name)
    require(name not in ctx['records'] or ctx['records'][name] == actual,
            'Conflicting/changed captured input: ' + name)
    ctx['records'][name] = actual
    resolved = str(path.resolve())
    require(name not in ctx['resolved_paths'] or ctx['resolved_paths'][name] == resolved,
            'Captured input path redirected: ' + name)
    ctx['resolved_paths'][name] = resolved
    return actual


def verify_context(ctx):
    require(ctx['records'] and set(ctx['records']) == set(ctx['resolved_paths']),
            'Incomplete downstream input snapshot')
    for name, digest in ctx['records'].items():
        path = Path(name)
        require(path.is_file() and str(path.resolve()) == ctx['resolved_paths'][name] and sha(path) == digest,
                'Frozen baseline/input changed: ' + name)


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def receipt_files(ctx, run, state):
    path = run / 'receipts.json'
    bind(ctx, path, state['receipts_sha256'])
    receipts = load(path)
    folders = {str(run / 'dc_soc')} | {str(run / 'sta' / c) for c in CORNERS}
    require(len(receipts) == 8 and {r.get('folder') for r in receipts} == folders,
            'V1.3 stage receipt inventory mismatch')
    expected = {}
    for receipt in receipts:
        folder = Path(receipt['folder'])
        for name, digest in receipt['files'].items():
            path = Path(name)
            require(path.is_absolute() and path.parent == folder and path.resolve() == path.absolute(),
                    'Out-of-stage or redirected receipt path: ' + name)
            require(name not in expected or expected[name] == digest, 'Conflicting receipt: ' + name)
            expected[name] = digest
    for name, digest in expected.items():
        bind(ctx, name, digest)
    return expected


def prepare(args):
    """Validate one V1.3 run and its frozen ancestry; make no files and run no EDA."""
    run = select_run(getattr(args, 'run', None))
    package = Path(getattr(args, 'parent_package', '~/RTL3307_Timing_TargetFix_V1')).expanduser().resolve()
    ctx = {'run': run, 'baseline_run': run, 'parent_package': package,
           'records': {}, 'resolved_paths': {}}
    bind(ctx, run / 'state.json')
    state = load(run / 'state.json')
    require(state.get('status') == COMPLETE and not state.get('error') and not state.get('errors') and
            state.get('original_consumed_inputs_unchanged') is True, 'V1.3 is not complete/input-verified')
    require(Path(state.get('output', '')).resolve() == run and state.get('setup_margin') == .35 and
            state.get('hold_margin') == .05, 'V1.3 identity or synthesis-margin mismatch')
    require(set(state.get('corners', {})) == set(CORNERS) and all(
        state['corners'][c].get('status') == 'PARSED_MARKED_ROWS' for c in CORNERS),
        'V1.3 corner inventory is incomplete')
    source = Path(state.get('source_run', '')).expanduser().resolve()
    previous = Path(state.get('previous_run', '')).expanduser().resolve()
    require(source.is_dir() and source.name == SOURCE_NAME and previous.is_dir() and
            previous.match(PREVIOUS_PATTERN) and Path(state.get('parent_run', '')).resolve() == previous,
            'V1.3 ancestral run identity mismatch')
    result = source / 'payload/result'
    require(Path(state.get('baseline_netlist', '')).resolve() == previous / 'dc_soc/design.v' and
            Path(state.get('eval_sdc', '')).resolve() == result / 'sysbus.sdc',
            'V1.3 baseline netlist or original evaluation SDC mismatch')
    require(isinstance(state.get('input_snapshot_sha256'), str) and len(state['input_snapshot_sha256']) == 64,
            'Missing V1.3 state-to-input-snapshot binding')
    bind(ctx, run / 'input_snapshot.json', state['input_snapshot_sha256'])
    snapshot = load(run / 'input_snapshot.json')
    require(isinstance(snapshot, dict) and snapshot, 'Empty V1.3 consumed-input snapshot')
    for name, record in snapshot.items():
        require(Path(name).is_absolute() and isinstance(record, dict) and
                set(record) == {'resolved', 'sha256'}, 'Invalid consumed-input record: ' + name)
        bind(ctx, name, record['sha256'])
        require(ctx['resolved_paths'][name] == record['resolved'], 'Consumed input redirected: ' + name)
    roots = [Path(name).parent for name, record in snapshot.items() if Path(name).name == 'run_resume.py' and
             record['sha256'] == V13_CORE['run_resume.py']]
    require(len(roots) == 1, 'Frozen V1.3 producer identity unavailable')
    for relative, digest in V13_CORE.items():
        require(snapshot.get(str(roots[0] / relative), {}).get('sha256') == digest,
                'Frozen V1.3 producer component mismatch: ' + relative)
    expected = receipt_files(ctx, run, state)
    chain = [str(result / 'dc_soc/design.svf'), str(previous / 'dc_soc/incremental.svf'),
             str(run / 'dc_soc/incremental.svf')]
    require(state.get('svf_chain') == chain, 'Expected original -> V1.2 -> V1.3 SVF order')
    for name in chain[:2]:
        require(name in snapshot, 'Ancestral SVF is not bound by V1.3 input snapshot: ' + name)
    for name in chain:
        require(Path(name).stat().st_size > 0 and name in ctx['records'], 'Empty/unbound SVF: ' + name)
    netlist = str(run / 'dc_soc/design.v')
    require(netlist in expected and expected.get(chain[-1]) == ctx['records'].get(chain[-1]),
            'V1.3 netlist/SVF lack current DC receipts')
    bind(ctx, package / 'payload/payload_manifest.json', PARENT_MANIFEST_SHA)
    bind(ctx, package / 'show_result.py', PARENT_READER_SHA)
    manifest = load(package / 'payload/payload_manifest.json')
    require(manifest.get('candidate_id') == 'RTL3307_TCM128_TARGETFIX_V1', 'Wrong parent package')
    bind(ctx, source / 'payload/payload_manifest.json', PARENT_MANIFEST_SHA)
    for relative in ('native/driver.py', 'native/common.tcl', 'formality/driver.py'):
        bind(ctx, package / 'payload' / relative, manifest['files'][relative])
        bind(ctx, source / 'payload' / relative, manifest['files'][relative])
    # The fixed original reader validates the original payload, state, receipts and reports.
    # It is used only for the actual TARGETFIX ancestor, never pointed at V1.3.
    reader = runpy.run_path(str(package / 'show_result.py'))
    ancestor = reader['bound_summary'](source)
    config_path = result / 'resolved_config.json'
    require(str(config_path) in snapshot, 'Original resolved config is absent from frozen V1.3 inputs')
    config = load(config_path)
    require(Path(config['out']).resolve() == result and config.get('candidate_id') == 'RTL3307_TCM128_TARGETFIX_V1',
            'Original resolved configuration identity mismatch')
    native = module(package / 'payload/native/driver.py', 'v13_frozen_native')
    native.verify_inputs(config)
    values = native.values(config, config['compile_max_corner'], 'soc')
    require(config['compile_max_corner'] == 'SS3' and config['compile_min_corner'] == 'SS3',
            'Unexpected original compile corners')
    libraries = values['libraries']
    require(libraries and len(libraries) == len(set(libraries)) and
            all(Path(name).suffix == '.db' for name in libraries), 'Compiled unique .db libraries required')
    for name in values['sources'] + libraries:
        require(name in snapshot, 'RTL/library missing from V1.3 input snapshot: ' + name)
    formal = module(package / 'payload/formality/driver.py', 'v13_frozen_formal')
    area_path = run / 'sta/TT5/cells.tsv'
    require(str(area_path) in expected, 'V1.3 TT5 area inventory is not receipt-bound')
    area = native.area(area_path)
    require(area['macros'] == native.MACROS and area == state.get('area'),
            'V1.3 area/macro inventory differs from native receipt/state')
    ctx.update(source_run=source, previous_run=previous, parent_payload=source / 'payload',
               resolved=config, config=config, netlist=netlist, sdc=str(result / 'sysbus.sdc'),
               eval_sdc=str(result / 'sysbus.sdc'), state=state, svf_chain=chain,
               libraries=libraries, sources=values['sources'], includes=values['includes'],
               native_driver=native, formal_driver=formal, ancestor=ancestor, area=area,
               producer_package=roots[0], protected_roots=[run, source, previous, package, roots[0], HERE])
    bind(ctx, HERE / 'frozen_context.py')
    verify_context(ctx)
    return ctx


def new_output(ctx, kind, output_base=None):
    require(kind in ('LEC', 'POWER'), 'Unknown downstream output kind')
    base = Path(output_base).expanduser().resolve() if output_base else ctx['run'].parent
    require(not any(inside(base, path) for path in ctx['protected_roots']),
            'Downstream output base overlaps a frozen run/package')
    base.mkdir(parents=True, exist_ok=True)
    prefix = 'R2RTL3307_V13_' + kind + '_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '_'
    out = Path(tempfile.mkdtemp(prefix=prefix, dir=str(base)))
    require(not any(inside(out, path) for path in ctx['protected_roots']), 'Output overlaps frozen baseline')
    return out


def evidence(ctx):
    return {'baseline_run': str(ctx['run']), 'source_run': str(ctx['source_run']),
            'previous_run': str(ctx['previous_run']), 'netlist': ctx['netlist'],
            'netlist_sha256': ctx['records'][ctx['netlist']],
            'svf_chain': [{'file': p, 'sha256': ctx['records'][p]} for p in ctx['svf_chain']],
            'eval_sdc': ctx['sdc'], 'eval_sdc_sha256': ctx['records'][ctx['sdc']],
            'libraries': ctx['libraries'], 'sources': ctx['sources'], 'includes': ctx['includes'],
            'area': ctx['area'], 'records': ctx['records'], 'resolved_paths': ctx['resolved_paths'],
            'scope': 'V1.3 immutable mapped netlist; original synthesis-selected RTL and evaluation constraints',
            'timing_acceptance': False, 'hold_removal_coverage_review_pending': True}
