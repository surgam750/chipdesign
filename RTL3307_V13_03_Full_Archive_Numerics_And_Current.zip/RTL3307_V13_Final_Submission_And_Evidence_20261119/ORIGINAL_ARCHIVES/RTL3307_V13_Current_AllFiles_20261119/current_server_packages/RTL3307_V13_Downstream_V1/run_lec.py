#!/usr/bin/env python3
"""Check or run native Formality for the exact frozen V1.3 netlist; Python 3.6+."""
from __future__ import print_function
import argparse
import hashlib
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
import frozen_context as frozen

HERE = Path(__file__).resolve().parent
# Synopsys Formality User Guide M-2016.12, Chapter 5, p.5-13:
# set_svf -ordered file1.svf file2.svf ... preserves the transformation sequence.
# Publisher-authored manual mirror (native-version help is also captured):
# https://studylib.net/doc/28221128/formality-user-guide--version-m-2016.12


def chain_script(formal, prepared):
    sentinel = '__V13_ORDERED_SVF_CHAIN__'
    p = dict(prepared, svf=sentinel)
    script = formal.formal_script(p)
    original = 'set_svf ' + formal.tcl(sentinel)
    frozen.require(script.count(original) == 1, 'Unexpected frozen Formality script structure')
    command = 'set_svf -ordered ' + ' '.join(formal.tcl(name) for name in prepared['svf_chain'])
    replacement = '\n'.join([
        'puts V13_SVF_HELP_BEGIN', 'help set_svf', 'puts V13_SVF_HELP_END',
        'set v13_svf_result [' + command + ']',
        'puts "V13_SVF_NATIVE_RETURN=$v13_svf_result"',
        'if {$v13_svf_result ne "1"} {error "Ordered V1.3 SVF chain load did not return native success 1"}',
        'puts V13_ORDERED_SVF_CHAIN_LOADED_3'])
    return script.replace(original, replacement)


def tool_environment(ctx):
    lc = ctx['config']['tools'].get('LC')
    if lc:
        os.environ['SYNOPSYS_LC_ROOT'] = str(Path(lc).parent.parent)


def area_brief(ctx):
    area = ctx['area']
    groups = area['groups_um2']
    def shown(name):
        return '%.6f' % groups[name] if name in groups else 'UNKNOWN/NOT_SEPARATELY_CLASSIFIED'
    print('AREA_TT5_SOC_LIBRARY_UM2=%.6f; source=V1.3/sta/TT5/cells.tsv' % area['total_um2'], flush=True)
    print('AREA_ACCEL_LOGIC_UM2=%s LOCAL_SRAM_UM2=%s' %
          (shown('accelerator_logic'), shown('accelerator_local_sram')), flush=True)
    print('AREA_NEW_ARBITER_UM2=%s SHARED_GLUE_UM2=%s LOADER_DMA_UM2=%s' %
          (shown('new_systembus_arbiter'), shown('shared_controller_glue'), shown('loader_dma')), flush=True)
    print('AREA_SCOPE_REVIEW_REQUIRED: library groups are not the final official accelerator/interface budget.', flush=True)


def status_excerpt(path, expected, limit=20):
    data = Path(path).read_bytes()
    frozen.require(hashlib.sha256(data).hexdigest() == expected, 'Native LEC status report changed before display')
    lines = [(n, line.rstrip()) for n, line in enumerate(data.decode('utf-8', errors='replace').splitlines(), 1)
             if line.strip()]
    print('NATIVE_STATUS_RAW design/status.rpt shown=%d omitted_nonempty=%d; native L labels; no inferred PASS' %
          (min(limit, len(lines)), max(0, len(lines) - limit)), flush=True)
    for n, text in lines[:limit]:
        prefix = 'L%d ' % n
        if len(prefix + text) > 170:
            marker = ' ...[display shortened]... '
            text = text[:170 - len(prefix) - len(marker) - 40] + marker + text[-40:]
        print(prefix + text, flush=True)


def controls(ctx, out, fm, timeout):
    formal = ctx['formal_driver']
    results = []
    for label, expression, expected in (('equivalent', '~a', True), ('different', 'a', False)):
        folder = out / ('probe_' + label)
        folder.mkdir()
        include = folder / 'include'
        include.mkdir()
        (include / 'defs.vh').write_text('`define INVERT(x) (~(x))\n', encoding='ascii')
        reference = folder / 'reference.v'
        reference.write_text('`include "defs.vh"\nmodule lec_probe(input a,output y);\n'
                             '`ifdef KWT_TCM_MACRO\nassign y=`INVERT(a);\n`else\n'
                             'MISSING_DEFINE missing();\n`endif\nendmodule\n', encoding='ascii')
        implementation = folder / 'implementation.v'
        implementation.write_text('module lec_probe(input a,output y);assign y=' + expression + ';endmodule\n', encoding='ascii')
        filelist = folder / 'sources.f'
        filelist.write_text(formal.filelist_text([str(reference)], [str(include)]), encoding='ascii')
        input_files = {str(p): frozen.sha(p) for p in
                       (reference, implementation, filelist, include / 'defs.vh')}
        p = {'libraries': ctx['libraries'], 'netlist': str(implementation), 'filelist': str(filelist)}
        script = formal.formal_script(p, 'lec_probe', True)
        actual = formal.invoke(fm, folder, script, min(300, timeout))
        frozen.require(all(frozen.sha(name) == digest for name, digest in input_files.items()),
                       'Native Formality control inputs changed: ' + label)
        frozen.require(actual == expected, 'Native Formality positive/negative control failed: ' + label)
        results.append({'label': label, 'actual': actual, 'expected': expected, 'inputs': input_files})
        print('V13_LEC_CONTROL %s actual=%d expected=%d' % (label, actual, expected), flush=True)
    return results


def run(ctx, args):
    frozen.require(args.timeout > 0, 'Positive --timeout required')
    formal = ctx['formal_driver']
    fm = formal.locate_fm(args.fm)
    frozen.bind(ctx, fm)
    frozen.bind(ctx, HERE / 'run_lec.py')
    frozen.verify_context(ctx)
    out = frozen.new_output(ctx, 'LEC', args.output_base)
    state = {'status': 'V13_LEC_RUNNING', 'baseline_run': str(ctx['run']), 'output': str(out),
             'netlist_sha256': ctx['records'][ctx['netlist']], 'acceptance': False,
             'timing_acceptance': False, 'started': time.time()}
    frozen.save(out / 'state.json', state)
    print('V13_LEC_OUTPUT=' + str(out), flush=True)
    try:
        tool_environment(ctx)
        prepared = frozen.evidence(ctx)
        prepared.update(fm=fm, timeout=args.timeout, svf_chain=list(ctx['svf_chain']),
                        filelist=str(out / 'sources.f'))
        Path(prepared['filelist']).write_text(formal.filelist_text(ctx['sources'], ctx['includes']), encoding='ascii')
        prepared['sources_file_sha256'] = frozen.sha(prepared['filelist'])
        frozen.save(out / 'prepared.json', prepared)
        prepared_sha = frozen.sha(out / 'prepared.json')
        probes = controls(ctx, out, fm, args.timeout)
        frozen.verify_context(ctx)
        frozen.require(frozen.sha(out / 'prepared.json') == prepared_sha and
                       frozen.sha(prepared['filelist']) == prepared['sources_file_sha256'],
                       'LEC capture/filelist changed before design verification')
        script = chain_script(formal, prepared)
        actual = formal.invoke(fm, out / 'design', script, args.timeout)
        frozen.verify_context(ctx)
        frozen.require(frozen.sha(out / 'prepared.json') == prepared_sha and
                       frozen.sha(prepared['filelist']) == prepared['sources_file_sha256'],
                       'LEC capture/filelist changed during verification')
        log = (out / 'design/tool.log').read_text(errors='replace')
        frozen.require(len(re.findall(r'^V13_ORDERED_SVF_CHAIN_LOADED_3\s*$', log, re.M)) == 1,
                       'Ordered native SVF-chain load marker missing/ambiguous')
        files = formal.invocation_records(out / 'design', fm, script)
        for name in list(formal.REPORTS) + ['tool.log']:
            path = out / 'design' / name
            frozen.require(path.is_file() and path.stat().st_size > 0, 'Missing native LEC report: ' + name)
            files[str(path)] = frozen.sha(path)
        optional = out / 'design/unverified.rpt'
        if optional.is_file():
            files[str(optional)] = frozen.sha(optional)
        for folder in out.glob('probe_*'):
            for path in folder.rglob('*'):
                if path.is_file():
                    files[str(path)] = frozen.sha(path)
        summary = {'status': 'V13_LEC_VERIFY_TRUE_REVIEW_REQUIRED' if actual else 'V13_LEC_VERIFY_FALSE_NO_ACCEPTANCE',
                   'native_verify_return': actual, 'baseline_run': str(ctx['run']),
                   'netlist': ctx['netlist'], 'netlist_sha256': ctx['records'][ctx['netlist']],
                   'svf_chain': [{'file': p, 'sha256': ctx['records'][p]} for p in ctx['svf_chain']],
                   'compiled_reference_libraries': ctx['libraries'], 'controls': probes,
                   'prepared_sha256': prepared_sha, 'files': files,
                   'scope': 'Original synthesis-selected physical RTL versus exact V1.3 mapped netlist; library SRAM boundaries',
                   'pending_review': ['compare-point / unmatched / aborted / unverified coverage',
                                      'SRAM macro boundaries, SVF guidance and auto-setup assumptions',
                                      'functional behavioral-to-physical memory relation remains separate'],
                   'baseline_unchanged': True, 'acceptance': False, 'timing_acceptance': False}
        frozen.save(out / 'summary.json', summary)
        state.update(status=summary['status'], summary_sha256=frozen.sha(out / 'summary.json'),
                     native_verify_return=actual, baseline_unchanged=True, finished=time.time())
        frozen.save(out / 'state.json', state)
        print(summary['status'], flush=True)
        print('NETLIST_SHA256=' + summary['netlist_sha256'], flush=True)
        print('SVF_CHAIN=original > V1.2 > V1.3; input files unchanged; timing/hold/removal remain separate.', flush=True)
        status_excerpt(out / 'design/status.rpt', files[str(out / 'design/status.rpt')])
        print('REVIEW_REPORTS=' + str(out / 'design'), flush=True)
        return out
    except BaseException as error:
        state.update(status='V13_LEC_INCOMPLETE', error=str(error)[:2000], finished=time.time())
        try:
            frozen.verify_context(ctx)
            state['baseline_unchanged'] = True
        except Exception as changed:
            state['baseline_unchanged'] = False
            state['input_integrity_error'] = str(changed)
        frozen.save(out / 'state.json', state)
        print('V13_LEC_OUTPUT=' + str(out), flush=True)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', nargs='?', choices=('check', 'run'), default='check')
    parser.add_argument('--run', help='Exact completed V1.3 baseline; default unique 224036 timestamp run')
    parser.add_argument('--parent-package', default='~/RTL3307_Timing_TargetFix_V1')
    parser.add_argument('--output-base', help='Fresh sibling output directory base; default baseline parent')
    parser.add_argument('--fm', help='Actual fm_shell executable; default existing frozen driver discovery')
    parser.add_argument('--timeout', type=int, default=7200)
    args = parser.parse_args(argv)
    ctx = frozen.prepare(args)
    print('V13_BASELINE=' + str(ctx['run']), flush=True)
    print('V13_NETLIST_SHA256=' + ctx['records'][ctx['netlist']], flush=True)
    print('V13_INPUTS_VERIFIED; original RTL/compiled DBs; three ordered SVFs; no re-synthesis.', flush=True)
    area_brief(ctx)
    if args.action == 'check':
        print('CHECK_ONLY_COMPLETE; no EDA started and no output written.', flush=True)
        return 0
    run(ctx, args)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (Exception, KeyboardInterrupt) as error:
        print('V13_LEC_STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
