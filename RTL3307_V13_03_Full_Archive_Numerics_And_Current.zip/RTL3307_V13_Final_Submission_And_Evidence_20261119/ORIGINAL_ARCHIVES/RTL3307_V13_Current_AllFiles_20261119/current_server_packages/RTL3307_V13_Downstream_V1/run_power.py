#!/usr/bin/env python3
"""Evaluate verified RTL task activity on the exact V1.3 netlist; Python 3.6+.

Default action is read-only check. 'run' creates an isolated power output.
TT5 is the default declared evaluation corner; --all-corners requests all seven.
Neither action resynthesizes, reruns VCS, or modifies the baseline run.
"""
from __future__ import print_function
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
import frozen_context as frozen

CORNERS = ('TT5', 'FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT6')
STATUS = 'V13_TASK_POWER_ESTIMATE_REVIEW_REQUIRED'


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    os.replace(str(temporary), str(path))


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def record(ctx, path, expected=None):
    path = Path(path).absolute()
    frozen.bind(ctx, path, expected)
    return str(path)


def capture_activity(ctx, corners):
    payload = Path(ctx['parent_payload'])
    config = ctx['config']
    work = Path(config['overlay']).resolve()
    need(work == (payload / 'work/soc').resolve(), 'Unexpected functional RTL source directory')
    report = payload / 'reports'
    state_path = report / 'state.json'
    state = load(state_path)
    need(state.get('status') == 'SERVER_SYSTEMBUS_FUNCTIONAL_RTL_PASS' and
         state.get('candidate_id') == 'RTL3307_TCM128_TARGETFIX_V1',
         'Power needs completed parent RTL activity; no activity was invented or rerun')
    # These are the exact source-run helpers already bound by the V1.3 input chain.
    for relative in ('power/driver.py', 'power/activity.py', 'power/task_activity.sv',
                     'native/driver.py', 'native/common.tcl', 'server/rtl_driver.py'):
        name = str(payload / relative)
        need(name in ctx['records'], 'V1.3 does not bind inherited helper: ' + relative)
        record(ctx, name, ctx['records'][name])
    power = module_at(payload / 'power/driver.py', 'v13_bound_power')
    rtl = module_at(payload / 'server/rtl_driver.py', 'v13_bound_rtl_activity')
    rtl.verify_run_inputs(work, state)
    record(ctx, state_path)
    record(ctx, work / 'simv', state['simv_sha256'])
    record(ctx, report / 'simulation.log', state['log_sha256'])
    record(ctx, report / 'compile.log', state['compile_log_sha256'])
    # pipeline.json legitimately advanced after RTL; consume only the exact
    # functional invocations, not unrelated later-stage orchestration metadata.
    for name in ('compile_command.json', 'simulation_command.json'):
        digest = state.get('receipt_files', {}).get(name)
        need(digest, 'Functional invocation lacks receipt: ' + name)
        record(ctx, report / name, digest)
    manifest = report / 'activity/manifest.json'
    record(ctx, manifest, state['activity_manifest_sha256'])
    activity = power.activity.verified(report, work, state['activity_manifest_sha256'])
    windows = activity['windows']
    need(len(windows) == 12 and [w['task'] for w in windows] == list(range(12)),
         'Exactly twelve complete task windows required')
    for window in windows:
        path = work / window['file']
        need(path.parent == work, 'Activity file outside functional work directory')
        record(ctx, path, window['sha256'])
    for name in ('source_manifest.json', 'sources.f', 'tasks_12.txt'):
        record(ctx, work / name)
    overlay = load(work / 'source_manifest.json')
    for relative, digest in overlay['after'].items():
        path = (work / relative).resolve()
        need(work in path.parents, 'Functional source outside frozen overlay')
        record(ctx, path, digest)
    common = record(ctx, payload / 'native/common.tcl')
    script = record(ctx, HERE / 'power/estimate.tcl')
    record(ctx, __file__)
    record(ctx, HERE / 'frozen_context.py')
    record(ctx, config['tools']['PT'])
    models, macros, configs = {}, {}, {}
    for corner in corners:
        cfg = ctx['native_driver'].values(config, corner, 'soc')
        cfg.update(netlist=str(ctx['netlist']), sdc=str(ctx['sdc']),
                   expected_library_count=len(cfg['libraries']))
        need(len(cfg['libraries']) == len(set(cfg['libraries'])) == 1 + len(power.MACROS),
             'Expected one standard and three distinct macro libraries')
        for name in cfg['libraries']:
            need(name in config['library_hashes'], 'Library lacks original resolved hash')
            record(ctx, name, config['library_hashes'][name])
        cells = str(Path(ctx['run']) / 'sta' / corner / 'cells.tsv')
        need(cells in ctx['records'], 'V1.3 macro inventory is not receipt-bound: ' + corner)
        record(ctx, cells, ctx['records'][cells])
        macros[corner] = power.expected_macros(Path(ctx['run']), corner)
        models[corner] = power.model_data(config, corner)
        for row in config['macro_source_resolution'][corner].values():
            record(ctx, row['selected_original'], row['sha256'])
        configs[corner] = cfg
    frozen.verify_context(ctx)
    return dict(power=power, windows=windows, work=work, configs=configs,
                models=models, macros=macros, common=common, script=script,
                activity_manifest=str(manifest), activity_manifest_sha256=sha(manifest),
                functional_state=str(state_path), functional_state_sha256=sha(state_path))


def invocation(ctx, activity, corner, window, folder):
    cfg = dict(activity['configs'][corner])
    cfg.update(saif=str(activity['work'] / window['file']),
               strip_path=window['strip_path'], task=window['task'])
    need(cfg['netlist'] == str(ctx['netlist']) and cfg['sdc'] == str(ctx['sdc']),
         'Power invocation lost exact baseline netlist/SDC')
    script = 'set cfg %s\n' % ctx['native_driver'].tcl(cfg)
    command = [ctx['config']['tools']['PT'], '-f', activity['script']]
    used = cfg['libraries'] + [cfg['netlist'], cfg['sdc'], cfg['saif'],
                              command[0], command[2], activity['common'], ctx['config']['tools']['LC']]
    inputs = {}
    for name in used:
        need(name in ctx['records'] and sha(name) == ctx['records'][name],
             'Power invocation input changed or is unbound: ' + name)
        inputs[name] = ctx['records'][name]
    need(inputs[cfg['saif']] == window['sha256'], 'Task activity changed')
    call = dict(command=command, cwd=str(folder), corner=corner, task=window['task'],
                KWT_NATIVE_CONFIG=str(folder / 'config.tcl'), KWT_POWER_COMMON=activity['common'],
                SYNOPSYS_LC_ROOT=str(Path(ctx['config']['tools']['LC']).parent.parent),
                inputs=inputs, baseline_run=str(ctx['run']), netlist_sha256=inputs[cfg['netlist']],
                saif_scope=window['strip_path'], duration_ps=window['duration_ps'])
    return script, call


def invoke(ctx, activity, corner, window, folder, timeout):
    folder.mkdir(parents=True, exist_ok=False)
    script, call = invocation(ctx, activity, corner, window, folder)
    (folder / 'config.tcl').write_text(script, encoding='utf-8')
    save(folder / 'invocation.json', call)
    env = os.environ.copy()
    env['KWT_NATIVE_CONFIG'] = call['KWT_NATIVE_CONFIG']
    env['KWT_POWER_COMMON'] = call['KWT_POWER_COMMON']
    env['SYNOPSYS_LC_ROOT'] = call['SYNOPSYS_LC_ROOT']
    print('V13_POWER_RUNNING %s task=%02d %s' % (corner, window['task'], folder), flush=True)
    with (folder / 'tool.log').open('w') as stream:
        proc = subprocess.Popen(call['command'], cwd=str(folder), env=env,
                                stdout=stream, stderr=subprocess.STDOUT,
                                start_new_session=(os.name == 'posix'))
        try:
            proc.wait(timeout=timeout)
        except BaseException:
            if proc.poll() is None:
                if os.name == 'posix':
                    os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
                proc.wait()
            raise
    if proc.returncode:
        tail = (folder / 'tool.log').read_text(errors='replace').splitlines()[-15:]
        print('\n'.join(tail)[:6000], flush=True)
        raise ValueError('PT-PX exit=%s: %s' % (proc.returncode, folder / 'tool.log'))
    need((folder / 'config.tcl').read_text(encoding='utf-8') == script and
         load(folder / 'invocation.json') == call, 'Power command/configuration changed')
    for name, digest in call['inputs'].items():
        need(sha(name) == digest, 'Power input changed during tool invocation: ' + name)
    return activity['power'].receipt(folder, corner, window['task'])


def execute(ctx, activity, corners, jobs, timeout, output_base=None):
    out = frozen.new_output(ctx, 'POWER', output_base)
    state = dict(status='V13_POWER_RUNNING', baseline_run=str(ctx['run']),
                 netlist=str(ctx['netlist']), netlist_sha256=ctx['records'][str(ctx['netlist'])],
                 corners=list(corners), expected_jobs=12 * len(corners), finished_jobs=0,
                 acceptance=False, started=time.time())
    save(out / 'input_snapshot.json', ctx['records'])
    save(out / 'state.json', state)
    receipts, summaries = {}, {}
    try:
        for corner in corners:
            windows = activity['windows']
            # One real native task first catches an incompatible tool/SDC/library
            # before scheduling the other eleven tasks for this corner.
            folders = [(w, out / corner / ('task_%02d' % w['task'])) for w in windows]
            window, folder = folders[0]
            key = '%s/task_%02d' % (corner, window['task'])
            receipts[key] = invoke(ctx, activity, corner, window, folder, timeout)
            state['finished_jobs'] = len(receipts)
            save(out / 'state.json', state)
            with ThreadPoolExecutor(max_workers=jobs) as pool:
                futures = {pool.submit(invoke, ctx, activity, corner, w, f, timeout): (w, f)
                           for w, f in folders[1:]}
                try:
                    for future in as_completed(futures):
                        w, unused = futures[future]
                        receipts['%s/task_%02d' % (corner, w['task'])] = future.result()
                        state['finished_jobs'] = len(receipts)
                        save(out / 'state.json', state)
                except BaseException:
                    for future in futures:
                        future.cancel()
                    raise
            assessed = []
            for w, f in folders:
                script, call = invocation(ctx, activity, corner, w, f)
                need((f / 'config.tcl').read_text(encoding='utf-8') == script and
                     load(f / 'invocation.json') == call, 'Saved power invocation changed')
                need(activity['power'].receipt(f, corner, w['task']) ==
                     receipts['%s/task_%02d' % (corner, w['task'])], 'Power outputs changed')
                assessed.append(activity['power'].assess(f, activity['macros'][corner],
                                                        activity['models'][corner], w))
            summaries[corner] = activity['power'].corner_summary(assessed, activity['models'][corner])
        frozen.verify_context(ctx)
        need(load(out / 'input_snapshot.json') == ctx['records'], 'Captured power inputs changed')
        summary = dict(status=STATUS, baseline_run=str(ctx['run']), netlist=str(ctx['netlist']),
                       netlist_sha256=ctx['records'][str(ctx['netlist'])],
                       eval_sdc=str(ctx['sdc']), eval_sdc_sha256=ctx['records'][str(ctx['sdc'])],
                       corners=summaries, jobs=len(receipts),
                       pvt={c: ctx['config']['operating_conditions'][c] for c in corners},
                       activity_manifest=activity['activity_manifest'],
                       activity_manifest_sha256=activity['activity_manifest_sha256'],
                       functional_state=activity['functional_state'],
                       functional_state_sha256=activity['functional_state_sha256'],
                       LEC='SEPARATE_RESULT_REQUIRED', acceptance=False, signoff_achieved=False,
                       scope='All 12 verified functional-RTL task windows mapped to exact V1.3 netlist. '
                             'Pre-layout averaged library power estimate; no gate-level glitches or routed parasitics. '
                             'Direct/inferred activity and macro model coverage issues remain explicit.')
        save(out / 'receipt.json', dict(inputs=ctx['records'], stages=receipts))
        save(out / 'summary.json', summary)
        state.update(status=STATUS, receipt_sha256=sha(out / 'receipt.json'),
                     summary_sha256=sha(out / 'summary.json'), finished=time.time())
        save(out / 'state.json', state)
        print('V13_POWER_OUTPUT=' + str(out), flush=True)
        print('NETLIST_SHA256=' + summary['netlist_sha256'], flush=True)
        for corner in corners:
            row = summaries[corner]
            print('%s all12 duration_weighted_total_W=%.12g mean_task_energy_uJ=%.12g issues=%d' %
                  (corner, row['duration_weighted_power_W']['total_W'], row['mean_task_energy_uJ'],
                   len(row['issues'])), flush=True)
            for issue in row['issues'][:6]:
                print('  REVIEW ' + issue, flush=True)
            if len(row['issues']) > 6:
                print('  Additional review issues=%d; see summary.json' % (len(row['issues']) - 6), flush=True)
        print(STATUS + ' | TIMING/LEC/ACTIVITY_REVIEW_SEPARATE', flush=True)
        return summary
    except BaseException as error:
        state.update(status='V13_POWER_INCOMPLETE', error=str(error), finished=time.time())
        try:
            frozen.verify_context(ctx)
            state['baseline_inputs_unchanged'] = True
        except BaseException as changed:
            state['baseline_inputs_unchanged'] = False
            state['input_error'] = str(changed)
        save(out / 'receipt.json', dict(inputs=ctx['records'], stages=receipts))
        save(out / 'state.json', state)
        print('V13_POWER_OUTPUT=' + str(out), flush=True)
        raise


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action', nargs='?', choices=('check', 'run'), default='check')
    ap.add_argument('--run', help='Exact completed V1.3 baseline; default selects the unique frozen timestamp')
    ap.add_argument('--parent-package', default='~/RTL3307_Timing_TargetFix_V1')
    select = ap.add_mutually_exclusive_group()
    select.add_argument('--corners', nargs='+', choices=CORNERS, default=['TT5'])
    select.add_argument('--all-corners', action='store_true')
    ap.add_argument('--jobs', type=int, default=2, help='Native PT-PX workers, 1..4; default 2')
    ap.add_argument('--timeout', type=int, default=7200, help='Maximum seconds per native task')
    ap.add_argument('--output-base', help='Parent directory for a new isolated output')
    args = ap.parse_args(argv)
    need(1 <= args.jobs <= 4 and args.timeout > 0, 'Need jobs 1..4 and a positive timeout')
    corners = list(CORNERS) if args.all_corners else args.corners
    need(len(corners) == len(set(corners)), 'Duplicate requested corner')
    ctx = frozen.prepare(args)
    activity = capture_activity(ctx, corners)
    print('V13_POWER_INPUTS_VERIFIED baseline=' + str(ctx['run']), flush=True)
    print('NETLIST_SHA256=' + ctx['records'][str(ctx['netlist'])], flush=True)
    print('TASK_WINDOWS=12 CORNERS=' + ','.join(corners) + ' NATIVE_JOBS=' + str(12 * len(corners)), flush=True)
    if args.action == 'check':
        print('READ_ONLY_CHECK_COMPLETE: no EDA started; run action required to calculate power.', flush=True)
        return 0
    execute(ctx, activity, corners, args.jobs, args.timeout, args.output_base)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print('POWER_INTERRUPTED: baseline remains selected; inspect isolated output.', file=sys.stderr)
        sys.exit(130)
    except (ValueError, OSError, KeyError, TypeError, RuntimeError, subprocess.TimeoutExpired) as error:
        print('POWER_STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
