RTL3307 Timing Resume V1.3 — 从成功的V1.2 DDC增加综合setup裕量

这是供服务器运行的受控综合实验，尚无本版服务器原生DC/PT结果，不保证时序通过。

立即运行（ZIP已放到服务器桌面时）
unzip -n "$HOME/Desktop/RTL3307_Timing_Resume_V1_3_20261118.zip" -d "$HOME"
python3 -B "$HOME/RTL3307_Timing_Resume_V1_3/run_resume.py" --jobs 4

保留原TARGETFIX、V1.2工具和运行目录。V1.3解压到新目录，结果也在新目录。
默认只接受下列时间戳匹配的唯一V1.2运行，不自动选“最新”运行：
~/Desktop/kwt_runs/R2RTL3307_RESUME_V1_2_20261118_212948_*
TARGETFIX祖先：
~/Desktop/kwt_runs/R2RTL3307_TCM128_TARGETFIX_V1_20261118_193123_mueo2wme
默认祖先工具：~/RTL3307_Timing_TargetFix_V1

本轮依据
V1.2原生SS3 setup标记960，最差约-0.01304ns：加速器31、cpu_other 1、ITCM A844/GWEN84。
同时SS3 hold从1271降到71、transition从7443降到0；SS4 hold从1375降到174、
transition从7326降到427。这是标记行统计，不是唯一物理路径。
最差样本是post shift_reg[0]到out_data_reg[7]/D。DC原生constraint中没有setup
违例标记，PT却有；DC第一条gating-latch的0 slack不能代替这些数据端点的裕量。
已核对代码的SS3库和原SDC来源；DC继承DDC、PT从Verilog+原SDC重建。
延迟差异原因尚未证明，不能擅自认定是wireload、OCV或某个宏错误。

唯一新的优化变量
                        V1.2综合       V1.3综合       PT评测
setup uncertainty         0.30ns         0.35ns        0.30ns
hold uncertainty          0.05ns         0.05ns        0.05ns
max_transition            0.25ns         0.25ns        0.30ns
hfclk保持6.666666667ns（150MHz），lfclk、I/O预算和评测库/工况保持。
增加50ps setup uncertainty使综合要求数据更早到达；PT仍按原SDC验证。
这不会直接给slack加50ps，也不是降低频率、隐藏违例或通过保证。

实际执行
1. 交叉校验V1.2 state/八阶段receipts/原consumed inputs/固定核心代码/配置，
   以及TARGETFIX祖先输入、库、SDC和DDC/SVF；缺失或变化在EDA前停止。
2. 新建Desktop/kwt_runs/R2RTL3307_RESUME_V1_3_*，读取V1.2的design.ddc。
3. 保持V1.2电气成本次序、set_fix_hold和.25 slew目标，setup改.35、hold保留.05。
4. 只执行一次compile_ultra -incremental -no_autoungroup。
5. 用新网表及原SDC/库重新跑七角PT，保存原生报告、state、receipts、summary.txt。

三个同端点诊断
post固定为V1.2截图out_data_reg[7]/D；itcm_A/GWEN分别从核验后的全量SS3标记
选择最差对象。原始全名保存，不使用显示别名查询。
每个对象有三份DC报告：pre继承.30、margin编译前.35、post编译后.35。
只有全名严格匹配且恰好一个pin时才运行带-to的报告；对象消失或改变明确标记
MISSING_OR_CHANGED，不退化成无-to全局查询。同端点也不保证同起点/同物理路径。
这些只是报告，不增加path group、单独预算或路径豁免。

边界
不重新LC/RTL analyze/elaborate；不改RTL、接口、数值、维度、CEN拍数、容量/宏。
新映射可能改变标准单元和面积。原V1.2 waveform显示格式兼容修正完整保留。
--self-check只校验本包；--check-only核对输入并退出，不启动EDA或写结果。
--parent-run可显式指定同一V1.2；不接受任意其他候选。
--source-run、--parent-package仅用于明确指定同一祖先的位置。
每原生进程默认超时1200秒（--timeout可调），不是总完成时间承诺。

输出解释
setup/hold/removal/transition为count/worst native marked slack；无标记显示
NO_MARKED_ROW，不证明正裕量。max/min为原生查询模式，min可能为removal；
SS4/TT的max=0需结合检查类型，不说成“七角setup全正”。
不完整解析保留UNKNOWN；缺失/失败报告不用旧结果替换。
COMPLETE仅表示七角报告完成，acceptance/signoff不自动为真。
本轮需同时看setup、hold、removal、电气和未测试覆盖，不只看总行数或WNS。

等价/功耗/面积
保存TARGETFIX design.svf→V1.2 incremental.svf→V1.3 incremental.svf三段链。
这是LEC输入来源，等价与功耗仍未完成。原RTL仿真不替代新网表等价检查。
SoC library total area不是2.25mm²评分口径；新增加速器、接口、内部SRAM仍需核对。
精度、吞吐、功耗、面积必须对应同一冻结配置，不拼接其他候选的最佳结果。

修改前官方规则复核见COMPLIANCE_PRECHECK.txt。
本地验证：6项Python流程/文件绑定/报告测试，28项Tcl stub；非服务器EDA/LEC。
