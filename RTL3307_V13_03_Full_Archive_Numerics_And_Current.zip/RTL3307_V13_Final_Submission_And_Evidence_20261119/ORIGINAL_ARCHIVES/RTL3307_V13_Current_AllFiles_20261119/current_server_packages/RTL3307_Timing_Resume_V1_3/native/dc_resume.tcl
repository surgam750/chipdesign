# Isolated incremental optimization of the completed Resume V1.2 mapped DDC.
# Add 0.05 ns synthesis setup margin; seven-corner evaluation uses the original SDC.
source [file join [file dirname [info script]] common.tcl]

proc dc_call {body} {
    set result [uplevel 1 $body]
    if {[string is boolean -strict $result] && !$result} {error "Command failed: $body"}
    return $result
}
proc numeric_equal {actual expected label} {
    if {![string is double -strict $actual] ||
        [catch {expr {abs(double($actual) - double($expected)) <= 1.0e-6}} valid] || !$valid} {
        error "$label unexpected: $actual; expected $expected"
    }
    return $actual
}
proc clock_waveform_pair {raw name phase} {
    # DC list-valued attributes can be returned directly or once per object.
    # Normalize representation only; do not default or modify clock edges.
    puts "RESUME_CLOCK_WAVEFORM_RAW phase=$phase name=$name raw=[list $raw]"
    if {[catch {llength $raw} count]} {
        error "Malformed waveform list: $name raw=[list $raw]"
    }
    set wave $raw
    set shape FLAT
    if {$count == 1} {
        set wave [lindex $raw 0]
        set shape SINGLETON_WRAPPED
        if {[catch {llength $wave} count]} {
            error "Malformed wrapped waveform list: $name raw=[list $raw]"
        }
    }
    if {$count != 2} {error "Unexpected waveform shape: $name raw=[list $raw]"}
    puts "RESUME_CLOCK_WAVEFORM_SHAPE phase=$phase name=$name shape=$shape normalized=[list $wave]"
    return $wave
}
proc waveform_fall_equal {actual expected label} {
    # Keep the original numeric check whenever the attribute retains precision.
    if {![catch {numeric_equal $actual $expected $label} exact]} {return $exact}
    # Native DC was observed returning {0 3.33333}. A list token is compared
    # only to the expected value rendered at the token's own precision.
    # This is representation equality, not a new timing tolerance or clock edit.
    if {![regexp {^[+]?([0-9]*\.?[0-9]+)([eE][+-]?[0-9]+)?$} $actual unused mantissa exponent]} {
        error "$label unexpected: $actual; expected $expected"
    }
    set digits [string trimleft [string map {. {}} $mantissa] 0]
    set precision [string length $digits]
    if {$precision < 6 || $precision > 17} {
        error "$label unexpected: $actual; expected $expected; unsupported display precision $precision"
    }
    set rounded [format %.*g $precision $expected]
    if {[catch {expr {double($actual) == double($rounded)}} equal] || !$equal} {
        error "$label unexpected: $actual; expected $expected ($precision-digit display $rounded)"
    }
    puts "RESUME_WAVEFORM_FALL_DISPLAY_MATCH label={$label} observed=$actual expected=$expected display=$rounded precision=$precision; not_full_precision_identity"
    return $actual
}
proc clock_check {phase setup hold} {
    if {[sizeof_collection [all_clocks]] != 2} {error "Exactly two inherited clocks required"}
    foreach {name period} {hfclk 6.666666667 lfclk 30517.578125} {
        set clock [get_clocks -quiet $name]
        if {[sizeof_collection $clock] != 1} {error "Missing or ambiguous inherited clock: $name"}
        set actual_period [numeric_equal [get_attribute $clock period] $period "$name period"]
        set actual_setup [numeric_equal [get_attribute $clock setup_uncertainty] $setup "$name setup uncertainty"]
        set actual_hold [numeric_equal [get_attribute $clock hold_uncertainty] $hold "$name hold uncertainty"]
        set wave [clock_waveform_pair [get_attribute $clock waveform] $name $phase]
        numeric_equal [lindex $wave 0] 0 "$name rise edge"
        waveform_fall_equal [lindex $wave 1] [expr {$period / 2.0}] "$name fall edge"
        puts "RESUME_CLOCK phase=$phase name=$name period=$actual_period setup=$actual_setup hold=$actual_hold waveform={$wave}"
    }
    numeric_equal [get_attribute [current_design] max_transition] 0.25 "inherited top max_transition"
}
proc priority_check {phase} {
    set desired {max_transition max_fanout max_capacitance max_delay min_delay}
    set raw [get_attribute [current_design] cost_priority]
    set observed {}
    foreach cost $raw {if {$cost in $desired} {lappend observed $cost}}
    if {$observed ne $desired} {error "Incremental priority readback mismatch: $raw"}
    puts "RESUME_COST_PRIORITY phase=$phase order=[join $observed ,] raw={$raw}"
}
proc target_setup_reports {phase} {
    # These endpoint-only reports diagnose DC/PT correlation. They do not add
    # path groups, exceptions, budgets, or optimization directives.
    set targets [required setup_targets]
    if {[lsort [dict keys $targets]] ne {itcm_A itcm_GWEN post}} {
        error "Exactly the three selected setup diagnostic endpoints are required"
    }
    dict for {label target} $targets {
        set matched {}
        # First try the original full name. Some tool versions treat brackets
        # as pattern characters, so retry their escaped form if needed.
        set patterns [list $target]
        regsub -all {\[} $target {\\[} escaped
        regsub -all {\]} $escaped {\\]} escaped
        if {$escaped ne $target} {lappend patterns $escaped}
        foreach pattern $patterns {
            set candidates [get_pins -quiet [list $pattern]]
            foreach_in_collection pin $candidates {
                if {[get_object_name $pin] eq $target} {
                    set matched [add_to_collection $matched $pin]
                }
            }
            if {[sizeof_collection $matched] > 0} {break}
        }
        set count [sizeof_collection $matched]
        redirect -file "target_${phase}_${label}.rpt" {
            puts "TARGET_PHASE=$phase TARGET_LABEL=$label TARGET_PIN=$target"
            puts "TARGET_EXACT_MATCHES=$count"
            if {$count == 1} {
                puts "TARGET_STATUS=EXACT_ENDPOINT_QUERY; not same-path identity"
                report_timing -to $matched -delay_type max -max_paths 1 \
                    -path_type full_clock_expanded -significant_digits 9
            } else {
                puts "TARGET_STATUS=MISSING_OR_CHANGED; no unconstrained fallback query"
            }
        }
    }
}
proc dc_binding {path maximum} {
    set expected_files [list [dict get $maximum standard]]
    foreach macro [lsort [dict keys [dict get $maximum macros]]] {
        lappend expected_files [dict get $maximum macros $macro]
    }
    set allowed [dict create]
    foreach db $expected_files {
        set cells [get_lib_cells -quiet [list "${db}:*/*"]]
        if {[sizeof_collection $cells] == 0} {error "Missing SS3 file-qualified library: $db"}
        set library [get_libs -quiet -of_objects $cells]
        if {[sizeof_collection $library] != 1} {error "Ambiguous SS3 library: $db"}
        dict set allowed $db $library
    }
    set f [open $path w]
    puts $f "instance\treference\tlibrary_cell\tlibrary\texpected_db"
    set count 0
    foreach_in_collection cell [get_cells -hierarchical -filter {is_hierarchical == false}] {
        set ref [get_attribute $cell ref_name]
        if {$ref in {**logic_0** **logic_1**}} {continue}
        set db [dict get $maximum standard]
        if {[dict exists $maximum macros $ref]} {set db [dict get $maximum macros $ref]}
        set bound [get_lib_cells -quiet -of_objects $cell]
        if {[sizeof_collection $bound] != 1} {error "Unresolved leaf binding: [get_object_name $cell]"}
        set library [get_libs -quiet -of_objects $bound]
        if {[sizeof_collection $library] != 1 ||
            [compare_collections $library [dict get $allowed $db]] != 0} {
            error "Non-SS3 library binding: [get_object_name $cell]"
        }
        puts $f "[get_object_name $cell]\t$ref\t[get_object_name $bound]\t[get_object_name $library]\t$db"
        incr count
    }
    close $f
    if {$count == 0} {error "Empty mapped library binding inventory"}
}

finish {
    set expected [dict create RAMSP128X16 1088 RAMSP4096X16 64 RAMSP8KX32 8]
    if {[required max_corner] ne "SS3" || [required min_corner] ne "SS3"} {
        error "Incremental baseline requires inherited SS3 max and min configuration"
    }
    if {[lsort [dict keys [required expected_macros]]] ne [lsort [dict keys $expected]]} {
        error "Wrong inherited macro inventory"
    }
    dict for {name count} $expected {
        if {[dict get [required expected_macros] $name] != $count} {error "Wrong macro count: $name"}
    }
    set maximum [required maximum]
    set minimum [required minimum]
    if {$maximum ne $minimum || [required max_op] ne [required min_op]} {
        error "Resume does not alter inherited max/min library configuration"
    }
    if {[required standard] ne [dict get $maximum standard] ||
        [required op_library] ne [dict get [required max_op] library] ||
        [required op_condition] ne [dict get [required max_op] condition]} {
        error "Inherited standard/operating condition mismatch"
    }
    set expected_libraries [list [dict get $maximum standard]]
    foreach macro [lsort [dict keys $expected]] {
        lappend expected_libraries [dict get $maximum macros $macro]
    }
    if {[lsort -unique [required libraries]] ne [lsort -unique $expected_libraries]} {
        error "Resume libraries differ from exact inherited SS3 set"
    }
    foreach path [concat [required libraries] [list [required resume_ddc]]] {
        if {![file isfile $path] || [file size $path] == 0} {error "Missing inherited input: $path"}
    }
    if {[file normalize [required resume_ddc]] eq [file normalize design.ddc]} {
        error "Refusing to overwrite parent DDC"
    }
    foreach output {design.v design.ddc incremental.svf emitted.sdc pre_emitted.sdc constraints.rpt pre_constraints.rpt} {
        if {[file exists $output]} {error "Refusing existing incremental output: $output"}
    }
    set setup [required setup_margin]
    set hold [required hold_margin]
    if {![string is double -strict $setup] || ![string is double -strict $hold] ||
        $setup != 0.35 || $hold != 0.05} {
        error "This experiment requires synthesis setup 0.35 and hold 0.05"
    }
    set setup [format %.2f $setup]
    set hold [format %.2f $hold]
    dc_call {setup_library DC}
    dc_call {set_app_var link_library [concat [list *] [required libraries]]}
    dc_call {set_svf incremental.svf}
    dc_call {read_ddc [required resume_ddc]}
    current_design e203_soc_top
    if {[get_object_name [current_design]] ne "e203_soc_top"} {error "Wrong inherited top"}
    if {![link]} {error "DDC relink failed"}
    macro_check
    dc_binding pre_library_binding.rpt $maximum
    clock_check inherited 0.30 0.05
    dc_call {write_sdc pre_emitted.sdc}
    redirect -file pre_operating_conditions.rpt {report_design}
    redirect -file pre_clocks.rpt {report_clock}
    redirect -file pre_constraints.rpt {report_constraint -all_violators}
    redirect -file pre_setup.rpt {report_timing -delay_type max -max_paths 20 -path_type full -significant_digits 9}
    redirect -file pre_hold.rpt {report_timing -delay_type min -max_paths 20 -path_type full -significant_digits 9}
    target_setup_reports pre
    puts "RESUME_PARENT_PRIORITY raw={[get_attribute [current_design] cost_priority]}"
    # A clock margin is synthesis-only and must be an explicitly selected cfg value.
    if {$setup ne "0.30"} {dc_call [list set_clock_uncertainty -setup $setup [all_clocks]]}
    if {$hold ne "0.05"} {dc_call [list set_clock_uncertainty -hold $hold [all_clocks]]}
    clock_check pre_compile $setup $hold
    target_setup_reports margin
    dc_call {set_cost_priority {max_transition max_fanout max_capacitance max_delay min_delay}}
    priority_check pre_compile
    dc_call {set_ungroup [get_cells -hierarchical -filter {is_hierarchical == true}] false}
    foreach clock {hfclk lfclk} {dc_call [list set_fix_hold [get_clocks -quiet $clock]]}
    # Supported gate-level incremental mapping; no fresh analyze/elaborate/compile.
    if {![compile_ultra -incremental -no_autoungroup]} {error "Incremental compile failed"}
    priority_check post_compile
    clock_check post_compile $setup $hold
    macro_check
    dc_binding library_binding.rpt $maximum
    redirect -file check_design.rpt {if {![check_design]} {error "check_design failed"}}
    redirect -file check_timing.rpt {check_timing}
    redirect -file operating_conditions.rpt {report_design}
    redirect -file clocks.rpt {report_clock}
    redirect -file constraints.rpt {report_constraint -all_violators}
    redirect -file setup.rpt {report_timing -delay_type max -max_paths 20 -path_type full -significant_digits 9}
    redirect -file hold.rpt {report_timing -delay_type min -max_paths 20 -path_type full -significant_digits 9}
    target_setup_reports post
    redirect -file area.rpt {report_area -hierarchy}
    redirect -file reference.rpt {report_reference -hierarchy}
    cell_area cells.tsv
    dc_call {write -format verilog -hierarchy -output design.v}
    dc_call {write -format ddc -hierarchy -output design.ddc}
    dc_call {write_sdc emitted.sdc}
    dc_call {set_svf -off}
    puts RESUME_DDC_INCREMENTAL_COMPLETE_NOT_TIMING_PASS
}
