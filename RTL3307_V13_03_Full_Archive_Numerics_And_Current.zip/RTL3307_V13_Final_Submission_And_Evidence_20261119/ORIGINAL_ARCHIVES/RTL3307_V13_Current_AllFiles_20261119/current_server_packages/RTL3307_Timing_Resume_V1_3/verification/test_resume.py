"""SYNTHETIC controller/report tests. No licensed tool or native measurement."""
import argparse
from collections import Counter
import contextlib
import io
import json
from pathlib import Path
import runpy
import sys
import tempfile
import unittest
from unittest import mock

ap = argparse.ArgumentParser(add_help=False)
ap.add_argument('--parent-package', required=True)
args, rest = ap.parse_known_args()
sys.argv = [sys.argv[0]] + rest
BASE = Path(__file__).resolve().parents[1]
runner = runpy.run_path(str(BASE / 'run_resume.py'))
support = runpy.run_path(str(BASE / 'report_support.py'))
parent = Path(args.parent_package).resolve()
parse = runpy.run_path(str(parent / 'verification/support/sta_marked_rows.py'))['parse_text']
paths = runpy.run_path(str(parent / 'verification/support/native_path_views.py'))['native_paths']
CONSTRAINTS = '''SYNTHETIC NOT A NATIVE MEASUREMENT
Report : constraint -all_violators
max_delay/setup ('hfclk' group)
u_kwt_accel/q/D 6.0 6.1 -0.1 (VIOLATED)
min_delay/hold ('hfclk' group)
u_e203_dtcm_ram/ram/D[0] 0.4 0.2 -0.2 (VIOLATED)
removal ('async_default' group)
u_sirv_pmu/reset/SDN 0.8 0.0 -0.8 (VIOLATED)
max_transition
u_kwt_accel/sel 0.3 0.6 -0.3 (VIOLATED)
'''
PATH = '''SYNTHETIC NOT A NATIVE MEASUREMENT
Startpoint: first/Q
Endpoint: gate/EN
Path Group: clock_gating_default
Path Type: max
clock gating setup time 0.0
data required time 0.0
data arrival time 0.0
slack (MET) 0.000000000
Startpoint: must_not_mix/Q
Endpoint: second/D
library setup time -0.1
slack (MET) 0.25
'''


def put(folder, name, text):
    path = folder / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')


def fixture(folder, constraints=CONSTRAINTS):
    put(folder, 'constraints.rpt', constraints)
    put(folder, 'timing.tsv', 'delay_type\tworst_slack_ns\nmax\t0.0\nmin\t-0.8\n')
    put(folder, 'setup.rpt', PATH)
    put(folder, 'coverage.rpt', 'Type of Check Total Met Violated Untested\nsetup 10 8 (80%) 1 (10%) 1 (10%)\nhold 10 8 (80%) 1 (10%) 1 (10%)\n')


def previous_fixture(base):
    """A synthetic sealed V1.2 inventory, using real on-disk SHA bindings."""
    previous = base / 'R2RTL3307_RESUME_V1_2_20261118_212948_SYNTHETIC'
    source = base / 'targetfix'
    bundle = base / 'v12_bundle'
    core_hashes = {}
    consumed_files = {}
    for name in ('run_resume.py', 'report_support.py', 'native/dc_resume.tcl', 'native/common.tcl'):
        put(bundle, name, 'SYNTHETIC reviewed-source fixture: ' + name + '\n')
        core_hashes[name] = runner['sha'](bundle / name)
        consumed_files[str(bundle / name)] = core_hashes[name]
    for name in ('payload/result/dc_soc/design.svf', 'payload/result/sysbus.sdc'):
        put(source, name, 'SYNTHETIC ancestor input: ' + name + '\n')
        consumed_files[str(source / name)] = runner['sha'](source / name)
    receipts = []
    dc_files = ('design.ddc', 'design.v', 'incremental.svf', 'emitted.sdc', 'pre_emitted.sdc',
                'config.tcl', 'library_binding.rpt', 'operating_conditions.rpt',
                'constraints.rpt', 'setup.rpt', 'hold.rpt')
    pt_files = ('constraints.rpt', 'setup.rpt', 'hold.rpt', 'coverage.rpt',
                'timing.tsv', 'units.rpt', 'load_reference.rpt', 'config.tcl')
    stages = [(previous / 'dc_soc', dc_files)] + [
        (previous / 'sta' / corner, pt_files) for corner in runner['CORNERS']]
    for folder, names in stages:
        for name in names:
            put(folder, name, 'SYNTHETIC output: ' + str(folder / name) + '\n')
        receipts.append({'folder': str(folder), 'files': {
            str(folder / name): runner['sha'](folder / name) for name in names}})
    runner['save'](previous / 'receipts.json', receipts)
    runner['save'](previous / 'input_snapshot.json', runner['snapshot'](consumed_files))
    state = {'status': 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED',
             'output': str(previous), 'parent_run': str(source), 'errors': {},
             'original_consumed_inputs_unchanged': True,
             'setup_margin': 0.30, 'hold_margin': 0.05,
             'eval_sdc': str(source / 'payload/result/sysbus.sdc'),
             'receipts_sha256': runner['sha'](previous / 'receipts.json'),
             'corners': {corner: {'status': 'PARSED_MARKED_ROWS'} for corner in runner['CORNERS']},
             'svf_chain': [str(source / 'payload/result/dc_soc/design.svf'),
                           str(previous / 'dc_soc/incremental.svf')]}
    runner['save'](previous / 'state.json', state)
    return previous, source, core_hashes


def target_fixture(phase, label, pin):
    return '''SYNTHETIC TIMING FORMAT FIXTURE; NOT A NATIVE MEASUREMENT
TARGET_PHASE={phase} TARGET_LABEL={label} TARGET_PIN={pin}
TARGET_EXACT_MATCHES=1
TARGET_STATUS=EXACT_ENDPOINT_QUERY; not same-path identity
Startpoint: u_kwt_accel/shift_reg[0]
Endpoint: {endpoint}
Path Group: hfclk
Path Type: max
Point                                              Incr         Path
--------------------------------------------------------------------
clock hfclk (rise edge)                     0.000000000  0.000000000
clock network delay (ideal)                 0.000000000  0.000000000
u_kwt_accel/shift_reg[0]/Q (DQV0_12TR40)     0.329261303  0.329261303 r
u_kwt_accel/U1/Z (BUF_12TR40)               6.051352978  6.380614281 r
{pin} (DQV2_12TR40)                        0.000000000  6.380614281 r
data arrival time                                       6.380614281
clock hfclk (rise edge)                     6.666666508  6.666666508
clock uncertainty                         -0.300000012  6.366666317
library setup time                         0.000907950  6.367574215
data required time                                      6.367574215
slack (VIOLATED)                                        -0.013039835
'''.format(phase=phase, label=label, pin=pin, endpoint=pin.rsplit('/', 1)[0])


class ResumeTests(unittest.TestCase):
    def test_target_samples_require_matching_header_last_pin_and_complete_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            pins = {'post': 'u_kwt_accel/u_post/out_data_reg[7]/D',
                    'itcm_A': 'u_e203_itcm_ram/u_ram/A[2]',
                    'itcm_GWEN': 'u_e203_itcm_ram/u_ram/GWEN'}
            for label, pin in pins.items():
                for phase in ('pre', 'margin', 'post'):
                    put(folder, 'target_%s_%s.rpt' % (phase, label), target_fixture(phase, label, pin))
            selected = support['target_reports'](folder, paths)
            for phases in selected.values():
                for row in phases.values():
                    self.assertEqual(row['status'], 'COMPLETE_EXACT_ENDPOINT_SAMPLE')
                    self.assertEqual(row['slack_native'], '-0.013039835')
                    self.assertEqual(row['arrival_native'], '6.380614281')
                    self.assertEqual(row['required_native'], '6.367574215')
                    self.assertEqual(row['checks'], ['setup'])
            file = folder / 'target_pre_post.rpt'
            valid = target_fixture('pre', 'post', pins['post'])
            variants = [
                valid.replace('TARGET_STATUS=EXACT_ENDPOINT_QUERY;', 'TARGET_STATUS=MISSING_OR_CHANGED;'),
                valid.replace('TARGET_LABEL=post', 'TARGET_LABEL=itcm_A'),
                valid.replace('TARGET_EXACT_MATCHES=1', 'TARGET_EXACT_MATCHES=2'),
                valid.replace(pins['post'] + ' (DQV2_12TR40)', 'another_register/D (DQV2_12TR40)'),
                valid.rsplit('slack (VIOLATED)', 1)[0],
            ]
            for text in variants:
                file.write_text(text)
                row = support['target_reports'](folder, paths)['post']['pre']
                self.assertEqual(row['status'], 'UNKNOWN_OR_MISSING_SAMPLE')
                self.assertEqual(row['slack_native'], 'UNKNOWN')

    def test_previous_selection_requires_unique_timestamp_and_explicit_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            previous, source, hashes = previous_fixture(base)
            self.assertEqual(runner['select_previous_run'](str(previous)), previous)
            with mock.patch.object(Path, 'glob', return_value=[previous]):
                self.assertEqual(runner['select_previous_run'](), previous)
            for found in ([], [previous, previous]):
                with mock.patch.object(Path, 'glob', return_value=found):
                    with self.assertRaisesRegex(ValueError, 'Exactly one'):
                        runner['select_previous_run']()
            with self.assertRaisesRegex(ValueError, 'Not the selected V1.2'):
                runner['select_previous_run'](str(source))

    def test_previous_evidence_binds_ddc_netlist_svf_receipts_and_source_inputs(self):
        cases = ('success', 'ddc', 'netlist', 'svf', 'receipt', 'ancestor_sdc',
                 'missing_corner', 'wrong_core', 'wrong_svf_chain')
        for case in cases:
            with self.subTest(case=case), tempfile.TemporaryDirectory() as tmp:
                previous, source, hashes = previous_fixture(Path(tmp))
                state = runner['load'](previous / 'state.json')
                if case in ('ddc', 'netlist', 'svf'):
                    name = {'ddc': 'design.ddc', 'netlist': 'design.v', 'svf': 'incremental.svf'}[case]
                    (previous / 'dc_soc' / name).write_text('tampered output\n')
                elif case == 'receipt':
                    (previous / 'receipts.json').write_text('[]\n')
                elif case == 'ancestor_sdc':
                    (source / 'payload/result/sysbus.sdc').write_text('changed evaluation constraints\n')
                elif case == 'missing_corner':
                    del state['corners']['SS3']
                    runner['save'](previous / 'state.json', state)
                elif case == 'wrong_core':
                    hashes = dict(hashes, **{'run_resume.py': '0' * 64})
                elif case == 'wrong_svf_chain':
                    state['svf_chain'].reverse()
                    runner['save'](previous / 'state.json', state)
                with mock.patch.dict(runner['previous_evidence'].__globals__, {'PREVIOUS_CORE_HASHES': hashes}):
                    if case == 'success':
                        result = runner['previous_evidence'](previous, source)
                        self.assertEqual(result['svf_chain'], state['svf_chain'])
                        for name in ('design.ddc', 'design.v', 'incremental.svf'):
                            path = previous / 'dc_soc' / name
                            self.assertEqual(result['expected'][str(path)], runner['sha'](path))
                        runner['verify_snapshot'](runner['snapshot'](result['expected']))
                    else:
                        with self.assertRaises(ValueError):
                            runner['previous_evidence'](previous, source)

    def test_native_failure_keeps_error_before_long_stack_tail(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            script = base / 'synthetic_failure.sh'
            error = 'NATIVE_ERROR: Unexpected waveform shape: hfclk raw={{0 1 2 3}}'
            lines = ["printf '%s\\n' 'RESUME_CLOCK_WAVEFORM_RAW phase=inherited name=hfclk raw={{0 1 2 3}}'",
                     "printf '%s\\n' '" + error + "'"]
            lines += ["printf '%%s\\n' 'SYNTHETIC_STACK_LINE_%d'" % i for i in range(25)]
            lines += ['exit 1']
            script.write_text('\n'.join(lines) + '\n')
            ctx = {'driver': {'tcl': lambda value: '{}'},
                   'config': {'tools': {'DC': '/bin/sh', 'LC': '/bin/sh'}}}
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                with self.assertRaisesRegex(ValueError, 'Native tool failed'):
                    runner['invoke'](ctx, 'DC', script, base / 'native', {}, 10, ())
            text = output.getvalue()
            self.assertIn(error, text)
            self.assertIn('RESUME_NATIVE_WAVEFORM_CONTEXT', text)
            self.assertIn('RESUME_NATIVE_LOG_TAIL', text)
            self.assertNotIn(error, text.split('RESUME_NATIVE_LOG_TAIL', 1)[1])

    def test_typed_reports_zero_query_and_partial_never_fabricate_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            fixture(folder)
            row = support['corner_report'](folder, parse, paths)
            self.assertEqual(row['status'], 'PARSED_MARKED_ROWS')
            self.assertEqual(row['typed']['hold']['worst_marked_native'], '-0.2')
            self.assertEqual(row['typed']['removal']['worst_marked_native'], '-0.8')
            self.assertEqual(row['query_slack_native']['max'], '0.0')
            self.assertEqual(row['first_max_sample']['checks'], ['clock_gating_setup'])
            self.assertEqual(row['first_max_sample']['end'], 'gate/EN')
            self.assertEqual(row['untested'], {'setup': 1, 'hold': 1})
            fixture(folder, 'Report : constraint -all_violators\nmax_skew\nu/a -0.1 (VIOLATED)\nmax_transition\n(VIOLATED)\n')
            row = support['corner_report'](folder, parse, paths)
            self.assertEqual(row['status'], 'PARTIAL_PARSE')
            self.assertEqual(row['unparsed_count'], 1)
            self.assertEqual(row['unknown_section_count'], 1)
            self.assertIsNone(row['typed']['setup']['count'])
            self.assertEqual(row['typed']['setup']['worst_marked_native'], 'UNKNOWN')

    def test_isolated_success_native_failure_and_parent_change_states(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            original = base / 'targetfix'
            previous = base / 'resume_v12'
            put(original, 'dc_soc/design.v', 'module ancestor; endmodule\n')
            put(original, 'dc_soc/design.svf', 'SYNTHETIC original guidance\n')
            put(original, 'sysbus.sdc', 'SYNTHETIC PT uncertainty .30/.05; period 6.666666667\n')
            put(previous, 'dc_soc/design.v', 'module old; endmodule\n')
            put(previous, 'dc_soc/design.ddc', 'SYNTHETIC resume V1.2 DDC\n')
            put(previous, 'dc_soc/incremental.svf', 'SYNTHETIC V1.2 guidance\n')
            lock = previous / 'dc_soc/design.v'
            original_bytes = lock.read_bytes()
            old_counts = {'setup': 960, 'hold': 71, 'removal': 5, 'transition': 0}
            ctx = {'run': previous, 'previous_run': previous, 'source_run': original,
                   'result': original, 'package': original,
                   'baseline_netlist': previous / 'dc_soc/design.v',
                   'svf_chain': [str(original / 'dc_soc/design.svf'),
                                 str(previous / 'dc_soc/incremental.svf')],
                   'config': {}, 'dc_values': {'resume_ddc': str(previous / 'dc_soc/design.ddc'),
                                              'setup_margin': 0.35, 'hold_margin': 0.05,
                                              'setup_targets': {'post': 'u_kwt_accel/out_data_reg[7]/D',
                                                                'itcm_A': 'itcm/ram/A[2]',
                                                                'itcm_GWEN': 'itcm/ram/GWEN'}},
                   'pt_values': {c: {'sdc': str(original / 'sysbus.sdc'), 'corner': c}
                                 for c in runner['CORNERS']},
                   'parse': parse, 'native_paths': paths,
                   'driver': {'PT_FILES': ('constraints.rpt', 'timing.tsv', 'setup.rpt', 'coverage.rpt'),
                              'MACROS': {'SYNTHETIC': 1},
                              'area': lambda p: {'total_um2': 1, 'macros': {'SYNTHETIC': 1}}},
                   'parent': {'corners': {c: {'counts': dict(old_counts)} for c in runner['CORNERS']}}}
            for mode in ('success', 'native_failure', 'parent_change', 'stale_before_start'):
                lock.write_bytes(original_bytes)
                ctx['locked'] = runner['snapshot']({str(lock): runner['sha'](lock)})
                if mode == 'stale_before_start':
                    lock.write_text('changed before execution\n')
                output = base / mode
                output.mkdir()
                calls = []
                def stub(context, name, script, folder, values, timeout, required, marker=None):
                    calls.append(name)
                    folder.mkdir(parents=True)
                    if name == 'DC':
                        self.assertEqual(values['resume_ddc'], str(previous / 'dc_soc/design.ddc'))
                        self.assertEqual(values['setup_margin'], 0.35)
                        self.assertEqual(values['hold_margin'], 0.05)
                    else:
                        self.assertNotIn('setup_margin', values)
                        self.assertNotIn('hold_margin', values)
                        self.assertEqual(values['sdc'], str(original / 'sysbus.sdc'))
                        self.assertEqual(values['netlist'], str(output / 'dc_soc/design.v'))
                    if name == 'DC' and mode == 'native_failure':
                        raise ValueError('SYNTHETIC DC failure')
                    for filename in required:
                        put(folder, filename, 'SYNTHETIC output\n')
                    if name == 'DC':
                        # Identical to V1.2 but different from TARGETFIX: a wrong
                        # ancestor comparison would falsely claim a change.
                        put(folder, 'design.v', 'module old; endmodule\n')
                        if mode == 'parent_change':
                            lock.write_text('changed parent\n')
                    else:
                        fixture(folder)
                    return {'folder': str(folder), 'files': {str(p): runner['sha'](p) for p in folder.iterdir()}}
                with contextlib.redirect_stdout(io.StringIO()):
                    state = runner['execute'](ctx, output, 4, 10, support, stub)
                self.assertFalse(state['acceptance'])
                self.assertFalse(state['signoff_achieved'])
                self.assertEqual(calls.count('DC'), 0 if mode == 'stale_before_start' else 1)
                if mode == 'success':
                    self.assertEqual(state['status'], 'RESUME_SEVEN_REPORTS_COMPLETE_REVIEW_REQUIRED')
                    self.assertEqual(calls.count('PT'), 7)
                    self.assertEqual(lock.read_bytes(), original_bytes)
                    self.assertFalse(state['netlist_body_changed'])
                    self.assertEqual(state['svf_chain'], ctx['svf_chain'] +
                                     [str(output / 'dc_soc/incremental.svf')])
                    self.assertEqual(state['setup_margin'], 0.35)
                    self.assertEqual(state['hold_margin'], 0.05)
                    summary = (output / 'summary.txt').read_text()
                    self.assertIn('setup:960->1', summary)
                else:
                    self.assertEqual(state['status'], 'RESUME_FAILED_NO_ACCEPTANCE')
                    self.assertEqual(calls.count('PT'), 0)
                    if mode in ('parent_change', 'stale_before_start'):
                        self.assertFalse(state['original_consumed_inputs_unchanged'])
                self.assertEqual(json.loads((output / 'state.json').read_text())['status'], state['status'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
