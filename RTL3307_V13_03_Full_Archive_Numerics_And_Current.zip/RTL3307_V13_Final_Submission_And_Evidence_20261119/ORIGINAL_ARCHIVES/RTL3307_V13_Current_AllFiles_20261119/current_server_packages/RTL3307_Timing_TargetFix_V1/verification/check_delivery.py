#!/usr/bin/env python3
"""Verify the isolated counter/A-GWEN/priority candidate and its exact authorized source delta.

No VCS, PDK, DC or PrimeTime is invoked. This never certifies timing closure.
The GLOBSLEW025 parent is a byte/hash reference, never a new candidate result.
"""
import hashlib
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PAYLOAD = ROOT / 'payload'
CANDIDATE = 'RTL3307_TCM128_TARGETFIX_V1'
PARENT = 'RTL3307_TCM128_GLOBSLEW025_V1'
PARENT_MANIFEST_SHA256 = '732c526fb39b4ee51355bca27ce1b6ca529d92e523a89d2fb12535c301ec8da3'
CTRL = 'frozen/rtl/accel/kwt_ctrl.v'
CORE_KEY = 'rtl/accel/kwt_ctrl.v'
CORE_MAPS = ('tools/w12_core_sha256.json', 'native/support/w12_core_sha256.json')
PROXY = 'native/support/kwt_tcm_proxy.v'
IDENTITY_SOURCES = ('pipeline.py', 'server/rtl_driver.py', 'native/driver.py',
                    'formality/driver.py', 'power/driver.py')
ALLOWED_CHANGES = set(IDENTITY_SOURCES) | set(CORE_MAPS) | {CTRL, PROXY, 'native/support/hashes.json', 'native/dc.tcl', 'source_identity.json'}
PARENT_CONTROLLER_SHA256 = '0dbc47dc193a572e44b54ba8b1c3ea23ebf73605049266602cb3ad686171e922'
EXPECTED_CONTROLLER_SHA256 = '72d4d8668ad6affd59d8ea09d7b3c6d2c1b3d55d85fb15002cf2ba4f48301d47'
EXPECTED_DC_SHA256 = 'befdb6e94607a59db8712f71f72ab1b62591b10482bf9ef7382953163f8322a9'
EXPECTED_PROXY_SHA256 = 'bc63c6b1ac488e63d5ed5adee013cd04c4fe3277096145f2d2b654acc1def4e0'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def baseline_manifest():
    path = ROOT / 'baseline/payload_manifest.json'
    require(sha(path) == PARENT_MANIFEST_SHA256, 'GLOBSLEW025 parent manifest changed')
    baseline = json.loads(path.read_text(encoding='utf-8'))
    require(baseline['candidate_id'] == PARENT, 'Wrong baseline candidate')
    return baseline


def baseline_bytes(rel, baseline=None):
    baseline = baseline or baseline_manifest()
    path = ROOT / 'baseline/files' / rel
    require(sha(path) == baseline['files'][rel], 'Parent source reference changed: ' + rel)
    return path.read_bytes()


def payload_hashes():
    files = {}
    for path in sorted(PAYLOAD.rglob('*')):
        require(not path.is_symlink(), 'Symlink in candidate payload: ' + str(path))
        if path.is_file() and '__pycache__' not in path.parts and path.suffix not in ('.pyc', '.pyo'):
            rel = path.relative_to(PAYLOAD).as_posix()
            if rel != 'payload_manifest.json':
                files[rel] = sha(path)
    return files


def check_controller(baseline=None):
    baseline = baseline or baseline_manifest()
    before = baseline_bytes(CTRL, baseline)
    candidate = (PAYLOAD / CTRL).read_bytes()
    require(hashlib.sha256(before).hexdigest() == PARENT_CONTROLLER_SHA256, 'Wrong parent controller')
    require(sha(PAYLOAD / CTRL) == EXPECTED_CONTROLLER_SHA256, 'Controller differs from frozen TARGETFIX source')
    return before, candidate


def check_proxy(baseline=None):
    baseline = baseline or baseline_manifest()
    before = baseline_bytes(PROXY, baseline)
    require(hashlib.sha256(before).hexdigest() == 'bae98efafae6bf03fa2eafb9feb053baafc4167fdd380305705c4a3570771cde', 'Wrong parent proxy')
    require(sha(PAYLOAD / PROXY) == EXPECTED_PROXY_SHA256, 'Proxy differs from frozen A/GWEN-only source')
    return before, (PAYLOAD / PROXY).read_bytes()


def check_dc(baseline=None):
    baseline = baseline or baseline_manifest()
    before = baseline_bytes('native/dc.tcl', baseline)
    require(hashlib.sha256(before).hexdigest() == '024214db5c50da69291178d8abc0aa90319be65799622e7309e01185e2e84cbd', 'Wrong parent DC source')
    require(sha(PAYLOAD / 'native/dc.tcl') == EXPECTED_DC_SHA256, 'DC differs from frozen priority-only source')
    return before, (PAYLOAD / 'native/dc.tcl').read_bytes()

def expected_core_map(baseline=None):
    baseline = baseline or baseline_manifest()
    first = json.loads(baseline_bytes(CORE_MAPS[0], baseline).decode('utf-8'))
    second = json.loads(baseline_bytes(CORE_MAPS[1], baseline).decode('utf-8'))
    require(first == second and len(first) == 13, 'Parent core maps disagree or have wrong file count')
    require(first[CORE_KEY] == PARENT_CONTROLLER_SHA256 == baseline['files'][CTRL],
            'Parent controller/core-map mismatch')
    first[CORE_KEY] = EXPECTED_CONTROLLER_SHA256
    return first

def expected_identity(files, baseline=None):
    baseline = baseline or baseline_manifest()
    identity = json.loads(baseline_bytes('source_identity.json', baseline).decode('utf-8'))
    identity.update({
        'candidate_id': CANDIDATE, 'parent_candidate_id': PARENT,
        'parent_payload_manifest_sha256': PARENT_MANIFEST_SHA256,
        'candidate_native_timing_status': 'NOT_RUN', 'candidate_rtl_functional_status': 'NOT_RUN',
        'timing_variant': 'GLOB parent; wr/sat counter prefixes; bank-qualified ITCM A/GWEN; explicit setup/hold-first cost priority; inherited DC0.25/PT0.30; native timing unverified',
        'reference_rtl_cycles_scope': 'Historical RTL3307_WRITEFAST behavioral-SoC observation only; not a TARGETFIX candidate measurement',
        'changed_parent_files': {rel: {'parent_sha256': baseline['files'][rel], 'candidate_sha256': files[rel]}
                                 for rel in sorted(ALLOWED_CHANGES - {'source_identity.json'})},
        'identity_metadata_change': 'TARGETFIX identity and exact GLOB-parent delta; inactive-bank A/GWEN pins differ, accepted operations retain intended semantics; no official platform certification claimed',
        'unchanged_parent_files': {rel: digest for rel, digest in baseline['files'].items() if rel not in ALLOWED_CHANGES},
    })
    identity['modified_archive_files']['tools/w12_core_sha256.json']['candidate_sha256'] = files[CORE_MAPS[0]]
    identity['modified_archive_files']['tools/w12_core_sha256.json']['reason'] = 'Update only the TARGETFIX controller entry; other twelve accelerator source hashes unchanged'
    return identity

def verify_source_delta(files=None):
    baseline = baseline_manifest()
    files = payload_hashes() if files is None else files
    require(set(files) == set(baseline['files']), 'Unexpected production file-set change')
    changed = {rel for rel, digest in baseline['files'].items() if files[rel] != digest}
    require(changed == ALLOWED_CHANGES,
            'Production delta differs from exact whitelist: missing=%r extra=%r' %
            (sorted(ALLOWED_CHANGES - changed), sorted(changed - ALLOWED_CHANGES)))
    check_controller(baseline)
    check_proxy(baseline)
    check_dc(baseline)
    for rel in IDENTITY_SOURCES:
        expected = baseline_bytes(rel, baseline).replace(PARENT.encode('ascii'), CANDIDATE.encode('ascii'))
        require((PAYLOAD / rel).read_bytes() == expected, 'Non-identity driver change: ' + rel)
    core = expected_core_map(baseline)
    for rel in CORE_MAPS:
        require(json.loads((PAYLOAD / rel).read_text(encoding='utf-8')) == core,
                'Core hash map contains changes beyond the approved controller: ' + rel)
    require((PAYLOAD / CORE_MAPS[0]).read_bytes() == (PAYLOAD / CORE_MAPS[1]).read_bytes(),
            'The two candidate core maps are not byte-identical')
    helper = json.loads(baseline_bytes('native/support/hashes.json', baseline).decode('utf-8'))
    helper['kwt_tcm_proxy.v'] = files[PROXY]
    helper['w12_core_sha256.json'] = files[CORE_MAPS[1]]
    require(json.loads((PAYLOAD / 'native/support/hashes.json').read_text(encoding='utf-8')) == helper,
            'Physical helper inventory changed beyond the proxy and accelerator-core-map digests')
    for rel, digest in helper.items():
        require(sha(PAYLOAD / 'native/support' / rel) == digest, 'Physical helper digest mismatch: ' + rel)
    identity = json.loads((PAYLOAD / 'source_identity.json').read_text(encoding='utf-8'))
    require(identity == expected_identity(files, baseline), 'Candidate provenance differs from the declared parent delta')
    for rel, digest in identity['unchanged_archive_files'].items():
        require(files[rel] == digest, 'Protected archive source changed: ' + rel)
    protected = set(files) - ALLOWED_CHANGES
    for rel in protected:
        require(files[rel] == baseline['files'][rel], 'Protected RDCOUNT source changed: ' + rel)
    return changed, protected


def main():
    manifest = json.loads((PAYLOAD / 'payload_manifest.json').read_text(encoding='utf-8'))
    require(manifest['candidate_id'] == CANDIDATE and manifest['parent_candidate_id'] == PARENT,
            'Wrong candidate or parent identity')
    files = payload_hashes()
    require(files == manifest['files'], 'Manifest file set or digest differs from candidate payload')
    changed, protected = verify_source_delta(files)
    actual = set(files) | {'payload_manifest.json'}
    entry_path = ROOT / 'r2rtl3307_tcm128_targetfix_v1.py'
    spec = importlib.util.spec_from_file_location('checked_timing_entry', str(entry_path))
    entry = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(entry)
    require(entry.TOKEN == 'R2RTL3307_TCM128_TARGETFIX_V1', 'Shared historical run namespace')
    raw = entry.read_payload()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        embedded = entry.members(archive)
        require(set(embedded) == actual, 'Embedded file set differs from payload')
        for rel, digest in embedded.items():
            require(sha(PAYLOAD / rel) == digest, 'Embedded source differs: ' + rel)
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'explicit_run' / 'payload'
            entry.install(target, archive, embedded)
            entry.verify_installed(target, embedded)
            victim = target / 'native/support/kwt_tcm_proxy.v'
            victim.write_bytes(victim.read_bytes() + b'\n// deliberate local tamper test\n')
            rejected = False
            try:
                entry.verify_installed(target, embedded)
            except ValueError:
                rejected = True
            require(rejected, 'Tampered installation was accepted')
            previous_base = entry.BASE
            previous_argv = sys.argv[:]
            entry.BASE = Path(directory) / 'must_not_create_a_fallback_run'
            rejection_cases = 0
            try:
                for arguments in (
                    ['check', '--run', str(target.parent)],
                    ['results', '--run', str(target.parent)],
                    ['results'],
                    ['results', '--fresh'],
                ):
                    sys.argv = [str(entry_path)] + arguments
                    rejected = False
                    with contextlib.redirect_stdout(io.StringIO()):
                        try:
                            entry.main()
                        except ValueError:
                            rejected = True
                    require(rejected, 'Invalid run selection was accepted: ' + repr(arguments))
                    require(not entry.BASE.exists(), 'Invalid run selection silently created a fallback run')
                    rejection_cases += 1
            finally:
                entry.BASE = previous_base
                sys.argv = previous_argv
    result = {
        'status': 'PASS', 'scope': 'LOCAL_DELIVERY_AND_EXACT_SOURCE_DELTA_ONLY',
        'candidate_id': CANDIDATE, 'parent_candidate_id': PARENT,
        'parent_manifest_sha256': PARENT_MANIFEST_SHA256,
        'payload_files': len(actual), 'changed_production_files': sorted(changed),
        'unchanged_parent_payload_files': len(protected), 'frozen_accelerator_sources_unchanged': 12,
        'changed_frozen_accelerator_sources': 1,
        'controller_sha256': sha(PAYLOAD / CTRL),
        'common_sta_sdc_and_macro_inputs_unchanged': True,
        'native_dc_sha256': sha(PAYLOAD / 'native/dc.tcl'),
        'tampered_installation_rejected': True,
        'invalid_explicit_or_absent_results_run_rejected_cases': rejection_cases,
        'candidate_proxy_sha256': sha(PAYLOAD / 'native/support/kwt_tcm_proxy.v'),
        'timing_closed': False, 'native_eda_run': False,
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
