#!/usr/bin/env python3
"""Synthetic summary input-binding tests; no EDA or real timing results."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('globslew025_summary', str(ROOT / 'show_result.py'))
summary = importlib.util.module_from_spec(spec)
spec.loader.exec_module(summary)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True), encoding='utf-8')


class SummaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='globslew025_summary_test_')
        self.run = Path(self.temp.name) / 'R2RTL3307_TCM128_TARGETFIX_V1_SYNTHETIC'
        self.payload = self.run / 'payload'
        shutil.copytree(str(ROOT / 'payload'), str(self.payload))
        self.result = self.payload / 'result'
        self.result.mkdir()
        self.files = {}
        for name in ('dc_soc/design.v', 'soc/physical_view.json', 'prepared.json', 'resolved_config.json'):
            self.write(name, 'synthetic fixture\n')
        self.write('dc_soc/globslew025_scope.tsv', 'status\tPRECHECKED_NOT_YET_APPLIED\ntop\te203_soc_top\nbefore\t0.300000012\nafter\t0.25\nstatus\tAPPLIED_AND_READBACK_VERIFIED\n')
        self.write('dc_soc/tool.log', 'GLOBSLEW025_SCOPE_VERIFIED top=e203_soc_top before=0.300000012 after=0.25 receipt=' + str(self.result / 'dc_soc/globslew025_scope.tsv') + '\n')
        self.write('dc_soc/tool.log', (self.result / 'dc_soc/tool.log').read_text() + ''.join('TARGETFIX_COST_PRIORITY_READBACK phase=%s top=e203_soc_top order=max_delay,min_delay,max_transition,max_fanout,max_capacitance raw={max_delay min_delay max_transition max_fanout max_capacitance}\n' % phase for phase in ('pre_compile', 'post_compile')))
        self.write('sysbus.sdc', (self.payload / 'native/sysbus.sdc').read_text())
        self.write('dc_soc/cells.tsv', 'instance\treference\tarea_um2\n' + ''.join(
            'u_e203_cpu_top/u_e203_itcm_ram/u_kwt_tcm/g_bank[%d].g_wide64.g_row[%d].g_slice[%d].u_ram\tRAMSP128X16\t1\n' % (b,r,s) for b in range(8) for r in range(32) for s in range(4)))
        self.metrics = {'candidate_id': summary.CANDIDATE,
                        'status': 'RTL3307_FULL7_REPORTS_COMPLETE_REVIEW_REQUIRED',
                        'timing': {}, 'soc': {'groups_um2': {'accelerator_logic': 100, 'accelerator_local_sram': 200, 'new_systembus_arbiter': 30, 'shared_controller_glue': 40, 'loader_dma': 50, 'platform_including_modified_ppi_irq': 1000}}}
        for corner in summary.CORNERS:
            marked = 'Report : constraint\n-all_violators\n'
            if corner == 'SS3':
                marked += ('max_delay/setup (hfclk group)\n'
                           'u_e203_cpu_top/u_e203_itcm_ram/u_kwt_tcm/g_bank[4].g_wide64.g_row[26].g_slice[2].u_ram/WEN[10] -0.003981659 (VIOLATED)\n')
            if corner in ('SS3', 'SS4'):
                marked += ('min_delay/hold (hfclk group)\n'
                           'u_e203_cpu_top/u_e203_itcm_ram/u_kwt_tcm/g_bank[4].g_wide64.g_row[26].g_slice[2].u_ram/WEN[6] -0.01 (VIOLATED)\n'
                           'removal\nreset_reg/RN -0.20 (VIOLATED)\n'
                           'max_transition\nnet0 0.1 0.2 -0.1 (VIOLATED)\n')
            hashes = {}
            for name in ('constraints.rpt', 'global.rpt', 'coverage.rpt', 'check_timing.rpt',
                         'units.rpt', 'clocks.rpt', 'setup.rpt', 'transition.rpt'):
                content = marked if name == 'constraints.rpt' else 'SYNTHETIC NATIVE-SHAPED FIXTURE\n'
                if name == 'units.rpt':
                    content = 'Report : units\n Time_unit : 1e-09 Second\n'
                path = self.write('sta/' + corner + '/' + name, content)
                hashes[name] = summary.sha(path)
            self.metrics['timing'][corner] = {'reports': hashes,
                'constraint_violation_rows': marked.count('(VIOLATED)'),
                'worst_ns': {'max': -0.003981659 if corner == 'SS3' else 0.0, 'min': -0.2}}
        for name, key in (('dc_soc/design.v', 'netlist_sha256'), ('sysbus.sdc', 'sdc_sha256'),
                          ('soc/physical_view.json', 'source_manifest_sha256')):
            self.metrics[key] = summary.sha(self.result / name)
        self.seal()

    def tearDown(self):
        self.temp.cleanup()

    def write(self, name, content):
        path = self.result / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        self.files[str(path)] = summary.sha(path)
        return path

    def seal(self):
        save(self.result / 'metrics.json', self.metrics)
        save(self.result / 'receipts.json', [{'folder': str(self.result), 'files': self.files}])
        state = {'status': self.metrics['status']}
        for name, key in (('metrics.json', 'metrics_sha256'), ('prepared.json', 'prepared_sha256'),
                          ('resolved_config.json', 'resolved_config_sha256'),
                          ('receipts.json', 'receipts_sha256')):
            state[key] = summary.sha(self.result / name)
        save(self.result / 'state.json', state)

    def change_report(self, content):
        path = self.write('sta/SS3/constraints.rpt', content)
        row = self.metrics['timing']['SS3']
        row['reports']['constraints.rpt'] = summary.sha(path)
        row['constraint_violation_rows'] = content.count('(VIOLATED)')
        self.seal()

    def test_typed_counts_no_zero_slack_invention(self):
        data = summary.bound_summary(self.run)
        self.assertEqual(data['corners']['SS3']['counts'],
                         {'setup': 1, 'hold': 1, 'removal': 1, 'transition': 1})
        self.assertEqual(data['corners']['SS4']['counts']['setup'], 0)
        lines = summary.render(data)
        self.assertIn('SS4 itcm setup_rows=0 worst=NO_MARKED_ROW hold_rows=1 worst=-0.01', lines)
        self.assertTrue(any('NOT timing PASS' in line for line in lines))
        self.assertLessEqual(len(lines), 44)
        self.assertTrue(any('SS3 DATA_HOLD worst_marked_native=-0.01' in line for line in lines))
        self.assertTrue(any('SS3 SETUP_BLOCK_ROWS=' in line for line in lines))
        self.assertTrue(any('SS4 TRANSITION_WORST' in line for line in lines))
        self.assertTrue(any('SUBTOTAL=300 (mm2=0.0003)' in line for line in lines))
        self.assertTrue(any('new_arbiter=30 shared_glue=40 loader_dma=50' in line for line in lines))

    def test_invalid_priority_readback_refused(self):
        text = (self.result / 'dc_soc/tool.log').read_text()
        text = text.replace('phase=post_compile', 'phase=pre_compile')
        self.write('dc_soc/tool.log', text)
        self.seal()
        with self.assertRaisesRegex(ValueError, 'cost-priority attribute readback'):
            summary.bound_summary(self.run)

    def test_stale_native_report_refused(self):
        (self.result / 'sta/SS3/constraints.rpt').write_text('changed\n')
        with self.assertRaisesRegex(ValueError, 'binding mismatch'):
            summary.bound_summary(self.run)

    def test_bounded_path_is_not_constraints(self):
        self.change_report('Report : timing\n-all_violators\nStartpoint: p\nslack -0.1 (VIOLATED)\n')
        with self.assertRaisesRegex(ValueError, 'Incomplete all-violator'):
            summary.bound_summary(self.run)

    def test_missing_all_violators_scope_refused(self):
        self.change_report('Report : constraint\nmax_delay/setup\na/D -0.1 (VIOLATED)\n')
        with self.assertRaisesRegex(ValueError, 'Incomplete all-violator'):
            summary.bound_summary(self.run)

    def test_missing_area_groups_stays_unknown(self):
        self.metrics.pop('soc')
        self.write('dc_soc/cells.tsv', 'instance\treference\tarea_um2\nelsewhere/q\tDFF\t1\n')
        self.seal()
        text = '\n'.join(summary.render(summary.bound_summary(self.run)))
        self.assertIn('AREA_TT5 groups_um2 accel_logic=UNKNOWN local_sram=UNKNOWN SUBTOTAL=UNKNOWN', text)
        self.assertNotIn('mapped_macros=1024', text)


if __name__ == '__main__':
    unittest.main(verbosity=2)
