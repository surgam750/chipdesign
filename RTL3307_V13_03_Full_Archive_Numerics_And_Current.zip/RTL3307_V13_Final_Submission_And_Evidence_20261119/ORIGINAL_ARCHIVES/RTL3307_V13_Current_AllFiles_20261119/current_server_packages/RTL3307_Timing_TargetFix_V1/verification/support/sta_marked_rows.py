#!/usr/bin/env python3
"""Audit marked rows in native PrimeTime all-violator constraint reports.

Dependency-free and read-only unless --json is supplied. Counts are report rows,
not unique paths. Neither a zero count nor exit code 0 establishes timing closure.
"""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import sys


CORNERS = ("FF0", "FF1", "FF2", "SS3", "SS4", "TT5", "TT6")
MARKER = re.compile(r"\(VIOLATED\)", re.I)
NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")
SECTION = re.compile(
    r"^(?P<name>(?:max|min)_[A-Za-z_]+(?:\s*/\s*[A-Za-z_]+)?"
    r"|recovery|removal|clock_gating(?:_[A-Za-z_]+)?)"
    r"(?:\s+\((?P<group>.*)\))?\s*$", re.I)
KINDS = {
    "max_delay/setup": "setup", "max_delay": "setup",
    "min_delay/hold": "hold", "min_delay": "hold",
    "recovery": "recovery", "removal": "removal",
    "max_transition": "transition", "min_transition": "min_transition",
    "max_capacitance": "capacitance", "min_capacitance": "min_capacitance",
    "max_fanout": "fanout", "min_pulse_width": "min_pulse_width",
    "clock_gating_setup": "clock_gating_setup",
    "clock_gating_hold": "clock_gating_hold", "clock_gating": "clock_gating",
}
MAIN_KINDS = ("setup", "hold", "recovery", "removal", "transition", "capacitance", "fanout")
COMPANIONS = ("global.rpt", "check_timing.rpt", "coverage.rpt", "units.rpt", "clocks.rpt")
LIMITS = [
    "This is a marked-row parser, not a timing signoff or constraint-validity check.",
    "Counts are VIOLATED rows. Multiple clock groups/checks can share one endpoint.",
    "Block attribution uses the reported object only; it does not prove the full path lies in that block.",
    "Slack stays in native report units. Capacitance/fanout margins are not nanoseconds.",
    "Absent sections, missing reports, unknown sections and unparsed markers are explicitly retained.",
    "A bounded report_timing path listing cannot prove a zero-violation result.",
    "Native global, coverage, check_timing, units and valid SDC review remain necessary.",
    "No conclusion about untimed paths, missing checks, library validity or physical closure is made.",
]


def classify_object(name):
    """Use exact instance segments, not accidental substring matches."""
    segments = set(name.strip("\\").split("/"))
    for block, instances in (
        ("itcm", {"u_e203_itcm_ram", "u_e203_itcm_ctrl"}),
        ("dtcm", {"u_e203_dtcm_ram", "u_e203_dtcm_ctrl"}),
        ("accelerator", {"u_kwt_accel"}),
        ("shared_sram", {"u_kwt_shared_sram"}),
        ("systembus_arbiter", {"u_kwt_sysbus_arbiter"}),
        ("loader_dma", {"u_kwt_loader_dma"}),
        ("always_on", {"u_sirv_aon_top", "u_sirv_aon", "u_sirv_pmu"}),
        ("cpu_other", {"u_e203_cpu_top", "u_e203_cpu"}),
    ):
        if segments.intersection(instances):
            return block
    if name.startswith("kwt_load_"):
        return "loader_port"
    return "other_or_unresolved"


def _header_or_separator(line):
    if not line or re.fullmatch(r"[-=*]+", line):
        return True
    # Native table headings have multiple words; do not discard a net named slack.
    lowered = line.lower()
    return (bool(re.search(r"\bslack\b", lowered)) and
            bool(re.search(r"\b(required|actual|endpoint|pin|net|constraint)\b", lowered))) or \
        lowered in {"endpoint", "pin", "net", "object", "required", "actual", "slack"}


def parse_row(lines):
    """Accept an inline row, object+numbers, or object/slack/marker layout.

    Native tools commonly move the number columns below a long object name.
    Arbitrary text reconstruction is intentionally rejected instead of guessed.
    """
    relevant = [(n, s.strip()) for n, s in lines if s.strip()]
    if not relevant:
        return None, "empty marked record"
    numbers = []
    obj = None
    obj_line = None
    for line_number, text in reversed(relevant[-8:]):
        tokens = text.split()
        tail = []
        while tokens and NUMBER.fullmatch(tokens[-1]):
            tail.insert(0, tokens.pop())
        numbers = tail + numbers
        if tokens:
            candidate = " ".join(tokens)
            if len(tokens) != 1 or _header_or_separator(candidate) or SECTION.fullmatch(candidate):
                return None, "object is missing or ambiguous; refusing to use a table heading"
            if candidate.startswith(("Warning:", "Error:", "Report:")):
                return None, "diagnostic text is not a constraint object"
            obj, obj_line = candidate, line_number
            break
    if obj is None or not numbers:
        return None, "no unambiguous object followed by numeric slack"
    slack = float(numbers[-1])
    if not math.isfinite(slack):
        return None, "non-finite displayed slack"
    return {"object": obj, "slack": slack, "slack_text": numbers[-1],
            "numeric_columns": numbers, "object_line": obj_line,
            "block": classify_object(obj)}, None


def parse_text(text, source="<memory>"):
    lines = text.splitlines()
    marker_count = len(MARKER.findall(text))
    timing_listing = bool(re.search(r"^\s*Report\s*:\s*timing\b", text, re.M | re.I)) or \
        bool(re.search(r"^\s*Startpoint\s*:", text, re.M))
    result = {
        "source": str(source), "present": True, "raw_marker_count": marker_count,
        "report_type": "timing_listing" if timing_listing else "constraint_or_unverified",
        "all_violators_option_visible": bool(re.search(r"(?<!\w)-all_violators\b", text)),
        "observed_sections": [], "records": [], "unparsed": [], "warnings": [],
        "closure_assessed": False,
    }
    if "\ufffd" in text:
        result["warnings"].append("Input contains replacement characters from text decoding.")
    if timing_listing:
        for n, line in enumerate(lines, 1):
            for unused in MARKER.finditer(line):
                result["unparsed"].append({"line": n, "reason": "bounded or mixed timing listing is not an all-violator constraint report", "context": line})
        result["status"] = "WRONG_REPORT_TYPE"
        return finish_result(result)
    section, group, kind = "unrecognized", None, "unknown"
    pending = []
    for n, original in enumerate(lines, 1):
        line = original.strip()
        match = SECTION.fullmatch(line)
        if match:
            section = re.sub(r"\s+", "", match.group("name")).lower()
            group = match.group("group")
            kind = KINDS.get(section, "unknown")
            result["observed_sections"].append({"line": n, "section": section, "kind": kind, "group": group})
            pending = []
            continue
        marks = list(MARKER.finditer(line))
        if marks:
            if len(marks) != 1 or line[marks[0].end():].strip():
                reason = "multiple markers or unexpected text after marker"
                record = None
            else:
                prefix = line[:marks[0].start()].strip()
                record, reason = parse_row(pending + [(n, prefix)])
            for unused in marks:
                if record is None:
                    result["unparsed"].append({"line": n, "section": section, "reason": reason,
                                               "context": "\n".join(s for _, s in (pending[-3:] + [(n, original)]))})
                else:
                    record.update({"line": n, "section": section, "kind": kind, "group": group})
                    result["records"].append(record)
            pending = []
            continue
        if "(MET)" in line.upper() or _header_or_separator(line):
            # Blank lines are allowed within a wrapped native row.
            if line:
                pending = []
            continue
        pending.append((n, line))
        pending = pending[-8:]
    if not result["all_violators_option_visible"]:
        result["warnings"].append("The -all_violators option is not visible; report scope is unverified.")
    if any(r["slack"] > 0 for r in result["records"]):
        result["warnings"].append("A VIOLATED record has positive displayed slack; inspect its native row.")
    result["status"] = "PARSED_ROWS" if marker_count else "NO_MARKED_ROWS"
    return finish_result(result)


def finish_result(result):
    records = result["records"]
    result["parsed_count"] = len(records)
    result["unparsed_count"] = len(result["unparsed"])
    result["unknown_section_count"] = sum(r["kind"] == "unknown" for r in records)
    result["marker_accounting_ok"] = result["raw_marker_count"] == len(records) + len(result["unparsed"])
    result["parse_coverage"] = (len(records) / result["raw_marker_count"] if result["raw_marker_count"] else None)
    if result["unparsed_count"] or result["unknown_section_count"]:
        if result["status"] != "WRONG_REPORT_TYPE":
            result["status"] = "PARTIAL_PARSE"
    groups = defaultdict(list)
    for row in records:
        groups[row["kind"]].append(row)
    result["groups"] = {}
    for kind, rows in sorted(groups.items()):
        blocks = {}
        for block in sorted({r["block"] for r in rows}):
            subset = [r for r in rows if r["block"] == block]
            blocks[block] = {"row_count": len(subset), "worst_slack": min(r["slack"] for r in subset)}
        result["groups"][kind] = {
            "row_count": len(rows), "unique_objects": len({r["object"] for r in rows}),
            "worst_slack": min(r["slack"] for r in rows), "blocks": blocks,
            "units": "native capacitance units" if "capacitance" in kind else
                     "native fanout/load units" if kind == "fanout" else "native time units or check-specific units",
        }
    return result

