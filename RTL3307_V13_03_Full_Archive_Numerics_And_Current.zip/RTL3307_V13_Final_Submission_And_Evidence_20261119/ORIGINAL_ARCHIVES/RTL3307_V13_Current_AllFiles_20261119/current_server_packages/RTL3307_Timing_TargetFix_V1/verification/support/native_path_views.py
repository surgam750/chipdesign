"""Four-page, in-memory views of bound native reports; no EDA or file I/O.

Counts describe printed all-violator rows. Path listings are bounded samples.
Aliases abbreviate display only; comparison keys always retain full objects.
"""
from __future__ import print_function

from collections import Counter, defaultdict
import math
import re


NUM = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'
NUMBER = re.compile(r'^' + NUM + r'$')
SLACK = re.compile(r'^\s*slack\s+\(([^)]+)\)\s+(' + NUM + r')\s*$', re.I)
NUMERIC = re.compile(r'^\s*' + NUM + r'(?:\s+' + NUM + r')*(?:\s+[rf])?\s*$', re.I)
POINT = re.compile(r'^\s*(\S+)\s+\(([^)]+)\)(.*)$')
COUNTER = re.compile(r'^u_kwt_accel/u_ctrl/perf_rd_words_reg\[(\d+)\](?:/[^/]+)?$')
KINDS = ('setup', 'hold', 'removal', 'transition')
MAX_LINES = 30


def _report(case, corner, name):
    return case.get('corners', {}).get(corner, {}).get('reports', {}).get(name, {})


def _lines(case, corner, name):
    report = _report(case, corner, name)
    if isinstance(report.get('text'), str):
        return report['text'].splitlines()
    return report.get('lines') or []


def _parsed(case, corner):
    return case.get('corners', {}).get(corner, {}).get('parsed', {})


def _records(case, corner, kind=None):
    rows = _parsed(case, corner).get('records', [])
    return [r for r in rows if kind is None or r.get('kind') == kind]


def _has_records(case, corner):
    parsed = _parsed(case, corner)
    return parsed.get('status') in ('PARSED_ROWS', 'NO_MARKED_ROWS') and isinstance(parsed.get('records'), list)


def _key(row):
    return row.get('kind'), row.get('group'), row.get('object')


def _finite(value):
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError, OverflowError):
        return False


def _slack(row):
    value = row.get('slack_text')
    return str(value) if value is not None and _finite(value) else 'UNKNOWN'


def _rank(row):
    value = row.get('slack_text')
    return float(value) if _finite(value) else float('inf')


def _short(value, width=140):
    text = ' '.join(str(value).split())
    return text if len(text) <= width else text[:width - 1] + '~'


def _block(name):
    segments = set(str(name).strip('\\').split('/'))
    for block, instances in (
        ('itcm', ('u_e203_itcm_ram', 'u_e203_itcm_ctrl')),
        ('dtcm', ('u_e203_dtcm_ram', 'u_e203_dtcm_ctrl')),
        ('accelerator', ('u_kwt_accel',)),
        ('shared_sram', ('u_kwt_shared_sram',)),
        ('systembus_arbiter', ('u_kwt_sysbus_arbiter',)),
        ('loader_dma', ('u_kwt_loader_dma',)),
        ('always_on', ('u_sirv_aon_top', 'u_sirv_aon', 'u_sirv_pmu')),
        ('cpu_other', ('u_e203_cpu_top', 'u_e203_cpu')),
    ):
        if segments.intersection(instances):
            return block
    return 'loader_port' if str(name).startswith('kwt_load_') else 'other_or_unresolved'


class _Aliases(object):
    def __init__(self, cases):
        names = set()
        for case in cases:
            for corner in ('SS3', 'SS4'):
                names.update(str(r.get('object')) for r in _records(case, corner))
        self.ids = {name: i + 1 for i, name in enumerate(sorted(names))}

    def __call__(self, value):
        name = str(value) if value else 'UNKNOWN'
        if name == 'UNKNOWN':
            return name
        if name not in self.ids:
            self.ids[name] = len(self.ids) + 1
        parts = name.split('/')
        if len(name) <= 80:
            return name
        # Preserve all indexed segments, including an indexed parent outside
        # the short suffix. Distinct full names also get distinct display IDs.
        suffix = '/'.join(parts[-2:])
        indexed = re.findall(r'[A-Za-z_$][\w$]*\[[^\]]+\]', name)
        omitted = [item for item in indexed if item not in suffix]
        tail = ('/'.join(omitted) + '/' if omitted else '') + suffix
        tail = tail.replace('g_bank', 'bank').replace('g_row', 'row').replace('g_slice', 'slice')
        alias = '%s:~/%s @%d' % (_block(name), tail, self.ids[name])
        # Never cut an index or final pin. Extremely unusual names remain
        # a labelled alias ID; native file/line in the view resolves the ID.
        if len(alias) > 96:
            pin = parts[-1]
            indices = ','.join(indexed)
            alias = '%s:~ %s /%s @%d' % (_block(name), indices, pin, self.ids[name])
        return alias


def _family(name):
    parts = str(name).split('/')
    position = len(parts) - 2 if len(parts) > 1 else 0
    # Group only a terminal register bit. All bank/row/slice hierarchy stays.
    parts[position] = re.sub(r'(_reg)\[\d+\]$', r'\1[*]', parts[position])
    return '/'.join(parts)


def _value(rows, index, label):
    tail = re.sub(r'^\s*' + re.escape(label) + r'\s*', '', rows[index][1], flags=re.I)
    if not tail.strip() and index + 1 < len(rows):
        tail = rows[index + 1][1].strip()
    values = re.findall(NUM, tail)
    if NUMERIC.fullmatch(tail) and len(values) == 1 and _finite(values[0]):
        return values[0]
    return 'UNKNOWN'


def native_paths(lines):
    """Complete path boundaries are Startpoint through that path's slack."""
    paths = []
    start = None
    for index, line in enumerate(lines):
        if re.match(r'^\s*Startpoint\s*:', line):
            if start is not None:
                paths.append(_path([(i + 1, lines[i]) for i in range(start, index)], False))
            start = index
        if start is not None and SLACK.fullmatch(line):
            paths.append(_path([(i + 1, lines[i]) for i in range(start, index + 1)], True))
            start = None
    if start is not None:
        paths.append(_path([(i + 1, lines[i]) for i in range(start, len(lines))], False))
    return paths


def _path(rows, complete):
    result = {'status': 'COMPLETE' if complete else 'INCOMPLETE_NO_SLACK', 'rows': rows,
              'start': 'UNKNOWN', 'end': 'UNKNOWN', 'group': 'UNKNOWN', 'type': 'UNKNOWN',
              'arrival': 'UNKNOWN', 'required': 'UNKNOWN', 'slack_text': None,
              'checks': [], 'pin': 'UNKNOWN', 'points': [], 'points_status': 'UNKNOWN', 'budget': []}
    checks = set()
    value_labels_seen = set()
    arrival = table = None
    for index, (lineno, line) in enumerate(rows):
        for label, key in (('Startpoint', 'start'), ('Endpoint', 'end'), ('Path Group', 'group'), ('Path Type', 'type')):
            match = re.match(r'^\s*' + label + r'\s*:\s*(\S+)', line)
            if match:
                result[key] = match.group(1)
        checks.update(s.lower() for s in re.findall(r'\blibrary\s+(setup|hold|recovery|removal)\s+time\b', line, re.I))
        checks.update('clock_gating_' + s.lower() for s in re.findall(r'\bclock\s+gating\s+(setup|hold)\s+time\b', line, re.I))
        if re.match(r'^\s*Point\s+.*\bIncr\b.*\bPath\b', line) and table is None:
            table = index
        for label, key in (('data arrival time', 'arrival'), ('data required time', 'required')):
            if re.match(r'^\s*' + label + r'\b', line) and key not in value_labels_seen:
                value_labels_seen.add(key)
                result[key] = _value(rows, index, label)
                if key == 'arrival' and arrival is None:
                    arrival = index
        if re.match(r'^\s*(clock \S+ \((?:rise|fall) edge\)|clock uncertainty|library \w+ time|(?:input|output) external delay|(?:max|min)[_ ]delay)(?:\s|$)', line, re.I):
            context = [line.strip()]
            following = index + 1
            while following < len(rows) and NUMERIC.fullmatch(rows[following][1]):
                context.append(rows[following][1].strip())
                following += 1
            result['budget'].append((lineno, ' | '.join(context)))
        match = SLACK.fullmatch(line)
        if match:
            result['slack_text'] = match.group(2)
    result['checks'] = sorted(checks)
    if table is None or arrival is None or table >= arrival:
        return result
    points, unknown, i = [], False, table + 1
    while i < arrival:
        lineno, line = rows[i]
        match = POINT.fullmatch(line)
        if match:
            tail = match.group(3).strip()
            number_parts = [tail] if tail else []
            end = i + 1
            while end < arrival and NUMERIC.fullmatch(rows[end][1]):
                number_parts.append(rows[end][1].strip())
                end += 1
            joined = ' '.join(number_parts)
            nums = re.findall(NUM, joined)
            valid = all(NUMERIC.fullmatch(p) for p in number_parts) and len(nums) == 2 and all(_finite(v) for v in nums)
            if valid:
                points.append({'object': match.group(1), 'reference': match.group(2),
                               'incr': nums[0], 'path': nums[1], 'line': lineno, 'end_index': end})
            else:
                unknown = True
            i = end
            continue
        if line.strip() and not re.fullmatch(r'[\s=*\-]+', line) and not NUMERIC.fullmatch(line) and not re.match(
                r'^\s*(clock\b|input external delay\b|output external delay\b|max[_ ]delay\b|min[_ ]delay\b)', line, re.I):
            unknown = True
        i += 1
    data = [p for p in points if p['reference'].lower() != 'net']
    if data:
        last = data[-1]
        tail = [s for _, s in rows[last['end_index']:arrival]
                if s.strip() and not re.fullmatch(r'[\s=*\-]+', s) and not NUMERIC.fullmatch(s)]
        if not tail:
            result['pin'] = last['object']
            result['pin_line'] = last['line']
    result['points'] = points
    result['points_status'] = 'PARSED' if points and not unknown else 'UNKNOWN'
    return result


def _coverage(case, corner):
    lines = _lines(case, corner, 'coverage.rpt')
    header = next((i for i, s in enumerate(lines) if re.search(r'Type\s+of\s+Check', s, re.I)
                   and all(re.search(r'\b' + w + r'\b', s, re.I) for w in ('Total', 'Met', 'Violated', 'Untested'))), None)
    found = {}
    if header is not None:
        for index in range(header + 1, len(lines)):
            line = lines[index]
            match = re.match(r'^\s*(setup|hold|removal)\s+\d+\s+\d+\s+\(', line)
            if match:
                found[match.group(1)] = 'L%d %s' % (index + 1, ' '.join(line.split()))
            elif found and not line.strip():
                break
            elif line.strip() and not re.fullmatch(r'[\s=*\-]+', line) and not re.match(r'^\s*[A-Za-z][\w/-]*\s+\d+\s+\d+\s+\(', line):
                break
    return [corner + ' coverage ' + found.get(kind, kind + '=UNKNOWN') for kind in ('setup', 'hold', 'removal')]


def _warnings(case, corner):
    lines = _lines(case, corner, 'check_timing.rpt')
    if not lines:
        return corner + ' check_timing=UNKNOWN/MISSING'
    warning = [(i + 1, s.strip()) for i, s in enumerate(lines) if re.match(r'^\s*Warning\s*:', s, re.I)]
    error = [(i + 1, s.strip()) for i, s in enumerate(lines) if re.match(r'^\s*(Error|Fatal)\s*:', s, re.I)]
    unconstrained = [(n, s) for n, s in warning if re.search(r'not constrained|unconstrained', s, re.I)]
    prefix = '%s check warnings=%d errors=%d unconstrained_warning_lines=%d' % (corner, len(warning), len(error), len(unconstrained))
    example = (unconstrained or error or warning)[:1]
    return prefix + ('; L%d %s' % example[0] if example else '; no markers is not validity proof')


def _count_text(case, corner):
    parsed = _parsed(case, corner)
    if parsed.get('status') not in ('PARSED_ROWS', 'NO_MARKED_ROWS'):
        return 'UNKNOWN/INCOMPLETE'
    counts = Counter(r['kind'] for r in parsed.get('records', []))
    return '/'.join(str(counts[k]) for k in KINDS)


def _audit_text(case, corner):
    parsed = _parsed(case, corner)
    lines = _lines(case, corner, 'constraints.rpt')
    text_rows = sum(bool(re.search(r'VIOLATED', s)) for s in lines) if lines else 'UNKNOWN'
    return '%s/text%s/parsed%s/u%s/k%s' % (parsed.get('raw_marker_count', '?'), text_rows,
            parsed.get('parsed_count', '?'), parsed.get('unparsed_count', '?'), parsed.get('unknown_section_count', '?'))


def _scalar(case, corner):
    metrics = case.get('corners', {}).get(corner, {}).get('metrics', {})
    worst = metrics.get('worst_ns', {})
    return 'max=%s min=%s' % tuple(str(worst.get(k)) if _finite(worst.get(k)) else 'UNKNOWN' for k in ('max', 'min'))


def _pack(items, width=138):
    lines, line = [], ''
    for item in items:
        if line and len(line) + len(item) + 3 > width:
            lines.append(line)
            line = ''
        line = (line + ' | ' if line else '') + item
    if line:
        lines.append(line)
    return lines


def _finish(title, body):
    if len(body) > MAX_LINES:
        raise ValueError('Page budget exceeded for %s: %d lines' % (title, len(body)))
    return title, body


def _overview(old, new, conditions):
    checks = conditions.get('checks', [])
    statuses = Counter(str(c.get('status', 'UNKNOWN')) for c in checks)
    lines = ['READ_ONLY existing reports; NOT timing PASS; old=ONEHOT, new=RDCOUNT.',
             'OLD_RUN ' + str(old.get('run', 'UNKNOWN')).rstrip('/').rsplit('/', 1)[-1],
             'NEW_RUN ' + str(new.get('run', 'UNKNOWN')).rstrip('/').rsplit('/', 1)[-1],
             'Bindings old=%s new=%s; conditions=%s' % (old.get('binding', {}).get('status', 'UNKNOWN'),
                   new.get('binding', {}).get('status', 'UNKNOWN'), conditions.get('status', 'UNKNOWN')),
             'Condition checks=%s; runtime environment=%s' % (dict(statuses), conditions.get('runtime_environment', 'UNKNOWN')),
             'Counts below are marked rows: setup/hold/removal/transition; not unique paths.']
    for corner in ('SS3', 'SS4'):
        lines.append('%s old %s -> new %s' % (corner, _count_text(old, corner), _count_text(new, corner)))
        lines.append('%s marker/text/parsed/unparsed/unknown: old %s; new %s' % (corner, _audit_text(old, corner), _audit_text(new, corner)))
        lines.append('%s scalars old %s; new %s [native query modes]' % (corner, _scalar(old, corner), _scalar(new, corner)))
    mapped = '32' if new.get('counter_mapped_32') is True else 'UNKNOWN'
    marks = [sum(bool(COUNTER.fullmatch(str(r.get('object')))) for r in _records(new, c, 'setup'))
             if _has_records(new, c) else 'UNKNOWN' for c in ('SS3', 'SS4')]
    lines.append('New perf_rd_words mapped_bits=%s; SS3/SS4 marked setup=%s/%s; zero marks does not prove coverage.' % (mapped, marks[0], marks[1]))
    lines.append('NEW coverage native columns: Type / Total / Met(%) / Violated(%) / Untested(%).')
    for corner in ('SS3', 'SS4'):
        lines.extend(_coverage(new, corner))
        lines.append(_short(_warnings(new, corner)))
    failed = [c.get('name', 'UNKNOWN') for c in checks if c.get('status') != 'MATCH']
    if failed:
        lines.append(_short('Conditions not MATCH: %d checks; use --detail identity; first=%s' % (len(failed), failed[0])))
    for corner in ('SS3', 'SS4'):
        units = [s.strip() for s in _lines(new, corner, 'units.rpt') if re.match(r'^\s*Time_unit\s*:', s)]
        lines.append(corner + ' native ' + (units[0] if len(units) == 1 else 'Time_unit=UNKNOWN'))
    lines.extend(['~ or @id abbreviates display only; full object remains in source file at stated line.',
                  'Coverage detail / other corners / global tables remain unresolved by this four-page view.'])
    return _finish('1/4 Sources, counts and coverage', lines)


def _setup_page(new, aliases):
    if not _has_records(new, 'SS3'):
        return _finish('2/4 Remaining SS3 setup and first native path',
                       ['SS3 setup inventory=UNKNOWN/INCOMPLETE; no zero count or family conclusion.',
                        'Native report/parse binding must be available; no worst endpoint inferred from scalar.'])
    rows = _records(new, 'SS3', 'setup')
    families, blocks = defaultdict(list), defaultdict(list)
    for row in rows:
        blocks[_block(row.get('object'))].append(row)
        families[_family(row.get('object'))].append(row)
    lines = ['SS3 ALL-VIOLATOR setup rows=%d unique(kind,group,object)=%d; object blocks are not whole-path attribution.' % (len(rows), len(set(_key(r) for r in rows)))]
    block_parts = []
    for name, group in sorted(blocks.items()):
        block_parts.append('%s=%d worst=%s' % (name, len(group), _slack(min(group, key=_rank))))
    lines.extend(_pack(block_parts) if block_parts else ['Setup block rows: NONE observed; no closure claim.'])
    ordered = sorted(families.items(), key=lambda item: (-len(item[1]), _rank(min(item[1], key=_rank)), item[0]))
    for name, group in ordered[:3]:
        worst = min(group, key=_rank)
        lines.append('Family rows=%d worst=%s L%s %s' % (len(group), _slack(worst), worst.get('line', '?'), aliases(name)))
    lines.append('Family top=%d/%d; omitted family rows=%d; full objects: new SS3/constraints.rpt.' % (min(3, len(ordered)), len(ordered), sum(len(v) for _, v in ordered[3:])))
    paths = native_paths(_lines(new, 'SS3', 'setup.rpt'))
    if not paths:
        lines.extend(['New setup.rpt first native path=UNKNOWN/NO_STARTPOINT.', 'Use --detail SS3/setup.rpt; no worst endpoint inferred from scalar.'])
        return _finish('2/4 Remaining SS3 setup and first native path', lines)
    path = paths[0]
    lines.append('setup.rpt first path=%s L%d-%d; saved listings are bounded (-max_paths 20).' % (path['status'], path['rows'][0][0], path['rows'][-1][0]))
    lines.extend(['Start ' + aliases(path['start']), 'End   ' + aliases(path['end']),
                  'Actual last data point L%s %s' % (path.get('pin_line', '?'), aliases(path['pin'])),
                  'Native check=%s; group=%s mode=%s' % (','.join(path['checks']) or 'UNKNOWN', path['group'], path['type']),
                  'arrival=%s required=%s slack=%s [native report values; not recomputed]' % (path['arrival'], path['required'], path.get('slack_text') or 'UNKNOWN')])
    # Keep all budget terms in detail. Show capture edge, uncertainty, check,
    # plus input/output external delay where present; omit launch-edge zero.
    budget = path['budget']
    last_clock = next((p for p in reversed(budget) if re.match(r'clock \S+ \((rise|fall) edge\)', p[1], re.I)), None)
    selected = [p for p in budget if re.match(r'(clock uncertainty|library \w+ time|(?:input|output) external delay|(?:max|min)[_ ]delay)', p[1], re.I)]
    if last_clock:
        selected.insert(0, last_clock)
    for lineno, text in selected[:4]:
        lines.append(_short('Budget L%d %s' % (lineno, text)))
    if len(selected) > 4:
        lines.append('Budget excerpt=%d/%d terms; all original terms: --detail SS3/setup.rpt.' % (4, len(selected)))
    if not selected:
        lines.append('Clock/check budget=UNKNOWN; inspect --detail SS3/setup.rpt.')
    if path['status'] == 'COMPLETE' and path['points_status'] == 'PARSED':
        points = sorted(path['points'], key=lambda p: (-float(p['incr']), p['line']))
        available = max(0, min(5, MAX_LINES - len(lines) - 2))
        lines.append('Top native arrival-side Point increments; launch clock may be included; no removable-delay claim:')
        for point in points[:available]:
            lines.append('L%s incr=%s path=%s %s' % (point['line'], point['incr'], point['path'], aliases(point['object'])))
        if available < min(5, len(points)):
            lines.append('Top-increment excerpt limited by page budget; full path: --detail SS3/setup.rpt.')
    else:
        lines.append('Data-point increment parsing=UNKNOWN; no cross-row or cross-path delay attribution.')
    lines.append('Full saved first path: --detail SS3/setup.rpt --path-index 1. No EDA or repeated old-path request.')
    return _finish('2/4 Remaining SS3 setup and first native path', lines)


def _stable_endpoint(name):
    parts = str(name).split('/')
    return not any(re.fullmatch(r'U\d+', part) for part in parts[:-1])


def _hold_page(old, new, aliases, comparable):
    lines = ['Exact keys=(kind,group,full object); ADD=new / DROP=old constraints.rpt; label delta is not physical correspondence.',
             'Net row difference is not the number of new violations. Duplicate-key multiplicity is retained.']
    if not comparable:
        lines.append('CONDITIONS_NOT_MATCH: differences below are descriptive only; no controlled-improvement claim.')
    for corner in ('SS3', 'SS4'):
        if not _has_records(old, corner) or not _has_records(new, corner):
            lines.append(corner + ' hold inventory/delta=UNKNOWN/INCOMPLETE; no zero count or key difference inferred.')
            continue
        before, after = _records(old, corner, 'hold'), _records(new, corner, 'hold')
        b, a = Counter(_key(r) for r in before), Counter(_key(r) for r in after)
        added, removed, common = set(a) - set(b), set(b) - set(a), set(a).intersection(b)
        plus, minus = sum((a - b).values()), sum((b - a).values())
        lines.append('%s HOLD rows %d->%d net=%+d; keys added=%d removed=%d common=%d; multiplicity +%d/-%d' % (corner, len(before), len(after), len(after) - len(before), len(added), len(removed), len(common), plus, minus))
        old_worst = _slack(min(before, key=_rank)) if before else 'NO_MARKED_ROW'
        new_worst = _slack(min(after, key=_rank)) if after else 'NO_MARKED_ROW'
        lines.append('%s HOLD worst marked slack old=%s new=%s; separate hold inventories, not the same physical path.' % (corner, old_worst, new_worst))
        for tag, source, keys in (('ADD', after, added), ('DROP', before, removed)):
            selected = sorted((r for r in source if _key(r) in keys and _stable_endpoint(r.get('object'))), key=_rank)
            # At most two of each sign per corner, four labels in total.
            shown, seen = 0, set()
            for row in selected:
                if _key(row) in seen:
                    continue
                seen.add(_key(row))
                lines.append('%s %s L%s slack=%s grp=%s %s' % (corner, tag, row.get('line', '?'), _slack(row), row.get('group') or '<none>', aliases(row.get('object'))))
                shown += 1
                if shown == 2:
                    break
            lines.append('%s %s stable keys shown=%d/%d; all changed keys=%d; full rows in that run constraints.rpt.' % (corner, tag, shown, len(set(_key(r) for r in selected)), len(keys)))
        known, types = [], Counter()
        for name in ('hold.rpt', 'hfclk_min.rpt'):
            for path_index, path in enumerate(native_paths(_lines(new, corner, name)), 1):
                types[','.join(path['checks']) or 'UNKNOWN'] += 1
                if path['status'] == 'COMPLETE' and path['checks'] == ['hold'] and _finite(path.get('slack_text')):
                    known.append((float(path['slack_text']), name, path_index, path))
        if known:
            _, name, path_index, path = min(known, key=lambda item: item[0])
            lines.append('%s saved DATA-HOLD worst=%s %s L%d-%d grp=%s' % (corner, path['slack_text'], name, path['rows'][0][0], path['rows'][-1][0], path['group']))
            lines.append('  Start ' + aliases(path['start']))
            lines.append('  Actual last data pin ' + aliases(path['pin']))
            lines.append('  arrival=%s required=%s; --detail %s/%s --path-index %d' % (path['arrival'], path['required'], corner, name, path_index))
        else:
            lines.append('%s saved DATA-HOLD sample=UNKNOWN/NOT_IN_SAVED_SAMPLE; native check labels=%s' % (corner, dict(types)))
        lines.append('%s removal rows %d->%d remain separate; global min/hold-table counts are not assumed identical.' % (corner, len(_records(old, corner, 'removal')), len(_records(new, corner, 'removal'))))
    lines.append('Hold samples have -max_paths 20/5 bounds; unseen paths are not waived. No data hold is inferred from min scalar.')
    return _finish('3/4 Hold identity changes and native hold samples', lines)


def _transition_page(old, new, aliases, comparable):
    if not _has_records(old, 'SS4') or not _has_records(new, 'SS4'):
        return _finish('4/4 SS4 transition concentration and worst objects',
                       ['SS4 transition inventory/delta=UNKNOWN/INCOMPLETE; no zero or improvement inferred.'])
    before, after = _records(old, 'SS4', 'transition'), _records(new, 'SS4', 'transition')
    b, a = defaultdict(list), defaultdict(list)
    for row in before:
        b[_block(row.get('object'))].append(row)
    for row in after:
        a[_block(row.get('object'))].append(row)
    lines = ['SS4 ALL-VIOLATOR transition rows=%d->%d; blocks below include every parsed block.' % (len(before), len(after)),
             'Block is the printed object location. Same U-number across two mapped netlists is not a physical match.']
    if not comparable:
        lines.append('CONDITIONS_NOT_MATCH: counts are descriptive; improvement attribution is unavailable.')
    for name in sorted(set(a).union(b)):
        old_worst = _slack(min(b[name], key=_rank)) if b[name] else 'NO_MARKED_ROW'
        new_worst = _slack(min(a[name], key=_rank)) if a[name] else 'NO_MARKED_ROW'
        lines.append('%s rows %d->%d delta=%+d; worst %s -> %s' % (name, len(b[name]), len(a[name]), len(a[name]) - len(b[name]), old_worst, new_worst))
    text = _lines(new, 'SS4', 'transition.rpt')
    header = [(i + 1, ' '.join(s.split())) for i, s in enumerate(text)
              if re.search(r'\b(required|actual|slack|transition)\b', s, re.I)
              and not re.match(r'^\s*(Report\s*:|max_transition\b|\S+/)', s)]
    lines.append('New worst 3 by constraints.rpt slack; cols are native numeric_columns, never data-arrival time.')
    for lineno, label in header[:2]:
        lines.append(_short('transition.rpt header L%d %s' % (lineno, label)))
    if not header:
        lines.append('transition.rpt header=UNKNOWN; Required/Actual column semantics are not inferred.')
    for row in sorted(after, key=_rank)[:3]:
        lines.append('constraints.rpt L%s slack=%s %s' % (row.get('line', '?'), _slack(row), aliases(row.get('object'))))
        lines.append('  cols(native)=%s; object starts L%s; group=%s' % (row.get('numeric_columns', 'UNKNOWN'), row.get('object_line', '?'), row.get('group') or '<none>'))
        object_name = str(row.get('object'))
        matches = [(i + 1, s.strip()) for i, s in enumerate(text)
                   if s.strip() == object_name or s.lstrip().startswith(object_name + ' ') or s.lstrip().startswith(object_name + '\t')]
        if len(matches) == 1:
            lineno, native = matches[0]
            tail = native[len(object_name):].strip()
            if not tail and lineno < len(text):
                tail = text[lineno].strip()
            lines.append(_short('  transition.rpt L%d native tail: %s' % (lineno, tail or 'UNKNOWN'))) 
        else:
            lines.append('  transition.rpt exact object rows=%d; ambiguous/missing association=UNKNOWN.' % len(matches))
    lines.extend(['The raw Required/Actual transition columns and units decide severity; no automatic sizing/hold waiver.',
                  'All remaining objects/header/columns: new SS4/constraints.rpt and transition.rpt, in the saved run.'])
    return _finish('4/4 SS4 transition concentration and worst objects', lines)


def build_pages(old_case, new_case, conditions):
    """Return exactly four (title, body) pairs; every body is at most 30 lines."""
    aliases = _Aliases((old_case, new_case))
    comparable = conditions.get('status') == 'MATCH'
    return [_overview(old_case, new_case, conditions), _setup_page(new_case, aliases),
            _hold_page(old_case, new_case, aliases, comparable),
            _transition_page(old_case, new_case, aliases, comparable)]
