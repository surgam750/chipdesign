// Regression fixtures, not synthesis or timing models.
// Default matches the supplied 128X16 model: Q becomes X after a non-read edge.
// TCM_TEST_HOLD_Q additionally tests equivalence when disabled/write cycles hold
// Q. Neither contract is imposed on the real vendor macro by this test.
module tcm_test_macro #(
    parameter integer AW = 7,
    parameter integer DW = 16
) (
    output reg [DW-1:0] Q,
    input wire CLK, CEN, GWEN, RET1N,
    input wire [DW-1:0] WEN, D,
    input wire [AW-1:0] A
);
    reg [DW-1:0] mem [0:(1<<AW)-1];
    integer k;
    always @(posedge CLK) begin
        if ((RET1N === 1'b1) && (CEN === 1'b0) && (GWEN === 1'b1))
            Q <= mem[A];
`ifndef TCM_TEST_HOLD_Q
        // Skipping an assignment of X to an already-all-X Q changes no
        // observable four-state value, and avoids thousands of redundant NBA
        // events per edge when many inactive macro instances are present.
        else if (Q !== {DW{1'bx}})
            Q <= {DW{1'bx}};
`endif
        if ((RET1N === 1'b1) && (CEN === 1'b0) && (GWEN === 1'b0))
            for (k = 0; k < DW; k = k+1)
                if (WEN[k] === 1'b0) mem[A][k] <= D[k];
    end
endmodule

module RAMSP128X16 (
    output wire [15:0] Q,
    input wire CLK, CEN, GWEN, RET1N,
    input wire [15:0] WEN, D,
    input wire [6:0] A,
    input wire [2:0] EMA,
    input wire [1:0] EMAW
);
    tcm_test_macro #(.AW(7), .DW(16)) u_model (
        .Q(Q), .CLK(CLK), .CEN(CEN), .GWEN(GWEN), .RET1N(RET1N),
        .WEN(WEN), .D(D), .A(A)
    );
endmodule

module RAMSP8KX32 (
    output wire [31:0] Q,
    input wire CLK, CEN, GWEN, RET1N,
    input wire [31:0] WEN, D,
    input wire [12:0] A,
    input wire [2:0] EMA,
    input wire [1:0] EMAW
);
    tcm_test_macro #(.AW(13), .DW(32)) u_model (
        .Q(Q), .CLK(CLK), .CEN(CEN), .GWEN(GWEN), .RET1N(RET1N),
        .WEN(WEN), .D(D), .A(A)
    );
endmodule
