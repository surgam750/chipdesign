`timescale 1ns/1ps
module tcm_proxy_case #(
    parameter integer DP = 32768,
    parameter integer DW = 64,
    parameter integer MW = 8,
    parameter integer AW = 15
) (output reg done = 0);
    localparam integer MROW = (DW == 64) ? 12 : 13;
    localparam integer RA = (DW == 64) ? 7 : 13;
    localparam integer BANKS = DP >> MROW;
    localparam integer ROWS = (DW == 64) ? 32 : 1;
`ifdef TCM_FULL_SWEEP
    localparam integer FULL_ADDRESS_SPACE = 1;
`else
    localparam integer FULL_ADDRESS_SPACE = 0;
`endif
    localparam integer LOW_SAMPLES = RA+2;
    localparam integer SAMPLED_WORDS = FULL_ADDRESS_SPACE ? DP : BANKS*ROWS;
    reg clk = 0;
    always begin
        #5;
        if (!done) clk = ~clk;
    end
    reg rst_n = 0, cs = 0, we = 0;
    reg [AW-1:0] addr = 0;
    reg [DW-1:0] din = 0;
    reg [MW-1:0] wem = 0;
    wire [DW-1:0] baseline_data, candidate_data;
    baseline_kwt_tcm_proxy #(.DP(DP),.DW(DW),.MW(MW),.AW(AW)) baseline (
        .clk(clk),.rst_n(rst_n),.cs(cs),.we(we),.addr(addr),.din(din),.wem(wem),.dout(baseline_data));
    kwt_tcm_proxy #(.DP(DP),.DW(DW),.MW(MW),.AW(AW)) candidate (
        .clk(clk),.rst_n(rst_n),.cs(cs),.we(we),.addr(addr),.din(din),.wem(wem),.dout(candidate_data));

    // Selected A/GWEN must match; CEN/WEN/D remain equal even when inactive.
    // Inactive-bank address/control differences are expected and observed.
    integer selected_pin_checks=0, inactive_A_differences=0, inactive_GWEN_differences=0;
    genvar mb, mr, mg;
    generate
      if (DW == 64) begin : targetfix_monitor
        for(mb=0;mb<BANKS;mb=mb+1) begin : b
          for(mr=0;mr<ROWS;mr=mr+1) begin : r
            for(mg=0;mg<DW/16;mg=mg+1) begin : g
              wire old_cen=baseline.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.CEN;
              wire new_cen=candidate.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.CEN;
              wire old_gwen=baseline.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.GWEN;
              wire new_gwen=candidate.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.GWEN;
              wire [RA-1:0] old_a=baseline.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.A;
              wire [RA-1:0] new_a=candidate.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.A;
              wire [15:0] old_d=baseline.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.D;
              wire [15:0] new_d=candidate.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.D;
              wire [15:0] old_wen=baseline.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.WEN;
              wire [15:0] new_wen=candidate.g_bank[mb].g_wide64.g_row[mr].g_slice[mg].u_ram.WEN;
              wire old_read=(old_cen===1'b0)&&(old_gwen===1'b1);
              wire new_read=(new_cen===1'b0)&&(new_gwen===1'b1);
              wire [15:0] old_write_bits={16{(old_cen===1'b0)&&(old_gwen===1'b0)}} & ~old_wen;
              wire [15:0] new_write_bits={16{(new_cen===1'b0)&&(new_gwen===1'b0)}} & ~new_wen;
              always @(posedge clk) if(!done) begin
                if ({old_cen,old_wen,old_d} !== {new_cen,new_wen,new_d})
                  $fatal(1,"TARGETFIX_UNCHANGED_PIN_DIFF bank=%0d row=%0d slice=%0d",mb,mr,mg);
                if (old_write_bits !== new_write_bits || old_read !== new_read)
                  $fatal(1,"TARGETFIX_EFFECTIVE_ACCESS_DIFF bank=%0d row=%0d slice=%0d",mb,mr,mg);
                if(old_cen===1'b0) begin
                  if({old_a,old_gwen} !== {new_a,new_gwen})
                    $fatal(1,"TARGETFIX_SELECTED_A_GWEN_DIFF bank=%0d row=%0d slice=%0d",mb,mr,mg);
                  selected_pin_checks=selected_pin_checks+1;
                end
                if ((^addr !== 1'bx) && old_cen===1'b1) begin
                  if(old_a !== new_a) inactive_A_differences=inactive_A_differences+1;
                  if(old_gwen !== new_gwen) inactive_GWEN_differences=inactive_GWEN_differences+1;
                end
              end
            end
          end
        end
      end
    endgenerate

    reg [DW-1:0] shadow [0:DP-1];
    reg [BANKS*ROWS-1:0] rows_read = 0;
    reg [(1<<MW)-1:0] masks_written = 0;
    reg [DW-1:0] previous_data;
    reg [31:0] prng;
    integer cycles = 0, reads = 0, writes = 0, idles = 0;
    integer phase = 0;
    integer i, b, r, byte_lane, mask_index, low_sample;
    reg [AW-1:0] target;
    reg [DW-1:0] pattern;
    reg [MW-1:0] mask;

    function automatic [DW-1:0] data_for(input integer a, input integer salt);
        reg [63:0] x;
        begin
            x = (64'h9e3779b97f4a7c15 * (a+1)) ^
                (64'hd1b54a32d192ed03 * (salt+17));
            data_for = x ^ (x >> 19) ^ (x << 7);
        end
    endfunction

    function automatic [RA-1:0] low_address(input integer sample);
        begin
            if(sample==0) low_address=0;
            else if(sample==LOW_SAMPLES-1) low_address=(1<<RA)-1;
            else low_address=1<<(sample-1);
        end
    endfunction

    function automatic [AW-1:0] sample_address(input integer sample, input bit permuted);
        integer row_index, low_index;
        begin
            row_index=sample%(BANKS*ROWS);
            low_index=sample/(BANKS*ROWS);
            if(permuted) row_index=(row_index*73+17)%(BANKS*ROWS);
            sample_address=(row_index<<RA)|low_address(low_index);
        end
    endfunction

    // Drive on the falling edge and check after the immediate read-capture
    // rising edge. An added output register or a shifted selector fails here.
    task automatic cycle(
        input bit enable, input bit write,
        input reg [AW-1:0] address,
        input reg [DW-1:0] data,
        input reg [MW-1:0] byte_enable
    );
        integer k;
        begin
            @(negedge clk);
            previous_data = candidate_data;
            cs = enable; we = write; addr = address; din = data; wem = byte_enable;
            if (enable && write) begin
                for (k=0; k<MW; k=k+1)
                    if (byte_enable[k] === 1'b1)
                        shadow[address][8*k +: 8] = data[8*k +: 8];
                masks_written[byte_enable] = 1'b1;
                writes = writes + 1;
            end
            @(posedge clk);
            #1;
            cycles = cycles + 1;
            if (candidate_data !== baseline_data)
                $fatal(1,"EQUIV DW=%0d phase=%0d cycle=%0d cs=%b we=%b addr=%h ref=%h got=%h",
                       DW,phase,cycles,cs,we,addr,baseline_data,candidate_data);
            if (candidate.read_bank !== baseline.read_bank ||
                candidate.read_row !== baseline.read_row)
                $fatal(1,"SELECTOR DW=%0d phase=%0d cycle=%0d",DW,phase,cycles);
            if (enable && !write) begin
                reads = reads + 1;
                rows_read[address >> RA] = 1'b1;
                if (candidate_data !== shadow[address])
                    $fatal(1,"SCOREBOARD DW=%0d phase=%0d cycle=%0d addr=%h want=%h got=%h",
                           DW,phase,cycles,addr,shadow[address],candidate_data);
            end else begin
                if (!enable) idles = idles + 1;
`ifdef TCM_TEST_HOLD_Q
                if (candidate_data !== previous_data)
                    $fatal(1,"Q_HOLD DW=%0d phase=%0d cycle=%0d",DW,phase,cycles);
`else
                if (candidate_data !== {DW{1'bx}})
                    $fatal(1,"Q_INVALIDATE DW=%0d phase=%0d cycle=%0d",DW,phase,cycles);
`endif
            end
        end
    endtask

    initial begin
        prng = 32'h51a7e203 ^ DW;
        // No reset-to-zero behavior is assumed or added to the memory/selector.
        phase = 1;
        cycle(0,0,0,0,0);
        cycle(0,0,{AW{1'bx}},{DW{1'bx}},{MW{1'bx}});
        rst_n = 1;
        cycle(0,0,0,0,0);
        cycle(1,0,0,0,0); // uninitialized read must remain X in both designs

        // Keep the full physical capacity. Normally initialize one known word
        // for every bank/row selector. Low-bit walking and boundary checks are
        // separate below; TCM_FULL_SWEEP optionally adds all internal words.
        phase = 2;
        for (i=0; i<SAMPLED_WORDS; i=i+1) begin
            target=FULL_ADDRESS_SPACE ? i : sample_address(i,0);
            cycle(1,1,target,data_for(target,1),{MW{1'b1}});
        end

        // An odd stride permutes bank/row selectors on consecutive read edges.
        phase = 3;
        for (i=0; i<SAMPLED_WORDS; i=i+1) begin
            target = FULL_ADDRESS_SPACE ? ((i*15437 + 91)&(DP-1)) : sample_address(i,1);
            cycle(1,0,target,0,0);
        end

        // Every low address bit and the last word in a representative row
        // of each physical bank. All 256 changed selectors were covered above.
        phase = 4;
        for (b=0; b<BANKS; b=b+1)
            for (low_sample=0; low_sample<LOW_SAMPLES; low_sample=low_sample+1) begin
                target=(b<<MROW)|(((b*5)%ROWS)<<RA)|low_address(low_sample);
                cycle(1,1,target,data_for(target,5),{MW{1'b1}});
                cycle(1,0,target,0,0);
            end
        // Single-byte writes cover every lane in every bank. Each address is
        // initialized, so a mistaken selector cannot pass because both are X.
        for (b=0; b<BANKS; b=b+1) begin
            target=(b<<MROW)|(((b*7)%ROWS)<<RA);
            for (byte_lane=0; byte_lane<MW; byte_lane=byte_lane+1) begin
                mask=1<<byte_lane;
                cycle(1,1,target,data_for(target,byte_lane+7),mask);
                cycle(1,0,target,0,0);
            end
        end

        // Exercise all byte-mask combinations, including zero and alternating.
        phase = 5;
        for (mask_index=0; mask_index<(1<<MW); mask_index=mask_index+1) begin
            target = (mask_index*1049 + 127) & (DP-1);
            cycle(1,1,target,data_for(target,17),{MW{1'b1}});
            cycle(1,1,target,data_for(target,mask_index+23),mask_index);
            cycle(1,0,target,0,0);
        end

        // Directed unknown DATA is legal in this functional test. Unselected
        // X macro outputs must not contaminate the chosen row/byte lanes.
        phase = 6;
        pattern = {DW{1'bx}};
        pattern[7:0] = 8'ha5;
        cycle(1,1,DP-1,pattern,{MW{1'b1}});
        cycle(1,0,DP-1,0,0);
        cycle(1,1,DP-1,data_for(DP-1,89),{MW{1'b1}});
        cycle(1,0,DP-1,0,0);
        cycle(0,0,{AW{1'bx}},{DW{1'bx}},{MW{1'bx}});
        cycle(1,0,DP-1,0,0);

        // Deterministic mixed traffic, consecutive reads/writes, idle gaps and
        // repeated addresses. Control/address are known on every active read.
        phase = 7;
        for (i=0; i<128; i=i+1) begin
            prng = {prng[30:0],prng[31]^prng[21]^prng[1]^prng[0]};
            target = ((prng%(BANKS*ROWS))<<RA);
            pattern = data_for(target,i+103);
            mask = prng >> 16;
            case (i & 7)
                0: cycle(0,0,{AW{1'bx}},0,0);
                1,2,3: cycle(1,1,target,pattern,mask);
                default: cycle(1,0,target,0,0);
            endcase
            if ((i & 31)==31) begin
                cycle(1,1,target,pattern,{MW{1'b1}});
                cycle(1,0,target,0,0);
                cycle(1,0,target,0,0);
            end
        end

        // rst_n never reset baseline selectors/macros. Preserve reads, writes
        // and retained selection across asserted reset rather than inventing a
        // reset behavior inside this proxy.
        phase = 8;
        rst_n = 0;
        cycle(1,0,(1<<RA)-1,0,0);
        cycle(1,1,128,data_for(128,211),{MW{1'b1}});
        cycle(1,0,128,0,0);
        cycle(0,0,0,0,0);
        rst_n = 1;
        cycle(1,0,128,0,0);
        cycle(1,0,(1<<RA)-1,0,0);

        if (DW==64) begin
            if (selected_pin_checks==0 || inactive_A_differences==0 || inactive_GWEN_differences==0)
                $fatal(1,"TARGETFIX_PIN_OBSERVATION_MISSING");
            $display("TARGETFIX_PIN_CHECK_PASS selected_checks=%0d inactive_A_differences=%0d inactive_GWEN_differences=%0d",selected_pin_checks,inactive_A_differences,inactive_GWEN_differences);
        end
        if (rows_read !== {BANKS*ROWS{1'b1}})
            $fatal(1,"COVERAGE missing bank/row DW=%0d",DW);
        if (masks_written !== {(1<<MW){1'b1}})
            $fatal(1,"COVERAGE missing byte masks DW=%0d",DW);
        $display("TCM_CASE_PASS DW=%0d capacity_words=%0d initialized_samples=%0d full_address=%0d bank_rows=%0d masks=%0d cycles=%0d reads=%0d writes=%0d idles=%0d",
                 DW,DP,SAMPLED_WORDS,FULL_ADDRESS_SPACE,BANKS*ROWS,1<<MW,cycles,reads,writes,idles);
        done = 1;
    end
endmodule

module tb_tcm_proxy_equiv;
    wire itcm_done, dtcm_done;
    tcm_proxy_case #(.DP(32768),.DW(64),.MW(8),.AW(15)) itcm(.done(itcm_done));
    tcm_proxy_case #(.DP(65536),.DW(32),.MW(4),.AW(16)) dtcm(.done(dtcm_done));
    initial begin
        wait(itcm_done && dtcm_done);
`ifdef TCM_TEST_HOLD_Q
        $display("TCM_EQUIV_PASS mode=hold_q");
`else
        $display("TCM_EQUIV_PASS mode=invalidate_q");
`endif
        $finish;
    end
    initial begin
        #5000000;
        $fatal(1,"TCM_EQUIV_TIMEOUT");
    end
endmodule
