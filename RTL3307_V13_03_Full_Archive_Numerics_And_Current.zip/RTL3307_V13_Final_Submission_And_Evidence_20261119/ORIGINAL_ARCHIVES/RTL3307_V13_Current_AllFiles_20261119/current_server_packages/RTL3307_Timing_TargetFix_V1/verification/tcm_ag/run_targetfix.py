#!/usr/bin/env python3
"""Bounded actual-source TARGETFIX_AGWEN equivalence simulation; no timing claim."""
import argparse
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
EXPECTED_BASELINE = "bae98efafae6bf03fa2eafb9feb053baafc4167fdd380305705c4a3570771cde"
EXPECTED_CANDIDATE = "bc63c6b1ac488e63d5ed5adee013cd04c4fe3277096145f2d2b654acc1def4e0"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def norm(text):
    return re.sub(r"\s+", "", re.sub(r"//[^\n]*", "", text))


def macro(source, name):
    matches = re.findall(r"\b"+name+r"\s+u_ram\s*\((.*?)\);", source, re.S)
    if len(matches) != 1:
        raise RuntimeError("Expected exactly one macro template " + name)
    return norm(matches[0])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--baseline", type=Path, default=WORKSPACE / "deadline_timing_20261118/globslew025_package/RTL3307_Timing_GlobSlew025_V1/payload/native/support/kwt_tcm_proxy.v")
    p.add_argument("--candidate", type=Path, default=HERE.parent / "kwt_tcm_proxy.v")
    p.add_argument("--iverilog", type=Path, default=WORKSPACE / "timing_work/toolchain/root/usr/bin/iverilog")
    p.add_argument("--vvp", type=Path, default=WORKSPACE / "timing_work/toolchain/root/usr/bin/vvp")
    p.add_argument("--ivl-base", type=Path, default=WORKSPACE / "timing_work/toolchain/root/usr/lib/x86_64-linux-gnu/ivl")
    p.add_argument("--out", type=Path)
    a = p.parse_args()
    out = (a.out or HERE / ("run_" + datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f"))).resolve()
    out.mkdir(parents=True, exist_ok=False)
    source_paths = [a.baseline.resolve(), a.candidate.resolve(), HERE / "tcm_macro_models.sv", HERE / "tb_targetfix.sv", Path(__file__).resolve()]
    hashes = {str(x): sha(x) for x in source_paths}
    receipt = {
        "status": "RUNNING", "kind": "TARGETFIX_AGWEN_ACTUAL_PROXY_FINITE_EQUIVALENCE",
        "source_sha256": hashes, "expected_baseline": EXPECTED_BASELINE,
        "expected_candidate": EXPECTED_CANDIDATE,
        "proof_scope": "Known active control/address; effective macro writes, immediate read-cycle data, unchanged read selectors. Inactive A/GWEN pins intentionally may differ. D/WEN/CEN remain unchanged.",
        "limits": ["Finite behavioral simulation, not formal proof or target-library STA/LEC.",
                   "No universal four-state equivalence claim for active unknown address/control.",
                   "No full internal memory-address sweep; all bank/row selectors and all byte-mask combinations are covered.",
                   "Macro models are regression fixtures, not vendor timing or retention models.",
                   "No PPA improvement or hold closure inferred from functional equivalence."],
        "modes": {}
    }

    def save():
        (out / "receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")

    save()
    try:
        if sha(a.baseline) != EXPECTED_BASELINE or sha(a.candidate) != EXPECTED_CANDIDATE:
            raise RuntimeError("Assigned baseline/candidate source hash mismatch")
        old = a.baseline.read_text()
        new = a.candidate.read_text()
        old_128 = macro(old, "RAMSP128X16")
        new_128 = macro(new, "RAMSP128X16")
        old_gwen, new_gwen = ".GWEN(~we)", ".GWEN(local_GWEN)"
        old_a, new_a = ".A(addr[RA-1:0])", ".A(local_A)"
        for before, after in ((old_gwen,new_gwen),(old_a,new_a)):
            if old_128.count(before)!=1 or new_128.count(after)!=1:
                raise RuntimeError("Unexpected ITCM A/GWEN expressions")
        if old_128.replace(old_gwen,new_gwen).replace(old_a,new_a) != new_128:
            raise RuntimeError("An ITCM macro pin other than approved A/GWEN changed")
        if macro(old,"RAMSP8KX32") != macro(new,"RAMSP8KX32"):
            raise RuntimeError("DTCM macro pins changed")
        allowed_block = """wire bank_match;
                wire [RA-1:0] local_A;
                wire local_GWEN;
                assign bank_match = (addr[AW-1:MROW] == bank);
                assign local_A = addr[RA-1:0] & {RA{bank_match}};
                assign local_GWEN = ~(we & bank_match);"""
        normalized = norm(new)
        if normalized.count(norm(allowed_block)) != 1:
            raise RuntimeError("Missing exact approved address/GWEN qualification")
        normalized = normalized.replace(norm(allowed_block), "", 1)
        normalized = normalized.replace(new_gwen,old_gwen,1).replace(new_a,old_a,1)
        if normalized != norm(old):
            raise RuntimeError("Unexpected functional source changes beyond A/GWEN")
        receipt["static_checks"] = {"only_approved_A_GWEN_functional_change": True, "ITCM_CEN_WEN_D_other_pins_unchanged": True, "DTCM_macro_pins_unchanged": True, "all_macro_A_GWEN_pin_values_always_equal": False}
        truth = []
        for cs, bank_match, row_match, we, mask, address_bit in itertools.product((0,1), repeat=6):
            cen = not(cs and bank_match and row_match)
            old_gw, new_gw = not we, not(we and bank_match)
            new_addr = address_bit and bank_match
            old_read, new_read = (not cen and old_gw), (not cen and new_gw)
            old_write = not cen and not old_gw and mask
            new_write = not cen and not new_gw and mask
            if old_write != new_write or old_read != new_read or (not cen and (old_gw != new_gw or address_bit != new_addr)):
                raise RuntimeError("Known Boolean access/address truth-table mismatch")
            truth.append([cs,bank_match,row_match,we,mask,address_bit,int(old_read),int(new_read),int(old_write),int(new_write),int(new_addr)])
        (out / "effective_access_truth_table.json").write_text(json.dumps({"columns":["cs","bank_match","row_match","we","mask","address_bit","old_read","new_read","old_write","new_write","new_address_bit"],"cases":truth},indent=2)+"\n")
        receipt["known_boolean_one_address_bit_truth_table_cases"] = len(truth)
        receipt["new_timing_risk"] = "New bank-address-to-A/GWEN paths can be slower. D hold and WEN hold are not directly changed or claimed fixed. No native STA was run."
        renamed, count = re.subn(r"(?m)^module kwt_tcm_proxy\b", "module baseline_kwt_tcm_proxy", old)
        if count != 1:
            raise RuntimeError("Expected one actual baseline module declaration")
        ref = out / "baseline_kwt_tcm_proxy.v"
        ref.write_text(renamed)
        receipt["reference_transform"] = "Actual GLOBSLEW025 proxy; only module declaration renamed to baseline_kwt_tcm_proxy"
        for mode, defines in (("invalidate_q",[]),("hold_q",["-DTCM_TEST_HOLD_Q"])):
            executable = out / (mode+".vvp")
            cmd = [str(a.iverilog.resolve()),"-B",str(a.ivl_base.resolve()),"-g2012","-Wall","-s","tb_tcm_proxy_equiv","-o",str(executable)] + defines + [str(ref),str(a.candidate.resolve()),str(HERE/"tcm_macro_models.sv"),str(HERE/"tb_targetfix.sv")]
            compiled = subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True,timeout=60)
            (out/(mode+"_compile.log")).write_text(compiled.stdout)
            receipt["modes"][mode] = {"compile_command":cmd,"compile_returncode":compiled.returncode}
            if compiled.returncode:
                raise RuntimeError(mode+" compile failed: "+compiled.stdout[-1500:])
            run_cmd=[str(a.vvp.resolve()),str(executable)]
            simulated=subprocess.run(run_cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True,timeout=90)
            (out/(mode+"_simulation.log")).write_text(simulated.stdout)
            print(simulated.stdout,end="",flush=True)
            case_lines=re.findall(r"^TCM_CASE_PASS.*$",simulated.stdout,re.M)
            pin_lines=re.findall(r"^TARGETFIX_PIN_CHECK_PASS.*$",simulated.stdout,re.M)
            ok=simulated.returncode==0 and len(case_lines)==2 and len(pin_lines)==1 and "TCM_EQUIV_PASS mode="+mode in simulated.stdout
            receipt["modes"][mode].update({"run_command":run_cmd,"run_returncode":simulated.returncode,"cases":case_lines,"pin_checks":pin_lines,"passed":ok})
            save()
            if not ok:
                raise RuntimeError(mode+" incomplete or failed")
        receipt["status"]="PASS_FINITE_EQUIVALENCE_ONLY"
    except Exception as exc:
        receipt["status"]="FAILED_OR_INCOMPLETE"
        receipt["error"]=str(exc)
        print("TARGETFIX_AGWEN_ERROR "+str(exc),flush=True)
    finally:
        receipt["source_changes"]=[p for p,h in hashes.items() if sha(p)!=h]
        if receipt["source_changes"]:
            receipt["status"]="FAILED_SOURCE_CHANGED"
        receipt["artifacts_sha256"]={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!="receipt.json"}
        save()
        print("RECEIPT "+str(out/"receipt.json"),flush=True)
    return 0 if receipt["status"]=="PASS_FINITE_EQUIVALENCE_ONLY" else 1


if __name__=="__main__":
    raise SystemExit(main())
