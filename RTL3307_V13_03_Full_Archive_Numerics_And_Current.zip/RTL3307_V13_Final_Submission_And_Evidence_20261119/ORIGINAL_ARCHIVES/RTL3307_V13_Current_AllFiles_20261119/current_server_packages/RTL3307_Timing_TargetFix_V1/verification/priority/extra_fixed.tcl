set mode extra_fixed
set count 0
set raw {}
proc dc_call {body} {
 set r [uplevel 1 $body]
 if {[string is boolean -strict $r] && !$r} {error "command failed"}
 return $r
}
proc current_design {} {return e203_soc_top}
proc sizeof_collection {v} {return 1}
proc get_object_name {v} {return $v}
proc set_cost_priority {v} {
 global mode raw
 if {$mode eq "false_return"} {return 0}
 set raw $v
 if {$mode eq "bad_order"} {set raw {min_delay max_delay max_transition max_fanout max_capacitance}}
 if {$mode eq "extra_fixed"} {set raw [concat {connection_classes min_capacitance} $raw {cell_degradation}]}
 return 1
}
proc get_attribute {o a} {global raw; return $raw}
proc compile_ultra {args} {
 global mode raw count
 incr count
 if {$mode eq "post_change"} {set raw {max_transition max_delay min_delay max_fanout max_capacitance}}
 return 1
}

set code [catch {
    # TARGETFIX: optimize setup and hold ahead of the unchanged 0.25ns DRC target.
    # This changes synthesis priorities only; the original PT SDC remains fixed.
    proc targetfix_check_priority {phase} {
        set top [current_design]
        if {[sizeof_collection $top] != 1 || [get_object_name $top] ne "e203_soc_top"} {
            error "TARGETFIX priority check requires e203_soc_top"
        }
        set desired {max_delay min_delay max_transition max_fanout max_capacitance}
        set raw [get_attribute $top cost_priority]
        set observed {}
        foreach cost $raw {
            if {$cost in $desired} {lappend observed $cost}
        }
        if {$observed ne $desired} {
            error "TARGETFIX cost_priority readback mismatch: $raw"
        }
        puts "TARGETFIX_COST_PRIORITY_READBACK phase=$phase top=e203_soc_top order=[join $observed ,] raw={$raw}"
    }
    dc_call {set_cost_priority {max_delay min_delay max_transition max_fanout max_capacitance}}
    targetfix_check_priority pre_compile
    if {![compile_ultra -no_autoungroup]} {error "Compile failed"}
    targetfix_check_priority post_compile

} message]
puts "RESULT code=$code count=$count message=$message"
