reg  clk;
reg  rst_n;
reg  start;
reg  abort;
reg  clr_perf;
reg [3:0] opcode;
reg [6:0] dim_m;
reg [9:0] dim_k;
reg [9:0] dim_n;
reg [31:0] x_base;
reg [31:0] w_base;
reg [31:0] y_base;
reg [31:0] x_stride;
reg [31:0] y_stride;
reg  rd_cmd_fire;
reg  wr_cmd_fire;
reg  rd_cmd_stall;
reg  wr_cmd_stall;
reg  rd_req_ready;
reg  rd_ret_valid;
reg  rd_ret_err;
reg  rd_idle;
reg [31:0] rd_ret_addr;
reg [31:0] rd_ret_data;
reg [15:0] rd_ret_tag;
reg  wr_req_ready;
reg  wr_ret_valid;
reg  wr_ret_err;
reg  wr_idle;
reg [31:0] wr_ret_addr;
reg  mac_out_valid;
reg [1:0] mac_sat;
reg  fifo_empty;
kwt_ctrl_reference reference (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .abort(abort),
        .clr_perf(clr_perf),
        .opcode(opcode),
        .dim_m(dim_m),
        .dim_k(dim_k),
        .dim_n(dim_n),
        .x_base(x_base),
        .w_base(w_base),
        .y_base(y_base),
        .x_stride(x_stride),
        .y_stride(y_stride),
        .rd_cmd_fire(rd_cmd_fire),
        .wr_cmd_fire(wr_cmd_fire),
        .rd_cmd_stall(rd_cmd_stall),
        .wr_cmd_stall(wr_cmd_stall),
        .rd_req_ready(rd_req_ready),
        .rd_ret_valid(rd_ret_valid),
        .rd_ret_err(rd_ret_err),
        .rd_idle(rd_idle),
        .rd_ret_addr(rd_ret_addr),
        .rd_ret_data(rd_ret_data),
        .rd_ret_tag(rd_ret_tag),
        .wr_req_ready(wr_req_ready),
        .wr_ret_valid(wr_ret_valid),
        .wr_ret_err(wr_ret_err),
        .wr_idle(wr_idle),
        .wr_ret_addr(wr_ret_addr),
        .mac_out_valid(mac_out_valid),
        .mac_sat(mac_sat),
        .fifo_empty(fifo_empty)
);
kwt_ctrl dut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .abort(abort),
        .clr_perf(clr_perf),
        .opcode(opcode),
        .dim_m(dim_m),
        .dim_k(dim_k),
        .dim_n(dim_n),
        .x_base(x_base),
        .w_base(w_base),
        .y_base(y_base),
        .x_stride(x_stride),
        .y_stride(y_stride),
        .rd_cmd_fire(rd_cmd_fire),
        .wr_cmd_fire(wr_cmd_fire),
        .rd_cmd_stall(rd_cmd_stall),
        .wr_cmd_stall(wr_cmd_stall),
        .rd_req_ready(rd_req_ready),
        .rd_ret_valid(rd_ret_valid),
        .rd_ret_err(rd_ret_err),
        .rd_idle(rd_idle),
        .rd_ret_addr(rd_ret_addr),
        .rd_ret_data(rd_ret_data),
        .rd_ret_tag(rd_ret_tag),
        .wr_req_ready(wr_req_ready),
        .wr_ret_valid(wr_ret_valid),
        .wr_ret_err(wr_ret_err),
        .wr_idle(wr_idle),
        .wr_ret_addr(wr_ret_addr),
        .mac_out_valid(mac_out_valid),
        .mac_sat(mac_sat),
        .fifo_empty(fifo_empty)
);
wire [497:0] reference_outputs = {reference.busy,reference.done_event,reference.error_event,reference.error_code,reference.error_addr,reference.perf_total,reference.perf_xload,reference.perf_issue,reference.perf_rd_stall,reference.perf_wr_stall,reference.perf_rd_words,reference.perf_wr_words,reference.perf_starve,reference.task_count,reference.sat_count,reference.cycle_now,reference.rd_req_valid,reference.rd_req_addr,reference.rd_req_tag,reference.wr_req_valid,reference.wr_req_addr,reference.x_write,reference.w_write,reference.row_issue,reference.x_write_raw,reference.row_issue_raw,reference.row_read,reference.x_capture,reference.mac_valid,reference.mac_set,reference.lane_count,reference.fifo_push,reference.fifo_pop,reference.fifo_flush};
wire [497:0] candidate_outputs = {dut.busy,dut.done_event,dut.error_event,dut.error_code,dut.error_addr,dut.perf_total,dut.perf_xload,dut.perf_issue,dut.perf_rd_stall,dut.perf_wr_stall,dut.perf_rd_words,dut.perf_wr_words,dut.perf_starve,dut.task_count,dut.sat_count,dut.cycle_now,dut.rd_req_valid,dut.rd_req_addr,dut.rd_req_tag,dut.wr_req_valid,dut.wr_req_addr,dut.x_write,dut.w_write,dut.row_issue,dut.x_write_raw,dut.row_issue_raw,dut.row_read,dut.x_capture,dut.mac_valid,dut.mac_set,dut.lane_count,dut.fifo_push,dut.fifo_pop,dut.fifo_flush};
