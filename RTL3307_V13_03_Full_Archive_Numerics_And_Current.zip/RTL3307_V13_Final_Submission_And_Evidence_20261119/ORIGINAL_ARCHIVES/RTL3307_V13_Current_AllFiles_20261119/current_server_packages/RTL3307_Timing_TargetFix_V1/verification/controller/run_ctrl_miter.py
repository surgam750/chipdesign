#!/usr/bin/env python3
"""Finite actual-source RTL simulation; no synthesis, STA or formal claim."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
DEFAULT_ORIGINAL = WORKSPACE / "deadline_timing_20261118/globslew025_package/RTL3307_Timing_GlobSlew025_V1/payload/frozen/rtl/accel/kwt_ctrl.v"
DEFAULT_CANDIDATE = HERE.parent / "kwt_ctrl.v"
EXPECTED_ORIGINAL_SHA = "0dbc47dc193a572e44b54ba8b1c3ea23ebf73605049266602cb3ad686171e922"
EXPECTED_CANDIDATE_SHA = "72d4d8668ad6affd59d8ea09d7b3c6d2c1b3d55d85fb15002cf2ba4f48301d47"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ports(text):
    header = text.split(") (", 1)[1].split("\n);", 1)[0]
    result = []
    for line in header.splitlines():
        if not line.strip():
            continue
        m = re.fullmatch(r"\s*(input|output)\s+(?:wire|reg)\s*(\[[^]]+\])?\s*([\w, ]+)\s*", line)
        if not m:
            raise RuntimeError("Unrecognized actual controller port declaration: " + line)
        width = m.group(2) or ""
        bits = 1
        if width:
            ends = [int(x) for x in width[1:-1].split(":")]
            bits = abs(ends[0] - ends[1]) + 1
        for name in m.group(3).split(","):
            if name.strip():
                result.append((m.group(1), width, name.strip(), bits))
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--original", type=Path, default=DEFAULT_ORIGINAL)
    p.add_argument("--candidate", type=Path, default=DEFAULT_CANDIDATE)
    p.add_argument("--regs", type=Path, default=DEFAULT_ORIGINAL.with_name("kwt_regs.v"))
    p.add_argument("--iverilog", type=Path, default=WORKSPACE / "timing_work/toolchain/root/usr/bin/iverilog")
    p.add_argument("--vvp", type=Path, default=WORKSPACE / "timing_work/toolchain/root/usr/bin/vvp")
    p.add_argument("--ivl-base", type=Path, default=WORKSPACE / "timing_work/toolchain/root/usr/lib/x86_64-linux-gnu/ivl")
    p.add_argument("--out", type=Path)
    a = p.parse_args()
    out = a.out or HERE / ("run_" + datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f"))
    out.mkdir(parents=True, exist_ok=False)
    original = a.original.resolve()
    candidate = a.candidate.resolve()
    regs = a.regs.resolve()
    bench = HERE / "tb_kwt_ctrl_miter.sv"
    sources = [original, candidate, regs, bench, Path(__file__).resolve()]
    source_hashes = {str(x): sha(x) for x in sources}
    receipt = {
        "kind": "ACTUAL_KWT_CTRL_FINITE_SIMULATION_MITER", "status": "RUNNING",
        "source_sha256": source_hashes,
        "expected_candidate_sha256": EXPECTED_CANDIDATE_SHA,
        "tools": {"iverilog": str(a.iverilog.resolve()), "vvp": str(a.vvp.resolve()), "ivl_base": str(a.ivl_base.resolve())},
        "limitations": [
            "Finite RTL simulation, not formal equivalence, target-library STA, SoC LEC, area or power measurement.",
            "Deposited counter/state tests check one-step transitions and do not establish reachability.",
            "Counter arithmetic is tested only for known 32-bit values and known mac_sat flags. X/Z update-enable hold is tested with known counter and state; arbitrary-X arithmetic equivalence is not claimed.",
            "The reset-to-task sequences use no deposits but a bounded known-input memory/MAC/FIFO stimulus model, not the complete SoC.",
            "The actual original kwt_regs instances observe the actual controller counters. CSR control outputs are not fed back in this focused miter."
        ], "test_scope": "Read/write +1 and saturation +0/+1/+2; carry lengths0..32 plus even variants/overflow/patterns/128 deterministic words; five states x start/clear x independent0/1/X/Z read/write/mac-valid; reset priorities; natural completion/abort/bad config; three same-edge CSRs and response backpressure"
    }

    def save():
        (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")

    save()
    try:
        if sha(original) != EXPECTED_ORIGINAL_SHA:
            raise RuntimeError("Original differs from the frozen GLOB/RDCOUNT controller")
        if sha(candidate) != EXPECTED_CANDIDATE_SHA:
            raise RuntimeError("Candidate differs from the explicitly assigned source SHA")
        old = original.read_text()
        new = candidate.read_text()
        mapping = ports(old)
        if mapping != ports(new):
            raise RuntimeError("Controller ports changed")
        renamed, count = re.subn(r"(?m)^module kwt_ctrl\b", "module kwt_ctrl_reference", old)
        if count != 1:
            raise RuntimeError("Expected exactly one module declaration to rename")
        ref_file = out / "kwt_ctrl_reference.v"
        ref_file.write_text(renamed)
        if ref_file.read_text().replace("module kwt_ctrl_reference", "module kwt_ctrl", 1) != old:
            raise RuntimeError("Reference transformation changed more than the module name")
        inputs = [x for x in mapping if x[0] == "input"]
        outputs = [x for x in mapping if x[0] == "output"]
        connection = ",\n".join("        .%s(%s)" % (x[2], x[2]) for x in inputs)
        bindings = ["reg %s %s;" % (x[1], x[2]) for x in inputs]
        for module, instance in (("kwt_ctrl_reference", "reference"), ("kwt_ctrl", "dut")):
            bindings.append("%s %s (\n%s\n);" % (module, instance, connection))
        for inst, label in (("reference", "reference"), ("dut", "candidate")):
            bindings.append("wire [%d:0] %s_outputs = {%s};" % (
                sum(x[3] for x in outputs) - 1, label,
                ",".join(inst + "." + x[2] for x in outputs)))
        (out / "bindings.svh").write_text("\n".join(bindings) + "\n")
        csr_bindings = []
        csr_ports = {"clk": "clk", "rst_n": "rst_n", "s_icb_cmd_valid": "csr_valid",
                     "s_icb_cmd_addr": "csr_addr", "s_icb_cmd_read": "csr_read",
                     "s_icb_cmd_wdata": "csr_wdata", "s_icb_cmd_wmask": "csr_mask",
                     "s_icb_rsp_ready": "csr_rsp_ready"}
        monitor_ports = ["busy", "done_event", "error_event", "error_code", "error_addr",
                         "perf_total", "perf_xload", "perf_issue", "perf_rd_stall", "perf_wr_stall",
                         "perf_rd_words", "perf_wr_words", "perf_starve", "task_count", "sat_count", "cycle_now"]
        for inst, prefix in (("reference", "ref"), ("dut", "dut")):
            con = dict(csr_ports)
            con.update({x: inst + "." + x for x in monitor_ports})
            con.update({"s_icb_cmd_ready": prefix + "_csr_ready", "s_icb_rsp_valid": prefix + "_csr_valid",
                        "s_icb_rsp_rdata": prefix + "_csr_data", "s_icb_rsp_err": prefix + "_csr_err", "irq": prefix + "_irq"})
            csr_bindings.append("kwt_regs %s_regs (\n%s\n);" % (prefix, ",\n".join("        .%s(%s)" % (k, v) for k, v in sorted(con.items()))))
        (out / "csr_bindings.svh").write_text("\n".join(csr_bindings) + "\n")
        receipt["all_compared_controller_output_ports"] = [x[2] for x in outputs]
        receipt["reference_transform"] = "Only the original actual module declaration is renamed to kwt_ctrl_reference"
        executable = out / "miter.vvp"
        commands = {
            "version_compiler": [str(a.iverilog.resolve()), "-B", str(a.ivl_base.resolve()), "-V"],
            "version_runtime": [str(a.vvp.resolve()), "-V"],
            "compile": [str(a.iverilog.resolve()), "-B", str(a.ivl_base.resolve()), "-g2012", "-Wall", "-I", str(out.resolve()), "-s", "tb_kwt_ctrl_miter", "-o", str(executable.resolve()), str(ref_file.resolve()), str(candidate), str(regs), str(bench)],
            "simulate": [str(a.vvp.resolve()), str(executable.resolve())]
        }
        receipt["commands"] = commands
        receipt["returncodes"] = {}
        for label, cmd in commands.items():
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    universal_newlines=True, timeout=30)
            (out / (label + ".log")).write_text(result.stdout)
            receipt["returncodes"][label] = result.returncode
            if label in ("compile", "simulate"):
                print(result.stdout, end="", flush=True)
            if result.returncode:
                raise RuntimeError(label + " failed; see saved log")
        simulation = (out / "simulate.log").read_text()
        groups = re.findall(r"^TARGETFIX_GROUP_PASS .*$", simulation, re.M)
        final = re.findall(r"^TARGETFIX_TEST_PASS .*$", simulation, re.M)
        if len(groups) != 5 or len(final) != 1:
            raise RuntimeError("Missing explicit expected test completion markers")
        receipt["groups"] = groups
        receipt["completion"] = final[0]
        receipt["status"] = "PASS_FINITE_SIMULATION_ONLY"
    except Exception as exc:
        receipt["status"] = "FAILED_OR_INCOMPLETE"
        receipt["error"] = str(exc)
    finally:
        changed = [x for x, digest in source_hashes.items() if sha(x) != digest]
        receipt["source_changes"] = changed
        if changed:
            receipt["status"] = "FAILED_SOURCE_CHANGED"
        receipt["artifacts_sha256"] = {x.name: sha(x) for x in sorted(out.iterdir()) if x.is_file() and x.name != "receipt.json"}
        save()
        print("RECEIPT " + str(out / "receipt.json"))
    return 0 if receipt["status"] == "PASS_FINITE_SIMULATION_ONLY" else 1


if __name__ == "__main__":
    raise SystemExit(main())
