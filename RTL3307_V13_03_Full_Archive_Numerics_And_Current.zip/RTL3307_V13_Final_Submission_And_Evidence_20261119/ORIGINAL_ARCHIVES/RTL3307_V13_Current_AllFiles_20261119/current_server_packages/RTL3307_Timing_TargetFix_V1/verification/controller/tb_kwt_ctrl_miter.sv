`timescale 1ns/1ps
module tb_kwt_ctrl_miter;
    // Generated bindings instantiate the actual old and new kwt_ctrl sources.
    `include "bindings.svh"

    reg csr_valid, csr_read, csr_rsp_ready;
    reg [31:0] csr_addr, csr_wdata;
    reg [3:0] csr_mask;
    wire ref_csr_ready, dut_csr_ready, ref_csr_valid, dut_csr_valid;
    wire [31:0] ref_csr_data, dut_csr_data;
    wire ref_csr_err, dut_csr_err, ref_irq, dut_irq;
    `include "csr_bindings.svh"

    integer steps=0, arithmetic_checks=0, priority_checks=0;
    integer async_checks=0, csr_reads=0, backpressure_checks=0;
    integer natural_cycles=0, natural_done=0, natural_errors=0;
    reg [4:0] natural_states=0;
    reg natural_phase=0;
    integer i, j, kcase, fire_kind, wr_kind, valid_kind, sat_kind;
    reg [63:0] wide;
    reg [31:0] mask, random_word;

    function [31:0] random_next;
        input [31:0] prior;
        reg [31:0] x;
        begin
            x=prior ^ (prior << 13);
            x=x ^ (x >> 17);
            random_next=x ^ (x << 5);
        end
    endfunction

    task compare_all;
        input require_known;
        begin
            if (reference_outputs !== candidate_outputs)
                $fatal(1,"CTRL_OUTPUT_MISMATCH step=%0d old_q=%h new_q=%h",steps,reference.perf_rd_words,dut.perf_rd_words);
            if (reference.state !== dut.state)
                $fatal(1,"CTRL_STATE_MISMATCH step=%0d",steps);
            if (require_known && (^candidate_outputs === 1'bx))
                $fatal(1,"UNKNOWN_CTRL_OUTPUT step=%0d",steps);
            if ({ref_csr_ready,ref_csr_valid,ref_csr_data,ref_csr_err,ref_irq} !==
                {dut_csr_ready,dut_csr_valid,dut_csr_data,dut_csr_err,dut_irq})
                $fatal(1,"CSR_OUTPUT_MISMATCH step=%0d",steps);
        end
    endtask

    task neutral;
        begin
            clk=0;
            start=0; abort=0; clr_perf=0;
            opcode=0; dim_m=1; dim_k=2; dim_n=2;
            x_base=32'h80000000; w_base=32'h80001000; y_base=32'h80002000;
            x_stride=4; y_stride=4;
            rd_cmd_fire=0; wr_cmd_fire=0; rd_cmd_stall=0; wr_cmd_stall=0;
            rd_req_ready=1; rd_ret_valid=0; rd_ret_err=0; rd_idle=1;
            rd_ret_addr=0; rd_ret_data=0; rd_ret_tag=0;
            wr_req_ready=1; wr_ret_valid=0; wr_ret_err=0; wr_idle=1; wr_ret_addr=0;
            mac_out_valid=0; mac_sat=0; fifo_empty=1;
            csr_valid=0; csr_read=1; csr_rsp_ready=1;
            csr_addr=32'h54; csr_wdata=0; csr_mask=4'hf;
        end
    endtask

    task reset_all;
        begin
            neutral();
            rst_n=1; #1; rst_n=0; #1;
            compare_all(1);
            if (dut.perf_rd_words !== 0 || dut.perf_wr_words !== 0 || dut.sat_count !== 0 || dut.state !== 0 || dut_csr_valid !== 0)
                $fatal(1,"ASYNC_RESET_FAILED before any clock edge");
            async_checks=async_checks+1;
            rst_n=1; #1;
        end
    endtask

    // One actual clock edge. Independent expected count uses 33-bit addition.
    // The pre-edge CSR read assertion checks the original kwt_regs NBA timing.
    task step;
        reg [31:0] before_q, before_wr, before_sat, expected_q, expected_wr, expected_sat, expected_csr;
        reg [32:0] sum, sum_wr, sum_sat;
        reg accepted_read;
        begin
            #1;
            compare_all((mac_out_valid === 1'b0) || (mac_out_valid === 1'b1));
            before_q=dut.perf_rd_words; before_wr=dut.perf_wr_words; before_sat=dut.sat_count;
            sum={1'b0,before_q}+33'd1;
            sum_wr={1'b0,before_wr}+33'd1;
            sum_sat={1'b0,before_sat}+{32'b0,mac_sat[0]}+{32'b0,mac_sat[1]};
            expected_q=before_q; expected_wr=before_wr; expected_sat=before_sat;
            if (!rst_n) begin expected_q=0; expected_wr=0; expected_sat=0; end
            else if (dut.state == 0 && (start || clr_perf)) begin expected_q=0; expected_wr=0; expected_sat=0; end
            else if (dut.busy) begin
                // Procedural guards retain 0/X/Z hold with known counters.
                if (rd_cmd_fire) expected_q=sum[31:0];
                if (wr_cmd_fire) expected_wr=sum_wr[31:0];
                if (dut.fifo_push) expected_sat=sum_sat[31:0];
            end
            case(csr_addr[11:0])
                12'h054: expected_csr=before_q;
                12'h058: expected_csr=before_wr;
                12'h068: expected_csr=before_sat;
                default: expected_csr=32'hx;
            endcase
            accepted_read=rst_n && csr_valid && dut_csr_ready && csr_read &&
                          (csr_addr[11:0]==12'h054 || csr_addr[11:0]==12'h058 || csr_addr[11:0]==12'h068);
            if (natural_phase) begin
                natural_cycles=natural_cycles+1;
                if (dut.state <= 4) natural_states[dut.state]=1;
                if (dut.done_event) natural_done=natural_done+1;
                if (dut.error_event) natural_errors=natural_errors+1;
            end
            clk=1; #1; steps=steps+1;
            compare_all((mac_out_valid === 1'b0) || (mac_out_valid === 1'b1));
            if (dut.perf_rd_words !== expected_q || dut.perf_wr_words !== expected_wr || dut.sat_count !== expected_sat)
                $fatal(1,"COUNT_RULE_MISMATCH step=%0d rd=%h/%h wr=%h/%h sat=%h/%h",steps,dut.perf_rd_words,expected_q,dut.perf_wr_words,expected_wr,dut.sat_count,expected_sat);
            if (accepted_read) begin
                if (dut_csr_valid !== 1 || dut_csr_data !== expected_csr)
                    $fatal(1,"CSR_PRE_EDGE_VALUE_MISMATCH step=%0d addr=%h expected=%h actual=%h",steps,csr_addr,expected_csr,dut_csr_data);
                csr_reads=csr_reads+1;
            end
            if (natural_phase && dut.state <= 4) natural_states[dut.state]=1;
            #1; clk=0; #1;
        end
    endtask

    // Deposits intentionally test one-step transitions, not reachability.
    task check_increment;
        input [31:0] value;
        reg [32:0] expected, expected_sat;
        integer flags;
        begin
            for(flags=0;flags<4;flags=flags+1) begin
                reference.state=3; dut.state=3;
                reference.perf_rd_words=value; dut.perf_rd_words=value;
                reference.perf_wr_words=value; dut.perf_wr_words=value;
                reference.sat_count=value; dut.sat_count=value;
                rd_cmd_fire=1; wr_cmd_fire=1; mac_out_valid=1; mac_sat=flags;
                expected={1'b0,value}+33'd1;
                expected_sat={1'b0,value}+{32'b0,mac_sat[0]}+{32'b0,mac_sat[1]};
                #1;
                if (dut.perf_rd_words_inc !== expected[31:0] || dut.perf_wr_words_inc !== expected[31:0] || dut.sat_count_next !== expected_sat[31:0])
                    $fatal(1,"PREFIX_ARITHMETIC_MISMATCH q=%h flags=%b wr=%h sat=%h expected_sat=%h",value,mac_sat,dut.perf_wr_words_inc,dut.sat_count_next,expected_sat[31:0]);
                arithmetic_checks=arithmetic_checks+1; step();
            end
        end
    endtask

    task csr_counter;
        input [31:0] address;
        integer tick;
        begin
            reset_all();
            reference.state=3; dut.state=3;
            reference.perf_rd_words=32'hfffffffe; dut.perf_rd_words=32'hfffffffe;
            reference.perf_wr_words=32'hfffffffe; dut.perf_wr_words=32'hfffffffe;
            reference.sat_count=32'hfffffffe; dut.sat_count=32'hfffffffe;
            csr_addr=address; csr_valid=1; rd_cmd_fire=1; wr_cmd_fire=1; mac_out_valid=1; mac_sat=1;
            step(); step(); rd_cmd_fire=0; wr_cmd_fire=0; mac_out_valid=0; step();
            csr_rsp_ready=0; rd_cmd_fire=1; wr_cmd_fire=1; mac_out_valid=1;
            for(tick=0;tick<3;tick=tick+1) begin
                step();
                if (dut_csr_data !== 0 || dut_csr_ready !== 0) $fatal(1,"CSR_BACKPRESSURE_VALUE_CHANGED addr=%h",address);
                backpressure_checks=backpressure_checks+1;
            end
            csr_rsp_ready=1; step();
            reference.state=0; dut.state=0;
            reference.perf_rd_words=42; dut.perf_rd_words=42;
            reference.perf_wr_words=42; dut.perf_wr_words=42;
            reference.sat_count=42; dut.sat_count=42;
            clr_perf=1; step(); clr_perf=0; rd_cmd_fire=0; wr_cmd_fire=0; mac_out_valid=0; step();
        end
    endtask

    // Bounded naturally reached controller sequence. Memory, MAC, FIFO input
    // stimuli are known and deterministic; no state/count deposits occur here.
    task natural_task;
        input should_abort;
        integer t, fifo_words, initial_done, initial_errors;
        reg pending_rd, pending_wr, next_rd, next_wr, push_now, pop_now, flush_now;
        reg [31:0] pending_rd_addr, pending_wr_addr, next_rd_addr, next_wr_addr;
        reg [15:0] pending_tag, next_tag;
        reg [2:0] mac_pipe, next_mac_pipe;
        begin
            neutral();
            pending_rd=0; pending_wr=0; pending_tag=0;
            pending_rd_addr=0; pending_wr_addr=0; fifo_words=0; mac_pipe=0;
            initial_done=natural_done; initial_errors=natural_errors;
            csr_valid=1; start=1; step(); start=0;
            begin : bounded_sequence
                for(t=0;t<80;t=t+1) begin
                    rd_req_ready=(t%4 != 1);
                    wr_req_ready=(t%3 != 0);
                    rd_ret_valid=pending_rd; rd_ret_tag=pending_tag; rd_ret_addr=pending_rd_addr;
                    wr_ret_valid=pending_wr; wr_ret_addr=pending_wr_addr;
                    rd_idle=!pending_rd; wr_idle=!pending_wr;
                    mac_out_valid=mac_pipe[2]; mac_sat=t%4;
                    fifo_empty=(fifo_words==0);
                    abort=should_abort && t==5;
                    clr_perf=(t==4); // Busy clear does not clear the count.
                    csr_rsp_ready=(t%5 != 2);
                    #1;
                    next_rd=dut.rd_req_valid && rd_req_ready;
                    next_wr=dut.wr_req_valid && wr_req_ready;
                    next_rd_addr=dut.rd_req_addr; next_tag=dut.rd_req_tag;
                    next_wr_addr=dut.wr_req_addr;
                    rd_cmd_fire=next_rd; wr_cmd_fire=next_wr;
                    rd_cmd_stall=dut.rd_req_valid && !rd_req_ready;
                    wr_cmd_stall=dut.wr_req_valid && !wr_req_ready;
                    push_now=dut.fifo_push; pop_now=dut.fifo_pop; flush_now=dut.fifo_flush;
                    next_mac_pipe={mac_pipe[1:0],dut.mac_valid};
                    step();
                    pending_rd=next_rd; pending_tag=next_tag; pending_rd_addr=next_rd_addr;
                    pending_wr=next_wr; pending_wr_addr=next_wr_addr; mac_pipe=next_mac_pipe;
                    if (flush_now) fifo_words=0;
                    else fifo_words=fifo_words+push_now-pop_now;
                    if (fifo_words<0) $fatal(1,"STIMULUS_FIFO_UNDERFLOW");
                    if (!dut.busy) disable bounded_sequence;
                end
                $fatal(1,"NATURAL_SEQUENCE_TIMEOUT abort=%0d",should_abort);
            end
            if (!should_abort && natural_done != initial_done+1)
                $fatal(1,"NATURAL_DONE_NOT_OBSERVED");
            if (should_abort && natural_errors != initial_errors+1)
                $fatal(1,"NATURAL_ABORT_COMPLETION_NOT_OBSERVED");
            neutral();
        end
    endtask

    initial begin
        rst_n=1;
        reset_all();

        // Carry lengths 0..32; each non-overflow boundary also gets a
        // patterned upper part with bit i cleared. Plus 6 patterns and 128
        // deterministic random words. These are finite known-state tests.
        for(i=0;i<=32;i=i+1) begin
            wide=(64'h1<<i)-1;
            check_increment(wide[31:0]);
            check_increment(wide[31:0] & 32'hfffffffe);
            if (i<32) begin
                mask=((64'h1<<(i+1))-1);
                check_increment((32'ha5a5a5a5 & ~mask) | wide[31:0]);
            end
        end
        check_increment(32'h7ffffffe); check_increment(32'h80000000);
        check_increment(32'hfffffffe); check_increment(32'h55555555);
        check_increment(32'haaaaaaaa); check_increment(32'h80000001);
        random_word=32'h8d03acb1;
        for(i=0;i<128;i=i+1) begin
            random_word=random_next(random_word);
            check_increment(random_word);
        end
        $display("TARGETFIX_GROUP_PASS arithmetic cases=%0d carry_lengths=0..32 random_seed=8d03acb1",arithmetic_checks);

        reset_all();
        for(i=0;i<5;i=i+1)
          for(j=0;j<2;j=j+1)
            for(kcase=0;kcase<2;kcase=kcase+1)
              for(fire_kind=0;fire_kind<4;fire_kind=fire_kind+1)
                for(wr_kind=0;wr_kind<4;wr_kind=wr_kind+1)
                  for(valid_kind=0;valid_kind<4;valid_kind=valid_kind+1) begin
                    reference.state=i; dut.state=i;
                    reference.perf_rd_words=32'h7fffffff; dut.perf_rd_words=32'h7fffffff;
                    reference.perf_wr_words=32'hfffffffe; dut.perf_wr_words=32'hfffffffe;
                    reference.sat_count=32'hffffffff; dut.sat_count=32'hffffffff;
                    start=j; clr_perf=kcase; mac_sat={i[0],kcase[0]};
                    case(fire_kind) 0:rd_cmd_fire=0; 1:rd_cmd_fire=1; 2:rd_cmd_fire=1'bx; 3:rd_cmd_fire=1'bz; endcase
                    case(wr_kind) 0:wr_cmd_fire=0; 1:wr_cmd_fire=1; 2:wr_cmd_fire=1'bx; 3:wr_cmd_fire=1'bz; endcase
                    case(valid_kind) 0:mac_out_valid=0; 1:mac_out_valid=1; 2:mac_out_valid=1'bx; 3:mac_out_valid=1'bz; endcase
                    step(); priority_checks=priority_checks+1;
                  end
        $display("TARGETFIX_GROUP_PASS priorities cases=%0d states=0..4 start/clear=0/1 rd/wr/mac_valid=0/1/X/Z known_counts_flags_only",priority_checks);

        neutral();
        reference.state=3; dut.state=3;
        reference.perf_rd_words=32'habcdef12; dut.perf_rd_words=32'habcdef12;
        reference.perf_wr_words=32'hfedcba98; dut.perf_wr_words=32'hfedcba98;
        reference.sat_count=32'hffffffff; dut.sat_count=32'hffffffff;
        start=1; clr_perf=1; rd_cmd_fire=1; wr_cmd_fire=1; mac_out_valid=1; mac_sat=3;
        #1; rst_n=0; #1;
        compare_all(1);
        if (dut.perf_rd_words !== 0 || dut.perf_wr_words !== 0 || dut.sat_count !== 0 || dut.state !== 0)
            $fatal(1,"ASYNC_RESET_PRIORITY_FAILED");
        async_checks=async_checks+1;
        step(); rst_n=1;

        csr_counter(32'h054); csr_counter(32'h058); csr_counter(32'h068);
        $display("TARGETFIX_GROUP_PASS csr reads=%0d backpressure_cycles=%0d addresses=054,058,068 same_edge_wrap_clear=checked",csr_reads,backpressure_checks);

        reset_all();
        natural_phase=1;
        natural_task(0);
        natural_task(1);
        // Invalid configuration reaches CHECK and returns to IDLE normally.
        neutral(); opcode=15; start=1; step(); start=0; step();
        if (dut.busy !== 0 || natural_errors<2)
            $fatal(1,"NATURAL_BAD_CONFIG_NOT_OBSERVED");
        // Reset during naturally reached busy state, between clock edges.
        neutral(); start=1; step(); start=0; step();
        if (dut.busy !== 1) $fatal(1,"NATURAL_BUSY_NOT_REACHED");
        #1; rst_n=0; #1;
        compare_all(1);
        if (dut.busy !== 0 || dut.perf_rd_words !== 0 || dut.perf_wr_words !== 0 || dut.sat_count !== 0)
            $fatal(1,"NATURAL_ASYNC_RESET_FAILED");
        async_checks=async_checks+1;
        rst_n=1; natural_phase=0;
        if (natural_states !== 5'b11111)
            $fatal(1,"NATURAL_STATE_COVERAGE_MISSING got=%b",natural_states);
        $display("TARGETFIX_GROUP_PASS natural cycles=%0d states=%b done_events=%0d error_events=%0d no_deposits=1",natural_cycles,natural_states,natural_done,natural_errors);
        $display("TARGETFIX_GROUP_PASS async observations=%0d includes_between_edges_busy_reset=1",async_checks);
        $display("TARGETFIX_TEST_PASS steps=%0d arithmetic=%0d priorities=%0d csr_reads_total=%0d",steps,arithmetic_checks,priority_checks,csr_reads);
        $finish;
    end
endmodule
