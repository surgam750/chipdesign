"""Same-run RTL3307 native Formality, independent of dynamic gate simulation."""
from collections import Counter
import csv
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
CORNERS=('FF0','FF1','FF2','SS3','SS4','TT5','TT6')
FM='/eda/synopsys/fm/fm_2020.09-SP5/bin/fm_shell'
REPORTS={'status.rpt':'report_status','black_boxes.rpt':'report_black_boxes',
         'unmatched.rpt':'report_unmatched_points','setup.rpt':'report_setup_status',
         'guidance.rpt':'report_guidance -summary','failing.rpt':'report_failing_points',
         'aborted.rpt':'report_aborted_points'}
BAD=re.compile(r'(?im)^\s*(?:Error:|Fatal:|LEC_TOOL_ERROR:)|license checkout failed|unable to checkout|invalid command name|FM-234')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    import hashlib
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
    return digest.hexdigest()


def load(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path,data):
    path=Path(path);temporary=path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    os.replace(str(temporary),str(path))


def verify_hashes(records):
    for name,digest in records.items():
        require(Path(name).is_file() and sha(name)==digest,'Bound proof input/output changed: '+name)


def tcl(value):
    text=str(value)
    for c in ('\\','"','$','[',']'):text=text.replace(c,'\\'+c)
    return '"'+text.replace('\n','\\n').replace('\r','\\r')+'"'


def filelist_text(sources,includes):
    require(sources and len(sources)==len(set(sources)),'Empty/duplicate reference RTL')
    for name in list(sources)+list(includes):
        require(re.fullmatch(r'[A-Za-z0-9_./:+-]+',name) and
                (name.startswith('/') or re.match(r'^[A-Za-z]:/',name)),'Unsupported filelist path: '+name)
    return '\n'.join(['+define+KWT_TCM_MACRO']+['+incdir+'+p for p in includes]+sources)+'\n'


def formal_script(p,top='e203_soc_top',probe=False):
    # Proven native sequence from the independently reviewed RTL3307 runner.
    lines=['set lec_verified 0','set lec_error [catch {','set_app_var synopsys_auto_setup true']
    if probe:
        for command in ('read_verilog','read_db','set_svf','verify','report_guidance'):
            lines+=['puts '+tcl('LEC_HELP_BEGIN '+command),'help '+command,'puts '+tcl('LEC_HELP_END '+command)]
    else:lines+=['set_svf '+tcl(p['svf'])]
    lines+=['read_db '+tcl(path) for path in p['libraries']]
    lines+=['read_verilog -r -libname WORK -vcs '+tcl('-f '+p['filelist']),
            'set_top r:/WORK/'+top,'read_verilog -i -libname WORK '+tcl(p['netlist']),
            'set_top i:/WORK/'+top,'match','set lec_verified [verify]','puts "LEC_VERIFY_RESULT=$lec_verified"']
    for name,command in REPORTS.items():
        if probe and name=='guidance.rpt':continue
        lines+=['redirect -file '+tcl(name)+' {'+command+'}']
    lines+=['if {[llength [info commands report_unverified_points]]} {',
            'redirect -file unverified.rpt {report_unverified_points}',
            '} else {puts "LEC_UNVERIFIED_REPORT_UNAVAILABLE: review native report_status coverage"}',
            '} lec_issue]',
            'if {$lec_error} {puts stderr "LEC_TOOL_ERROR: $lec_issue"; puts stderr $::errorInfo; exit 1}',
            'puts LEC_TOOL_DONE','exit 0']
    return '\n'.join(lines)+'\n'


def verify_result(log,code):
    require(code==0 and not BAD.search(log),'Native Formality tool error; inspect tool.log')
    lines=[line.strip() for line in log.splitlines()]
    values=[line.split('=',1)[1] for line in lines if line.startswith('LEC_VERIFY_RESULT=')]
    require(lines.count('LEC_TOOL_DONE')==1 and len(values)==1 and values[0] in ('0','1'),
            'Missing/ambiguous native verify result')
    result=values[0]=='1'
    outcomes=re.findall(r'(?im)^\s*Verification\s+(SUCCEEDED|FAILED|ABORTED|INCONCLUSIVE)\b',log)
    require(set(outcomes)==({'SUCCEEDED'} if result else {'FAILED'}),'Native verification incomplete or contradictory')
    return result


def invocation_records(folder,fm,script):
    folder=Path(folder);path=folder/'run.tcl';command=folder/'command.json'
    require(path.is_file() and path.read_bytes()==script.encode('ascii'),'Actual Formality Tcl changed')
    require(load(command)==[str(fm),'-f',str(path)],'Actual Formality command changed')
    return {str(p):sha(p) for p in (path,command)}


def invoke(fm,folder,script,timeout):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    path=folder/'run.tcl';path.write_bytes(script.encode('ascii'))
    command=[str(fm),'-f',str(path)];save(folder/'command.json',command)
    records=invocation_records(folder,fm,script)
    print('FORMALITY_RUNNING='+str(folder),flush=True)
    with (folder/'tool.log').open('w') as stream:
        kwargs={'cwd':str(folder),'stdout':stream,'stderr':subprocess.STDOUT}
        if os.name!='nt':kwargs['start_new_session']=True
        proc=subprocess.Popen(command,**kwargs);start=time.monotonic()
        try:
            while proc.poll() is None:
                if time.monotonic()-start>timeout:raise RuntimeError('Formality timeout: '+str(folder))
                time.sleep(0.25)
        except BaseException:
            if proc.poll() is None:
                if os.name!='nt':os.killpg(proc.pid,signal.SIGTERM)
                else:proc.terminate()
                try:proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    if os.name!='nt':os.killpg(proc.pid,signal.SIGKILL)
                    else:proc.kill()
                    proc.wait()
            raise
    verify_hashes(records);invocation_records(folder,fm,script)
    log=(folder/'tool.log').read_text(errors='replace')
    try:return verify_result(log,proc.returncode)
    except ValueError:
        print('\n'.join(log.splitlines()[-35:]),flush=True);raise


def locate_fm(explicit=None):
    for path in ([explicit] if explicit else [FM,shutil.which('fm_shell')]):
        if path and Path(path).is_file():return str(Path(path).absolute())
    raise ValueError('fm_shell not found; use --fm /actual/path/bin/fm_shell')


def get_native():
    spec=importlib.util.spec_from_file_location('full7_fm_native',str(ROOT/'native/driver.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    require(module.ROOT==ROOT and tuple(module.CORNERS)==CORNERS,'Wrong fresh native driver')
    return module


def capture(config):
    native=get_native();out=Path(config['out']).resolve()
    require(out==ROOT/'result','Proof must belong to this fresh full-flow run')
    require(set(config['corners'])==set(CORNERS),'Exactly seven native corners required')
    report=native.results(config)
    require(report['candidate_id']=='RTL3307_TCM128_TARGETFIX_V1','Wrong proof candidate')
    net=out/'dc_soc/design.v';svf=out/'dc_soc/design.svf'
    require(net.is_file() and svf.is_file() and svf.stat().st_size>0,'Fresh netlist and same-run SVF required')
    require(sha(net)==report['netlist_sha256'],'Fresh DC receipt does not bind netlist')
    maximum=config['compile_max_corner'];values=native.values(config,maximum,'soc')
    require(values['libraries'] and len(set(values['libraries']))==len(values['libraries']),'Missing/duplicate compile libraries')
    # Formality read_db takes compiled databases only; an unconverted Liberty
    # source fails there as DB-1 after the tool has already started.
    require(all(Path(x).suffix=='.db' for x in values['libraries']),
            'Formality requires compiled .db libraries, got: '+repr(values['libraries']))
    # Tool scripts replaced after synthesis are reported, not sealed: they cannot
    # change the netlist. Everything else in the snapshot is still strict.
    replaced=report.get('replaced_tool_files') or {}
    records={name:digest for name,digest in config['input_snapshot'].items() if name not in replaced}
    records.update(config['library_hashes'])
    for name in ('prepared.json','resolved_config.json','receipts.json','metrics.json','state.json'):
        path=out/name
        if path.is_file():records[str(path)]=sha(path)
    for path in [net,svf]+[Path(p) for p in values['sources']]+[Path(p) for p in values['libraries']]:
        records[str(path)]=sha(path)
    verify_hashes(records)
    return {'out':str(out/'formality'),'compile_corner':maximum,'netlist':str(net),
            'netlist_sha256':sha(net),'svf':str(svf),'svf_sha256':sha(svf),
            'libraries':values['libraries'],'sources':values['sources'],'includes':values['includes'],
            'replaced_tool_files':replaced,'records':records}


def run(config,timeout=7200,fm=None):
    p=capture(config);root=Path(p['out'])
    require(not root.exists(),'Fresh Formality output required')
    root.mkdir();p['fm']=locate_fm(fm);p['records'][p['fm']]=sha(p['fm'])
    p['timeout']=timeout;p['filelist']=str(root/'sources.f')
    Path(p['filelist']).write_text(filelist_text(p['sources'],p['includes']),encoding='ascii')
    p['records'][p['filelist']]=sha(p['filelist'])
    for label,expression in [('equivalent','~a'),('different','a')]:
        folder=root/('probe_'+label);folder.mkdir()
        include=folder/'include';include.mkdir()
        (include/'defs.vh').write_text('`define INVERT(x) (~(x))\n')
        reference=folder/'reference.v'
        reference.write_text('`include "defs.vh"\nmodule lec_probe(input a,output y);\n`ifdef KWT_TCM_MACRO\nassign y=`INVERT(a);\n`else\nMISSING_DEFINE missing();\n`endif\nendmodule\n')
        implementation=folder/'implementation.v'
        implementation.write_text('module lec_probe(input a,output y);assign y='+expression+';endmodule\n')
        filelist=folder/'sources.f';filelist.write_text(filelist_text([reference.as_posix()],[include.as_posix()]))
        small={'libraries':p['libraries'],'netlist':str(implementation),'filelist':str(filelist)}
        result=invoke(p['fm'],folder,formal_script(small,'lec_probe',True),min(300,timeout))
        require(result==(label=='equivalent'),'Native positive/negative Formality control failed')
        print('FORMALITY_CONTROL %s actual=%d expected=%d'%(label,result,label=='equivalent'),flush=True)
    for path in root.rglob('*'):
        if path.is_file():p['records'][str(path)]=sha(path)
    verify_hashes(p['records']);get_native().results(config)
    save(root/'prepared.json',p)
    prepared_sha=sha(root/'prepared.json')
    result=invoke(p['fm'],root/'design',formal_script(p),timeout)
    get_native().results(config);verify_hashes(p['records'])
    require(sha(root/'prepared.json')==prepared_sha,'Proof input capture changed')
    invocation=invocation_records(root/'design',p['fm'],formal_script(p))
    files=dict(invocation)
    for name in list(REPORTS)+['tool.log']:
        path=root/'design'/name
        require(path.is_file() and path.stat().st_size>0,'Missing native Formality report: '+name)
        files[str(path)]=sha(path)
    optional=root/'design/unverified.rpt'
    if optional.is_file():files[str(optional)]=sha(optional)
    summary={'status':'LEC_VERIFY_TRUE_REVIEW_REQUIRED' if result else 'LEC_VERIFY_FALSE_NO_ACCEPTANCE',
             'native_verify_return':result,'netlist_sha256':p['netlist_sha256'],
             'svf_sha256':p['svf_sha256'],'compile_corner':p['compile_corner'],
             'prepared_sha256':prepared_sha,'files':files,
             'replaced_tool_files':p.get('replaced_tool_files') or {},
             'scope':'Fresh synthesis-selected physical RTL versus same-run complete mapped netlist; SRAM technology macro boundaries',
             'pending_review':['compare-point and unmatched/aborted/unverified coverage','SRAM macro boundaries and guidance/auto-setup assumptions'],
             'acceptance':False}
    save(root/'summary.json',summary);save(root/'state.json',{'summary_sha256':sha(root/'summary.json'),'status':summary['status']})
    print(summary['status'],flush=True)
    return summary


def results(config):
    root=Path(config['out'])/'formality';state=load(root/'state.json')
    require(sha(root/'summary.json')==state['summary_sha256'],'Formality summary changed')
    summary=load(root/'summary.json')
    require(sha(root/'prepared.json')==summary['prepared_sha256'],'Formality prepared input changed')
    p=load(root/'prepared.json')
    require(Path(p['out']).resolve()==root.resolve(),'Proof output identity changed')
    get_native().results(config);verify_hashes(p['records']);verify_hashes(summary['files'])
    require(sha(p['netlist'])==p['netlist_sha256']==summary['netlist_sha256'],'Proof netlist identity changed')
    require(sha(p['svf'])==p['svf_sha256']==summary['svf_sha256'],'Proof SVF identity changed')
    invocation=invocation_records(root/'design',p['fm'],formal_script(p))
    require(all(summary['files'].get(path)==digest for path,digest in invocation.items()),'Actual invocation not sealed')
    native=verify_result((root/'design/tool.log').read_text(errors='replace'),0)
    require(native==summary['native_verify_return'],'Proof native result changed')
    return summary
