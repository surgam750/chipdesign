// Same-latency output selection candidate for the supplied B TCM configuration.
// ITCM: unchanged 8 banks x 32 row slices x 4 RAMSP128X16 macros.
// DTCM: unchanged 8 x RAMSP8KX32 macros and binary bank output multiplexer.
//
// The ITCM bank and row selectors are decoded BEFORE the existing read-capture
// edge and retained as separate one-hot vectors. Their conjunction selects one
// macro row. A balanced masked-OR tree replaces the variable-index 32:1 row
// mux followed by the variable-index bank mux. No response cycle is added.
// Whether this maps faster depends on the target library, placement and loads;
// this RTL is a timing candidate, not a claim that setup/hold already closes.
//
// TARGETFIX_AGWEN: qualify ITCM address and global write control per bank.
// Inactive-bank A/GWEN pins may differ. CEN=0 implies bank_match=1, so the
// enabled macro sees its original A/GWEN values and the original access edge.
// Macro hierarchy, capacity, CEN/WEN/D, read selection and DTCM are unchanged.
// rst_n intentionally remains unused, as in the supplied baseline.
// read_bank/read_row remain available for the existing debug testbench.
// Supported active reads use known, in-range addresses. Before the first read,
// selectors and memory outputs are uninitialized; no reset-to-zero is added.
module kwt_tcm_proxy #(
    parameter integer DP = 65536,
    parameter integer DW = 32,
    parameter integer MW = 4,
    parameter integer AW = 16
) (
    input wire clk,
    input wire rst_n,
    input wire cs,
    input wire we,
    input wire [AW-1:0] addr,
    input wire [DW-1:0] din,
    input wire [MW-1:0] wem,
    output wire [DW-1:0] dout
);
    localparam integer RA     = (DW == 64) ? 7 : 13;
    localparam integer MROW   = (DW == 64) ? 12 : 13;
    localparam integer MDEPTH = 1 << MROW;
    localparam integer BANKS  = DP / MDEPTH;
    localparam integer BW     = DW / 8;
    localparam integer ROWS   = (DW == 64) ? (MDEPTH >> RA) : 1;
    localparam integer GRP    = DW / 16;
    localparam integer ROWW   = (DW == 64) ? (MROW - RA) : 1;

    function integer next_power_of_two;
        input integer value;
        integer result;
        begin
            result = 1;
            while (result < value) result = result * 2;
            next_power_of_two = result;
        end
    endfunction

    localparam integer SLICES = BANKS * ROWS;
    localparam integer TREE_LEAVES = next_power_of_two(SLICES);
    wire [BANKS*DW-1:0] bank_data;
    wire [DW-1:0] slice_q [0:BANKS*ROWS-1];
    wire [DW-1:0] write_disable;
    reg [AW-1-MROW:0] read_bank;
    reg [ROWW-1:0] read_row;

    genvar bank, bit_index, row, grp, node;
    generate
        for (bit_index = 0; bit_index < DW; bit_index = bit_index + 1) begin : g_wen
            assign write_disable[bit_index] = ~wem[bit_index/8];
        end
    endgenerate

    // Preserve the original selector edge, enable and lack of reset exactly.
    // These binary indices implement the unchanged DTCM branch and retain the
    // public debug names; ITCM synthesis can remove them when unobserved.
    always @(posedge clk) begin
        if (cs && !we) begin
            read_bank <= addr[AW-1:MROW];
            read_row  <= addr[RA +: ROWW];
        end
    end

    generate
        if (DW == 64) begin : g_read_mux
            reg [BANKS-1:0] read_bank_onehot;
            reg [ROWS-1:0] read_row_onehot;
            wire [DW-1:0] tree [0:2*TREE_LEAVES-2];

            for (bank = 0; bank < BANKS; bank = bank + 1) begin : g_bank_decode
                always @(posedge clk) begin
                    if (cs && !we)
                        read_bank_onehot[bank] <= (addr[AW-1:MROW] == bank);
                end
            end
            for (row = 0; row < ROWS; row = row + 1) begin : g_row_decode
                always @(posedge clk) begin
                    if (cs && !we)
                        read_row_onehot[row] <= (addr[MROW-1:RA] == row);
                end
            end

            // Select controls settle independently of the macro Q path. Keep
            // bank/row decoding out of the post-SRAM variable-index mux chain.
            for (node = 0; node < TREE_LEAVES; node = node + 1) begin : g_leaf
                if (node < SLICES) begin : g_used
                    wire selected;
                    assign selected = read_bank_onehot[node/ROWS] &
                                      read_row_onehot[node%ROWS];
                    assign tree[TREE_LEAVES-1+node] =
                           slice_q[node] & {DW{selected}};
                end else begin : g_pad
                    assign tree[TREE_LEAVES-1+node] = {DW{1'b0}};
                end
            end
            for (node = 0; node < TREE_LEAVES-1; node = node + 1) begin : g_or
                assign tree[node] = tree[2*node+1] | tree[2*node+2];
            end
            assign dout = tree[0];
        end else begin : g_original_read_mux
            assign dout = bank_data[read_bank*DW +: DW];
        end

        // Preserve all macro pins except inactive-bank ITCM A/GWEN. This
        // adds combinational bank-address paths, not state or a new cycle.
        for (bank = 0; bank < BANKS; bank = bank + 1) begin : g_bank
            wire bank_select;
            assign bank_select = cs && (addr[AW-1:MROW] == bank);
            if (DW == 64) begin : g_wide64
                // Only address bank matching qualifies these local controls.
                // New bank-address-to-A/GWEN paths require native STA review.
                wire bank_match;
                wire [RA-1:0] local_A;
                wire local_GWEN;
                assign bank_match = (addr[AW-1:MROW] == bank);
                assign local_A = addr[RA-1:0] & {RA{bank_match}};
                assign local_GWEN = ~(we & bank_match);
                for (row = 0; row < ROWS; row = row + 1) begin : g_row
                    for (grp = 0; grp < GRP; grp = grp + 1) begin : g_slice
                        RAMSP128X16 u_ram (
                            .Q    (slice_q[bank*ROWS + row][grp*16 +: 16]),
                            .CLK  (clk),
                            .CEN  (~(bank_select && (addr[MROW-1:RA] == row))),
                            .GWEN (local_GWEN),
                            .WEN  (write_disable[grp*16 +: 16]),
                            .A    (local_A),
                            .D    (din[grp*16 +: 16]),
                            .EMA  (3'b011),
                            .EMAW (2'b00),
                            .RET1N(1'b1)
                        );
                    end
                end
            end else begin : g_wide32
                RAMSP8KX32 u_ram (
                    .Q    (bank_data[bank*DW +: DW]),
                    .CLK  (clk),
                    .CEN  (~bank_select),
                    .GWEN (~we),
                    .WEN  (write_disable),
                    .A    (addr[MROW-1:0]),
                    .D    (din),
                    .EMA  (3'b011),
                    .EMAW (2'b00),
                    .RET1N(1'b1)
                );
            end
        end
    endgenerate
endmodule
