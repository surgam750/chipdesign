# Fresh RTL synthesis compiles at SS3 for both the max and min views. SS3 is the
# corner that PT actually reports as worst for setup AND for hold on this PDK.
source [file join [file dirname [info script]] common.tcl]

proc dc_call {body} {
    set result [uplevel 1 $body]
    if {[string is boolean -strict $result] && !$result} {error "Command failed: $body"}
    return $result
}

proc dc_binding {path maximum} {
    set expected_files [list [dict get $maximum standard]]
    foreach macro [lsort [dict keys [dict get $maximum macros]]] {
        lappend expected_files [dict get $maximum macros $macro]
    }
    set allowed [dict create]
    foreach db $expected_files {
        set cells [get_lib_cells -quiet [list "${db}:*/*"]]
        if {[sizeof_collection $cells] == 0} {error "Missing SS3 file-qualified library: $db"}
        set library [get_libs -quiet -of_objects $cells]
        if {[sizeof_collection $library] != 1} {error "Ambiguous SS3 library: $db"}
        dict set allowed $db $library
    }
    set f [open $path w]
    puts $f "instance\treference\tlibrary_cell\tlibrary\texpected_db"
    set count 0
    foreach_in_collection cell [get_cells -hierarchical -filter {is_hierarchical == false}] {
        set ref [get_attribute $cell ref_name]
        if {$ref in {**logic_0** **logic_1**}} {continue}
        set db [dict get $maximum standard]
        if {[dict exists $maximum macros $ref]} {set db [dict get $maximum macros $ref]}
        set bound [get_lib_cells -quiet -of_objects $cell]
        if {[sizeof_collection $bound] != 1} {error "Unresolved leaf binding: [get_object_name $cell]"}
        set library [get_libs -quiet -of_objects $bound]
        if {[sizeof_collection $library] != 1 ||
            [compare_collections $library [dict get $allowed $db]] != 0} {
            error "Non-SS3 library binding: [get_object_name $cell]"
        }
        puts $f "[get_object_name $cell]\t$ref\t[get_object_name $bound]\t[get_object_name $library]\t$db"
        incr count
    }
    close $f
    if {$count == 0} {error "Empty mapped library binding inventory"}
}

finish {
    set expected [dict create RAMSP128X16 1088 RAMSP4096X16 64 RAMSP8KX32 8]
    if {[required max_corner] ne "SS3" || [required min_corner] ne "SS3" ||
        [lsort [dict keys [required expected_macros]]] ne [lsort [dict keys $expected]]} {
        error "Fresh RTL3307 synthesis requires SS3 max and SS3 min and exactly three macro types"
    }
    dict for {name count} $expected {
        if {[dict get [required expected_macros] $name] != $count} {error "Wrong macro inventory: $name"}
    }
    set maximum [required maximum]
    set minimum [required minimum]
    set max_op [required max_op]
    set min_op [required min_op]
    if {[required standard] ne [dict get $maximum standard] ||
        [required op_library] ne [dict get $max_op library] ||
        [required op_condition] ne [dict get $max_op condition]} {
        error "SS3 target, driving library and operating condition must agree"
    }
    foreach side [list $maximum $minimum] {
        if {[lsort [dict keys $side]] ne {macros standard} ||
            [lsort [dict keys [dict get $side macros]]] ne [lsort [dict keys $expected]]} {
            error "Unpaired standard/SRAM library configuration"
        }
    }
    set pairs [list [list [dict get $maximum standard] [dict get $minimum standard]]]
    foreach name [lsort [dict keys $expected]] {
        lappend pairs [list [dict get $maximum macros $name] [dict get $minimum macros $name]]
    }
    set all_libraries {}
    set max_link [list *]
    foreach pair $pairs {
        lappend max_link [lindex $pair 0]
        foreach path $pair {
            if {![file isfile $path] || [file size $path] == 0} {error "Missing paired DB: $path"}
            lappend all_libraries $path
        }
    }
    # SS3/SS3 shares one library set between the max and min views, so the
    # distinct count is four (standard + three macro types), not eight. Both
    # counts stay legal: a dual-corner configuration must still be eight.
    set distinct [llength [lsort -unique $all_libraries]]
    if {$distinct != 4 && $distinct != 8} {
        error "Expected four (single-corner) or eight (dual-corner) distinct libraries; found $distinct"
    }
    if {[lsort -unique [required libraries]] ne [lsort -unique $all_libraries]} {
        error "Loaded library set does not match the configured SS3 max/min set"
    }
    if {[llength [required sources]] == 0} {error "Fresh synthesis source list is empty"}
    dc_call {setup_library DC}
    dc_call {set_app_var link_library $max_link}
    # A single-corner compile (max == min) has no separate min version: DC uses
    # the linked library for both views. Calling set_min_library with the same
    # file on both sides is unnecessary and its acceptance varies by release.
    foreach pair $pairs {
        if {[lindex $pair 0] ne [lindex $pair 1]} {
            dc_call [list set_min_library [lindex $pair 0] -min_version [lindex $pair 1]]
        }
    }
    dc_call {set_svf design.svf}
    dc_call {define_design_lib WORK -path ./WORK}
    if {![analyze -format verilog -define KWT_TCM_MACRO [required sources]]} {error "Analyze failed"}
    dc_call {elaborate e203_soc_top}
    current_design e203_soc_top
    if {[get_object_name [current_design]] ne "e203_soc_top"} {error "Cannot select e203_soc_top"}
    if {![link]} {error "DC link failed"}
    dc_call {uniquify}
    dc_call [list set_operating_conditions -analysis_type bc_wc \
        -max_library [dict get $max_op library] -max [dict get $max_op condition] \
        -min_library [dict get $min_op library] -min [dict get $min_op condition]]
    source [required sdc]
# Source after the original SDC and before the unchanged DC compile.
# Only the top synthesis max_transition objective changes; PT stays original.
proc globslew025_read_value {object expected} {
    set value [get_attribute $object max_transition]
    # Native storage can report 0.300000012 for the original 0.30 setting.
    if {![string is double -strict $value] ||
        abs(double($value) - $expected) > 1.0e-6} {
        error "GLOBSLEW025 unexpected max_transition: $value (expected $expected)"
    }
    return $value
}

proc globslew025_apply {receipt_path} {
    set top [current_design]
    if {[sizeof_collection $top] != 1 || [get_object_name $top] ne "e203_soc_top"} {
        error "GLOBSLEW025 requires exactly one current design named e203_soc_top"
    }
    set before [globslew025_read_value $top 0.30]
    set f [open $receipt_path {WRONLY CREAT EXCL}]
    puts $f "status\tPRECHECKED_NOT_YET_APPLIED"
    puts $f "top\te203_soc_top"
    puts $f "before\t$before"
    flush $f
    set code [catch {
        set result [set_max_transition 0.25 $top]
        if {[string is boolean -strict $result] && !$result} {
            error "GLOBSLEW025 set_max_transition returned false"
        }
        set after [globslew025_read_value $top 0.25]
        puts $f "after\t$after"
        puts $f "status\tAPPLIED_AND_READBACK_VERIFIED"
    } message options]
    if {$code} {
        puts $f "status\tFAILED"
        puts $f "error\t$message"
        close $f
        return -options $options $message
    }
    close $f
    puts "GLOBSLEW025_SCOPE_VERIFIED top=e203_soc_top before=$before after=$after receipt=$receipt_path"
}

globslew025_apply [file join [pwd] globslew025_scope.tsv]
    macro_check
    foreach clock {hfclk lfclk} {
        if {[sizeof_collection [get_clocks -quiet $clock]] != 1} {error "Required clock absent or ambiguous: $clock"}
    }
    dc_call {set_ungroup [get_cells -hierarchical -filter {is_hierarchical == true}] false}
    foreach clock {hfclk lfclk} {dc_call [list set_fix_hold [get_clocks -quiet $clock]]}
    # TARGETFIX: optimize setup and hold ahead of the unchanged 0.25ns DRC target.
    # This changes synthesis priorities only; the original PT SDC remains fixed.
    proc targetfix_check_priority {phase} {
        set top [current_design]
        if {[sizeof_collection $top] != 1 || [get_object_name $top] ne "e203_soc_top"} {
            error "TARGETFIX priority check requires e203_soc_top"
        }
        set desired {max_delay min_delay max_transition max_fanout max_capacitance}
        set raw [get_attribute $top cost_priority]
        set observed {}
        foreach cost $raw {
            if {$cost in $desired} {lappend observed $cost}
        }
        if {$observed ne $desired} {
            error "TARGETFIX cost_priority readback mismatch: $raw"
        }
        puts "TARGETFIX_COST_PRIORITY_READBACK phase=$phase top=e203_soc_top order=[join $observed ,] raw={$raw}"
    }
    dc_call {set_cost_priority {max_delay min_delay max_transition max_fanout max_capacitance}}
    targetfix_check_priority pre_compile
    if {![compile_ultra -no_autoungroup]} {error "Compile failed"}
    targetfix_check_priority post_compile
    dc_binding library_binding.rpt $maximum
    macro_check
    redirect -file check_design.rpt {if {![check_design]} {error "check_design failed"}}
    redirect -file check_timing.rpt {check_timing}
    redirect -file operating_conditions.rpt {report_design}
    redirect -file clocks.rpt {report_clock}
    redirect -file area.rpt {report_area -hierarchy}
    redirect -file reference.rpt {report_reference -hierarchy}
    redirect -file constraints.rpt {report_constraint -all_violators}
    cell_area cells.tsv
    dc_call {write -format verilog -hierarchy -output design.v}
    dc_call {write -format ddc -hierarchy -output design.ddc}
    dc_call {write_sdc emitted.sdc}
    dc_call {set_svf -off}
    puts RTL3307_FRESH_RTL_SYNTHESIS_SS3_MAX_SS3_MIN
}
