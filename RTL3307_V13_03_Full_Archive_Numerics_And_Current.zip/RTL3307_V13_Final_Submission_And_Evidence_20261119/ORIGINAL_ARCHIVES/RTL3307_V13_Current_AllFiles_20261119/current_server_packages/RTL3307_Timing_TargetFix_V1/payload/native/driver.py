"""Fresh RTL3307 SoC synthesis and seven-corner reports. Python 3.6."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CORNERS = ('FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT5', 'TT6')
EXPECTED_PVT = {'FF0': ('FF', 1.21, -40), 'FF1': ('FF', 1.21, 0), 'FF2': ('FF', 1.21, 125),
                'SS3': ('SS', 0.99, -40), 'SS4': ('SS', 0.99, 125),
                'TT5': ('TT', 1.10, 25), 'TT6': ('TT', 1.10, 125)}
# Hold must be repaired at the corner that actually shows the worst hold slack.
# Seven-corner PT on this PDK reports SS3 (0.99 V / -40 C) at -0.2604 ns versus
# FF2 at -0.1692 ns: the SRAM macro hold arc grows with the slow corner faster
# than the launch path does. Compiling with FF2 as the min library therefore
# repaired hold against a corner that is not the worst one.
MAX_CORNER, MIN_CORNER = 'SS3', 'SS3'
CANDIDATE = 'RTL3307_TCM128_TARGETFIX_V1'
COMPLETE = 'RTL3307_FULL7_REPORTS_COMPLETE_REVIEW_REQUIRED'
DC_FILES = ('globslew025_scope.tsv', 'design.v', 'design.ddc', 'design.svf', 'emitted.sdc', 'check_design.rpt',
            'check_timing.rpt', 'area.rpt', 'reference.rpt', 'constraints.rpt',
            'library_binding.rpt', 'cells.tsv', 'operating_conditions.rpt', 'clocks.rpt')
PT_FILES = ('timing.tsv', 'global.rpt', 'setup.rpt', 'hold.rpt', 'constraints.rpt',
            'coverage.rpt', 'check_timing.rpt', 'clocks.rpt', 'units.rpt',
            'operating_condition_library.rpt', 'cells.tsv', 'design.sdf',
            'transition.rpt', 'mincap.rpt', 'hfclk_min.rpt', 'hfclk_min.tsv',
            'load_reference.rpt')
# ITCM is built from 8 banks x 32 row slices x 4 bit slices of RAMSP128X16
# (1024 macros) instead of 8 x RAMSP4KX64, because the 128-word macro has a
# 1.56 ns shorter CLK->Q access time at ss 0.99 V / -40 C. 1088 = 1024 TCM
# + 64 accelerator-local slices.
MACROS = {'RAMSP128X16': 1088, 'RAMSP4096X16': 64, 'RAMSP8KX32': 8}
ERROR = re.compile(r'(^\s*(Error:|Fatal:|NATIVE_ERROR:)|unresolved reference|unable to resolve|creating black box|license checkout failed)', re.M | re.I)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def save(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp_' + uuid.uuid4().hex)
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    os.replace(str(temporary), str(path))


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def checked(path):
    path = Path(path).expanduser().absolute()
    if not path.is_file() or not path.stat().st_size:
        raise ValueError('Missing/empty file: ' + str(path))
    return str(path)


def tcl(value):
    if isinstance(value, dict):
        return '[dict create %s]' % ' '.join(tcl(k) + ' ' + tcl(v) for k, v in sorted(value.items()))
    if isinstance(value, list):
        return '[list %s]' % ' '.join(tcl(v) for v in value)
    value = str(value)
    for c in ('\\', '"', '$', '[', ']'):
        value = value.replace(c, '\\' + c)
    return '"' + value.replace('\n', '\\n').replace('\r', '\\r') + '"'


def pvt(path, macro=False):
    pattern = (r'_(tt|ss|ff)_([0-9]+p[0-9]+)v_([0-9]+p[0-9]+)v_([mn-]?[0-9]+)c' if macro
               else r'_(tt|ss|ff)_v([0-9]+p[0-9]+)_([mn-]?[0-9]+)c')
    matches = list(re.finditer(pattern + r'(?=_|\.|$)', Path(path).name, re.I))
    if len(matches) != 1:
        raise ValueError('Cannot identify exact PVT: ' + str(path))
    m = matches[0]
    if macro and float(m[2].replace('p', '.')) != float(m[3].replace('p', '.')):
        raise ValueError('Dual voltage macro unsupported')
    return m[1].upper(), float(m[2].replace('p', '.')), int(m[4 if macro else 3].lower().replace('m', '-').replace('n', '-'))


def helper():
    manifest = load(HERE / 'support/hashes.json')
    for name, digest in manifest.items():
        if sha(HERE / 'support' / name) != digest:
            raise ValueError('Readonly physical helper changed: ' + name)
    spec = importlib.util.spec_from_file_location('physical_helpers', str(HERE / 'support/patch_soc.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def physical_view(source, dst, helper_module):
    # Never invoke old SoC/loader/fetch/TB patches. Only these four selectors.
    before = {p.relative_to(source).as_posix(): sha(p) for p in sorted((source / 'rtl').rglob('*.v'))}
    dst.mkdir(parents=True)
    shutil.copytree(str(source / 'rtl'), str(dst / 'rtl'))
    for rel, digest in before.items():
        if sha(dst / rel) != digest:
            raise ValueError('Source changed while copying: ' + rel)
    changed = {}
    selections = [('rtl/e203/core/e203_itcm_ram.v', 'itcm'),
                  ('rtl/e203/core/e203_dtcm_ram.v', 'dtcm')]
    for rel, bank in selections:
        e = helper_module.Editor(rel, (dst / rel).read_bytes())
        helper_module.patch_tcm_proxy(e, bank)
        (dst / rel).write_bytes(e.bytes())
        changed[rel] = {'before': before[rel], 'after': sha(dst / rel)}
    for rel, fn in [('rtl/e203/mems/sirv_mrom_top.v', helper_module.patch_boot_rom_logic),
                    ('rtl/e203/generic/GENERIC_RVT_SMIC.v', helper_module.patch_clockgate_logic)]:
        e = helper_module.Editor(rel, (dst / rel).read_bytes())
        fn(e)
        (dst / rel).write_bytes(e.bytes())
        changed[rel] = {'before': before[rel], 'after': sha(dst / rel)}
    extra = dst / 'rtl/e203/kwt'
    extra.mkdir(exist_ok=True)
    shutil.copyfile(str(HERE / 'support/kwt_tcm_proxy.v'), str(extra / 'kwt_tcm_proxy.v'))
    after = {p.relative_to(dst).as_posix(): sha(p) for p in sorted((dst / 'rtl').rglob('*.v'))}
    save(dst / 'physical_view.json', {'before': before, 'after': after, 'selectors': changed,
                                    'defines': ['KWT_TCM_MACRO'], 'source': str(source)})
    save(dst / 'synthesis_sources.json', synthesis_sources(dst))
    return dst


def synthesis_sources(root):
    """Reviewed file selection and lexical-only checks; no preprocessing proof."""
    selected, excluded, modules = [], [], {}
    generic = {'generic/GENERIC_LVT_ARM.v', 'generic/GENERIC_RVT_ARM.v',
               'generic/GENERIC_RVT_SYNOPSYS.v'}
    vendor = re.compile(r'mem_gen/(RAMSP2KX64|RAMSP4KX64|RAMSP8KX32|ROM1KX32|ROM2KX32)/verilog/\1(?:_rtl)?\.v$')
    for path in sorted((root / 'rtl/e203').rglob('*.v')):
        if path.resolve() != path.absolute() or not path.is_file():
            raise ValueError('Redirected/non-file synthesis source: ' + str(path))
        rel = path.relative_to(root).as_posix()
        local = path.relative_to(root / 'rtl/e203').as_posix()
        entry = {'path': rel, 'sha256': sha(path)}
        if local in generic or vendor.fullmatch(local):
            entry['reason'] = ('reviewed alternate generic provider; retain SMIC' if local in generic
                               else 'reviewed vendor simulation model; use linked macro library')
            excluded.append(entry)
            continue
        # Remove comments and strings before scanning tokens, retaining newlines.
        text = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"',
                      lambda m: '\n' * m[0].count('\n') + ' ', path.read_text(errors='replace'))
        if re.search(r'`define\s+(?:FPGA|FPGA_SOURCE|KWT_SRAM_BEHAV)\b', text):
            raise ValueError('Forbidden synthesis define candidate (lexical-only): ' + rel)
        for match in re.finditer(r'\bmodule\s+(?:automatic\s+)?([A-Za-z_$][\w$]*)', text):
            name = match[1]
            if re.match(r'(?:RAMSP|ROM)\d', name, re.I):
                raise ValueError('Unreviewed vendor RAM/ROM model definition (lexical-only): ' + rel)
            if name in modules:
                raise ValueError('Duplicate module definition (lexical-only): %s in %s and %s' %
                                 (name, modules[name], rel))
            modules[name] = rel
        entry['reason'] = 'selected synthesis RTL; lexical-only audit passed'
        selected.append(entry)
    if not selected:
        raise ValueError('Empty synthesis source selection')
    return {'audit_scope': 'LEXICAL_ONLY_NO_SIMULATED_PREPROCESSING_PROOF',
            'selected': selected, 'excluded': excluded}


def validated_sources(config, kind):
    root = Path(config['out']) / kind
    path = root / 'synthesis_sources.json'
    if sha(path) != config['synthesis_sources_sha256'][kind]:
        raise ValueError('Synthesis source selection manifest changed: ' + kind)
    manifest = load(path)
    if synthesis_sources(root) != manifest:
        raise ValueError('Synthesis source selection differs from RTL tree: ' + kind)
    return [str(root / row['path']) for row in manifest['selected']]


def log_tail(path):
    # Bound both file I/O and terminal output, even for a single very long line.
    with path.open('rb') as stream:
        stream.seek(0, os.SEEK_END)
        stream.seek(max(0, stream.tell() - 16384))
        return '\n'.join(stream.read(16384).decode('utf-8', errors='replace').splitlines()[-40:])


def tool(config, name, stage, folder, values):
    timeout = config.get('timeout', 7200)
    require(isinstance(timeout, int) and not isinstance(timeout, bool) and timeout > 0,
            'Native tool timeout must be positive seconds')
    folder.mkdir(parents=True, exist_ok=False)
    script = folder / 'config.tcl'
    script.write_text('set cfg %s\n' % tcl(values))
    env = os.environ.copy()
    env['KWT_NATIVE_CONFIG'] = str(script)
    env['SYNOPSYS_LC_ROOT'] = str(Path(config['tools']['LC']).parent.parent)
    command = [config['tools'][name], '-f', str(HERE / (stage + '.tcl'))]
    invocation = {'command': command, 'config_sha256': sha(script)}
    save(folder / 'invocation.json', invocation)
    print('NATIVE_RUNNING ' + str(folder), flush=True)
    with (folder / 'tool.log').open('w') as stream:
        p = subprocess.Popen(command, cwd=str(folder), env=env, stdout=stream, stderr=subprocess.STDOUT,
                             start_new_session=(os.name == 'posix'))
        try:
            p.wait(timeout=timeout)
        except BaseException as error:
            # A shell can spawn licensed workers. Cancel their session with its parent.
            if os.name == 'posix':
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                p.kill()
            p.wait()
            if isinstance(error, subprocess.TimeoutExpired):
                raise RuntimeError('%s timed out after %ds: %s' % (name, timeout, folder / 'tool.log'))
            raise
    log = (folder / 'tool.log').read_text(errors='replace')
    if sha(script) != invocation['config_sha256'] or load(folder / 'invocation.json') != invocation:
        raise ValueError('Native invocation/config changed during tool execution')
    if p.returncode or ERROR.search(log) or log.splitlines().count('NATIVE_TOOL_DONE') != 1:
        print('NATIVE_TOOL_LOG_TAIL (last 40 lines, at most 16384 bytes):\n' +
              log_tail(folder / 'tool.log'), flush=True)
        raise ValueError('Native tool failed; inspect ' + str(folder / 'tool.log') +
                         ' (exit=%s)' % p.returncode)


def classify(instance, ref):
    if instance.startswith('u_kwt_accel/'):
        return 'accelerator_local_sram' if ref == 'RAMSP128X16' else 'accelerator_logic'
    if instance.startswith('u_kwt_shared_sram/'):
        return 'shared_512KiB_sram' if ref == 'RAMSP4096X16' else 'shared_controller_glue'
    if '/u_kwt_loader_dma/' in instance or instance.startswith('u_kwt_loader_dma/'):
        return 'loader_dma'
    if '/u_kwt_sysbus_arbiter/' in instance:
        return 'new_systembus_arbiter'
    if ref in ('RAMSP4KX64', 'RAMSP8KX32', 'RAMSP128X16'):
        return 'cpu_private_tcm'
    return 'platform_including_modified_ppi_irq'


def area(path):
    groups, counts = defaultdict(float), Counter()
    instances = set()
    with path.open() as stream:
        for row in csv.DictReader(stream, delimiter='\t'):
            name, ref = row['instance'], row['reference']
            require(name and ref and name not in instances, 'Empty/duplicate mapped cell: ' + str(name))
            instances.add(name)
            a = float(row['area_um2'])
            if not math.isfinite(a) or a < 0:
                raise ValueError('Invalid native area')
            groups[classify(name, ref)] += a
            if ref in MACROS:
                counts[ref] += 1
            elif re.match(r'(?:RAMSP|ROM)\d', ref, re.I):
                raise ValueError('Unexpected memory macro: ' + ref)
    if not groups:
        raise ValueError('Empty physical cell inventory')
    total = sum(groups.values())
    require(math.isfinite(total), 'Nonfinite total mapped area')
    return {'total_um2': total, 'groups_um2': dict(groups), 'macros': dict(counts)}


def require(condition, message):
    if not condition:
        raise ValueError(message)


# Tool scripts that cannot influence the netlist. Replacing one of these after
# synthesis is recorded in the report instead of invalidating the run: a typo in
# the power or Formality driver used to force a full 3-hour re-synthesis even
# though the design itself was untouched. Anything outside this list (RTL, SDC,
# libraries, dc.tcl, native driver, support files) stays strictly sealed.
REVISABLE_DIRS = ('power/', 'formality/')
REVISABLE_FILES = ('pipeline.py',)


def revisable(path):
    try:
        rel = Path(path).resolve().relative_to(Path(ROOT).resolve()).as_posix()
    except (ValueError, OSError):
        return False
    return rel in REVISABLE_FILES or any(rel.startswith(prefix) for prefix in REVISABLE_DIRS)


def verify_snapshot(snapshot, record_revisable=False):
    replaced = {}
    for path, digest in snapshot.items():
        checked(path)
        current = sha(path)
        if current == digest:
            continue
        if record_revisable and revisable(path):
            replaced[str(path)] = {'recorded': digest, 'current': current}
            continue
        raise ValueError('Input/report changed: ' + str(path))
    return replaced


def scoped_file(root, relative):
    root = Path(root).resolve()
    require(isinstance(relative, str) and relative and '\\' not in relative and ':' not in relative,
            'Invalid manifest-relative path')
    parts = relative.split('/')
    require(all(p not in ('', '.', '..') for p in parts), 'Unsafe manifest-relative path')
    path = root.joinpath(*parts)
    require(path.resolve() == path and root in path.parents, 'Redirected manifest file: ' + relative)
    checked(path)
    return path


def original_macro_source(row, macro, corner, candidates):
    """Use the hint for identity only. Every macro gets a fresh Liberty conversion."""
    expected = EXPECTED_PVT[corner]
    hint = row.get('macro_sources', row['macros']).get(macro)
    direct = None
    if hint is None:
        # The historical wide-TCM configuration had no shared RAMSP4096X16 entry.
        require(macro == 'RAMSP4096X16', 'Missing configured macro identity: ' + macro)
    else:
        source = Path(hint)
        aliases = {name: label for label in CORNERS for name in
                   (macro + '_' + label + '.db', label + '_' + macro + '.db')}
        alias_corner = aliases.get(source.name)
        if alias_corner:
            require(alias_corner == corner, 'Wrong macro corner alias: ' + str(source))
        else:
            require(source.suffix in ('.lib', '.db') and source.name.startswith(macro + '_') and
                    pvt(source, True) == expected, 'Wrong macro PVT or cell identity: ' + str(source))
            if source.suffix == '.lib':
                direct = Path(checked(source))
    if direct is not None:
        # The configured hint already matched cell identity and numeric PVT above, so it is
        # authoritative. A second copy with the same PVT elsewhere under --ref (for example a
        # simulator-generated model tree such as vsim/install/rtl/mem/gen) must not turn a
        # configured source into an ambiguous one.
        path = checked(direct.resolve())
        print('NATIVE_LIBRARY_SOURCE %s %s %s' % (corner, macro, path), flush=True)
        return path
    # No configured Liberty hint: exactly one matching file may exist under --ref.
    matches = {p.resolve(): p for p in candidates[macro] if pvt(p, True) == expected}
    require(len(matches) == 1,
            'Expected one %s original Liberty for %s %s; found %d: %s' %
            (macro, corner, expected, len(matches), [str(p) for p in matches]))
    path = checked(next(iter(matches.values())))
    print('NATIVE_LIBRARY_SOURCE %s %s %s' % (corner, macro, path), flush=True)
    return path


def inspect_inputs(old_config, ref):
    """Discover library and tool paths for the seven specified PVT conditions."""
    old_config, ref = Path(checked(old_config)), Path(ref).resolve()
    old = load(old_config)
    require(old.get('time_unit') == 'ns', 'Expected nanosecond source library configuration')
    missing = [c for c in CORNERS if c not in old.get('corners', {})]
    require(not missing, 'Missing required seven-corner library entries: ' + ', '.join(missing))
    tools = {name: checked(old['tools'][name]) for name in ('LC', 'DC', 'PT')}
    config = {'tools': tools, 'corners': {}, 'operating_conditions': {}, 'time_unit': 'ns',
              'macro_source_resolution': {},
              'buffer_cell': old['buffer_cell'], 'buffer_input': old['buffer_input'],
              'compile_max_corner': MAX_CORNER, 'compile_min_corner': MIN_CORNER,
              'compile_corner_interpretation': 'SS3_MAX_SS3_MIN_WORST_SETUP_AND_HOLD_CORNER_SEVEN_CORNERS_MEASURED_SEPARATELY',
              'old_config': str(old_config), 'old_config_sha256': sha(old_config)}
    require(all(isinstance(config[k], str) and config[k].strip() for k in ('buffer_cell', 'buffer_input')),
            'Missing buffer cell/input reference')
    source_candidates = {name: sorted(ref.rglob(name + '_*.lib')) for name in MACROS}
    snapshot = {str(old_config): sha(old_config)}
    snapshot.update({path: sha(path) for path in tools.values()})
    libraries = {}
    for corner in CORNERS:
        row, expected = old['corners'][corner], EXPECTED_PVT[corner]
        standard = checked(row['standard'])
        require(Path(standard).suffix == '.db' and pvt(standard) == expected,
                'Wrong standard-library PVT for ' + corner)
        op = old['operating_conditions'][corner]
        require(isinstance(op.get('library'), str) and op['library'].strip() and
                isinstance(op.get('condition'), str) and pvt('op_' + op['condition']) == expected,
                'Wrong operating condition for ' + corner)
        macros = {name: original_macro_source(row, name, corner, source_candidates) for name in sorted(MACROS)}
        for name, path in macros.items():
            data = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', Path(path).read_text(encoding='latin1'))
            cells = re.findall(r'\bcell\s*\(\s*"?([\w.-]+)"?\s*\)', data)
            require(cells == [name], 'Macro Liberty cell declaration mismatch: ' + path)
            for field, value in [('nom_voltage', expected[1]), ('nom_temperature', expected[2])]:
                hits = re.findall(r'\b' + field + r'\s*:\s*([-+0-9.eE]+)\s*;', data)
                require(len(hits) == 1 and math.isfinite(float(hits[0])) and abs(float(hits[0]) - value) < 1e-6,
                        'Liberty numeric PVT mismatch: ' + path + ' ' + field)
        config['corners'][corner] = {'standard': standard, 'macros': macros}
        hints = row.get('macro_sources', row['macros'])
        config['macro_source_resolution'][corner] = {
            name: {'configured_source_hint': hints.get(name), 'selected_original': path,
                   'sha256': sha(path)} for name, path in macros.items()}
        config['operating_conditions'][corner] = {'library': op['library'], 'condition': op['condition']}
        for path in [standard] + list(macros.values()):
            libraries[path] = sha(path)
    views = len(CORNERS) * (1 + len(MACROS))
    require(len(set(path for row in config['corners'].values() for path in
                    [row['standard']] + list(row['macros'].values()))) == views,
            'Distinct standard/SRAM library views required: %d' % views)
    config['library_hashes'] = libraries
    snapshot.update(libraries)
    config['input_snapshot'] = snapshot
    verify_snapshot(snapshot)
    return config


def validate_overlay(overlay):
    """Bind this candidate's verified functional log, payload, original source, and RTL."""
    overlay = Path(overlay).resolve()
    report = overlay.parents[1] / 'reports'
    functional = load(report / 'state.json')
    require(functional.get('status') == 'SERVER_SYSTEMBUS_FUNCTIONAL_RTL_PASS' and
            functional.get('candidate_id') == CANDIDATE,
            'RTL3307 current-candidate functional PASS receipt required')
    require(overlay == (ROOT / 'work/soc').resolve(), 'Overlay must belong to this independent RTL3307 payload')
    payload = load(ROOT / 'payload_manifest.json')
    require(payload.get('kind') == 'RTL3307_FULL7_SERVER' and
            sha(ROOT / 'payload_manifest.json') == functional.get('payload_manifest_sha256'),
            'Functional receipt does not bind this RTL3307 payload')
    snapshot = {str(ROOT / 'payload_manifest.json'): sha(ROOT / 'payload_manifest.json'),
                str(report / 'state.json'): sha(report / 'state.json')}
    for rel, digest in payload['files'].items():
        path = scoped_file(ROOT, rel)
        require(sha(path) == digest, 'Payload input changed: ' + rel)
        snapshot[str(path)] = digest
    manifest = load(overlay / 'source_manifest.json')
    require(manifest['reference_provenance']['mode'] == 'original_zip_byte_comparison',
            'Official ZIP-bound source required; a public-reference receipt is insufficient')
    require(functional.get('soc_manifest_sha256') == sha(overlay / 'source_manifest.json'),
            'Functional receipt does not bind exact overlay')
    snapshot[str(overlay / 'source_manifest.json')] = sha(overlay / 'source_manifest.json')
    for rel, digest in manifest['after'].items():
        path = scoped_file(overlay, rel)
        require(sha(path) == digest, 'Functional overlay changed: ' + rel)
        snapshot[str(path)] = digest
    require({p.relative_to(overlay).as_posix() for p in (overlay / 'rtl').rglob('*.v')} ==
            {rel for rel in manifest['after'] if rel.startswith('rtl/') and rel.endswith('.v')},
            'Functional overlay RTL file inventory changed')
    original = Path(manifest['source']).resolve()
    require({p.relative_to(original).as_posix() for p in (original / 'rtl').rglob('*.v')} ==
            {rel for rel in manifest['before_raw'] if rel.startswith('rtl/') and rel.endswith('.v')},
            'Original source RTL file inventory changed')
    for rel, digest in manifest['before_raw'].items():
        path = scoped_file(original, rel)
        require(sha(path) == digest, 'Official original source changed: ' + rel)
        snapshot[str(path)] = digest
    for path, key in [(report / 'simulation.log', 'log_sha256'), (report / 'compile.log', 'compile_log_sha256'),
                      (overlay / 'sources.f', 'compiled_source_list_sha256'),
                      (overlay / 'tasks_12.txt', 'runtime_task_list_sha256')]:
        require(sha(checked(path)) == functional.get(key), 'Functional input/log receipt differs: ' + str(path))
        snapshot[str(path)] = sha(path)
    # Reparse the native functional transcript with the delivered validator.
    validator_spec = importlib.util.spec_from_file_location('rtl3307_functional_receipt', str(ROOT / 'server/rtl_driver.py'))
    validator = importlib.util.module_from_spec(validator_spec)
    validator_spec.loader.exec_module(validator)
    parsed = validator.validate_output((report / 'simulation.log').read_text(errors='replace'))
    require(all(functional.get(key) == value for key, value in parsed.items()),
            'Functional summary differs from raw log')
    core = load(HERE / 'support/w12_core_sha256.json')
    require(len(core) == 13, 'Exactly 13 frozen numerical-core files required')
    for rel, digest in core.items():
        require(sha(overlay / 'rtl/e203/kwt' / Path(rel).name) == digest,
                'Frozen numerical core changed: ' + rel)
    clock = load(HERE / 'clock_review.json')
    for rel, digest in clock['lf_sha256'].items():
        require(hashlib.sha256((overlay / rel).read_bytes().replace(b'\r\n', b'\n')).hexdigest() == digest,
                'Reviewed clock topology changed: ' + rel)
    verify_snapshot(snapshot)
    return manifest, snapshot


def prepare(args):
    out, overlay = Path(args.out).absolute(), Path(args.overlay).resolve()
    require(not out.exists() and out.resolve() == out, 'Fresh unredirected output required')
    config = inspect_inputs(args.old_config, args.ref)
    manifest, snapshot = validate_overlay(overlay)
    config['input_snapshot'].update(snapshot)
    timeout = getattr(args, 'timeout', 7200)
    require(isinstance(timeout, int) and not isinstance(timeout, bool) and timeout > 0,
            'Native tool timeout must be positive seconds')
    module = helper()
    out.mkdir(parents=True)
    physical_view(overlay, out / 'soc', module)
    shutil.copyfile(str(HERE / 'sysbus.sdc'), str(out / 'sysbus.sdc'))
    config.update(out=str(out), overlay=str(overlay), candidate_id=CANDIDATE,
                  physical_view_sha256={'soc': sha(out / 'soc/physical_view.json')},
                  synthesis_sources_sha256={'soc': sha(out / 'soc/synthesis_sources.json')},
                  sdc_sha256=sha(out / 'sysbus.sdc'),
                  timeout=timeout, timing_scope='SEVEN_CORNER_SYNTHESIS_STA_DIGITAL_FIXTURE')
    config['input_snapshot'].update({str(p): sha(p) for p in
                                    [out / 'soc/physical_view.json', out / 'soc/synthesis_sources.json', out / 'sysbus.sdc']})
    for rel, digest in load(out / 'soc/physical_view.json')['after'].items():
        config['input_snapshot'][str(out / 'soc' / rel)] = digest
    verify_inputs(config)
    save(out / 'prepared.json', config)
    save(out / 'state.json', {'status': 'RTL3307_NATIVE_PREPARED_EDA_NOT_RUN',
                             'prepared_sha256': sha(out / 'prepared.json'), 'signoff_achieved': False})
    return config


def verify_inputs(config):
    require(set(config['corners']) == set(CORNERS) and set(config['operating_conditions']) == set(CORNERS) and
            config.get('candidate_id') == CANDIDATE and config.get('compile_max_corner') == MAX_CORNER and
            config.get('compile_min_corner') == MIN_CORNER, 'Seven-corner RTL3307 configuration required')
    replaced = verify_snapshot(config['input_snapshot'], True)
    out = Path(config['out'])
    view = load(out / 'soc/physical_view.json')
    require({p.relative_to(out / 'soc').as_posix() for p in (out / 'soc/rtl').rglob('*.v')} == set(view['after']),
            'Physical source inventory changed')
    validated_sources(config, 'soc')
    verify_snapshot(config['library_hashes'])
    return replaced


def values(config, corner, kind='soc'):
    require(corner in CORNERS and kind == 'soc', 'Unsupported native corner/design')
    out = Path(config['out'])
    row, op = config['corners'][corner], config['operating_conditions'][corner]
    root = out / 'soc/rtl/e203'
    return dict(corner=corner, standard=row['standard'], libraries=[row['standard']] +
                [row['macros'][name] for name in sorted(MACROS)],
                sources=validated_sources(config, 'soc'),
                includes=[str(root / x) for x in ('core', 'perips', 'perips/apb_i2c')],
                op_library=op['library'], op_condition=op['condition'], buffer_cell=config['buffer_cell'],
                buffer_input=config['buffer_input'], expected_macros=MACROS, sdc=str(out / 'sysbus.sdc'),
                netlist=str(out / 'dc_soc/design.v'))


def dc_values(config):
    value = values(config, MAX_CORNER)
    maximum, minimum = config['corners'][MAX_CORNER], config['corners'][MIN_CORNER]
    value.update(max_corner=MAX_CORNER, min_corner=MIN_CORNER, maximum=maximum, minimum=minimum,
                 max_op=config['operating_conditions'][MAX_CORNER], min_op=config['operating_conditions'][MIN_CORNER])
    value['libraries'] += [p for p in
                           [minimum['standard']] + [minimum['macros'][name] for name in sorted(MACROS)]
                           if p not in value['libraries']]
    return value


def stage_record(folder, required_files, extra_files=()):
    folder = Path(folder)
    files = [folder / name for name in tuple(required_files) + ('tool.log', 'config.tcl', 'invocation.json')]
    files += [Path(p) for p in extra_files]
    snapshot = {checked(path): sha(path) for path in files}
    for path in files:
        if path.suffix in ('.rpt', '.log'):
            require(not ERROR.search(path.read_text(errors='replace')), 'Tool error in report: ' + str(path))
    return {'folder': str(folder), 'files': snapshot}


def verify_stage(receipt):
    verify_snapshot(receipt['files'])


def timing_values(path):
    with Path(path).open() as stream:
        rows = list(csv.DictReader(stream, delimiter='\t'))
    require(len(rows) == 2 and {r.get('delay_type') for r in rows} == {'max', 'min'},
            'Missing/duplicate native timing values')
    data = {r['delay_type']: float(r['worst_slack_ns']) for r in rows}
    require(all(math.isfinite(v) for v in data.values()), 'Nonfinite native timing value')
    return data


def summarize(config):
    out = Path(config['out'])
    soc = area(out / 'sta/TT5/cells.tsv')
    require(soc['macros'] == MACROS, 'Mapped macro inventory mismatch')
    timings = {}
    for corner in CORNERS:
        folder = out / 'sta' / corner
        timing = timing_values(folder / 'timing.tsv')
        coverage = (folder / 'coverage.rpt').read_text(errors='replace')
        constraints = (folder / 'constraints.rpt').read_text(errors='replace')
        global_lines = (folder / 'global.rpt').read_text(errors='replace').splitlines()
        violations = [line.strip() for line in constraints.splitlines() if re.search(r'VIOLATED', line)]
        timings[corner] = {'pvt': list(EXPECTED_PVT[corner]), 'worst_ns': timing,
                           'negative_slack': any(v < 0 for v in timing.values()),
                           'constraint_violation_rows': len(violations),
                           'native_global_report_lines': global_lines,
                           'untested_report_rows': [line.strip() for line in coverage.splitlines()
                                                    if re.search(r'\buntested\b', line, re.I)],
                           'reports': {p.name: sha(p) for p in folder.glob('*.rpt')},
                           'coverage_review': 'REQUIRED_NO_AUTOMATIC_WAIVERS'}
    return {'status': COMPLETE, 'candidate_id': CANDIDATE, 'timing': timings, 'soc': soc,
            'area_scope': 'TT5 standard-cell and SRAM library area of this SoC; no baseline delta or die area',
            'netlist': str(out / 'dc_soc/design.v'), 'netlist_sha256': sha(out / 'dc_soc/design.v'),
            'prepared_sha256': sha(out / 'prepared.json'), 'resolved_config_sha256': sha(out / 'resolved_config.json'),
            'source_manifest_sha256': sha(out / 'soc/physical_view.json'), 'sdc_sha256': sha(out / 'sysbus.sdc'),
            'compile_corner_interpretation': config['compile_corner_interpretation'],
            'library_hashes': config['library_hashes'], 'signoff_achieved': False,
            'pending': ['native global setup/hold/recovery/removal review', 'electrical and coverage review',
                        'RTL-to-netlist LEC', 'native-macro GLS', 'task-window power']}


def workers():
    """Parallel tool invocations from the environment; 1 keeps the serial behaviour."""
    raw = os.environ.get('RTL3307_WORKERS', '1')
    try:
        count = int(raw)
    except (TypeError, ValueError):
        raise ValueError('Invalid RTL3307_WORKERS: ' + str(raw))
    require(count > 0, 'RTL3307_WORKERS must be positive')
    return count


def together(config, jobs):
    """Run independent (name, engine, script, folder, value) jobs; each owns its folder."""
    count = min(workers(), len(jobs))
    if count <= 1:
        for name, engine, script, folder, value in jobs:
            tool(config, engine, script, folder, value)
        return
    from concurrent.futures import ThreadPoolExecutor
    print('NATIVE_PARALLEL %d jobs with %d workers' % (len(jobs), count), flush=True)
    with ThreadPoolExecutor(max_workers=count) as pool:
        pending = [(job, pool.submit(tool, config, job[1], job[2], job[3], job[4]))
                   for job in jobs]
        for job, future in pending:
            future.result()


def run(config):
    """Run fresh synthesis only; no input DDC, baseline compile, or old results."""
    out = Path(config['out'])
    prepared_hash = sha(out / 'prepared.json')
    state = load(out / 'state.json')
    require(state.get('status') == 'RTL3307_NATIVE_PREPARED_EDA_NOT_RUN' and
            state.get('prepared_sha256') == prepared_hash and config == load(out / 'prepared.json'),
            'Prepared configuration differs or run already started; use a fresh run')
    lock = out / '.RUNNING'
    descriptor = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.write(descriptor, str(os.getpid()).encode('ascii'))
    os.close(descriptor)
    receipts = []
    try:
        state = {'status': 'RUNNING_NATIVE', 'pid': os.getpid(), 'prepared_sha256': prepared_hash,
                 'signoff_achieved': False, 'started': time.time()}
        save(out / 'state.json', state)

        def validate():
            require(sha(out / 'prepared.json') == prepared_hash, 'Prepared configuration changed during run')
            verify_inputs(config)
            for receipt in receipts:
                verify_stage(receipt)

        def stage(name, engine, script, folder, value, required_files, extra=()):
            validate()
            state['stage'] = name
            save(out / 'state.json', state)
            tool(config, engine, script, folder, value)
            validate()
            receipts.append(stage_record(folder, required_files, extra))
            save(out / 'receipts.json', receipts)

        validate()
        lc = []
        for corner in CORNERS:
            row = config['corners'][corner]
            for macro, path in sorted(row['macros'].items()):
                if Path(path).suffix == '.lib':
                    dest = out / 'libraries' / (corner + '_' + macro + '.db')
                    dest.parent.mkdir(exist_ok=True)
                    require(not dest.exists(), 'Refusing existing converted DB: ' + str(dest))
                    lc.append((corner, macro, path, dest))
        state['stage'] = 'LC_%d' % len(lc)
        save(out / 'state.json', state)
        together(config, [('LC_' + corner + '_' + macro, 'LC', 'convert', out / 'lc' / (corner + '_' + macro),
                           {'liberty': path, 'macro': macro, 'destination': str(dest)})
                          for corner, macro, path, dest in lc])
        validate()
        for corner, macro, path, dest in lc:
            config['corners'][corner]['macros'][macro] = checked(dest)
            config['library_hashes'][str(dest)] = sha(dest)
            receipts.append(stage_record(out / 'lc' / (corner + '_' + macro), ('library.rpt',), (dest,)))
            save(out / 'receipts.json', receipts)
        save(out / 'resolved_config.json', config)
        resolved_hash = sha(out / 'resolved_config.json')
        stage('DC_TT6_MAX_TT5_MIN', 'DC', 'dc', out / 'dc_soc', dc_values(config), DC_FILES)
        validate()
        stations = [(corner, out / 'sta' / corner) for corner in CORNERS]
        state['stage'] = 'STA_SEVEN_CORNERS'
        save(out / 'state.json', state)
        together(config, [('STA_' + corner, 'PT', 'sta', folder, values(config, corner))
                          for corner, folder in stations])
        for corner, folder in stations:
            require(sha(out / 'resolved_config.json') == resolved_hash, 'Resolved configuration changed')
            receipts.append(stage_record(folder, PT_FILES))
            save(out / 'receipts.json', receipts)
        validate()
        require(sha(out / 'resolved_config.json') == resolved_hash, 'Resolved configuration changed')
        report = summarize(config)
        save(out / 'metrics.json', report)
        state.update(status=COMPLETE, stage='DONE', resolved_config_sha256=resolved_hash,
                     receipts_sha256=sha(out / 'receipts.json'), metrics_sha256=sha(out / 'metrics.json'),
                     finished=time.time())
        save(out / 'state.json', state)
        return report
    except BaseException as error:
        state.update(status='RTL3307_NATIVE_FAILED_NO_ACCEPTANCE', error=str(error)[:2000])
        save(out / 'state.json', state)
        raise
    finally:
        lock.unlink()


def results(config):
    """Read a completed result only after revalidating the original inputs and all stages."""
    out = Path(config['out'])
    state = load(out / 'state.json')
    require(state.get('status') == COMPLETE, 'Native reports are not complete')
    for name, key in [('prepared.json', 'prepared_sha256'), ('resolved_config.json', 'resolved_config_sha256'),
                      ('receipts.json', 'receipts_sha256'), ('metrics.json', 'metrics_sha256')]:
        require(sha(out / name) == state.get(key), 'Completed receipt changed: ' + name)
    prepared, resolved = load(out / 'prepared.json'), load(out / 'resolved_config.json')
    require(config == prepared or config == resolved, 'Caller configuration differs from completed run')
    replaced = verify_inputs(resolved)
    receipts = load(out / 'receipts.json')
    expected = [str(out / 'lc' / (corner + '_' + macro)) for corner in CORNERS
                for macro, path in sorted(prepared['corners'][corner]['macros'].items()) if Path(path).suffix == '.lib']
    expected += [str(out / 'dc_soc')] + [str(out / 'sta' / corner) for corner in CORNERS]
    require([r['folder'] for r in receipts] == expected, 'Incomplete/reordered native stage receipts')
    for receipt in receipts:
        verify_stage(receipt)
    report = load(out / 'metrics.json')
    require(report == summarize(resolved), 'Metrics differ from current native reports')
    if replaced:
        report = dict(report)
        report['replaced_tool_files'] = replaced
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'run', 'status', 'results'))
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--overlay', type=Path, default=ROOT / 'work/soc')
    parser.add_argument('--old-config', type=Path, default=Path.home() / 'kwt_runs/R2COMPARE_20261110_193824_Am2w82/candidates/w12/result/soc/resolved_config.json')
    parser.add_argument('--ref', type=Path, default=Path.home() / 'ref')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args)
        print('RTL3307_NATIVE_PREPARED_EDA_NOT_RUN', flush=True)
        return
    if args.action == 'status':
        print(json.dumps(load(args.out / 'state.json'), indent=2))
        return
    config = load(args.out / 'prepared.json')
    report = run(config) if args.action == 'run' else results(config)
    print(report['status'], flush=True)
    for corner in CORNERS:
        print(corner, report['timing'][corner]['worst_ns'], flush=True)
    print('SIGNOFF=False; review native reports, coverage and remaining verification.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('RTL3307_NATIVE_REFUSED=' + str(error), file=sys.stderr, flush=True)
        sys.exit(1)


