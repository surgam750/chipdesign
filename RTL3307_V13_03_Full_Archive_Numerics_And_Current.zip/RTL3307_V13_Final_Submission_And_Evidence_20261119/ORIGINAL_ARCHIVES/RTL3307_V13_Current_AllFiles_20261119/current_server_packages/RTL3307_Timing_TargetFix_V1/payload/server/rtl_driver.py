"""User-operated original-platform SystemBus RTL functional verification (Python 3.6)."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'tools'))
from build_sysbus_overlay import build, archive_reference, FUNCTIONAL_MEMORIES
sys.path.insert(0, str(ROOT / 'power'))
import activity as task_activity

LIMIT = 'FUNCTIONAL_RTL_ONLY: behavioral RAM and selected original clockgate latch; not native macro, synthesis, STA, GLS, PPA or submission acceptance'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def payload_check():
    manifest = json.loads((ROOT / 'payload_manifest.json').read_text())
    if manifest.get('kind') != 'RTL3307_FULL7_SERVER' or manifest.get('candidate_id') != 'RTL3307_TCM128_TARGETFIX_V1':
        raise ValueError('Wrong candidate package; expected RTL3307_TCM128_TARGETFIX_V1')
    for rel, digest in manifest['files'].items():
        target = (ROOT / rel).resolve()
        if ROOT.resolve() not in target.parents or target.is_symlink():
            raise ValueError('Unsafe payload path: ' + rel)
        if sha(ROOT / rel) != digest:
            raise ValueError('payload hash mismatch: ' + rel)
    folders = ('rtl/', 'tb/', 'sw/', 'tools/', 'frozen/', 'server/', 'native/', 'optimization/', 'power/', 'formality/')
    actual = {p.relative_to(ROOT).as_posix() for folder in folders
              for p in (ROOT / folder).rglob('*') if p.is_file()}
    expected_files = {rel for rel in manifest['files'] if rel.startswith(folders)}
    if actual != expected_files:
        raise ValueError('Payload source file set changed')
    expected = json.loads((ROOT / 'tools/w12_core_sha256.json').read_text())
    if len(expected) != 13:
        raise ValueError('expected exactly13 frozen core files')
    for rel, digest in expected.items():
        if sha(ROOT / 'frozen' / rel) != digest:
            raise ValueError('frozen core hash mismatch: ' + rel)
    return sha(ROOT / 'payload_manifest.json')


def verify_overlay(dst):
    manifest = json.loads((dst / 'source_manifest.json').read_text())
    for rel, digest in manifest['after'].items():
        path = (dst / rel).resolve()
        if dst.resolve() not in path.parents or sha(path) != digest:
            raise ValueError('Overlay identity changed: ' + rel)
    actual = {p.relative_to(dst).as_posix() for folder in ('rtl', 'tb')
              for p in (dst / folder).rglob('*') if p.is_file()}
    expected = {rel for rel in manifest['after'] if rel.startswith(('rtl/', 'tb/'))}
    if actual != expected:
        raise ValueError('Overlay source file set changed')


def verify_run_inputs(dst, state):
    if payload_check() != state['payload_manifest_sha256']:
        raise ValueError('Payload manifest changed during run')
    checks = [(dst / 'source_manifest.json', 'soc_manifest_sha256'),
              (dst / 'sources.f', 'compiled_source_list_sha256'),
              (dst / 'tasks_12.txt', 'runtime_task_list_sha256'),
              (ROOT / 'sw/out/t_linear_irq.verilog', 'firmware_sha256')]
    for path, key in checks:
        if sha(path) != state[key]:
            raise ValueError('Functional input changed: ' + key)
    if tasks_check() != state['task_manifest_sha256']:
        raise ValueError('Task manifest changed during run')
    verify_overlay(dst)


def tasks_check(out=None):
    base = ROOT / 'frozen/data/tasks/validation'
    manifest = json.loads((base / 'manifest.json').read_text())
    tasks = manifest['tasks']
    if len(tasks) != 12 or [t['layer'] for t in tasks] != list(range(12)):
        raise ValueError('expected exact twelve ordered tasks')
    lines = []
    for task in tasks:
        folder = (base / task['directory']).resolve()
        if base.resolve() not in folder.parents or any(c.isspace() for c in str(folder)):
            raise ValueError('unsafe task path')
        if sha(folder / 'meta.json') != task['meta_sha256']:
            raise ValueError('metadata hash mismatch')
        meta = json.loads((folder / 'meta.json').read_text())
        for name, record in meta['files'].items():
            path = (folder / name).resolve()
            if folder not in path.parents or sha(path) != record['sha256']:
                raise ValueError('task file mismatch: ' + name)
        lines.append('%s %s\n' % (task['layer'], folder.as_posix()))
    if out:
        out.write_text(''.join(lines), encoding='ascii')
    return sha(base / 'manifest.json')


def validate_output(output):
    # Require independent CPU completion and every task record, not just a summary.
    if re.search(r'TEST_FAIL|Time Out !!!|\bFatal\b|\bFATAL\b|\bError\b|\bERROR\b|\*\* Error', output):
        raise ValueError('simulator/CPU error in log')
    if len(re.findall(r'\bTEST_PASS\b', output)) != 1:
        raise ValueError('missing/duplicate independent CPU TEST_PASS')
    records = re.findall(r'KWT_TASK id=(\d+) layer=(\d+) cycles=(\d+) x_rsp=(\d+) w_rsp=(\d+) y_rsp=(\d+) checked=(\d+) mism=0 PASS', output)
    if len(records) != 12:
        raise ValueError('missing/duplicate full task completions')
    for i, row in enumerate(records):
        values = list(map(int, row))
        if values[:2] != [i, i] or values[2] <= 0 or values[3:] != [3168, 6656, 12672, 12672]:
            raise ValueError('task counts/identity mismatch')
    summaries = re.findall(r'KWT_SOC_SUMMARY PASS tasks=(\d+) scalar_outputs=(\d+) cycles_sum=(\d+) placement=SYSTEMBUS32 mode=IRQ timing=LOAD_TO_LAST_WRITE_RSP loader_cmd=(\d+) loader_rsp=(\d+)', output)
    fabrics = re.findall(r'KWT_FABRIC_COUNTS accepted=(\d+) delivered=(\d+) responses=(\d+) pending=(\d+) contention_cycles=(\d+) outlet_stall_cycles=(\d+) master_stall_cycles=(\d+)', output)
    if len(summaries) != 1 or len(fabrics) != 1:
        raise ValueError('missing/duplicate final accounting')
    summary, fabric = list(map(int, summaries[0])), list(map(int, fabrics[0]))
    if summary[:2] != [12, 304128] or summary[2] != sum(int(r[2]) for r in records) or summary[3] <= 0 or summary[3] != summary[4]:
        raise ValueError('summary/loader accounting mismatch')
    if not (fabric[0] == fabric[1] == fabric[2] > 0) or fabric[3] != 0 or fabric[4] <= 0 or fabric[6] <= 0:
        raise ValueError('fabric incomplete/unexercised')
    return {'tasks': 12, 'scalar_outputs': 304128, 'cycles_sum': summary[2],
            'loader_commands': summary[3], 'loader_responses': summary[4],
            'fabric': dict(zip(('accepted', 'delivered', 'responses', 'pending',
                               'contention_cycles', 'outlet_stall_cycles', 'master_stall_cycles'), fabric))}


def compilation_sources(dst):
    rtl = dst / 'rtl/e203'
    sources = sorted(rtl.rglob('*.v'))
    manifest = json.loads((dst / 'source_manifest.json').read_text())
    original = rtl / 'generic/GENERIC_RVT_SMIC.v'
    selected = dst / 'tb/kwt/GENERIC_RVT_SMIC_functional.v'
    if original.is_file():
        if not selected.is_file():
            raise ValueError('missing functional clockgate view')
        for path in (original, selected):
            if manifest['after'].get(path.relative_to(dst).as_posix()) != sha(path):
                raise ValueError('functional clockgate source hash mismatch: ' + path.name)
        sources.remove(original)
    elif selected.exists():
        raise ValueError('functional clockgate view has no original source')
    records = manifest.get('functional_memory_views', [])
    expected = {relative: 'tb/kwt/' + module + '_functional.v'
                for relative, module, _, _ in FUNCTIONAL_MEMORIES}
    recorded = set()
    for record in records:
        relative = record['original']
        if (relative not in expected or relative in recorded or
                record['generated'] != expected[relative] or record['selector'] != 'KWT_SRAM_BEHAV'):
            raise ValueError('unexpected/duplicate functional memory view')
        recorded.add(relative)
        for key in ('original', 'generated'):
            path = dst / record[key]
            if not path.is_file():
                raise ValueError('missing functional memory source: ' + record[key])
            digest = sha(path)
            if digest != record[key + '_sha256'] or manifest['after'].get(record[key]) != digest:
                raise ValueError('functional memory source hash mismatch: ' + record[key])
        sources.remove(dst / relative)
    for relative, generated in expected.items():
        if relative not in recorded and (dst / generated).exists():
            raise ValueError('unrecorded functional memory view: ' + generated)
    return sources + sorted((dst / 'tb/kwt').glob('*.v')) + sorted((dst / 'tb/kwt').glob('*.sv')) + [dst / 'tb/tb_top.v']


def show_failure_log(log):
    with log.open('rb') as stream:
        stream.seek(max(0, log.stat().st_size - 24000))
        lines = stream.read().decode('utf-8', errors='replace').splitlines()[-24:]
    print('FAILURE_DETAIL ' + log.name + ' LAST24LINES:', flush=True)
    for line in lines:
        print(line[:1000], flush=True)


def invoke(command, cwd, log, timeout):
    print('START ' + log.name, flush=True)
    (log.parent / (log.stem + '_command.json')).write_text(json.dumps(command, indent=2) + '\n')
    start = time.time()
    with log.open('w') as out:
        process = subprocess.Popen(command, cwd=str(cwd), stdout=out, stderr=subprocess.STDOUT)
        try:
            while process.poll() is None:
                if time.time() - start > timeout:
                    process.kill()
                    process.wait()
                    raise RuntimeError('timeout: ' + log.name)
                time.sleep(2)
                if int(time.time() - start) % 30 < 2:
                    print('RUNNING %s elapsed=%ds log_bytes=%d' % (log.name, time.time()-start, log.stat().st_size), flush=True)
        except BaseException:
            if process.poll() is None:
                process.kill()
                process.wait()
            raise
    if process.returncode:
        show_failure_log(log)
        raise RuntimeError('%s exit=%d' % (log.name, process.returncode))
    print('DONE ' + log.name, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('check', 'run'))
    parser.add_argument('--source', type=Path, default=Path.home() / 'ref/SOC_RTL_2025/e203_hbirdv2-master')
    parser.add_argument('--archive', type=Path)
    parser.add_argument('--vcs', default='/eda/synopsys/vcs/vcs_2020.03-SP2-6/bin/vcs')
    parser.add_argument('--timeout', type=int, default=3600)
    args = parser.parse_args()
    archive = args.archive or args.source.parent / 'e203_hbirdv2-master_1013_update_sim.zip'
    report = ROOT / 'reports'
    report.mkdir(exist_ok=True)
    state = {'status': 'CHECKING', 'candidate_id': 'RTL3307_TCM128_TARGETFIX_V1',
             'evidence_limit': LIMIT, 'pid': os.getpid()}
    state_path = report / 'state.json'
    write_json(state_path, state)
    try:
        state['payload_manifest_sha256'] = payload_check()
        state['task_manifest_sha256'] = tasks_check()
        _, provenance = archive_reference(args.source.resolve(), archive.resolve())
        state['original_reference'] = provenance
        state['firmware_sha256'] = sha(ROOT / 'sw/out/t_linear_irq.verilog')
        state['raw_config_sha256'] = sha(args.source / 'rtl/e203/core/config.v')
        if not Path(args.vcs).is_file():
            raise ValueError('VCS executable missing: ' + args.vcs)
        state['vcs_sha256'] = sha(args.vcs)
        if args.action == 'check':
            state['status'] = 'SOURCE_CHECK_PASS_RTL_NOT_RUN'
            print(state['status'], flush=True)
            return
        dst = ROOT / 'work/soc'
        state['status'] = 'BUILDING_ORIGINAL_OVERLAY'
        write_json(state_path, state)
        build(args.source, dst, ROOT / 'frozen', archive)
        state['soc_manifest_sha256'] = sha(dst / 'source_manifest.json')
        tasks = dst / 'tasks_12.txt'
        tasks_check(tasks)
        rtl = dst / 'rtl/e203'
        sources = compilation_sources(dst)
        source_list = dst / 'sources.f'
        source_list.write_text(''.join(p.relative_to(dst).as_posix() + '\n' for p in sources))
        state['compiled_source_list_sha256'] = sha(source_list)
        state['runtime_task_list_sha256'] = sha(tasks)
        command = [args.vcs, '-full64', '-sverilog', '-timescale=1ns/1ps',
                   '-debug_access+all', '-debug_region+cell+lib',
                   '+define+KWT_SRAM_BEHAV+KWT_CLK_150M+DISABLE_SV_ASSERTION',
                   '-top', 'tb_top', '-o', 'simv', '-Mdir=csrc']
        command += ['+incdir+' + p.relative_to(dst).as_posix() for p in (rtl / 'core', rtl / 'perips', rtl / 'perips/apb_i2c')]
        command += ['-f', 'sources.f', str(ROOT / 'power/task_activity.sv')]
        state['status'] = 'VCS_COMPILING'
        write_json(state_path, state)
        verify_run_inputs(dst, state)
        invoke(command, dst, report / 'compile.log', args.timeout)
        verify_run_inputs(dst, state)
        compile_output = (report / 'compile.log').read_text(errors='replace')
        state['compile_warning_diagnostics'] = len(re.findall(r'Warning-\[', compile_output))
        if re.search(r'Error-\[|\bFatal\b|\bFATAL\b', compile_output) or not (dst / 'simv').is_file():
            raise ValueError('VCS compile missing executable or error diagnostics')
        state['status'] = 'RTL_RUNNING'
        state['simv_sha256'] = sha(dst / 'simv')
        write_json(state_path, state)
        invoke([str(dst / 'simv'), '+TESTCASE=' + (ROOT / 'sw/out/t_linear_irq').as_posix(),
                '+KWT_TASKS=' + tasks.as_posix(), '+KWT_EXPECT_TASKS=12'], dst, report / 'simulation.log', args.timeout)
        verify_run_inputs(dst, state)
        state.update(validate_output((report / 'simulation.log').read_text(errors='replace')))
        if state['vcs_sha256'] != sha(args.vcs) or state['simv_sha256'] != sha(dst / 'simv'):
            raise ValueError('Functional VCS executable identity changed')
        state['activity_manifest_sha256'] = sha(task_activity.seal(report, dst))
        state['status'] = 'SERVER_SYSTEMBUS_FUNCTIONAL_RTL_PASS'
        state['log_sha256'] = sha(report / 'simulation.log')
        state['compile_log_sha256'] = sha(report / 'compile.log')
        print('%s tasks=12 scalar_outputs=304128 cycles=%d' % (state['status'], state['cycles_sum']), flush=True)
    except BaseException as exc:
        state['status'] = 'FAILED'
        state['error'] = str(exc)[:1200]
        print('FAILED: ' + state['error'], flush=True)
        raise
    finally:
        state['updated'] = datetime.now().isoformat()
        state['receipt_files'] = {path.name: sha(path) for path in sorted(report.glob('*'))
                                  if path.is_file() and path.name != 'state.json'}
        write_json(state_path, state)
        print(LIMIT, flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # main records the failure, and tool failures already show the actual
        # bounded log tail. A Python traceback obscures the native diagnostic.
        print('RTL3307_DRIVER_FAILED: ' + str(error)[:1200], file=sys.stderr)
        sys.exit(1)
