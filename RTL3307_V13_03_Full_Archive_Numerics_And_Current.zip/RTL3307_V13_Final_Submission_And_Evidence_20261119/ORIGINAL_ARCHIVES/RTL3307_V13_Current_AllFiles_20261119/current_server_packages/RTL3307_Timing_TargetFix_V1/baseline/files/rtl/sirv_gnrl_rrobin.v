// Compatible dependency for the original ICB arbiter's round-robin branch.
// The public E203 snapshot references this module but does not supply its body.
module sirv_gnrl_rrobin #(
    parameter ARBT_NUM = 4
) (
    output reg [ARBT_NUM-1:0] grt_vec,
    input [ARBT_NUM-1:0] req_vec,
    input arbt_ena,
    input clk,
    input rst_n
);
    integer next_port;
    integer offset;
    integer candidate;
    integer granted_port;
    reg held;
    reg [ARBT_NUM-1:0] held_grant;
    reg found;

    always @(*) begin
        grt_vec = {ARBT_NUM{1'b0}};
        found = 1'b0;
        candidate = 0;
        granted_port = 0;
        if (held) begin
            grt_vec = held_grant;
        end else begin
            for (offset = 0; offset < ARBT_NUM; offset = offset + 1) begin
                candidate = next_port + offset;
                if (candidate >= ARBT_NUM) candidate = candidate - ARBT_NUM;
                if (!found && req_vec[candidate]) begin
                    grt_vec[candidate] = 1'b1;
                    found = 1'b1;
                end
            end
        end
        for (offset = 0; offset < ARBT_NUM; offset = offset + 1)
            if (grt_vec[offset]) granted_port = offset;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            next_port <= 0;
            held <= 1'b0;
            held_grant <= {ARBT_NUM{1'b0}};
        end else if (arbt_ena) begin
            next_port <= granted_port == ARBT_NUM-1 ? 0 : granted_port + 1;
            held <= 1'b0;
        end else if (|grt_vec) begin
            held <= 1'b1;
            held_grant <= grt_vec;
        end
    end
endmodule
