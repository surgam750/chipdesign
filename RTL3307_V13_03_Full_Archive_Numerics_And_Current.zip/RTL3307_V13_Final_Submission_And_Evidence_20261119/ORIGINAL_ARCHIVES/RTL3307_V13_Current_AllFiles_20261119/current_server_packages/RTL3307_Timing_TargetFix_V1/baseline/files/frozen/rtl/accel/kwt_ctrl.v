`timescale 1ns/1ps
`default_nettype none

// UG task sequencing, byte addresses, completion events, and counters (plan §6).
module kwt_ctrl #(
    parameter [31:0] WIN0_BASE = 32'h8000_0000,
    parameter [31:0] WIN0_SIZE = 32'h0004_0000,
    parameter [31:0] WIN1_BASE = 32'h9000_0000,
    parameter [31:0] WIN1_SIZE = 32'h0004_0000
) (
    input  wire         clk, rst_n,
    input  wire         start, abort, clr_perf,
    input  wire [3:0]   opcode,
    input  wire [6:0]   dim_m,
    input  wire [9:0]   dim_k, dim_n,
    input  wire [31:0]  x_base, w_base, y_base, x_stride, y_stride,
    output wire         busy, done_event, error_event,
    output wire [3:0]   error_code,
    output wire [31:0]  error_addr,
    output reg  [31:0]  perf_total, perf_xload, perf_issue,
    output reg  [31:0]  perf_rd_stall, perf_wr_stall,
    output reg  [31:0]  perf_rd_words, perf_wr_words, perf_starve,
    output reg  [31:0]  task_count, sat_count, cycle_now,
    input  wire         rd_cmd_fire, wr_cmd_fire, rd_cmd_stall, wr_cmd_stall,
    output wire         rd_req_valid,
    input  wire         rd_req_ready,
    output wire [31:0]  rd_req_addr,
    output wire [15:0]  rd_req_tag,
    input  wire         rd_ret_valid, rd_ret_err, rd_idle,
    input  wire [31:0]  rd_ret_addr, rd_ret_data,
    input  wire [15:0]  rd_ret_tag,
    output wire         wr_req_valid,
    input  wire         wr_req_ready,
    output reg  [31:0]  wr_req_addr,
    input  wire         wr_ret_valid, wr_ret_err, wr_idle,
    input  wire [31:0]  wr_ret_addr,
    output wire         x_write, w_write, row_issue,
    output wire         x_write_raw, row_issue_raw,
    output wire [6:0]   row_read,
    output wire         x_capture, mac_valid, mac_set,
    output reg  [6:0]   lane_count,
    input  wire         mac_out_valid,
    input  wire [1:0]   mac_sat,
    input  wire         fifo_empty,
    output wire         fifo_push, fifo_pop, fifo_flush
);
    localparam [2:0] IDLE = 3'd0, CHECK = 3'd1, XLOAD = 3'd2,
                     COMPUTE = 3'd3, DRAIN = 3'd4;
    reg [2:0] state;
    reg [3:0] op;
    reg [6:0] m;
    reg [9:0] k, n;
    reg [31:0] xb, wb, yb, xs, ys;
    reg [3:0] first_error;
    reg [31:0] first_error_addr;
    reg [2:0] drain_cycles;
    wire [39:0] x_last, w_last, y_last;
    wire [39:0] x_offset, w_bytes, y_offset;
    wire [6:0] last_row, weight_last_word;
    wire [11:0] packed_weight_words;
    wire [4:0] last_x_pair;
    wire [7:0] pairs;
    wire [14:0] expected_writes;
    wire cfg_ok, x_range, w_range, y_range, check_fail, drain_done;

    reg [6:0] x_row;
    reg [4:0] x_pair;
    reg [31:0] x_row_base, x_next_addr;
    reg x_all_sent;
    reg [1:0] group_busy, group_full;
    reg w_active;
    reg [6:0] w_word;
    reg [7:0] w_block;
    reg [31:0] w_next_addr;
    reg [6:0] compute_row;
    reg [7:0] compute_block;
    reg valid_c0, valid_c1, set_c0, set_c1, last_c0, last_c1;
    reg [4:0] reserved_words;
    reg [6:0] write_row;
    reg [31:0] write_block_base;
    reg [14:0] responses;

    wire rd_fire, x_request, x_response, w_response, x_finished, w_header;
    wire bad_param, fault, computing, activity;
    wire reserve_group, release_group;

    // RDCOUNT_V1: compute the increment from the old count only. The original
    // sequential handshake guard below remains the update selector.
    wire [31:0] perf_rd_words_inc;
    genvar perf_rd_bit;
    assign perf_rd_words_inc[0] = ~perf_rd_words[0];
    generate
        for (perf_rd_bit = 1; perf_rd_bit < 32; perf_rd_bit = perf_rd_bit + 1) begin : g_perf_rd_inc
            assign perf_rd_words_inc[perf_rd_bit] = perf_rd_words[perf_rd_bit] ^
                                                   (&perf_rd_words[perf_rd_bit-1:0]);
        end
    endgenerate

    function in_window;
        input [31:0] first_addr;
        input [39:0] last_addr;
        input [31:0] base;
        input [31:0] size;
        begin
            in_window = size != 0 && first_addr >= base && last_addr[39:32] == 0 &&
                        last_addr < ({8'b0, base} + {8'b0, size});
        end
    endfunction

    assign busy = state != IDLE;
    assign last_row = m - 1'b1;
    assign last_x_pair = k[5:1] - 1'b1; // k=64 wraps to pair 31.
    // Each lane contributes two signed twelve-bit weights; round to words.
    assign packed_weight_words = ({2'b0, k} * 12'd3 + 12'd3) >> 2;
    assign weight_last_word = packed_weight_words[6:0] + 7'd3;
    assign pairs = n[8:1];
    assign expected_writes = m * pairs;
    assign x_offset = last_row * xs;
    assign y_offset = last_row * ys;
    assign w_bytes = pairs * ({28'b0, packed_weight_words} + 40'd4) * 40'd4;
    assign x_last = {8'b0, xb} + x_offset + {29'b0, k, 1'b0} - 1'b1;
    assign y_last = {8'b0, yb} + y_offset + {29'b0, n, 1'b0} - 1'b1;
    assign w_last = {8'b0, wb} + w_bytes - 1'b1;
    assign cfg_ok = op == 0 && m != 0 && m <= 99 &&
                    k >= 2 && k <= 64 && !k[0] && n >= 2 && n <= 256 && !n[0] &&
                    ((xb[1:0] | wb[1:0] | yb[1:0] | xs[1:0] | ys[1:0]) == 0) &&
                    xs >= {21'b0, k, 1'b0} && ys >= {21'b0, n, 1'b0};
    assign x_range = in_window(xb, x_last, WIN0_BASE, WIN0_SIZE) ||
                     in_window(xb, x_last, WIN1_BASE, WIN1_SIZE);
    assign w_range = in_window(wb, w_last, WIN0_BASE, WIN0_SIZE) ||
                     in_window(wb, w_last, WIN1_BASE, WIN1_SIZE);
    assign y_range = in_window(yb, y_last, WIN0_BASE, WIN0_SIZE) ||
                     in_window(yb, y_last, WIN1_BASE, WIN1_SIZE);
    assign check_fail = state == CHECK && !abort && !(cfg_ok && x_range && w_range && y_range);
    // Drain old arithmetic valid bits before a minimum-size restarted task.
    assign drain_done = state == DRAIN && rd_idle && wr_idle && drain_cycles == 0;
    assign error_event = check_fail || drain_done;
    assign error_code = drain_done ? first_error : !cfg_ok ? 4'd3 : 4'd4;
    assign error_addr = drain_done ? first_error_addr :
                        !cfg_ok ? 32'b0 : !x_range ? xb : !w_range ? wb : yb;

    assign activity = state == XLOAD || state == COMPUTE;
    assign computing = state == COMPUTE;
    assign w_header = rd_ret_tag[6:0] == 1 || rd_ret_tag[6:0] == 3;
    assign bad_param = rd_ret_valid && rd_ret_tag[15] && w_header &&
                       (rd_ret_data[31:14] != 0 || rd_ret_data[13:8] > 40);
    assign fault = (state == CHECK || activity) &&
                   (abort || rd_ret_err || wr_ret_err || bad_param);
    // Send X first, then use its response-drain interval for the first W block.
    // The request kind also selects which cursor advances on an accepted read.
    assign x_request = state == XLOAD && !x_all_sent;
    assign rd_req_valid = !fault && (x_request || (activity && w_active));
    assign rd_req_addr = x_request ? x_next_addr : w_next_addr;
    assign rd_req_tag = x_request ? {2'b0, x_row, 2'b0, x_pair} :
                                         {1'b1, w_block[0], 7'b0, w_word};
    assign rd_fire = rd_req_valid && rd_req_ready;
    assign x_response = rd_ret_valid && !rd_ret_tag[15];
    assign w_response = rd_ret_valid && rd_ret_tag[15];
    // Raw SRAM accesses are disposable on a fault. State, retirement and
    // arithmetic validity remain fault-qualified, and restart reloads X.
    assign x_write_raw = state == XLOAD && x_response;
    assign x_write = x_write_raw && !fault;
    assign w_write = activity && w_response && !fault;
    assign x_finished = x_write && rd_ret_tag[13:7] == last_row &&
                        rd_ret_tag[4:0] == last_x_pair;
    assign reserve_group = activity && !fault && !w_active && w_block < pairs &&
                           !group_busy[w_block[0]];
    assign release_group = valid_c1 && last_c1 && computing && !fault;
    assign row_issue_raw = computing && compute_block < pairs &&
                           group_full[compute_block[0]] && reserved_words < 16;
    assign row_issue = row_issue_raw && !fault;
    assign row_read = compute_row;
    assign x_capture = valid_c0;
    assign mac_valid = valid_c1;
    assign mac_set = set_c1;
    assign fifo_push = computing && mac_out_valid && !fault;
    assign fifo_flush = state == IDLE || fault || state == DRAIN;
    assign wr_req_valid = computing && !fault && !fifo_empty;
    assign fifo_pop = wr_req_valid && wr_req_ready;
    assign done_event = computing && !fault && wr_ret_valid &&
                        responses + 1'b1 == expected_writes;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            op <= 0;
            m <= 0;
            k <= 0;
            n <= 0;
            lane_count <= 0;
            xb <= 0;
            wb <= 0;
            yb <= 0;
            xs <= 0;
            ys <= 0;
            first_error <= 0;
            first_error_addr <= 0;
            drain_cycles <= 0;
        end else if (fault) begin
            state <= DRAIN;
            first_error <= rd_ret_err ? 4'd1 : wr_ret_err ? 4'd2 : bad_param ? 4'd7 : 4'd5;
            first_error_addr <= (rd_ret_err || bad_param) ? rd_ret_addr :
                                 wr_ret_err ? wr_ret_addr : 32'b0;
            drain_cycles <= 3'd5;
        end else begin
            case (state)
                IDLE: if (start) begin
                    state <= CHECK;
                    op <= opcode;
                    m <= dim_m;
                    k <= dim_k;
                    n <= dim_n;
                    lane_count <= dim_k[6:0];
                    xb <= x_base;
                    wb <= w_base;
                    yb <= y_base;
                    xs <= x_stride;
                    ys <= y_stride;
                end
                CHECK: state <= check_fail ? IDLE : XLOAD;
                XLOAD: if (x_finished) state <= COMPUTE;
                COMPUTE: if (done_event) state <= IDLE;
                DRAIN: begin
                    if (drain_cycles != 0) drain_cycles <= drain_cycles - 1'b1;
                    if (drain_done) state <= IDLE;
                end
                default: state <= IDLE;
            endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_row <= 0;
            x_pair <= 0;
            x_row_base <= 0;
            x_next_addr <= 0;
            x_all_sent <= 0;
        end else if (state == CHECK) begin
            x_row <= 0;
            x_pair <= 0;
            x_row_base <= xb;
            x_next_addr <= xb;
            x_all_sent <= 0;
        end else if (x_request && rd_fire) begin
            if (x_pair == last_x_pair) begin
                x_pair <= 0;
                x_row <= x_row + 1'b1;
                x_row_base <= x_row_base + xs;
                x_next_addr <= x_row_base + xs;
                if (x_row == last_row) x_all_sent <= 1;
            end else begin
                x_pair <= x_pair + 1'b1;
                x_next_addr <= x_next_addr + 32'd4;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            group_busy <= 0;
            group_full <= 0;
            w_active <= 0;
            w_word <= 0;
            w_block <= 0;
            w_next_addr <= 0;
        end else if (state == CHECK) begin
            group_busy <= 0;
            group_full <= 0;
            w_active <= 0;
            w_word <= 0;
            w_block <= 0;
            w_next_addr <= wb;
        end else if (activity) begin
            if (reserve_group) begin
                w_active <= 1;
                group_busy[w_block[0]] <= 1;
            end
            if (rd_fire && !x_request) begin
                w_next_addr <= w_next_addr + 32'd4;
                if (w_word == weight_last_word) begin
                    w_active <= 0;
                    w_word <= 0;
                    w_block <= w_block + 1'b1;
                end else begin
                    w_word <= w_word + 1'b1;
                end
            end
            if (w_write && rd_ret_tag[6:0] == weight_last_word)
                group_full[rd_ret_tag[14]] <= 1;
            if (release_group) begin
                group_full[set_c1] <= 0;
                group_busy[set_c1] <= 0;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            compute_row <= 0;
            compute_block <= 0;
            valid_c0 <= 0;
            valid_c1 <= 0;
            set_c0 <= 0;
            set_c1 <= 0;
            last_c0 <= 0;
            last_c1 <= 0;
            reserved_words <= 0;
        end else if (!computing || fault) begin
            compute_row <= 0;
            compute_block <= 0;
            valid_c0 <= 0;
            valid_c1 <= 0;
            reserved_words <= 0;
        end else begin
            valid_c0 <= row_issue;
            valid_c1 <= valid_c0;
            set_c0 <= compute_block[0];
            set_c1 <= set_c0;
            last_c0 <= compute_row == last_row;
            last_c1 <= last_c0;
            if (row_issue) begin
                if (compute_row == last_row) begin
                    compute_row <= 0;
                    compute_block <= compute_block + 1'b1;
                end else begin
                    compute_row <= compute_row + 1'b1;
                end
            end
            case ({row_issue, fifo_pop})
                2'b10: reserved_words <= reserved_words + 1'b1;
                2'b01: reserved_words <= reserved_words - 1'b1;
                default: reserved_words <= reserved_words;
            endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            write_row <= 0;
            write_block_base <= 0;
            wr_req_addr <= 0;
            responses <= 0;
        end else if (state == CHECK) begin
            write_row <= 0;
            write_block_base <= yb;
            wr_req_addr <= yb;
            responses <= 0;
        end else if (computing && !fault) begin
            if (wr_ret_valid) responses <= responses + 1'b1;
            if (fifo_pop) begin
                if (write_row == last_row) begin
                    write_row <= 0;
                    write_block_base <= write_block_base + 32'd4;
                    wr_req_addr <= write_block_base + 32'd4;
                end else begin
                    write_row <= write_row + 1'b1;
                    wr_req_addr <= wr_req_addr + ys;
                end
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cycle_now <= 0;
            task_count <= 0;
        end else begin
            cycle_now <= cycle_now + 1'b1;
            if (done_event) task_count <= task_count + 1'b1;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            perf_total <= 0;
            perf_xload <= 0;
            perf_issue <= 0;
            perf_rd_stall <= 0;
            perf_wr_stall <= 0;
            perf_rd_words <= 0;
            perf_wr_words <= 0;
            perf_starve <= 0;
            sat_count <= 0;
        end else if (state == IDLE && (start || clr_perf)) begin
            perf_total <= 0;
            perf_xload <= 0;
            perf_issue <= 0;
            perf_rd_stall <= 0;
            perf_wr_stall <= 0;
            perf_rd_words <= 0;
            perf_wr_words <= 0;
            perf_starve <= 0;
            sat_count <= 0;
        end else if (busy) begin
            perf_total <= perf_total + 1'b1;
            if (state == XLOAD) perf_xload <= perf_xload + 1'b1;
            if (row_issue) perf_issue <= perf_issue + 1'b1;
            if (rd_cmd_stall) perf_rd_stall <= perf_rd_stall + 1'b1;
            if (wr_cmd_stall) perf_wr_stall <= perf_wr_stall + 1'b1;
            if (rd_cmd_fire) perf_rd_words <= perf_rd_words_inc;
            if (wr_cmd_fire) perf_wr_words <= perf_wr_words + 1'b1;
            if (computing && compute_block < pairs && !row_issue)
                perf_starve <= perf_starve + 1'b1;
            if (fifo_push) sat_count <= sat_count + {31'b0, mac_sat[0]} + {31'b0, mac_sat[1]};
        end
    end
endmodule

`default_nettype wire
