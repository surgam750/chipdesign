"""Seven-corner native averaged power driven by twelve fresh VCS RTL task SAIFs."""
from collections import Counter, defaultdict
import csv
import importlib.util
import math
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CORNERS = ('TT5', 'FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT6')
LABEL = 'RTL_ACTIVITY_MAPPED_POWER_ESTIMATE'
KEYS = ('internal_W', 'switching_W', 'leakage_W', 'total_W')
# Keep in step with native/driver.py: the ITCM now uses 1024 RAMSP128X16
# slices (8 banks x 32 rows x 4 bit groups) plus 64 accelerator slices.
MACROS = {'RAMSP128X16': 1088, 'RAMSP4096X16': 64, 'RAMSP8KX32': 8}
FILES = ('activity_defaults.rpt', 'read_saif_help.rpt', 'read_saif.rpt', 'units.rpt', 'clocks.rpt',
         'check_power.rpt', 'switching_before_power.rpt', 'switching_activity.rpt',
         'switching_not_annotated.rpt', 'power_total.rpt', 'power_hierarchy.rpt', 'load_reference.rpt',
         'design.tsv', 'macros.tsv', 'macro_pins.tsv', 'sources.tsv', 'rtl_witness.tsv',
         'tool.log', 'config.tcl', 'invocation.json')
NUMBER = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'
UNITS = {'W': 1, 'Watt': 1, 'Watts': 1, 'mW': 1e-3, 'uW': 1e-6, 'nW': 1e-9, 'pW': 1e-12}


def local_module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


activity = local_module(HERE/'activity.py', 'rtl3307_activity_reader')
native = local_module(ROOT/'native/driver.py', 'rtl3307_power_native')
sha, check, save, load = activity.sha, activity.check, native.save, native.load


def table(path):
    with path.open(encoding='utf-8') as stream:
        return list(csv.DictReader(stream, delimiter='\t'))


def close(a, b, rel=.002):
    return abs(a-b) <= max(1e-12, rel*max(abs(a), abs(b)))


def power_values(raw, leaf=False, rel=.002):
    values = list(map(float, raw))
    check(len(values) == 4 and all(math.isfinite(x) for x in values) and min(values[1:3]) >= 0,
          'Unknown, nonfinite or negative switching/leakage power')
    check(values[3] >= 0 or (leaf and values[0] < 0), 'Negative design power or unexplained negative leaf')
    check(close(sum(values[:3]), values[3], rel), 'Power components differ from the native total')
    return dict(zip(KEYS, values))


def energy_uj(watts, picoseconds):
    return watts * picoseconds / 1e6


def native_power(text):
    labels = ('Cell Internal Power', 'Net Switching Power', 'Cell Leakage Power', 'Total Power')
    declared = re.findall(r'^\s*Power\s+[Uu]nits?\s*[:=]\s*([^\r\n]+)', text, re.M)
    check(len(declared) <= 1, 'Ambiguous native power units')
    scale = 1.
    if declared:
        m = re.fullmatch(r'\s*('+NUMBER+r')?\s*([A-Za-z]+)\s*', declared[0])
        check(m and m[2] in UNITS, 'Unknown native report power unit')
        scale = float(m[1] or 1) * UNITS[m[2]]
        check(math.isfinite(scale) and scale > 0, 'Invalid report scale')
    result = []
    for label in labels:
        hits = re.findall(r'^\s*'+label+r'\s*=\s*([^\r\n]+)', text, re.M)
        # Some PT-PX versions emit grouped columns rather than the scalar summary.
        # Keep that native table for review; do not guess the column units or order.
        if not hits and not result and not any(re.search(r'^\s*'+name+r'\s*=', text, re.M) for name in labels):
            check(re.search(r'Power\s+Group', text, re.I) and re.search(r'^\s*Total\s+', text, re.M),
                  'No recognizable PT-PX total report')
            return None
        check(len(hits) == 1, 'Missing or ambiguous native summary for ' + label)
        m = re.fullmatch(r'\s*('+NUMBER+r')\s*([A-Za-z]+)?\s*(?:\([^)]*\))?\s*', hits[0])
        check(m and (not m[2] or m[2] in UNITS), 'Unknown native scalar power value/unit')
        result.append(float(m[1])*(UNITS[m[2]] if m[2] else scale))
    # report_power prints every value with three significant digits and ignores
    # report_default_significant_digits, so a total of 0.0366 next to components
    # summing to 0.03652478 is already 0.21% apart from rounding alone. Comparing
    # text-parsed values therefore needs a whole-quantum tolerance (1%); the
    # full-precision TSV tables keep the tighter 0.2%.
    return power_values(result, rel=.01)


def lib_groups(text, keyword, cell=None):
    header = r'\b'+keyword+r'\s*\(\s*'+(r'"?'+re.escape(cell)+r'"?\s*' if cell else r'[^()]*')+r'\)\s*\{'
    for start in re.finditer(header, text):
        level = 1
        for token in re.finditer(r'"(?:\\.|[^"\\])*"|[{}]', text[start.end():]):
            if token[0] == '{':
                level += 1
            elif token[0] == '}':
                level -= 1
                if level == 0:
                    yield text[start.end():start.end()+token.start()]
                    break
        else:
            raise ValueError('Unbalanced Liberty block ' + keyword)


def model_evidence(text, cell):
    text = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', text)
    cells = list(lib_groups(text, 'cell', cell))
    check(len(cells) == 1, 'Cannot identify one original Liberty cell ' + cell)
    body = cells[0]
    internal = list(lib_groups(body, 'internal_power'))
    nz = False
    for group in internal:
        for data in re.finditer(r'\bvalues\s*\(([\s\S]*?)\)\s*;', group):
            if any(float(v) != 0 and math.isfinite(float(v)) for v in re.findall(NUMBER, data[1])):
                nz = True
                break
        if nz:
            break
    leaks = re.findall(r'\bcell_leakage_power\s*:\s*('+NUMBER+r')\s*;', body)
    for group in lib_groups(body, 'leakage_power'):
        leaks.extend(re.findall(r'\bvalue\s*:\s*('+NUMBER+r')\s*;', group))
    return {'internal_groups': len(internal), 'nonzero_internal_model': nz,
            'leakage_values': len(leaks), 'nonzero_leakage_model': any(float(v)>0 and math.isfinite(float(v)) for v in leaks),
            'scope': 'Presence of nonzero cell-local tables/scalars; mode and conditional arc completeness requires review'}


def model_data(resolved, corner):
    output = {}
    for ref, row in resolved['macro_source_resolution'][corner].items():
        path = Path(row['selected_original'])
        check(path.suffix == '.lib' and sha(path) == row['sha256'], 'Power requires the original hashed SRAM Liberty')
        view = model_evidence(path.read_text(errors='replace'), ref)
        view.update(original_sha256=row['sha256'], db_sha256=resolved['library_hashes'][resolved['corners'][corner]['macros'][ref]])
        output[ref] = view
    check(set(output) == set(MACROS), 'Missing SRAM model family')
    return output


def assess(folder, expected, models, window):
    rows = table(folder/'design.tsv')
    check(len(rows) == 1, 'Expected one native design power row')
    try:
        total = power_values(rows[0][key] for key in KEYS)
    except ValueError as error:
        raise ValueError('%s: %s' % (folder, error))
    issues = []
    reported = native_power((folder/'power_total.rpt').read_text(errors='replace'))
    if reported is None:
        issues.append('GROUPED_NATIVE_REPORT_FORMAT_REVIEW')
    else:
        # Same three-significant-digit quantisation as above.
        check(all(close(total[key], reported[key], .01) for key in KEYS),
              'Native power report disagrees with design attributes in W: ' + str(folder))
    if total['total_W'] == 0 or total['internal_W'] <= 0:
        issues.append('DESIGN_ZERO_TOTAL_OR_NONPOSITIVE_INTERNAL')
    raw_witness = table(folder/'rtl_witness.tsv')
    witnesses = {r['port']: r for r in raw_witness}
    check(len(raw_witness) == 2 and set(witnesses) == set(window['sentinels']), 'Native RTL witness inventory mismatch')
    # Direct annotation of a known switching data input is required; a clock-only or vectorless job cannot qualify.
    data_witness = witnesses['kwt_load_icb_cmd_valid']
    check(data_witness['source'].lower() == 'file' and window['sentinels']['kwt_load_icb_cmd_valid']['TC'] > 0,
          'No direct task-SAIF annotation on the switching loader command port')
    for name, row in witnesses.items():
        if row['toggle_rate'] == 'UNKNOWN':
            issues.append('MAPPED_TOGGLE_RATE_UNAVAILABLE:'+name)
        elif not (math.isfinite(float(row['toggle_rate'])) and float(row['toggle_rate']) > 0):
            raise ValueError('No positive mapped witness toggles on ' + name)
    source_counts = defaultdict(dict)
    for r in table(folder/'sources.tsv'):
        category, source, n = r['category'], r['source'], int(r['count'])
        check(category in ('hierarchical_net', 'register_output') and n > 0 and source and source not in source_counts[category],
              'Missing, duplicate or invalid activity source count')
        source_counts[category][source] = n
    check(set(source_counts) == {'hierarchical_net','register_output'}, 'Missing activity denominators')
    for category, counts in source_counts.items():
        if sum(counts.values()) != counts.get('file', 0):
            issues.append('PARTIAL_DIRECT_ACTIVITY:'+category)
    macro_rows = table(folder/'macros.tsv')
    macro_names, pin_counts = {}, {}
    classes = defaultdict(lambda: dict.fromkeys(KEYS, 0.))
    incomplete_classes = set()
    for r in macro_rows:
        name, ref = r['instance'], r['reference']
        check(name not in macro_names and expected.get(name) == ref and r['lib_cell'].split('/')[-1] == ref,
              'Wrong, duplicate or unresolved SRAM binding: '+name)
        macro_names[name], pin_counts[name] = ref, int(r['pin_count'])
        try:
            watts = power_values((r[key] for key in KEYS), leaf=True)
        except ValueError:
            issues.append('SRAM_COMPONENT_UNKNOWN_OR_INCONSISTENT:'+ref)
            incomplete_classes.add(ref)
            continue
        for key in KEYS:
            classes[ref][key] += watts[key]
        if watts['total_W'] == 0:
            issues.append('SRAM_INSTANCE_ZERO_TOTAL:'+ref)
    check(macro_names == expected and dict(Counter(expected.values())) == MACROS, 'Power SRAM inventory differs from native area')
    seen_pins = set()
    counts = Counter()
    families = defaultdict(lambda: defaultdict(Counter))
    rates = defaultdict(Counter)
    for r in table(folder/'macro_pins.tsv'):
        name, pin, source = r['instance'], r['pin'], r['source']
        check(name in expected and pin.startswith(name+'/') and pin not in seen_pins and source, 'Unknown or duplicate SRAM pin')
        seen_pins.add(pin)
        counts[name] += 1
        family = re.sub(r'\[.*$', '', pin[len(name)+1:])
        families[expected[name]][family][source] += 1
        value = r['toggle_rate']
        if value == 'UNKNOWN':
            rates[expected[name]]['rate_unavailable'] += 1
        else:
            value = float(value)
            check(math.isfinite(value) and value >= 0, 'Invalid SRAM pin toggle rate')
            rates[expected[name]]['active' if value > 0 else 'zero'] += 1
    check(dict(counts) == pin_counts and all(n>0 for n in counts.values()), 'SRAM pin activity denominator mismatch')
    for ref, model in models.items():
        if not model['nonzero_internal_model'] or not model['nonzero_leakage_model']:
            issues.append('SRAM_NONZERO_INTERNAL_OR_LEAKAGE_MODEL_UNCONFIRMED:'+ref)
        if ref in incomplete_classes:
            classes[ref] = dict.fromkeys(KEYS)
        elif classes[ref]['internal_W'] <= 0 or classes[ref]['leakage_W'] <= 0:
            issues.append('SRAM_CLASS_NONPOSITIVE_INTERNAL_OR_LEAKAGE:'+ref)
        if not {'CLK','CEN','GWEN','WEN','A','D','Q'}.issubset(families[ref]):
            issues.append('SRAM_BOUNDARY_PIN_FAMILY_REVIEW:'+ref)
        if any(sum(c.values()) != c.get('file', 0) for c in families[ref].values()):
            issues.append('SRAM_BOUNDARY_PARTIAL_DIRECT_ACTIVITY:'+ref)
    check_text = (folder/'check_power.rpt').read_text(errors='replace')
    if re.search(r'\bwarning\b|no.{0,24}power.{0,25}(table|model|information)|missing.{0,50}power', check_text, re.I):
        issues.append('NATIVE_CHECK_POWER_REVIEW')
    return {'task':window['task'], 'duration_ps':window['duration_ps'], 'cycles':window['cycles'],
            'saif_sha256':window['sha256'], 'power_W':total, 'energy_uJ':energy_uj(total['total_W'],window['duration_ps']),
            'macro_classes_W':dict(classes), 'mapped_RTL_witnesses':witnesses,
            'activity_source_counts':dict(source_counts), 'macro_pin_sources':dict(families), 'macro_pin_toggle_counts':dict(rates),
            'issues':sorted(set(issues)), 'model_coverage':'LIMITED_OR_REVIEW_REQUIRED' if issues else 'ENUMERATED_CHECKS_COMPLETE',
            'native_reports':str(folder)}


def preflight(config=None):
    checks = [HERE/'activity.py', HERE/'driver.py', HERE/'task_activity.sv', HERE/'estimate.tcl', ROOT/'native/common.tcl']
    result = {str(p.relative_to(ROOT)):sha(p) for p in checks}
    if config is not None:
        check(set(config['corners']) == set(CORNERS) and Path(config['tools']['PT']).is_file(), 'Seven corners and native PT required')
    return {'status':'POWER_PREFLIGHT_INPUTS_ONLY', 'files':result, 'corners':list(CORNERS), 'native_jobs':84}


def context(config):
    preflight(config)
    metrics = native.results(config)
    out = Path(config['out'])
    resolved = load(out/'resolved_config.json')
    work = Path(resolved['overlay'])
    report = work.parents[1]/'reports'
    functional = load(report/'state.json')
    check(work.resolve() == (ROOT/'work/soc').resolve() and
          functional['status'] == 'SERVER_SYSTEMBUS_FUNCTIONAL_RTL_PASS' and metrics['candidate_id'] == 'RTL3307_TCM128_GLOBSLEW025_V1',
          'Task SAIF and new mapped design must come from this fresh functional run')
    windows = activity.verified(report, work, functional['activity_manifest_sha256'])
    files = [out/'prepared.json', out/'resolved_config.json', out/'metrics.json', out/'receipts.json', out/'state.json',
             out/'dc_soc/design.v', out/'sysbus.sdc', report/'state.json', report/'activity/manifest.json',
             report/'simulation.log', report/'compile.log', report/'compile_command.json', report/'simulation_command.json',
             work/'simv', HERE/'driver.py', HERE/'activity.py', HERE/'estimate.tcl', HERE/'task_activity.sv',
             ROOT/'native/common.tcl', ROOT/'native/driver.py', ROOT/'server/rtl_driver.py', Path(resolved['tools']['PT'])]
    snap = {str(p):sha(p) for p in files}
    snap.update(resolved['library_hashes'])
    for row in windows['windows']:
        snap[str(work/row['file'])] = row['sha256']
    check(snap[str(out/'dc_soc/design.v')] == metrics['netlist_sha256'] and sha(work/'simv') == functional['simv_sha256'],
          'Power netlist or simulated RTL executable mismatch')
    return resolved, windows['windows'], snap, metrics.get('replaced_tool_files') or {}


def expected_macros(out, corner):
    result = {}
    for r in table(out/'sta'/corner/'cells.tsv'):
        if r['reference'] in MACROS:
            check(r['instance'] not in result, 'Duplicate mapped SRAM in native area')
            result[r['instance']] = r['reference']
    check(dict(Counter(result.values())) == MACROS, 'Incomplete macro STA inventory versus native area')
    return result


def invocation(resolved, corner, window, folder):
    cfg = native.values(resolved, corner, 'soc')
    cfg.update(saif=str(Path(resolved['overlay'])/window['file']), strip_path=window['strip_path'], task=window['task'])
    check(len(set(cfg['libraries'])) == 5 and cfg['netlist'] == str(Path(resolved['out'])/'dc_soc/design.v'),
          'Power requires new synthesized netlist and five libraries for this corner')
    script = 'set cfg %s\n' % native.tcl(cfg)
    cmd = [resolved['tools']['PT'], '-f', str(HERE/'estimate.tcl')]
    used = cfg['libraries']+[cfg['saif'], cfg['netlist'], cfg['sdc'], cmd[0], cmd[2], str(ROOT/'native/common.tcl')]
    record = dict(command=cmd, cwd=str(folder), KWT_NATIVE_CONFIG=str(folder/'config.tcl'),
                  inputs={p:sha(p) for p in used}, corner=corner, task=window['task'],
                  saif_scope=cfg['strip_path'], duration_ps=window['duration_ps'])
    check(record['inputs'][cfg['saif']] == window['sha256'], 'Task SAIF changed before invocation')
    return script, record


def invoke(resolved, corner, window, folder, timeout):
    folder.mkdir(parents=True, exist_ok=False)
    script, call = invocation(resolved,corner,window,folder)
    (folder/'config.tcl').write_bytes(script.encode('utf-8'))
    save(folder/'invocation.json',call)
    env = os.environ.copy()
    env['KWT_NATIVE_CONFIG'] = call['KWT_NATIVE_CONFIG']
    print('POWER_RUNNING %s task=%02d/11 %s' % (corner,window['task'],folder),flush=True)
    with (folder/'tool.log').open('w') as stream:
        try:
            proc = subprocess.run(call['command'], cwd=str(folder), env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
        except subprocess.TimeoutExpired:
            raise RuntimeError('Task power timed out, see '+str(folder/'tool.log'))
    if proc.returncode:
        print(native.log_tail(folder/'tool.log'),flush=True)
        raise ValueError('PT-PX tool exit=%d: %s' % (proc.returncode, folder/'tool.log'))
    check(script.encode('utf-8') == (folder/'config.tcl').read_bytes() and load(folder/'invocation.json') == call,
          'Power Tcl config or invocation changed')
    native.verify_snapshot(call['inputs'])


def receipt(folder, corner, task):
    output = {name:sha(native.checked(folder/name)) for name in FILES}
    for name in FILES:
        if name.endswith(('.rpt','.log')):
            check(not native.ERROR.search((folder/name).read_text(errors='replace')), 'Native power error: '+str(folder/name))
    log = (folder/'tool.log').read_text(errors='replace')
    check(len(re.findall(r'^NATIVE_TOOL_DONE\s*$',log,re.M)) == 1 and
          len(re.findall(r'^RTL3307_TASK_POWER '+corner+' '+str(task)+r'\s*$',log,re.M)) == 1,
          'Power stage completion marker/corner/task mismatch: '+str(folder))
    return output


def corner_summary(jobs, models):
    check([j['task'] for j in jobs] == list(range(12)), 'Expected all ordered task power jobs')
    duration = sum(j['duration_ps'] for j in jobs)
    aggregate = {k:sum(j['power_W'][k]*j['duration_ps'] for j in jobs)/duration for k in KEYS}
    energy = sum(j['energy_uJ'] for j in jobs)
    return {'windows':jobs, 'models':models, 'task_time_ps':duration, 'duration_weighted_power_W':aggregate,
            'summed_task_energy_uJ':energy, 'mean_task_energy_uJ':energy/12,
            'issues':sorted({issue for j in jobs for issue in j['issues']})}


def workers():
    """Parallel PT-PX invocations from the environment; 1 keeps the serial behaviour."""
    raw = os.environ.get('RTL3307_WORKERS', '1')
    try:
        count = int(raw)
    except (TypeError, ValueError):
        raise ValueError('Invalid RTL3307_WORKERS: ' + str(raw))
    check(count > 0, 'RTL3307_WORKERS must be positive')
    return count


def evaluate(resolved, windows, parents, timeout=None, previous=None):
    out = Path(resolved['out'])
    work = out/'power'
    corners, receipts = {}, {}
    for corner in CORNERS:
        expected, models = expected_macros(out,corner), model_data(resolved,corner)
        jobs = []
        folders = [(window, work/('%s/task_%02d' % (corner,window['task']))) for window in windows]
        if timeout is not None:
            count = min(workers(), len(folders))
            if count <= 1:
                for window, folder in folders:
                    invoke(resolved,corner,window,folder,timeout)
            else:
                from concurrent.futures import ThreadPoolExecutor
                print('POWER_PARALLEL %s tasks with %d workers' % (corner,count),flush=True)
                with ThreadPoolExecutor(max_workers=count) as pool:
                    pending = [pool.submit(invoke,resolved,corner,window,folder,timeout)
                               for window,folder in folders]
                    for future in pending:
                        future.result()
        for window, folder in folders:
            key = '%s/task_%02d' % (corner,window['task'])
            files = receipt(folder,corner,window['task'])
            cfg, call = invocation(resolved,corner,window,folder)
            check((folder/'config.tcl').read_bytes() == cfg.encode('utf-8') and load(folder/'invocation.json') == call and
                  all(parents.get(k) == v for k,v in call['inputs'].items()), 'Power invocation/input differs from sealed current parents')
            if previous is not None:
                check(previous.get(key) == files, 'Changed task power reports: '+key)
            receipts[key] = files
            jobs.append(assess(folder,expected,models,window))
            if timeout is not None:
                save(work/'state.json',{'status':'POWER_RUNNING','finished_jobs':len(receipts),'last':key})
        corners[corner] = corner_summary(jobs,models)
    if previous is not None:
        check(set(receipts) == set(previous), 'Invalid task power receipt inventory')
    return {'status':LABEL,'corners':corners,'jobs':len(receipts),'model_coverage_review_required':True,
            'GLS_performed':False,'signoff_achieved':False,'netlist_sha256':parents[str(out/'dc_soc/design.v')],
            'scope':'Functional-RTL task SAIF on mapped logic; native inferred/default activity is enumerated. '
                    'Physicalized TCM bank paths differ from behavioral RTL. Per-pin source data is retained. '
                    'Averaged pre-layout estimate with library models. No gate glitches, delay back-annotation, CTS or routed parasitics.',
            'power_groups':'Native power_hierarchy.rpt, four macro family totals and the native design total per task.'}, receipts


def run(config, timeout=7200):
    check(timeout > 0, 'Positive power timeout required')
    resolved, windows, parents, replaced = context(config)
    work = Path(resolved['out'])/'power'
    work.mkdir(exist_ok=False)
    save(work/'state.json',{'status':'POWER_RUNNING','finished_jobs':0})
    try:
        summary, receipts = evaluate(resolved,windows,parents,timeout)
        native.verify_snapshot(parents)
        if replaced:
            summary['replaced_tool_files'] = replaced
        save(work/'receipt.json',{'inputs':parents,'stages':receipts})
        save(work/'metrics.json',summary)
        save(work/'state.json',{'status':LABEL,'finished_jobs':84,'receipt_sha256':sha(work/'receipt.json'),
                                'metrics_sha256':sha(work/'metrics.json')})
        return summary
    except BaseException as error:
        state = load(work/'state.json')
        state.update(status='POWER_INCOMPLETE',error=str(error)[:2400])
        save(work/'state.json',state)
        raise


def results(config):
    resolved, windows, parents, replaced = context(config)
    work = Path(resolved['out'])/'power'
    state = load(work/'state.json')
    check(state['status'] == LABEL and state['finished_jobs'] == 84 and sha(work/'metrics.json') == state['metrics_sha256'] and
          sha(work/'receipt.json') == state['receipt_sha256'], 'Incomplete or changed power metrics/receipt')
    receipt_data = load(work/'receipt.json')
    check(receipt_data['inputs'] == parents, 'Power inputs differ from the sealed design/activity run')
    derived, _ = evaluate(resolved,windows,parents,previous=receipt_data['stages'])
    if replaced:
        derived['replaced_tool_files'] = replaced
    check(derived == load(work/'metrics.json'),'Power summary differs from native reports')
    return derived

