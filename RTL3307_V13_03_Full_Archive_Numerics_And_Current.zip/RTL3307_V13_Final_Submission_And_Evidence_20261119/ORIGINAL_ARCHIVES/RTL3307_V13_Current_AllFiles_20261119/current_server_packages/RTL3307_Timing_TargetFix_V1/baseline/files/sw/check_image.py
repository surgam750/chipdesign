"""Check the byte image and fixed E203 TB entry/completion layout."""
import hashlib
import re
import sys
from pathlib import Path


def check(image, dump):
    raw = image.read_bytes()
    tokens = raw.decode("ascii").split()
    if not tokens or tokens[0].lower() != "@00000000":
        raise ValueError("expected a byte-addressed image starting at offset zero")
    data = {}
    pos = None
    for token in tokens:
        if re.fullmatch(r"@[a-fA-F0-9]{8}", token):
            pos = int(token[1:], 16)
        elif re.fullmatch(r"[a-fA-F0-9]{2}", token):
            if pos is None or not 0 <= pos < 0x8000 or pos in data:
                raise ValueError("image writes outside the ITCM firmware slot or repeats an address")
            data[pos] = int(token, 16)
            pos += 1
        else:
            raise ValueError(f"invalid byte image token {token!r}")
    prefix = bytes(data[i] for i in range(0x104))
    if prefix[:4] != bytes.fromhex("6f000010"):  # jal x0, +0x100
        raise ValueError("reset entry does not jump to the body")
    if prefix[0x86:0x88] != bytes.fromhex("01a0"):  # c.j +0
        raise ValueError("TB completion PC is missing its self-loop")
    if any(prefix[4:0x86]) or any(prefix[0x88:0x100]):
        raise ValueError("unexpected bytes in boot-header padding")
    listing = dump.read_text(encoding="ascii")
    for address, symbol in (("80000000", "_start"), ("80000086", "kwt_end"),
                            ("80000100", "boot"), ("90000f00", "__stack_top")):
        if not re.search(rf"^{address}\s+.*\b{symbol}$", listing, re.M):
            raise ValueError(f"missing linker symbol {symbol} at {address}")
    print(f"IMAGE_PASS {image.name} bytes={len(data)} sha256={hashlib.sha256(raw).hexdigest()}")


if __name__ == "__main__":
    check(Path(sys.argv[1]), Path(sys.argv[2]))
