"""Build a fresh checked E203 overlay with one original System Bus outlet."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT.parent / 'server_handover_20261102/reports/irq_fetch_public/e203'
FROZEN = ROOT.parent / 'optimization_20261110/server/release_compare_final/contents/candidates/w12'
SUBSYS = 'rtl/e203/subsys/'
PERIPS, MAIN, TOP, PLIC = [SUBSYS + name + '.v' for name in
                         ('e203_subsys_perips', 'e203_subsys_main', 'e203_subsys_top', 'e203_subsys_plic')]
PLIC_TOP = 'rtl/e203/perips/sirv_plic_top.v'
SOC = 'rtl/e203/soc/e203_soc_top.v'
TB = 'tb/tb_top.v'
MEMS = SUBSYS + 'e203_subsys_mems.v'
CONFIG = 'rtl/e203/core/config.v'
ICB = [('cmd_valid', '', 'output'), ('cmd_ready', '', 'input'),
       ('cmd_addr', '[31:0]', 'output'), ('cmd_read', '', 'output'),
       ('cmd_wdata', '[31:0]', 'output'), ('cmd_wmask', '[3:0]', 'output'),
       ('rsp_valid', '', 'input'), ('rsp_ready', '', 'output'),
       ('rsp_rdata', '[31:0]', 'input'), ('rsp_err', '', 'input')]
CLOCK_IRQ = (('kwt_clk', 'output'), ('kwt_rst_n', 'output'), ('ai_irq', 'input'))

def sha(data):
    return hashlib.sha256(data).hexdigest()


def functional_clockgate_view(dst):
    """Copy the official SMIC view, selecting only its reviewed clockgate latch.

    The original RTL stays available for native synthesis. Unknown wrapper
    shapes fail closed; the public snapshot without this file stays unchanged.
    """
    original_rel = 'rtl/e203/generic/GENERIC_RVT_SMIC.v'
    generated_rel = 'tb/kwt/GENERIC_RVT_SMIC_functional.v'
    source = dst / original_rel
    if not source.exists():
        return None
    original = source.read_bytes()
    private = b'KWT_SYSBUS_CLOCKGATE_LATCH'
    if private in original:
        raise ValueError('clockgate private selector already present')
    matches = list(re.finditer(
        rb'(?m)^[ \t]*module\s+GENERIC_CLOCKGATE_RVT\b[\s\S]*?\bendmodule\b', original))
    if len(matches) != 1:
        raise ValueError('expected exactly one SMIC clockgate wrapper')
    match = matches[0]
    block = match[0]
    expected = b'''module GENERIC_CLOCKGATE_RVT (ECK, E, SE, CK);
output ECK; input E, SE, CK;
`ifdef FPGA
reg latch_out;
always @(CK or E or SE) begin
if(!CK) begin latch_out = E | SE; end
end
assign ECK = latch_out & CK;
`else
CLKLANAQV4_8TR40 u_donttouch_CLOCKGATE(.Q(ECK),.E(E),.TE(SE),.CK(CK));
`endif
endmodule'''
    def compact(data):
        data = re.sub(rb'/\*[\s\S]*?\*/|//[^\r\n]*', b'', data)
        return re.sub(rb'\s+', b'', data)
    if compact(block) != compact(expected):
        raise ValueError('unreviewed SMIC clockgate wrapper/branch/technology cell')
    newline = b'\r\n' if b'\r\n' in original else b'\n'
    selector = newline.join([
        b'`ifdef KWT_SRAM_BEHAV', b'`define ' + private,
        b'`elsif FPGA', b'`define ' + private, b'`endif', b'`ifdef ' + private])
    replacement, count = re.subn(rb'(?m)^[ \t]*`ifdef[ \t]+FPGA[ \t]*\r?$', selector, block)
    if count != 1:
        raise ValueError('expected one line-isolated original FPGA selector')
    replacement = replacement.replace(b'endmodule', b'`undef ' + private + newline + b'endmodule')
    generated = original[:match.start()] + replacement + original[match.end():]
    target = dst / generated_rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(generated)
    return {'original': original_rel, 'generated': generated_rel,
            'original_sha256': sha(original), 'generated_sha256': sha(generated),
            'selector': 'KWT_SRAM_BEHAV',
            'scope': 'functional clockgate latch selection only; original RTL preserved'}

FUNCTIONAL_MEMORIES = (
    ('rtl/e203/core/e203_itcm_ram.v', 'e203_itcm_ram', 'sirv_gnrl_ram', 'u_e203_itcm_gnrl_ram'),
    ('rtl/e203/core/e203_dtcm_ram.v', 'e203_dtcm_ram', 'sirv_gnrl_ram', 'u_e203_dtcm_gnrl_ram'),
    ('rtl/e203/mems/sirv_mrom_top.v', 'sirv_mrom_top', 'sirv_mrom', 'u_sirv_mrom'),
)


def functional_memory_views(dst, official=False):
    """Retarget original FPGA memory selectors in isolated functional copies.

    Neither branch body nor any native source is edited. Verified unconditional
    logic wrappers are a no-op in either source; physical/unknown shapes fail closed.
    The official argument remains for caller compatibility.
    """
    prepared = []
    for original_rel, module, child, instance in FUNCTIONAL_MEMORIES:
        original = (dst / original_rel).read_bytes()
        # Ignore comments only for locating/validating structure; edit raw bytes.
        clean = re.sub(rb'/\*[\s\S]*?\*/|//[^\r\n]*',
                       lambda m: re.sub(rb'[^\r\n]', b' ', m[0]), original)
        modules = list(re.finditer(rb'\bmodule\s+' + module.encode() +
                                  rb'\b[\s\S]*?\bendmodule\b', clean))
        if len(modules) != 1:
            raise ValueError('expected one memory wrapper: ' + original_rel)
        block = modules[0]
        private = ('KWT_SYSBUS_' + module.upper() + '_LOGIC').encode()
        if private in original:
            raise ValueError('memory private selector already present: ' + original_rel)
        selectors = list(re.finditer(rb'(?m)^[ \t]*`(ifdef|ifndef)[ \t]+FPGA[ \t]*\r?$', block[0]))
        instance_pattern = rb'\b' + child.encode() + rb'\s*#\s*\([\s\S]*?\)\s*' + instance.encode() + rb'\s*\('
        if not selectors:
            if re.search(rb'`(?:ifdef|ifndef|elsif)\s+FPGA\b|\b(?:ROM1KX32|RAMSP\w*)\b', clean):
                raise ValueError('missing reviewed FPGA memory selector: ' + original_rel)
            if len(re.findall(instance_pattern, block[0])) != 1:
                raise ValueError('missing unconditional public memory instance: ' + original_rel)
            continue
        if len(selectors) != 1:
            raise ValueError('expected one FPGA memory selector: ' + original_rel)
        selector = selectors[0]
        depth, alternate, closing = 0, None, None
        for directive in re.finditer(rb'(?m)^[ \t]*`(ifdef|ifndef|else|elsif|endif)\b[^\r\n]*', block[0][selector.end():]):
            start, end = selector.end() + directive.start(), selector.end() + directive.end()
            kind = directive[1]
            if kind in (b'ifdef', b'ifndef'):
                depth += 1
            elif kind == b'endif':
                if depth == 0:
                    closing = start
                    break
                depth -= 1
            elif depth == 0:
                if kind != b'else' or alternate is not None:
                    raise ValueError('unsupported FPGA memory alternatives: ' + original_rel)
                alternate = (start, end)
        if alternate is None or closing is None:
            raise ValueError('incomplete FPGA memory conditional: ' + original_rel)
        selected = (block[0][selector.end():alternate[0]] if selector[1] == b'ifdef'
                    else block[0][alternate[1]:closing])
        if len(re.findall(instance_pattern, selected)) != 1:
            raise ValueError('FPGA branch lacks original logic memory instance: ' + original_rel)
        newline = b'\r\n' if b'\r\n' in original else b'\n'
        prefix = newline.join([b'`ifdef KWT_SRAM_BEHAV', b'`define ' + private,
                               b'`elsif FPGA', b'`define ' + private, b'`endif']) + newline
        start, end = block.start() + selector.start(), block.start() + selector.end()
        # Add the private selector immediately before this conditional and clear
        # it at module end; all other original bytes remain identical.
        retarget = re.sub(rb'\bFPGA\b', private, original[start:end], count=1)
        module_end = block.end() - len(b'endmodule')
        generated = (original[:start] + prefix + retarget + original[end:module_end] +
                     b'`undef ' + private + newline + original[module_end:])
        generated_rel = 'tb/kwt/' + module + '_functional.v'
        prepared.append((generated_rel, generated, {
            'original': original_rel, 'generated': generated_rel,
            'original_sha256': sha(original), 'generated_sha256': sha(generated),
            'selector': 'KWT_SRAM_BEHAV', 'original_selector': selector[1].decode() + ' FPGA',
            'instance': instance,
            'scope': 'original FPGA memory branch only; branch bodies and native RTL preserved'}))
    # Validate all three wrappers before publishing any view.
    for relative, data, _ in prepared:
        target = dst / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return [record for _, _, record in prepared]


# Editor and PPI/IRQ functions below are copied verbatim from the frozen helper.
class Editor:
    def __init__(self, path, original):
        self.path = path
        self.newline = "\r\n" if b"\r\n" in original else "\n"
        self.text = original.decode("latin1").replace("\r\n", "\n")

    def match(self, pattern):
        matches = list(re.finditer(pattern, self.text, re.MULTILINE))
        if len(matches) != 1:
            context = [self.text[max(0, m.start()-45):m.start()+85] for m in matches[:3]]
            raise ValueError(f"{self.path}: expected one anchor {pattern!r}, "
                             f"found {len(matches)}; context {context!r}")
        return matches[0]

    def replace(self, pattern, replacement):
        match = self.match(pattern)
        value = replacement(match) if callable(replacement) else replacement
        self.text = self.text[:match.start()] + value + self.text[match.end():]

    def literal(self, anchor, replacement):
        self.replace(re.escape(anchor), replacement)

    def prepend_ports(self, module, ports):
        anchor = f"module {module}("
        self.literal(anchor, anchor + "\n" + "\n".join(ports))

    def bytes(self):
        return self.text.replace("\n", self.newline).encode("latin1")


def signal_ports(port_prefix, wire_prefix):
    return [f".{port_prefix}_icb_{suffix}({wire_prefix}_icb_{suffix})"
            for suffix, _, _ in ICB]


def add_connections(editor, instance_pattern, connections):
    editor.replace(instance_pattern, lambda m: m[0] + "\n    "
                   + ",\n    ".join(connections) + ",")


def add_irq_input(editor, module):
    if re.search(r"^\s*input\s+(?:wire\s+)?ai_irq\s*,", editor.text, re.MULTILINE):
        editor.match(r"^\s*input\s+(?:wire\s+)?ai_irq\s*,")
    else:
        editor.prepend_ports(module, ["  input ai_irq,"])


def patch_peripheral_path(editors):
    port_lines = [f"  {direction} {width + ' ' if width else ''}kwt_icb_{suffix},"
                  for suffix, width, direction in ICB]
    perips = editors[PERIPS]
    perips.prepend_ports("e203_subsys_perips", port_lines)
    perips.literal("  // * Here is an example AXI Peripheral\n  .O14_BASE_ADDR",
                   "  // * KWT accelerator register window\n  .O14_BASE_ADDR")
    perips.match(r"^  \.O14_BASE_ADDR +\(32'h1004_1000\),[ \t]*$")
    perips.match(r"^  \.O14_BASE_REGION_LSB +\(12\),$")
    for suffix, _, _ in ICB:
        perips.replace(rf"^  wire [^\n]*\bexpl_axi_icb_{suffix};[ \t]*\n", "")
        original = "1'b0 " if suffix == "rsp_err" else rf"expl_axi_icb_{suffix}[ ]*"
        perips.replace(rf"^(    \.o14_icb_{suffix} +\(){original}(\),)$",
                       lambda m: m[1] + f"kwt_icb_{suffix}" + m[2])
    perips.replace(
        r"^  // \* Here is an example AXI Peripheral\n  wire expl_axi_arvalid;\n"
        r"(?:(?!^  sirv_hclkgen_regs)[\s\S])*?"
        r"u_expl_axi_icb2axi\([\s\S]*?u_perips_expl_axi_slv \([\s\S]*?^  \);\n",
        "",
    )
    if "expl_axi_" in perips.text:
        raise ValueError(f"{PERIPS}: example AXI references remain")

    main = editors[MAIN]
    top = editors[TOP]
    for editor, module in ((main, "e203_subsys_main"), (top, "e203_subsys_top")):
        add_irq_input(editor, module)
        editor.prepend_ports(module, port_lines + ["  output kwt_clk,", "  output kwt_rst_n,"])
    ppi = signal_ports("kwt", "kwt")
    add_connections(main, r"^  e203_subsys_perips u_e203_subsys_perips \($", ppi)
    main.match(r"^    \.ls_clk +\(ls_clk  \),\n    \.clk +\(hfclk  \),\n"
               r"    \.bus_rst_n +\(bus_rst_n\),[ \t]*\n    \.rst_n +\(per_rst_n\)")
    main.literal("  wire bus_rst_n  = main_rst_n;",
                 "  wire bus_rst_n  = main_rst_n;\n"
                 "  assign kwt_clk = hfclk;\n"
                 "  assign kwt_rst_n = bus_rst_n;")
    add_connections(top, r"^  e203_subsys_main  u_e203_subsys_main\($",
                    ppi + [f".{wire}({wire})" for wire, _ in CLOCK_IRQ
                           if not re.search(rf"\.({wire})\s*\(", top.text)])

    plic = editors[PLIC]
    add_irq_input(plic, "e203_subsys_plic")
    if not re.search(r"\.ai_irq\s*\(", main.text):
        add_connections(main, r"^ e203_subsys_plic u_e203_subsys_plic\($", [".ai_irq(ai_irq)"])
    main.match(r"^ e203_subsys_plic u_e203_subsys_plic\([\s\S]*?\.ai_irq\s*\(\s*ai_irq\s*\)")
    plic.replace(r"^(  wire plic_irq_i_7 += )(?:qspi2_irq|ai_irq);$",
                 lambda m: m[1] + "ai_irq;")
    plic.match(r"^    \.io_devices_0_7 +\(plic_irq_i_7 \),$")
    editors[PLIC_TOP].match(r"^ +io_devices_0_7 +,\n +io_devices_0_6 +,")


def wires(prefix):
    return '\n'.join('  wire %s%s_icb_%s;' % ((width+' ') if width else '', prefix, suffix)
                     for suffix, width, _ in ICB)

def master_ports(prefix):
    return ['  %s %s%s_icb_%s,' % ('input' if direction == 'output' else 'output',
            (width+' ') if width else '', prefix, suffix) for suffix, width, direction in ICB]

def patch_system_bus(editors):
    main, top, soc, tb = [editors[p] for p in (MAIN, TOP, SOC, TB)]
    masters = ('kwt_m0', 'kwt_m1', 'kwt_load')
    ports = sum((master_ports(p) for p in masters), [])
    main.prepend_ports('e203_subsys_main', ports)
    top.prepend_ports('e203_subsys_top', ports)
    add_connections(top, r'^  e203_subsys_main  u_e203_subsys_main\($',
                    sum((signal_ports(p, p) for p in masters), []))
    # Preserve original CPU mem wires; reconnect only the mems instance input.
    begin = main.text.index('e203_subsys_mems u_e203_subsys_mems(')
    end = main.text.index('\n  );', begin)
    block = main.text[begin:end]
    for suffix, _, _ in ICB:
        block = re.sub(r'(\.mem_icb_'+suffix+r'\s*\(\s*)mem_icb_'+suffix,
                       r'\1bus_icb_'+suffix, block)
    main.text = main.text[:begin] + block + main.text[end:]
    connections = ['.clk(hfclk)', '.rst_n(bus_rst_n)']
    connections += signal_ports('o', 'bus')
    for suffix, _, _ in ICB:
        connections.append('.i_bus_icb_%s({%s})' % (suffix, ', '.join(
            p+'_icb_'+suffix for p in ('kwt_load', 'kwt_m1', 'kwt_m0', 'mem'))))
    for suffix, value in [('cmd_burst', "8'b0"), ('cmd_beat', "8'b0"),
                          ('cmd_lock', "4'b0"), ('cmd_excl', "4'b0"),
                          ('cmd_size', "8'haa"), ('cmd_usr', "4'b0")]:
        connections += ['.i_bus_icb_%s(%s)' % (suffix, value), '.o_icb_%s()' % suffix]
    connections += [".o_icb_rsp_excl_ok(1'b0)", ".o_icb_rsp_usr(1'b0)",
                    '.i_bus_icb_rsp_excl_ok()', '.i_bus_icb_rsp_usr()']
    arbiter = (wires('bus') + '\n  sirv_gnrl_icb_arbt #(\n'
        '    .AW(32), .DW(32), .USR_W(1), .ARBT_SCHEME(1),\n'
        '    .FIFO_OUTS_NUM(3), .FIFO_CUT_READY(0), .ARBT_NUM(4), .ARBT_PTR_W(2)\n'
        '  ) u_kwt_sysbus_arbiter (\n    ' + ',\n    '.join(connections) + '\n  );\n')
    main.literal('e203_subsys_mems u_e203_subsys_mems(', arbiter + '\ne203_subsys_mems u_e203_subsys_mems(')
    soc.prepend_ports('e203_soc_top', master_ports('kwt_load'))
    declarations = '  wire kwt_clk, kwt_rst_n, kwt_irq;\n'
    declarations += '\n'.join(wires(p) for p in ('kwt', 'kwt_m0', 'kwt_m1'))
    declarations += '\n  wire kwt_write_rsp_valid, kwt_write_rsp_ready, kwt_write_rsp_err;\n'
    declarations += '\n'.join('  assign kwt_write_rsp_%s = kwt_m1_icb_rsp_%s;' % (s,s)
                              for s in ('valid','ready','err'))
    # cmd_valid/ready already declared in the reference SoC.
    declarations += '\n' + '\n'.join(wires('sysmem').splitlines()[2:])
    accel = ['.clk(kwt_clk)', '.rst_n(kwt_rst_n)', '.irq(kwt_irq)']
    accel += signal_ports('s', 'kwt') + signal_ports('m0', 'kwt_m0') + signal_ports('m1', 'kwt_m1')
    declarations += "\n  kwt_accel_top #(.WIN0_BASE(32'hA0000000), .WIN0_SIZE(32'h00080000),\n    .WIN1_BASE(32'b0), .WIN1_SIZE(32'b0)) u_kwt_accel (\n    " + ',\n    '.join(accel) + '\n  );\n'
    declarations += '  kwt_shared_sram u_kwt_shared_sram (\n    ' + ',\n    '.join(
        ['.clk(kwt_clk)', '.rst_n(kwt_rst_n)'] + signal_ports('s', 'sysmem')) + '\n  );\n'
    soc.literal(' e203_subsys_top u_e203_subsys_top(', declarations + '\n e203_subsys_top u_e203_subsys_top(')
    add_connections(soc, r'^ e203_subsys_top u_e203_subsys_top\($',
                    signal_ports('kwt','kwt') + sum((signal_ports(p,p) for p in masters), []) +
                    ['.kwt_clk(kwt_clk)', '.kwt_rst_n(kwt_rst_n)', '.ai_irq(kwt_irq)'])
    for suffix, _, _ in ICB:
        soc.replace(r'(\.sysmem_icb_'+suffix+r'\s*\()[^)]*(\))',
                    lambda m: m[1]+'sysmem_icb_'+suffix+m[2])
    tb.literal('module tb_top();', 'module tb_top();\n  kwt_sysbus_harness u_kwt();\n  tb_sysbus_monitor u_sysbus_monitor();')
    add_connections(tb, r'^e203_soc_top u_e203_soc_top\($',
                    ['.kwt_load_icb_%s(u_kwt.load_%s)' % (s,s) for s,_,_ in ICB])
    tb.literal('`include "e203_defines.v"', '`timescale 1ns/1ps\n`include "e203_defines.v"')
    tb.literal('     #2 clk <= ~clk;', '     #3.333 clk <= ~clk;')
    tb.literal('     #33 lfextclk <= ~lfextclk;', '     #15258.789 lfextclk <= ~lfextclk;')
    # Original CPU TEST_PASS still prints, but completion must include harness drain/accounting.
    tb.literal('    #10\n     $finish;', '    wait (u_kwt.harness_done);\n    #10\n     $finish;')
    tb.literal('    #40000000', '    #2000000000')

def archive_reference(src, archive_path):
    """Compare original expanded sources to original ZIP without extracting it."""
    critical_lf = {
        SOC: '97bfe3fd1119b4682589a48f57a60e108d496e2c1c1a53d7c0255b50fe79c02b',
        MAIN: '4258161cac87bc56ef19f22ee8c82dbcae9d3effb2f0159282d3f8acd85c015c',
        MEMS: 'dc63cbcc9ebe9331c824c27f6f3645f0f330740573ee1b9a52dc5ca259a339fd'}
    critical_raw = {
        CONFIG: 'c2830ad5e73e9acec9cff0e8c98a1648ec5c53cddd8cdc9a04b7f0c7f2fbef61',
        TB: 'eb4b97dc4aeb5e64783ce9c32eb1669c65071e6547c721047bfcf994ba788de2'}
    before = {}
    actual_files = {p.relative_to(src).as_posix() for p in (src / 'rtl').rglob('*.v')}
    with zipfile.ZipFile(str(archive_path)) as archive:
        names = archive.namelist()
        anchors = [n for n in names if n == MEMS or n.endswith('/'+MEMS)]
        if len(anchors) != 1:
            raise ValueError('official archive must contain exactly one original mems path')
        prefix = anchors[0][:-len(MEMS)]
        archived_files = {n[len(prefix):] for n in names if n.startswith(prefix+'rtl/') and n.endswith('.v')}
        if actual_files != archived_files:
            raise ValueError('expanded original RTL file set differs from official ZIP')
        for rel in sorted(actual_files):
            data = (src / rel).read_bytes()
            name = prefix + rel
            if names.count(name) != 1 or archive.read(name) != data:
                raise ValueError('expanded original source differs from original ZIP: '+rel)
            if rel in critical_lf and sha(data.replace(b'\r\n',b'\n')) != critical_lf[rel]:
                raise ValueError('official critical source LF hash mismatch: '+rel)
            if rel in critical_raw and sha(data) != critical_raw[rel]:
                raise ValueError('official critical source raw hash mismatch: '+rel)
            before[rel] = data
    # The server TB has a separately reviewed one-line delta; bind its exact raw hash.
    before[TB] = (src / TB).read_bytes()
    if sha(before[TB]) != critical_raw[TB]:
        raise ValueError('official critical source raw hash mismatch: '+TB)
    archive_digest = hashlib.sha256()
    with Path(archive_path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            archive_digest.update(chunk)
    return before, {'mode':'original_zip_byte_comparison', 'archive':str(archive_path),
                    'archive_sha256':archive_digest.hexdigest(), 'archive_prefix':prefix,
                    'critical_lf':critical_lf, 'critical_raw':critical_raw,
                    'review_limit':'Other RTL is bound to the user-confirmed official original archive, not individually line-reviewed'}

def build(src, dst, frozen=FROZEN, reference_archive=None):
    src, dst = Path(src).resolve(), Path(dst).resolve()
    if dst.exists() or src == dst or src in dst.parents:
        raise ValueError('destination must be fresh and outside source')
    expected = json.loads((ROOT / 'tools/e203_reference_lf_sha256.json').read_text())
    core_expected = json.loads((ROOT / 'tools/w12_core_sha256.json').read_text())
    for rel, expected_hash in core_expected.items():
        if sha((frozen / rel).read_bytes()) != expected_hash:
            raise ValueError('frozen numerical core changed: '+rel)
    before = {}
    provenance = {'mode':'strict_public_lf_manifest'}
    if reference_archive is not None:
        before, provenance = archive_reference(src, reference_archive)
    else:
        for rel, allowed in expected.items():
            data = (src / rel).read_bytes()
            if sha(data.replace(b'\r\n', b'\n')) not in allowed:
                raise ValueError('unreviewed source hash: '+rel)
            before[rel] = data
        unreviewed = {p.relative_to(src).as_posix() for p in (src / 'rtl').rglob('*.v')} - set(expected)
        if unreviewed:
            raise ValueError('unreviewed additional reference sources: '+', '.join(sorted(unreviewed)[:5]))
    editors = {p: Editor(p, before[p]) for p in (PERIPS,MAIN,TOP,PLIC,PLIC_TOP,SOC,TB)}
    patch_peripheral_path(editors)
    patch_system_bus(editors)
    # Simulation-only portability: explicit reset edge and 64-bit watchdog delays.
    # No task data preload, bus clock, task-cycle accounting or firmware change.
    editors[TB].literal('rst_n <=0;\n    #120 rst_n <=1;',
                        'rst_n = 1;\n    #1 rst_n = 0;\n    #119 rst_n <= 1;')
    editors[TB].literal('#2000000000', "#(64'd2000000000)")
    editors[TB].literal('      $readmemh({testcase, ".verilog"}, itcm_mem);',
                        '      if (!$value$plusargs("TESTCASE=%s",testcase)) $fatal(1, "TESTCASE required");\n      $readmemh({testcase, ".verilog"}, itcm_mem);')
    for directory in ('rtl','tb'):
        shutil.copytree(src / directory, dst / directory)
    for rel, data in before.items():
        if (dst / rel).read_bytes() != data:
            raise ValueError('reference changed during copy: '+rel)
    for rel, editor in editors.items():
        (dst / rel).write_bytes(editor.bytes())
    if (dst / MEMS).read_bytes() != before[MEMS]:
        raise ValueError('original mems changed')
    extra = dst / 'rtl/e203/kwt'
    extra.mkdir()
    core_manifest = {}
    for directory in ('accel','mem'):
        for path in sorted((frozen / 'rtl' / directory).glob('*.v')):
            if path.relative_to(frozen).as_posix() not in core_expected:
                raise ValueError('unreviewed added core source: '+str(path))
            shutil.copyfile(path, extra / path.name)
            core_manifest[path.name] = sha(path.read_bytes())
    shutil.copyfile(ROOT / 'rtl/kwt_shared_sram.v', extra / 'kwt_shared_sram.v')
    shutil.copyfile(ROOT / 'rtl/kwt_loader_dma.v', extra / 'kwt_loader_dma.v')
    # Supply only when the source snapshot lacks this original-arbiter dependency.
    if not any(re.search(r'\bmodule\s+sirv_gnrl_rrobin\b', p.read_text(errors='replace'))
               for p in (src / 'rtl').rglob('*.v')):
        shutil.copyfile(ROOT / 'rtl/sirv_gnrl_rrobin.v', extra / 'sirv_gnrl_rrobin.v')
    support = dst / 'tb/kwt'
    support.mkdir(exist_ok=True)
    shutil.copyfile(ROOT / 'tb/kwt_sysbus_harness.sv', support / 'kwt_sysbus_harness.sv')
    shutil.copyfile(ROOT / 'tb/tb_sysbus_monitor.sv', support / 'tb_sysbus_monitor.sv')
    shutil.copyfile(ROOT / 'tb/models/ramsp4096x16_model.v', support / 'ramsp4096x16_model.v')
    model = ROOT / 'tb/models/ramsp128x16_model.v'
    if model.exists():
        shutil.copyfile(model, support / model.name)
    else:
        raise ValueError('missing RAMSP128X16 local model')
    clockgate_provenance = functional_clockgate_view(dst)
    memory_provenance = functional_memory_views(dst, official=reference_archive is not None)
    inventory = {'source': str(src), 'reference_provenance':provenance,
                 'before_raw': {p: sha(d) for p,d in before.items()},
                 'frozen_core': core_manifest,
                 'after': {p.relative_to(dst).as_posix(): sha(p.read_bytes()) for p in sorted(dst.rglob('*')) if p.is_file()}}
    if clockgate_provenance is not None:
        inventory['functional_clockgate_view'] = clockgate_provenance
    inventory['functional_memory_views'] = memory_provenance
    (dst / 'source_manifest.json').write_text(json.dumps(inventory, indent=2)+'\n')
    return inventory

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--src', type=Path, default=PUBLIC)
    parser.add_argument('--dst', type=Path, required=True)
    parser.add_argument('--frozen', type=Path, default=FROZEN)
    parser.add_argument('--reference-archive', type=Path)
    args = parser.parse_args()
    build(args.src, args.dst, args.frozen, args.reference_archive)
    print('KWT_SYSBUS_OVERLAY_PASS destination='+str(args.dst))

if __name__ == '__main__':
    main()


