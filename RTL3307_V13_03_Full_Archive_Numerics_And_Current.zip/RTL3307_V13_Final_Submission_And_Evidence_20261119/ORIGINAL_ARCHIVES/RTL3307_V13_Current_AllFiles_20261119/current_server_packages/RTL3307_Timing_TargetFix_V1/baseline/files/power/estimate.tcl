# RTL activity from one verified task, one fresh netlist, one characterized corner.
source [file join [file dirname [info script]] .. native common.tcl]

proc power_row {object} {
    set row {}
    foreach attr {internal_power switching_power leakage_power total_power} {
        if {[catch {get_attribute -quiet $object $attr} value] ||
            ![string is double -strict $value] || [catch {expr {abs($value)<Inf}} finite] || !$finite} {
            lappend row UNKNOWN
        } else {
            lappend row [format %.16g $value]
        }
    }
    return $row
}

proc net_activity {object} {
    set nets [get_nets -quiet -of_objects $object]
    if {[sizeof_collection $nets] != 1} {return [list NO_UNIQUE_NET UNKNOWN]}
    set source [get_attribute -quiet $nets activity_source]
    if {$source eq ""} {set source UNKNOWN}
    if {[catch {get_attribute -quiet $nets toggle_rate} toggle] || $toggle eq ""} {set toggle UNKNOWN}
    return [list $source $toggle]
}

finish {
    set_app_var power_enable_analysis true
    set_app_var power_analysis_mode averaged
    if {![get_app_var power_enable_analysis] || [get_app_var power_analysis_mode] ne "averaged"} {
        error "Averaged power analysis unavailable"
    }
    setup_library PT
    if {[llength [libraries]] != 5} {error "Expected exactly five corner libraries"}
    read_verilog [required netlist]
    if {![link_design e203_soc_top]} {error "Mapped SoC link failed"}
    apply_conditions
    source [required sdc]
    # PrimeTime stores time as integer picoseconds, so a period written as
    # 6.666666667 ns comes back from get_attribute as 6.666667 ns (6666667 ps).
    # A 1e-7 ns tolerance is below that storage resolution and can never pass:
    # it made every power job abort with "Clock absent or wrong period: hfclk"
    # even though the clock was created correctly. Compare at the 1 ps
    # granularity the tool actually keeps.
    foreach {clock period} {hfclk 6.666666667 lfclk 30517.578125} {
        set obj [get_clocks -quiet $clock]
        if {[sizeof_collection $obj] != 1 || abs([get_attribute $obj period]-$period)>1.0e-3} {
            error "Clock absent or wrong period: $clock"
        }
    }
    update_timing
    macro_check
    help read_saif > read_saif_help.rpt
    printvar power_default* > activity_defaults.rpt
    report_units > units.rpt
    report_clock > clocks.rpt
    read_saif [required saif] -strip_path [required strip_path] > read_saif.rpt
    report_switching_activity > switching_before_power.rpt
    set checked [check_power > check_power.rpt]
    puts "RTL3307_CHECK_POWER_RETURN=[list $checked]"
    update_power
    report_switching_activity > switching_activity.rpt
    report_switching_activity -list_not_annotated > switching_not_annotated.rpt
    report_power > power_total.rpt
    report_power -hierarchy > power_hierarchy.rpt

    set component_names "internal_W\tswitching_W\tleakage_W\ttotal_W"
    set design [open design.tsv w]
    puts $design $component_names
    puts $design [join [power_row [current_design]] \t]
    close $design
    set macro [open macros.tsv w]
    puts $macro "instance\treference\tlib_cell\tpin_count\t$component_names"
    set pins [open macro_pins.tsv w]
    puts $pins "instance\tpin\tsource\ttoggle_rate"
    set registers [all_registers -cells]
    dict for {ref expected} [required expected_macros] {
        set selected [get_cells -hierarchical -quiet -filter "ref_name == $ref"]
        set registers [remove_from_collection $registers $selected]
        foreach_in_collection cell $selected {
            set instance [get_object_name $cell]
            set binding [get_lib_cells -quiet -of_objects $cell]
            if {[sizeof_collection $binding] != 1} {error "Missing or ambiguous SRAM binding: $instance"}
            set boundary [get_pins -quiet -of_objects $cell]
            puts $macro "$instance\t$ref\t[get_object_name $binding]\t[sizeof_collection $boundary]\t[join [power_row $cell] \t]"
            foreach_in_collection pin $boundary {
                puts $pins "$instance\t[get_object_name $pin]\t[join [net_activity $pin] \t]"
            }
        }
    }
    close $pins
    close $macro
    set summary [open sources.tsv w]
    puts $summary "category\tsource\tcount"
    set counts {}
    foreach_in_collection cell $registers {
        foreach_in_collection pin [filter_collection [get_pins -quiet -of_objects $cell] {direction == out}] {
            set source [lindex [net_activity $pin] 0]
            dict incr counts $source
        }
    }
    dict for {source count} $counts {puts $summary "register_output\t$source\t$count"}
    set counts {}
    foreach_in_collection net [get_nets -hierarchical -quiet *] {
        set source [get_attribute -quiet $net activity_source]
        if {$source eq ""} {set source UNKNOWN}
        dict incr counts $source
    }
    dict for {source count} $counts {puts $summary "hierarchical_net\t$source\t$count"}
    close $summary
    set port_file [open rtl_witness.tsv w]
    puts $port_file "port\tsource\ttoggle_rate"
    foreach name {hfextclk kwt_load_icb_cmd_valid} {
        set port [get_ports -quiet $name]
        if {[sizeof_collection $port] != 1} {error "Expected exactly one RTL witness port: $name"}
        puts $port_file "$name\t[join [net_activity $port] \t]"
    }
    close $port_file
    puts "RTL3307_TASK_POWER [required corner] [required task]"
}

