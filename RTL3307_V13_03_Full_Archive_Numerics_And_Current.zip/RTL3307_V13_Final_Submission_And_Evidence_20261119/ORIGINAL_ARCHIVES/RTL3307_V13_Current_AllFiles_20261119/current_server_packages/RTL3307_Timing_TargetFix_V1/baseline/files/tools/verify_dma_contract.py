"""Check protected RTL, native capacities, arithmetic and timed-task invariants."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def check(soc):
    reference = json.loads((ROOT/'optimization/protected_baseline.json').read_text())
    for name, expected in reference['protected_rtl'].items():
        if digest((soc/name).read_bytes()) != expected:
            raise ValueError('protected original/frozen RTL changed: '+name)
    main = (soc/'rtl/e203/subsys/e203_subsys_main.v').read_text()
    optimized = '.FIFO_OUTS_NUM(3), .FIFO_CUT_READY(0), .ARBT_NUM(4)'
    if main.count(optimized) != 1:
        raise ValueError('unexpected participant arbiter configuration')
    reverted = main.replace(optimized, '.FIFO_OUTS_NUM(1), .FIFO_CUT_READY(0), .ARBT_NUM(4)')
    if digest(reverted.encode()) != reference['main_baseline_lf_sha256']:
        raise ValueError('unexpected main-module routing/interface edit')
    sram = (soc/'rtl/e203/kwt/kwt_shared_sram.v').read_text()
    macros = sram.split('    genvar bank, lane;',1)[1]
    if digest(macros.encode()) != reference['shared_macro_section_sha256']:
        raise ValueError('native SRAM instances/pins/port wiring changed')
    if digest((ROOT/'sw/out/t_linear_irq.verilog').read_bytes()) != reference['firmware_sha256']:
        raise ValueError('CPU firmware changed')
    return {'protected_rtl_files':len(reference['protected_rtl']),
            'native_splitter_outstanding':1,'native_cmd_fifo_depth':2,
            'participant_arbiter_owner_entries':3,'data_width':32,
            'core_and_firmware_unchanged':True,'macro_wiring_unchanged':True,
            'scope':'provided public reference; not official server-source certification'}

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--soc',type=Path,default=ROOT/'work/optimized_soc')
    args=parser.parse_args()
    print(json.dumps(check(args.soc),indent=2))
