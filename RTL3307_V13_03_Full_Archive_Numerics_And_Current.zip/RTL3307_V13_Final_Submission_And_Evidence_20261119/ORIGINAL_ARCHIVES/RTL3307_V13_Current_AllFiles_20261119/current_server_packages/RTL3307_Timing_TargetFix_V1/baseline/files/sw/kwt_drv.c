#include "kwt_drv.h"
#include "plic.h"
#include "mailbox.h"

static volatile uint32_t irq_status;
extern void kwt_finish(int code) __attribute__((noreturn));

int kwt_probe(void)
{
    uint32_t cfg = KWT(KWT_HWCFG);
    /* UG v1, 64 lanes and XDEPTH=128. Both 1- and 2-column UG builds are valid. */
    return (KWT(KWT_ID) != 0x4b575431u || (cfg & ~0xffu) != 0x01014000u ||
            ((cfg & 0xffu) != 1u && (cfg & 0xffu) != 2u));
}

void kwt_irq_init(void)
{
    KWT(KWT_IRQ_EN) = 0;
    KWT(KWT_STATUS) = KWT_W1C;
    plic_init();
    kwt_fence();
    __asm__ volatile ("csrs mie, %0; csrsi mstatus, 8" :: "r"(1u << 11) : "memory");
}

void kwt_select_irq(int irq)
{
    KWT(KWT_IRQ_EN) = irq ? 3u : 0u;
}

int kwt_start(const kwt_cfg_t *c)
{
    if (KWT(KWT_STATUS) & KWT_BUSY)
        return -1;

    irq_status = 0;
    KWT(KWT_STATUS) = KWT_W1C;
    KWT(KWT_OPCODE) = c->opcode;
    KWT(KWT_DIM_M) = c->m;
    KWT(KWT_DIM_K) = c->k;
    KWT(KWT_DIM_N) = c->n;
    KWT(KWT_X_BASE) = c->x_base;
    KWT(KWT_W_BASE) = c->w_base;
    KWT(KWT_Y_BASE) = c->y_base;
    KWT(KWT_X_STRIDE) = c->x_stride;
    KWT(KWT_Y_STRIDE) = c->y_stride;
    KWT(KWT_AUX_BASE) = c->aux_base;
    KWT(KWT_AUX_CFG) = c->aux_cfg;
    kwt_fence();
    KWT(KWT_CTRL) = KWT_START;
    return 0;
}

int kwt_wait_irq(void)
{
    for (;;) {
        /* E203 WFI wake depends on MEIE, not the global MIE bit. Keep MIE
         * clear between checking irq_status and WFI to avoid a lost wakeup. */
        __asm__ volatile ("csrci mstatus, 8" ::: "memory");
        uint32_t status = irq_status;
        if (!(status & (KWT_DONE | KWT_ERR)))
            __asm__ volatile ("wfi" ::: "memory");
        __asm__ volatile ("csrsi mstatus, 8" ::: "memory");
        if (status & (KWT_DONE | KWT_ERR))
            return (int)status;
    }
}

int kwt_wait_poll(void)
{
    uint32_t status;
    do {
        status = KWT(KWT_STATUS);
    } while (!(status & (KWT_DONE | KWT_ERR)));
    KWT(KWT_STATUS) = status & KWT_W1C;
    return (int)status;
}

void kwt_read_perf(kwt_perf_t *p)
{
    for (unsigned i = 0; i < 8; ++i)
        p->counters[i] = KWT(KWT_PERF + 4 * i);
    p->sat = KWT(KWT_SAT_COUNT);
}

void kwt_abort(void)
{
    KWT(KWT_CTRL) = KWT_ABORT;
}

void kwt_isr(void)
{
    uint32_t source = plic_claim();
    if (source == KWT_PLIC_SOURCE) {
        uint32_t status = KWT(KWT_STATUS);
        KWT(KWT_STATUS) = status & KWT_W1C;
        /* Drop the device's level before opening the PLIC gateway again. */
        kwt_fence();
        plic_complete(source);
        if (status & (KWT_DONE | KWT_ERR))
            irq_status = status;
    } else if (source) {
        plic_complete(source);
    }
}

void __attribute__((interrupt("machine"), aligned(4))) kwt_trap(void)
{
    uint32_t cause;
    __asm__ volatile ("csrr %0, mcause" : "=r"(cause));
    if (cause == 0x8000000bu) {
        kwt_isr();
    } else {
        MB(MB_STATUS) = cause;
        kwt_fence();
        MB(MB_STATE) = MB_ERROR;
        kwt_finish(1);
    }
}
