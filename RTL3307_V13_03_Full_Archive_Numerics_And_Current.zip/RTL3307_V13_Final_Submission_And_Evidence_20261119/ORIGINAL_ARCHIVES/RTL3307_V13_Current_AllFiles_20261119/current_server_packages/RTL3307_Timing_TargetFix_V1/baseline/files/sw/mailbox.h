#ifndef KWT_MAILBOX_H
#define KWT_MAILBOX_H
#include "kwt_drv.h"

#define MB(offset) MMIO32(0xA0000F00u + (offset))
enum {
    MB_STATE = 0x00, MB_TASK_ID = 0x04, MB_OPCODE = 0x08, MB_DIMS = 0x0c,
    MB_X_BASE = 0x10, MB_W_BASE = 0x14, MB_Y_BASE = 0x18, MB_STRIDES = 0x1c,
    MB_MODE = 0x20, MB_PERF = 0x40, MB_STATUS = 0x60,
    MB_MCYCLE_START = 0x64, MB_MCYCLE_END = 0x68
};
enum { MB_READY = 1, MB_GO = 2, MB_DONE = 3, MB_EXIT = 4, MB_ERROR = 0xe };
#endif

