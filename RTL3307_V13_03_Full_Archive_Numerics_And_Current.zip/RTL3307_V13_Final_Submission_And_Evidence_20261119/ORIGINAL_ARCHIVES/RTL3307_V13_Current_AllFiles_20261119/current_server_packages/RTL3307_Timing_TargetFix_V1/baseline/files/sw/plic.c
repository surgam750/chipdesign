#include "kwt_drv.h"
#include "plic.h"

/* E203 machine context 0, PLIC ID 8. Competition mapping pending confirmation. */
void plic_init(void)
{
    MMIO32(0x0c000020u) = 1;
    MMIO32(0x0c002000u) = 1u << KWT_PLIC_SOURCE;
    MMIO32(0x0c200000u) = 0;
}
uint32_t plic_claim(void)
{
    return MMIO32(0x0c200004u);
}
void plic_complete(uint32_t source)
{
    MMIO32(0x0c200004u) = source;
}
