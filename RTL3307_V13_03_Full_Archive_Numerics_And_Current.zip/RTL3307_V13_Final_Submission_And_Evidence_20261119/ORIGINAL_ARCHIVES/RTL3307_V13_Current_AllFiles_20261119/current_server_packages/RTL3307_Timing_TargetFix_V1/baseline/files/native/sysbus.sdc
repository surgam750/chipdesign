# New SystemBus fixture; ns. No path exceptions or asynchronous group cuts.
create_clock -name hfclk -period 6.666666667 [need [get_ports hfextclk] hfextclk]
create_clock -name lfclk -period 30517.578125 [need [get_ports lfextclk] lfextclk]
set_clock_uncertainty -setup 0.30 [all_clocks]
set_clock_uncertainty -hold 0.05 [all_clocks]
set_clock_transition 0.15 [all_clocks]
# The TB holds these inputs at constants. Reset stays timed to expose recovery/removal.
foreach {pin value} {io_pads_jtag_TCK_i_ival 0 io_pads_jtag_TMS_i_ival 0 io_pads_jtag_TDI_i_ival 0 io_pads_dbgmode0_n_i_ival 1 io_pads_dbgmode1_n_i_ival 1 io_pads_dbgmode2_n_i_ival 1 io_pads_bootrom_n_i_ival 0 io_pads_aon_pmu_dwakeup_n_i_ival 1} {
    set_case_analysis $value [need [get_ports $pin] $pin]
}
set loader_in [need [get_ports {kwt_load_icb_cmd_* kwt_load_icb_rsp_ready}] loader_inputs]
set loader_out [need [get_ports {kwt_load_icb_cmd_ready kwt_load_icb_rsp_*}] loader_outputs]
# Select directions explicitly because cmd_ready belongs to the opposite side.
set loader_in [filter_collection $loader_in {direction == in}]
set loader_out [filter_collection $loader_out {direction == out}]
# Commands and response-ready change at the TB falling edge, 3.333 ns
# before rising capture. The harness observes ready/response at rising edges.
# This is a digital test fixture, not a PCB specification.
set_input_delay -clock hfclk -max 3.333333333 $loader_in
set_input_delay -clock hfclk -min 3.333333333 $loader_in
set_output_delay -clock hfclk -max 0.0 $loader_out
set_output_delay -clock hfclk -min 0.0 $loader_out
# Other dynamic pads have provisional 2 ns/0 ns budgets, explicitly review-required.
set other_in [remove_from_collection [all_inputs] [get_ports {hfextclk lfextclk kwt_load_* io_pads_jtag_* io_pads_dbgmode* io_pads_bootrom* io_pads_aon_pmu_dwakeup*}]]
set other_out [remove_from_collection [all_outputs] $loader_out]
set_input_delay -clock hfclk -max 2.0 $other_in
set_input_delay -clock hfclk -min 0.0 $other_in
set_output_delay -clock hfclk -max 2.0 $other_out
set_output_delay -clock hfclk -min 0.0 $other_out
set dynamic [add_to_collection $loader_in $other_in]
set_driving_cell -library [required op_library] -lib_cell [required buffer_cell] $dynamic
set load_pin_name "[required op_library]/[required buffer_cell]/[required buffer_input]"
set pin [get_lib_pins -quiet $load_pin_name]
if {[sizeof_collection $pin] != 1} {error "Buffer capacitance reference is ambiguous"}
if {[llength [info commands load_of]] != 1} {error "Required load_of command unavailable"}
set load_cap [load_of $load_pin_name]
if {![string is double -strict $load_cap]} {error "Invalid buffer capacitance: $load_cap"}
if {[catch {expr {$load_cap > 0.0 && $load_cap < Inf}} load_valid] || !$load_valid} {error "Non-positive/non-finite buffer capacitance: $load_cap"}
set applied_load [expr {4.0 * $load_cap}]
if {![expr {$applied_load > 0.0 && $applied_load < Inf}]} {error "Invalid applied load"}
set_load $applied_load [all_outputs]
set load_report [open load_reference.rpt w]
puts $load_report "pin=$load_pin_name"
puts $load_report "capacitance=$load_cap"
puts $load_report "multiplier=4.0"
puts $load_report "applied_load=$applied_load"
close $load_report
set_max_transition 0.30 [current_design]
set_max_fanout 32 [current_design]
