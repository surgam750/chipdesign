// Signed INT16 by INT12 dot product with registered products and two reduction stages.
`timescale 1ns/1ps

module kwt_dot64 (
    input  wire                 clk,
    input  wire [1023:0]        x_flat,
    input  wire [1023:0]        w_flat,
    output reg  signed [37:0]  acc
);

    wire signed [27:0] products [0:63];
    wire signed [30:0] group_sums [0:7];
    wire signed [33:0] total;
    genvar lane;
    genvar group_index;

    generate
        for (lane = 0; lane < 64; lane = lane + 1) begin : g_product
            wire signed [15:0] x_lane;
            wire signed [11:0] w_lane;
            reg signed [27:0] product;

            assign x_lane = x_flat[lane * 16 +: 16];
            assign w_lane = w_flat[lane * 16 +: 12];
            assign products[lane] = product;

            always @(posedge clk)
                product <= x_lane * w_lane;
        end

        // R11 timing: each reduction stage is written as ONE multi-operand sum so
        // DC builds a single carry-save (Wallace) tree with one final carry-
        // propagate adder, instead of three chained 31-34 bit CPAs. Exact integer
        // arithmetic: results are exact for signed twelve-bit weights.
        for (group_index = 0; group_index < 8; group_index = group_index + 1) begin : g_group
            localparam B = group_index * 8;
            wire signed [30:0] group_total;
            reg signed [30:0] group_sum;

            assign group_total = $signed(products[B])     + $signed(products[B + 1])
                               + $signed(products[B + 2]) + $signed(products[B + 3])
                               + $signed(products[B + 4]) + $signed(products[B + 5])
                               + $signed(products[B + 6]) + $signed(products[B + 7]);
            assign group_sums[group_index] = group_sum;

            always @(posedge clk)
                group_sum <= group_total;
        end
    endgenerate

    assign total = $signed(group_sums[0]) + $signed(group_sums[1])
                 + $signed(group_sums[2]) + $signed(group_sums[3])
                 + $signed(group_sums[4]) + $signed(group_sums[5])
                 + $signed(group_sums[6]) + $signed(group_sums[7]);

    always @(posedge clk)
        acc <= total;

endmodule
