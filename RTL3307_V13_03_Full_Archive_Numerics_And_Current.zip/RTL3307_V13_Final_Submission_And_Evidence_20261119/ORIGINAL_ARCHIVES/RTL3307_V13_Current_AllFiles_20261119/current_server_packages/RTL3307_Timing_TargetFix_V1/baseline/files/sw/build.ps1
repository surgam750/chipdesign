param(
    [Parameter(Mandatory=$true)][string]$ToolchainPrefix,
    [string]$OutputDir = (Join-Path $PSScriptRoot 'out'),
    [string]$Python = 'python'
)
$ErrorActionPreference = 'Stop'
$gcc = "${ToolchainPrefix}gcc"
$objcopy = "${ToolchainPrefix}objcopy"
$objdump = "${ToolchainPrefix}objdump"
function Invoke-Checked($Program, [string[]]$Arguments) {
    Write-Host "$Program $($Arguments -join ' ')"
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program exited $LASTEXITCODE" }
}
$OutputDir = (New-Item -ItemType Directory -Force $OutputDir).FullName
Push-Location $PSScriptRoot
try {
    Invoke-Checked $gcc @('--version') | Set-Content (Join-Path $OutputDir 'compiler.txt') -Encoding ASCII
    foreach ($variant in 't_regs','t_linear_irq','t_linear_poll') {
        $elf = Join-Path $OutputDir "$variant.elf"
        $image = Join-Path $OutputDir "$variant.verilog"
        $dump = Join-Path $OutputDir "$variant.dump"
        $argsFw = @('-march=rv32imac_zicsr','-mabi=ilp32','-O2','-ffreestanding',
            '-nostdlib','-nostartfiles','-msmall-data-limit=0','-fno-builtin',
            '-Wall','-Wextra','-Werror','-I.','-Wl,--no-relax','-T','link.ld',
            '-o',$elf,'crt0.S','kwt_drv.c','plic.c')
        if ($variant -eq 't_regs') { $argsFw += 'tests/t_regs.c' }
        else { $argsFw += 'tests/t_linear.c' }
        if ($variant -eq 't_linear_poll') { $argsFw += '-DKWT_FORCE_POLL' }
        Invoke-Checked $gcc $argsFw
        Invoke-Checked $objcopy @('-O','verilog','--change-addresses','-0x80000000',$elf,$image)
        Invoke-Checked $objdump @('-h','-t','-d',$elf) | Set-Content $dump -Encoding ASCII
        Invoke-Checked $Python @('check_image.py',$image,$dump)
    }
    $evidence = @(Get-Item 'crt0.S','link.ld','kwt_drv.c','kwt_drv.h','plic.c','plic.h','mailbox.h',
                            'tests/t_regs.c','tests/t_linear.c','build.ps1','Makefile','check_image.py')
    $evidence += @(Get-ChildItem $OutputDir -File | Where-Object Extension -in '.elf','.verilog','.dump')
    $evidence | Get-FileHash -Algorithm SHA256 | ForEach-Object {
        "$($_.Hash.ToLowerInvariant())  $($_.Path)"
    } | Set-Content (Join-Path $OutputDir 'sha256.txt') -Encoding ASCII
} finally {
    Pop-Location
}
