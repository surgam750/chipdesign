from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[2]
class Contract(unittest.TestCase):
    def test_shared_firmware_mailbox(self):
        path = ROOT / 'sw/mailbox.h'
        self.assertTrue(path.exists(), 'isolated firmware missing')
        self.assertIn('0xA0000F00u', path.read_text())
    def test_no_task_memory_backdoor(self):
        path = ROOT / 'tb/kwt_sysbus_harness.sv'
        self.assertTrue(path.exists(), 'single SystemBus loader missing')
        text = path.read_text()
        for token in ('mem_r', 'dmem_write', 'imem_write', 'host_itcm', 'host_dtcm'):
            self.assertNotIn(token, text)
        for token in ('load_cmd_valid', 'load_rsp_ready', 'kwt_clk', 'kwt_rst_n', 'Y_WORDS', 'A002_0000'):
            self.assertIn(token, text)
if __name__ == '__main__': unittest.main()
