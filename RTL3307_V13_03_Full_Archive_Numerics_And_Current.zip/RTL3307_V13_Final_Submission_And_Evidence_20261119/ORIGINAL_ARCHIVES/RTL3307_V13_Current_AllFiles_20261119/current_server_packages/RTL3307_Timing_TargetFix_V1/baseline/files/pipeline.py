"""RTL3307 seven-corner full flow: RTL regression -> LC/DC -> 7-corner STA ->
native Formality -> task-window power -> area. Python 3.6.

Stages are independent and can be re-run separately:
  check | run --stage rtl | run --stage synth | run --stage sta | run --stage lec | run --stage power
Gate-level simulation is skipped by the user and recorded as such; its absence never
turns report completion into acceptance.
"""
import argparse
from datetime import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
CANDIDATE = 'RTL3307_TCM128_GLOBSLEW025_V1'
CORNERS = ('FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT5', 'TT6')
COMPLETE = 'RTL3307_FULL7_REPORTS_COMPLETE_REVIEW_REQUIRED'
PREFLIGHT = 'RTL3307_PREFLIGHT_PASS_EDA_NOT_RUN'
RTL_DONE = 'RTL3307_RTL_STAGE_COMPLETE_SYNTH_NOT_RUN'
STAGES = ('all', 'rtl', 'synth', 'sta', 'lec', 'power')
GATE_LEVEL = 'SKIPPED_BY_USER'
NOT_RUN_ALWAYS = ['physical_signoff', 'native_macro_gate_level_simulation']


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def get_native():
    return module_at(ROOT / 'native/driver.py', 'rtl3307_native')


def get_formal():
    return module_at(ROOT / 'formality/driver.py', 'rtl3307_formal')


def get_power():
    return module_at(ROOT / 'power/driver.py', 'rtl3307_power')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def save_state(state):
    folder = ROOT / 'reports'
    folder.mkdir(exist_ok=True)
    state['updated'] = datetime.now().isoformat()
    temp = folder / 'pipeline.json.tmp'
    temp.write_text(json.dumps(state, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    os.replace(str(temp), str(folder / 'pipeline.json'))


def run_rtl(action, args):
    command = [sys.executable, '-B', '-u', str(ROOT / 'server/rtl_driver.py'), action,
               '--source', str(args.source), '--archive', str(args.archive),
               '--vcs', str(args.vcs), '--timeout', str(args.timeout)]
    subprocess.check_call(command)
    state = load(ROOT / 'reports/state.json')
    expected = 'SOURCE_CHECK_PASS_RTL_NOT_RUN' if action == 'check' else 'SERVER_SYSTEMBUS_FUNCTIONAL_RTL_PASS'
    if state.get('candidate_id') != CANDIDATE or state.get('status') != expected:
        raise ValueError('Missing current-candidate functional receipt')
    return state


def sealed_config():
    """Reload this run's post-LC configuration; native.results re-verifies it.

    prepared.json still points at the original Liberty sources, which Library
    Compiler has not yet turned into .db.  Formality read_db and PrimeTime both
    need the compiled .db paths, so the resolved configuration is the one that
    every downstream stage must see.  Loading prepared.json here made every
    standalone lec/power run die with "File is not a DB file. (DB-1)".
    """
    for name in ('resolved_config.json', 'prepared.json'):
        path = ROOT / 'result' / name
        if path.is_file():
            return load(path)
    raise ValueError('No prepared configuration; run --stage synth first: '
                     + str(ROOT / 'result/prepared.json'))


def execute(action, args):
    stage = getattr(args, 'stage', 'all')
    if action not in ('check', 'run') or stage not in STAGES:
        raise ValueError('Unsupported execution action or stage')
    jobs = getattr(args, 'jobs', 1)
    if not isinstance(jobs, int) or isinstance(jobs, bool) or jobs < 1:
        raise ValueError('--jobs must be a positive integer')
    # Read by native/driver.py and power/driver.py; 1 keeps the serial path.
    os.environ['RTL3307_WORKERS'] = str(jobs)
    state = {'candidate_id': CANDIDATE, 'status': 'RUNNING', 'stage': 'PREFLIGHT',
             'corners': list(CORNERS), 'gate_level_simulation': GATE_LEVEL,
             'parallel_jobs': jobs, 'accepted': False, 'pid': os.getpid(),
             'not_run': list(NOT_RUN_ALWAYS)}
    keep = ('rtl', 'netlist_sha256', 'timing', 'timing_state', 'area_um2', 'area_groups_um2',
            'macros', 'formality', 'power', 'energy_uJ', 'result_dir')
    existing = ROOT / 'reports/pipeline.json'
    if existing.is_file() and stage != 'all':
        try:
            recorded = load(existing)
        except ValueError:
            recorded = {}
        for key in keep:
            if key in recorded:
                state[key] = recorded[key]
    save_state(state)
    try:
        native = get_native()
        if action == 'check':
            run_rtl('check', args)
            native.inspect_inputs(args.old_config, args.ref)
            state['status'] = PREFLIGHT
            state['stage'] = 'PREFLIGHT'
            print(state['status'], flush=True)
            print('Seven corners, 35 library views and tool paths resolved; no EDA started.', flush=True)
            return

        if stage in ('all', 'rtl'):
            run_rtl('check', args)
            state['stage'] = 'RTL'
            save_state(state)
            state['rtl'] = run_rtl('run', args)
            if stage == 'rtl':
                state['status'] = RTL_DONE
                state['stage'] = 'RTL_DONE'
                print(state['status'], flush=True)
                return

        config = None
        if stage in ('all', 'synth'):
            state['stage'] = 'SYNTHESIS_AND_SEVEN_CORNER_STA'
            save_state(state)
            config = native.prepare(argparse.Namespace(
                out=ROOT / 'result', overlay=ROOT / 'work/soc',
                old_config=args.old_config, ref=args.ref,
                timeout=getattr(args, 'timeout', 7200)))
            native.run(config)
        if config is None:
            config = sealed_config()

        state['stage'] = 'STA_SEVEN_CORNER_VERIFY'
        save_state(state)
        metrics = native.results(config)
        state['netlist_sha256'] = metrics['netlist_sha256']
        timing = metrics.get('timing') or {}
        state['timing'] = {corner: {'max_ns': timing[corner]['worst_ns']['max'],
                                    'min_ns': timing[corner]['worst_ns']['min'],
                                    'negative_slack': timing[corner].get('negative_slack'),
                                    'violation_rows': timing[corner].get('constraint_violation_rows')}
                           for corner in CORNERS if corner in timing}
        # timing.tsv holds two scalar extremes only; this label never stands for all checks.
        negative = [c for c in CORNERS if state['timing'].get(c, {}).get('negative_slack')]
        state['timing_state'] = metrics.get('timing_state') or (
            'WORST_SLACK_NEGATIVE' if negative else 'WORST_SLACK_NONNEGATIVE')
        soc = metrics.get('soc') or {}
        state['area_um2'] = soc.get('total_um2')
        state['area_groups_um2'] = soc.get('groups_um2')
        state['macros'] = soc.get('macros')
        if stage == 'sta':
            state['status'] = 'RTL3307_SEVEN_CORNER_STA_REVIEW_REQUIRED'
            state['stage'] = 'STA_DONE'
            save_state(state)
            print(state['status'], flush=True)
            indicate(state)
            return

        if stage in ('all', 'lec'):
            state['stage'] = 'FORMALITY'
            save_state(state)
            proof = get_formal().run(config, timeout=getattr(args, 'fm_timeout', 7200),
                                     fm=getattr(args, 'fm', None))
            if proof.get('netlist_sha256') != metrics['netlist_sha256']:
                raise ValueError('Formality netlist identity differs from this run')
            proof_state = proof.get('status') or ('LEC_VERIFY_TRUE_REVIEW_REQUIRED'
                                                  if proof.get('native_verify_return')
                                                  else 'LEC_VERIFY_FALSE_NO_ACCEPTANCE')
            state['formality'] = {'status': proof_state,
                                  'native_verify_return': proof.get('native_verify_return'),
                                  'netlist_sha256': proof['netlist_sha256'],
                                  'svf_sha256': proof.get('svf_sha256'),
                                  'replaced_tool_files': proof.get('replaced_tool_files') or {}}
            if stage == 'lec':
                state['status'] = proof_state
                state['stage'] = 'FORMALITY_DONE'
                save_state(state)
                print(state['status'], flush=True)
                return

        if stage in ('all', 'power'):
            state['stage'] = 'TASK_POWER'
            save_state(state)
            power = get_power()
            power.preflight(config)
            summary = power.run(config, timeout=getattr(args, 'power_timeout', 7200))
            if summary.get('netlist_sha256') != metrics['netlist_sha256']:
                raise ValueError('Power netlist identity differs from this run')
            powered = summary.get('corners') or {}
            state['power'] = {'status': summary.get('status'), 'jobs': summary.get('jobs'),
                              'replaced_tool_files': summary.get('replaced_tool_files') or {},
                              'corners': {corner: powered[corner]['duration_weighted_power_W']
                                          for corner in CORNERS if corner in powered}}
            state['energy_uJ'] = {corner: powered[corner]['mean_task_energy_uJ']
                                  for corner in CORNERS if corner in powered}

        state['status'] = COMPLETE
        state['stage'] = 'REPORT_REVIEW'
        state['result_dir'] = str(ROOT / 'result')
        state['signoff_achieved'] = False
        print(state['status'], flush=True)
        indicate(state)
    except BaseException as exc:
        state['status'] = 'FAILED'
        state['error'] = str(exc)[:1600]
        raise
    finally:
        save_state(state)


def indicate(state):
    """Print recorded facts only; report completion is never acceptance."""
    for corner in CORNERS:
        row = state.get('timing', {}).get(corner)
        if row:
            state_label = 'NEGATIVE_WORST_SLACK' if row.get('negative_slack') else 'WORST_SLACK_NONNEGATIVE'
            print('%s max=%+.9g ns min=%+.9g ns %s violation_rows=%s' %
                  (corner, row['max_ns'], row['min_ns'], state_label, row.get('violation_rows')),
                  flush=True)
    if 'area_um2' in state:
        print('SOC_LIBRARY_AREA_UM2=%.6f  MACROS=%s' %
              (state['area_um2'], json.dumps(state['macros'], sort_keys=True)), flush=True)
    if 'formality' in state:
        print('FORMALITY=' + state['formality']['status'], flush=True)
    if 'power' in state:
        print('POWER=' + state['power']['status'] + ' JOBS=' + str(state['power']['jobs']), flush=True)
    print('GATE_LEVEL_SIMULATION=' + GATE_LEVEL +
          '  NOT_RUN=' + ','.join(sorted(set(NOT_RUN_ALWAYS))) +
          '  ACCEPTANCE=false', flush=True)


def tail(path):
    if not path.is_file():
        return
    with path.open('rb') as stream:
        stream.seek(max(0, path.stat().st_size - 12000))
        text = stream.read().decode('utf-8', errors='replace')
    print(str(path) + ' LAST24LINES:')
    print('\n'.join(line[:1000] for line in text.splitlines()[-24:]))


def show_results():
    path = ROOT / 'reports/pipeline.json'
    if not path.is_file():
        print('RTL3307_NOT_STARTED')
        return
    state = load(path)
    for key in ('candidate_id', 'status', 'stage', 'error'):
        if key in state:
            label = 'RECORDED_' + key.upper() if key in ('status', 'stage') else key.upper()
            print(label + '=' + str(state[key]))
    if not (ROOT / 'result/prepared.json').is_file():
        tail(ROOT / 'reports/compile.log')
        tail(ROOT / 'reports/simulation.log')
        return
    native = get_native()
    prepared = load(ROOT / 'result/prepared.json')
    data = native.results(prepared)
    print('VERIFIED_RESULT=' + str(ROOT / 'result/metrics.json'))
    functional_path = ROOT / 'reports/state.json'
    raw = functional_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != prepared['input_snapshot'][str(functional_path)]:
        raise ValueError('Functional receipt changed after result verification')
    functional = json.loads(raw.decode('utf-8'))
    cycles = functional['cycles_sum']
    print('RTL_TASKS=12 SCALAR_OUTPUTS=304128 CYCLES_SUM=%d NOMINAL_150MHZ_TPS=%.6f' %
          (cycles, 150000000.0 * 12 / cycles))
    for corner in CORNERS:
        row = data['timing'][corner]
        label = 'NEGATIVE_WORST_SLACK' if row.get('negative_slack') else 'WORST_SLACK_NONNEGATIVE'
        print('%s %s %.2fV %sC max=%+.9g ns min=%+.9g ns %s violation_rows=%s' %
              (corner, row['pvt'][0], row['pvt'][1], row['pvt'][2],
               row['worst_ns']['max'], row['worst_ns']['min'],
               label, row.get('constraint_violation_rows')))
        print('NATIVE_GLOBAL ' + corner + ' (original report precision):')
        for line in row['native_global_report_lines']:
            if line.strip():
                print(line)
    print('SOC_LIBRARY_AREA_UM2=%.6f' % data['soc']['total_um2'])
    for name in sorted(data['soc']['groups_um2']):
        print('  AREA_GROUP %-28s %.6f um2' % (name, data['soc']['groups_um2'][name]))
    proof = ROOT / 'result/formality/summary.json'
    if proof.is_file():
        summary = load(proof)
        print('FORMALITY=%s netlist=%s' % (summary['status'], summary['netlist_sha256'][:16]))
    power = ROOT / 'result/power/metrics.json'
    if power.is_file():
        summary = load(power)
        print('POWER=%s JOBS=%d' % (summary['status'], summary['jobs']))
        for corner in CORNERS:
            row = summary['corners'][corner]
            print('  POWER %s duration_weighted=%.9g W mean_task_energy=%.9g uJ' %
                  (corner, row['duration_weighted_power_W']['total_W'], row['mean_task_energy_uJ']))
    print('GATE_LEVEL_SIMULATION=' + GATE_LEVEL)
    print('REPORTS_COMPLETE; timing, electrical, coverage, proof and power review required; '
          'acceptance=false')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('check', 'run', 'results'))
    parser.add_argument('--stage', choices=STAGES, default='all',
                        help='rtl / synth / sta / lec / power run independently; all runs every stage')
    parser.add_argument('--source', type=Path, default=Path.home() / 'ref/SOC_RTL_2025/e203_hbirdv2-master')
    parser.add_argument('--archive', type=Path)
    parser.add_argument('--vcs', default='/eda/synopsys/vcs/vcs_2020.03-SP2-6/bin/vcs')
    parser.add_argument('--old-config', type=Path,
                        default=Path.home() / 'kwt_runs/R2COMPARE_20261110_193824_Am2w82/candidates/w12/result/soc/resolved_config.json')
    parser.add_argument('--ref', type=Path, default=Path.home() / 'ref')
    parser.add_argument('--timeout', type=int, default=3600)
    parser.add_argument('--fm-timeout', type=int, default=7200)
    parser.add_argument('--power-timeout', type=int, default=7200)
    parser.add_argument('--fm', default=None, help='Explicit formality executable; auto-detected when omitted')
    parser.add_argument('--jobs', type=int, default=1,
                        help='Parallel EDA invocations for LC/STA/task power; 1 = serial')
    args = parser.parse_args()
    if args.action == 'results':
        show_results()
    else:
        args.archive = args.archive or args.source.parent / 'e203_hbirdv2-master_1013_update_sim.zip'
        execute(args.action, args)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('RTL3307_PIPELINE_FAILED: ' + str(exc)[:1600], file=sys.stderr)
        sys.exit(1)
