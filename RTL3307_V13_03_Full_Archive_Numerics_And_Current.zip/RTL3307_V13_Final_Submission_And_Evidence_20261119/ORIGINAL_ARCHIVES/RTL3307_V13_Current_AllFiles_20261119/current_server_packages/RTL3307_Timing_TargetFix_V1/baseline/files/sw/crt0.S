.section .text.start,"ax",@progbits
.option push
.option norvc
.globl _start
_start:
    j boot
.option pop

.section .text.kwt_end,"ax",@progbits
.option push
.option rvc
.globl kwt_end
kwt_end:
    c.j kwt_end
.option pop

.section .text.boot,"ax",@progbits
.globl boot
boot:
    csrci mstatus, 8
    csrw mie, zero
    la sp, __stack_top
    .option push
    .option norelax
    la gp, __global_pointer$
    .option pop

    la t0, __data_load
    la t1, __data_start
    la t2, __data_end
1:  bgeu t1, t2, 2f
    lw t3, 0(t0)
    sw t3, 0(t1)
    addi t0, t0, 4
    addi t1, t1, 4
    j 1b
2:  la t1, __bss_start
    la t2, __bss_end
3:  bgeu t1, t2, 4f
    sw zero, 0(t1)
    addi t1, t1, 4
    j 3b
4:  la t0, kwt_trap
    csrw mtvec, t0
    call main

.globl kwt_finish
kwt_finish:
    csrci mstatus, 8
    li gp, 1
    beqz a0, 5f
    addi gp, a0, 2
5:  j kwt_end
