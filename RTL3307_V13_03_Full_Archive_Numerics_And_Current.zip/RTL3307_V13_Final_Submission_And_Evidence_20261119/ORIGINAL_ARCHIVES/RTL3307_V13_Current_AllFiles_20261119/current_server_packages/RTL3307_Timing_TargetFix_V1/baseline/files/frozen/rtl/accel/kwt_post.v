// Add a per-column bias, then round and clamp to the signed INT16 range.
`timescale 1ns/1ps

module kwt_post (
    input  wire                 clk,
    input  wire signed [37:0]  acc,
    input  wire signed [39:0]  bias,
    input  wire        [5:0]   shift,
    output reg  signed [15:0]  out_data,
    output reg                  sat
);

    localparam signed [41:0] MAX_OUTPUT = 42'sd32767;
    localparam signed [41:0] MIN_OUTPUT = -42'sd32768;

    reg  signed [41:0] biased_sum;
    reg         [5:0]  shift_reg;
    wire signed [41:0] quotient;
    wire        [5:0]  align_shift;
    wire        [41:0] discarded;
    wire               sticky;
    wire               increment;
    wire signed [41:0] rounded;
    wire               high;
    wire               low;

    assign quotient = biased_sum >>> shift_reg;
    // Align the highest discarded bit with bit 41. A shift of zero clears all bits.
    assign align_shift = 6'd42 - shift_reg;
    assign discarded = biased_sum << align_shift;
    assign sticky = |discarded[40:0];
    assign increment = discarded[41] & (sticky | quotient[0]);
    assign rounded = quotient + $signed({41'b0, increment});
    assign high = rounded > MAX_OUTPUT;
    assign low = rounded < MIN_OUTPUT;

    always @(posedge clk) begin
        biased_sum <= acc + bias;
        shift_reg <= shift;
    end

    always @(posedge clk) begin
        sat <= high | low;
        if (high)
            out_data <= MAX_OUTPUT[15:0];
        else if (low)
            out_data <= MIN_OUTPUT[15:0];
        else
            out_data <= rounded[15:0];
    end

endmodule
