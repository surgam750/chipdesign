source [file join [file dirname [info script]] common.tcl]

proc finite_slack {value label} {
    if {![string is double -strict $value] ||
        [catch {expr {$value > -Inf && $value < Inf}} finite] || !$finite} {
        error "Invalid/non-finite $label slack: $value"
    }
    return $value
}

finish {
    set_app_var report_default_significant_digits 9
    setup_library PT
    read_verilog [required netlist]
    if {![link_design e203_soc_top]} {error "PT link failed"}
    apply_conditions
    source [required sdc]
    foreach name {hfclk lfclk} {
        if {[sizeof_collection [get_clocks -quiet $name]] != 1} {
            error "Exactly one $name clock is required"
        }
    }
    update_timing
    macro_check
    check_timing -verbose > check_timing.rpt
    report_clock > clocks.rpt
    report_units > units.rpt
    report_lib [required op_library] > operating_condition_library.rpt
    report_analysis_coverage -status_details untested -nosplit > coverage.rpt
    report_constraint -all_violators > constraints.rpt
    report_constraint -max_transition -all_violators -significant_digits 9 -nosplit > transition.rpt
    report_constraint -min_capacitance -all_violators -significant_digits 9 -nosplit > mincap.rpt
    report_timing -delay_type max -slack_lesser_than 1.0e30 -max_paths 20 -path_type full_clock_expanded > setup.rpt
    report_timing -delay_type min -slack_lesser_than 1.0e30 -max_paths 20 -path_type full_clock_expanded > hold.rpt
    # Native global/constraint/coverage reports retain recovery and removal checks.
    report_global_timing > global.rpt
    set f [open timing.tsv w]
    puts $f "delay_type\tworst_slack_ns"
    foreach type {max min} {
        set paths [get_timing_paths -delay_type $type -slack_lesser_than 1.0e30 -max_paths 1]
        if {[sizeof_collection $paths] != 1} {error "Exactly one $type timing path is required"}
        set slack [finite_slack [get_attribute $paths slack] $type]
        puts $f "$type\t$slack"
    }
    close $f
    cell_area cells.tsv
    write_sdf design.sdf
    # This diagnostic does not replace global minimum or reset checks.
    report_timing -delay_type min -group hfclk -slack_lesser_than 1.0e30 -max_paths 5 -path_type full_clock_expanded > hfclk_min.rpt
    set paths [get_timing_paths -delay_type min -group hfclk -slack_lesser_than 1.0e30 -max_paths 1]
    if {[sizeof_collection $paths] != 1} {error "Exactly one hfclk min timing path is required"}
    set slack [finite_slack [get_attribute $paths slack] {hfclk min}]
    set start [get_object_name [get_attribute $paths startpoint]]
    set end [get_object_name [get_attribute $paths endpoint]]
    foreach name [list $start $end] {
        if {$name eq "" || [regexp {[\t\r\n]} $name]} {error "Invalid hfclk min path name"}
    }
    set f [open hfclk_min.tsv w]
    puts $f "slack_ns\tstartpoint\tendpoint"
    puts $f "$slack\t$start\t$end"
    close $f
}
