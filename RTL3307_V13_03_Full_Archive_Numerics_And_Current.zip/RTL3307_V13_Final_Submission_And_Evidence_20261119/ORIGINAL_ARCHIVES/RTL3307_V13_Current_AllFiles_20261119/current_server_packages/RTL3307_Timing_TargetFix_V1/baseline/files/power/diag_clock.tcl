# Read-only clock diagnostic for the PT-PX power stage.
# Runs the same link flow as estimate.tcl and prints the state that
# "Clock absent or wrong period: hfclk" leaves invisible.
# Nothing is written except the log redirection the caller chooses.
# Every probe is wrapped in catch so one bad command cannot stop the rest.
source [file join [file dirname [info script]] .. native common.tcl]

proc probe {label script} {
    if {[catch {uplevel 1 $script} value]} {
        puts "DIAG_$label=ERROR:$value"
    } else {
        puts "DIAG_$label=$value"
    }
}

finish {
    setup_library PT
    puts "DIAG_MARK start"

    set sdc [required sdc]
    puts "DIAG_SDC_PATH=$sdc"
    puts "DIAG_SDC_EXISTS=[file exists $sdc]"
    if {[file exists $sdc]} {puts "DIAG_SDC_SIZE=[file size $sdc]"}

    set netlist [required netlist]
    puts "DIAG_NETLIST=$netlist"
    puts "DIAG_NETLIST_EXISTS=[file exists $netlist]"
    if {[file exists $netlist]} {puts "DIAG_NETLIST_SIZE=[file size $netlist]"}

    read_verilog $netlist
    puts "DIAG_MARK after_read_verilog"

    if {![link_design e203_soc_top]} {error "DIAG link failed"}
    puts "DIAG_MARK after_link"

    probe PORT_TOTAL {llength [get_object_name [get_ports *]]}
    probe PORT_HFEXTCLK_COUNT {sizeof_collection [get_ports -quiet hfextclk]}
    probe PORT_HFEXTCLK_NAME {get_object_name [get_ports -quiet hfextclk]}
    probe PORT_LFEXTCLK_COUNT {sizeof_collection [get_ports -quiet lfextclk]}
    probe NET_HFEXTCLK_COUNT {sizeof_collection [get_nets -quiet hfextclk]}
    probe PORT_PATTERN {get_object_name [get_ports -quiet *hfextclk*]}
    probe PIN_HFEXTCLK {get_object_name [get_pins -quiet *hfextclk*]}

    apply_conditions
    puts "DIAG_MARK after_apply_conditions"

    probe CLOCKS_BEFORE {get_object_name [all_clocks]}
    probe CLOCK_COUNT_BEFORE {sizeof_collection [all_clocks]}

    # Source without letting an error abort, so the failure point is visible.
    if {[catch {source $sdc} problem]} {
        puts "DIAG_SOURCE_ERROR=$problem"
        puts "DIAG_SOURCE_ERRORINFO=$::errorInfo"
    } else {
        puts "DIAG_SOURCE_OK"
    }

    probe CLOCKS_AFTER {get_object_name [all_clocks]}
    probe CLOCK_COUNT_AFTER {sizeof_collection [all_clocks]}
    probe HFCLK_COUNT_AFTER {sizeof_collection [get_clocks -quiet hfclk]}
    probe HFCLK_PERIOD_AFTER {get_attribute -quiet [get_clocks -quiet hfclk] period}
    probe MARK end
}
