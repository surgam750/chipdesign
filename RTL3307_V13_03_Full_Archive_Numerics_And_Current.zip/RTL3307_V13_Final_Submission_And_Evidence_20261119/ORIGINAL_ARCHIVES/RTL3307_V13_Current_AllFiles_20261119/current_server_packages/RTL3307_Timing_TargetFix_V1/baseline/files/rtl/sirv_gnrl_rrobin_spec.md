# Missing original arbiter dependency

The checked public E203 `sirv_gnrl_icbs.v` references `sirv_gnrl_rrobin` for ARBT_SCHEME=1 but does not contain its definition. The supplied module is an explicit compatibility implementation, not an original-source claim. The original `sirv_gnrl_icb_arbt` remains unchanged.

For four requesters, grant at most one requester, beginning at `next_port` and wrapping. After an accepted command (`arbt_ena`), advance priority to the port following the granted port. A grant stalled at a clock edge is held until acceptance, so newly arriving requesters cannot replace its command. Reset is asynchronous active low and clears held state, with port zero initially first.

The arbiter's existing response-ID FIFO remains responsible for response routing and limits outstanding transactions to one. This helper contains no memory route or response path.

```wavedrom
{signal:[{name:'clk',wave:'p.....'},{name:'req_vec',wave:'x3....',data:['1111']},{name:'arbt_ena',wave:'01.1..'},{name:'grt_vec',wave:'x3.3.3',data:['0001','0010','0100']}]}
```

Local compile and end-to-end simulation evidence is separate from target-library synthesis and timing evidence. Compatibility implementation requires review if the official tree supplies its own definition.
