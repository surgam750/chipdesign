#include "kwt_drv.h"

int main(void)
{
    if (kwt_probe())
        return 1;
    if (KWT(KWT_STATUS) || KWT(KWT_IRQ_EN) || KWT(KWT_OPCODE) ||
        KWT(KWT_DIM_M) != 99 || KWT(KWT_DIM_K) != 64 || KWT(KWT_DIM_N) != 256 ||
        KWT(KWT_X_STRIDE) != 128 || KWT(KWT_Y_STRIDE) != 512 ||
        KWT(KWT_X_BASE) || KWT(KWT_W_BASE) || KWT(KWT_Y_BASE) ||
        KWT(0x0f0) || KWT(KWT_CTRL))
        return 2;
    KWT(KWT_DIM_K) = 0xffffffffu;
    KWT(KWT_OPCODE) = 0xffffffffu;
    KWT(KWT_IRQ_EN) = 0xffffffffu;
    if (KWT(KWT_DIM_K) != 0x3ff || KWT(KWT_OPCODE) != 0xf || KWT(KWT_IRQ_EN) != 3)
        return 3;
    KWT(KWT_IRQ_EN) = 0;
    KWT(KWT_X_BASE) = 0x11223344u;
    *(volatile uint8_t *)(uintptr_t)(KWT_BASE + KWT_X_BASE + 1) = 0xa5;
    if (KWT(KWT_X_BASE) != 0x1122a544u)
        return 4;

    /* Illegal opcode must latch BAD_CFG without starting a DMA transaction. */
    KWT(KWT_CTRL) = KWT_START;
    if ((KWT(KWT_STATUS) & 0xf0fu) != (0x300u | KWT_ERR))
        return 5;
    KWT(KWT_STATUS) = 0;
    if (!(KWT(KWT_STATUS) & KWT_ERR))
        return 6;
    KWT(KWT_STATUS) = KWT_ERR;
    if (KWT(KWT_STATUS))
        return 7;

    /* The harness supplies zero X and Wpack for a long-enough BUSY window. */
    const kwt_cfg_t cfg = {
        .x_base = 0x90001000u, .w_base = 0x90001200u, .y_base = 0x90001300u,
        .m = 99, .k = 2, .n = 2, .x_stride = 4, .y_stride = 4
    };
    if (kwt_start(&cfg) || !(KWT(KWT_STATUS) & KWT_BUSY))
        return 8;
    KWT(KWT_DIM_M) = 1;
    KWT(KWT_CTRL) = KWT_START;
    if (KWT(KWT_DIM_M) != 99 || !(KWT(KWT_STATUS) & KWT_START_IGNORED))
        return 9;
    return (kwt_wait_poll() & (KWT_DONE | KWT_ERR)) == KWT_DONE ? 0 : 10;
}
