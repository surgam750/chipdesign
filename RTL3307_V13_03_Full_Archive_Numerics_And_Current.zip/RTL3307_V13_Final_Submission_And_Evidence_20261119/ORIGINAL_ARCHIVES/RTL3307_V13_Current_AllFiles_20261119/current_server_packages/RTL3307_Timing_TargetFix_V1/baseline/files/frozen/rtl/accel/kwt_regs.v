`timescale 1ns/1ps

// ICB register bank; task configuration stays stable while the engine is busy.
module kwt_regs #(
    parameter integer FULL = 0,
    parameter integer NCOL = 2,
    parameter integer LANES = 64,
    parameter integer XDEPTH = 128,
    parameter [3:0] CFG_VERSION = 4'd1
) (
    input wire clk,
    input wire rst_n,
    input wire s_icb_cmd_valid,
    output wire s_icb_cmd_ready,
    input wire [31:0] s_icb_cmd_addr,
    input wire s_icb_cmd_read,
    input wire [31:0] s_icb_cmd_wdata,
    input wire [3:0] s_icb_cmd_wmask,
    output reg s_icb_rsp_valid,
    input wire s_icb_rsp_ready,
    output reg [31:0] s_icb_rsp_rdata,
    output wire s_icb_rsp_err,
    output wire irq,
    output wire start,
    output wire abort,
    output wire clr_perf,
    output reg [3:0] opcode,
    output reg [6:0] dim_m,
    output reg [9:0] dim_k,
    output reg [9:0] dim_n,
    output reg [31:0] x_base,
    output reg [31:0] w_base,
    output reg [31:0] y_base,
    output reg [31:0] x_stride,
    output reg [31:0] y_stride,
    output reg [31:0] aux_base,
    output reg [31:0] aux_cfg,
    input wire busy,
    input wire done_event,
    input wire error_event,
    input wire [3:0] error_code,
    input wire [31:0] error_addr,
    input wire [31:0] perf_total,
    input wire [31:0] perf_xload,
    input wire [31:0] perf_issue,
    input wire [31:0] perf_rd_stall,
    input wire [31:0] perf_wr_stall,
    input wire [31:0] perf_rd_words,
    input wire [31:0] perf_wr_words,
    input wire [31:0] perf_starve,
    input wire [31:0] task_count,
    input wire [31:0] sat_count,
    input wire [31:0] cycle_now
);

    // HWCFG stores log2 of XDEPTH relative to a 64-entry bank.
    function integer depth_log2;
        input integer depth;
        integer remaining;
        begin
            remaining = depth;
            depth_log2 = 0;
            while (remaining > 1) begin
                remaining = remaining >> 1;
                depth_log2 = depth_log2 + 1;
            end
        end
    endfunction

    localparam [3:0] XDEPTH_CODE = depth_log2(XDEPTH) - 6;
    localparam [31:0] HWCFG = {4'b0, CFG_VERSION, 3'b0, (FULL != 0),
                              XDEPTH_CODE, LANES[7:0], NCOL[7:0]};

    wire [11:0] offset;
    wire cmd_fire;
    wire wr_fire;
    wire ctrl_write;
    wire status_write;
    wire [31:0] write_mask;
    reg [31:0] read_data;
    reg [1:0] irq_en;
    reg done_sticky;
    reg error_sticky;
    reg ignored_sticky;
    reg [3:0] err_code;
    reg [31:0] err_addr;

    // E203 forwards the byte address and a separate byte-lane mask.
    assign offset = {s_icb_cmd_addr[11:2], 2'b00};
    assign s_icb_cmd_ready = rst_n && (!s_icb_rsp_valid || s_icb_rsp_ready);
    assign s_icb_rsp_err = 1'b0;
    assign cmd_fire = s_icb_cmd_valid && s_icb_cmd_ready;
    assign wr_fire = cmd_fire && !s_icb_cmd_read;
    assign ctrl_write = wr_fire && (offset == 12'h008) && s_icb_cmd_wmask[0];
    assign status_write = wr_fire && (offset == 12'h010) && s_icb_cmd_wmask[0];
    assign write_mask = {{8{s_icb_cmd_wmask[3]}}, {8{s_icb_cmd_wmask[2]}},
                         {8{s_icb_cmd_wmask[1]}}, {8{s_icb_cmd_wmask[0]}}};

    assign start = ctrl_write && s_icb_cmd_wdata[0] && !busy;
    assign abort = ctrl_write && s_icb_cmd_wdata[1];
    assign clr_perf = ctrl_write && s_icb_cmd_wdata[2];
    assign irq = (done_sticky && irq_en[0]) || (error_sticky && irq_en[1]);

    // The response captures live read data at command acceptance.
    always @* begin
        case (offset)
            12'h000: read_data = 32'h4B57_5431;
            12'h004: read_data = HWCFG;
            12'h00c: read_data = {30'b0, irq_en};
            12'h010: read_data = {15'b0, irq, 4'b0, err_code, 4'b0,
                                  ignored_sticky, error_sticky, done_sticky, busy};
            12'h014: read_data = {28'b0, opcode};
            12'h018: read_data = {25'b0, dim_m};
            12'h01c: read_data = {22'b0, dim_k};
            12'h020: read_data = {22'b0, dim_n};
            12'h024: read_data = x_base;
            12'h028: read_data = w_base;
            12'h02c: read_data = y_base;
            12'h030: read_data = x_stride;
            12'h034: read_data = y_stride;
            12'h038: read_data = aux_base;
            12'h03c: read_data = aux_cfg;
            12'h040: read_data = perf_total;
            12'h044: read_data = perf_xload;
            12'h048: read_data = perf_issue;
            12'h04c: read_data = perf_rd_stall;
            12'h050: read_data = perf_wr_stall;
            12'h054: read_data = perf_rd_words;
            12'h058: read_data = perf_wr_words;
            12'h05c: read_data = perf_starve;
            12'h060: read_data = err_addr;
            12'h064: read_data = task_count;
            12'h068: read_data = sat_count;
            12'h06c: read_data = cycle_now;
            default: read_data = 32'b0;
        endcase
    end

    // A consumed response and its replacement can use the same edge.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s_icb_rsp_valid <= 1'b0;
            s_icb_rsp_rdata <= 32'b0;
        end else if (cmd_fire) begin
            s_icb_rsp_valid <= 1'b1;
            s_icb_rsp_rdata <= s_icb_cmd_read ? read_data : 32'b0;
        end else if (s_icb_rsp_ready) begin
            s_icb_rsp_valid <= 1'b0;
        end
    end

    // A new event survives a simultaneous clear; the first uncleared error owns its metadata.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            irq_en <= 2'b0;
            done_sticky <= 1'b0;
            error_sticky <= 1'b0;
            ignored_sticky <= 1'b0;
            err_code <= 4'b0;
            err_addr <= 32'b0;
        end else begin
            if (wr_fire && (offset == 12'h00c) && s_icb_cmd_wmask[0]) begin
                irq_en <= s_icb_cmd_wdata[1:0];
            end
            if (done_event) begin
                done_sticky <= 1'b1;
            end else if (status_write && s_icb_cmd_wdata[1]) begin
                done_sticky <= 1'b0;
            end
            if (error_event) begin
                error_sticky <= 1'b1;
                if (!error_sticky || (status_write && s_icb_cmd_wdata[2])) begin
                    err_code <= error_code;
                    err_addr <= error_addr;
                end
            end else if (status_write && s_icb_cmd_wdata[2]) begin
                error_sticky <= 1'b0;
                err_code <= 4'b0;
                err_addr <= 32'b0;
            end
            if (ctrl_write && s_icb_cmd_wdata[0] && busy) begin
                ignored_sticky <= 1'b1;
            end else if (status_write && s_icb_cmd_wdata[3]) begin
                ignored_sticky <= 1'b0;
            end
        end
    end

    // Each writable field retains bytes disabled by the ICB mask.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            opcode <= 4'd0;
            dim_m <= 7'd99;
            dim_k <= 10'd64;
            dim_n <= 10'd256;
            x_base <= 32'd0;
            w_base <= 32'd0;
            y_base <= 32'd0;
            x_stride <= 32'd128;
            y_stride <= 32'd512;
            aux_base <= 32'd0;
            aux_cfg <= 32'd0;
        end else if (wr_fire && !busy) begin
            case (offset)
                12'h014: opcode <= (opcode & ~write_mask[3:0]) |
                                     (s_icb_cmd_wdata[3:0] & write_mask[3:0]);
                12'h018: dim_m <= (dim_m & ~write_mask[6:0]) |
                                     (s_icb_cmd_wdata[6:0] & write_mask[6:0]);
                12'h01c: dim_k <= (dim_k & ~write_mask[9:0]) |
                                     (s_icb_cmd_wdata[9:0] & write_mask[9:0]);
                12'h020: dim_n <= (dim_n & ~write_mask[9:0]) |
                                     (s_icb_cmd_wdata[9:0] & write_mask[9:0]);
                12'h024: x_base <= (x_base & ~write_mask[31:0]) |
                                     (s_icb_cmd_wdata[31:0] & write_mask[31:0]);
                12'h028: w_base <= (w_base & ~write_mask[31:0]) |
                                     (s_icb_cmd_wdata[31:0] & write_mask[31:0]);
                12'h02c: y_base <= (y_base & ~write_mask[31:0]) |
                                     (s_icb_cmd_wdata[31:0] & write_mask[31:0]);
                12'h030: x_stride <= (x_stride & ~write_mask[31:0]) |
                                     (s_icb_cmd_wdata[31:0] & write_mask[31:0]);
                12'h034: y_stride <= (y_stride & ~write_mask[31:0]) |
                                     (s_icb_cmd_wdata[31:0] & write_mask[31:0]);
                12'h038: aux_base <= (aux_base & ~write_mask[31:0]) |
                                     (s_icb_cmd_wdata[31:0] & write_mask[31:0]);
                12'h03c: aux_cfg <= (aux_cfg & ~write_mask[31:0]) |
                                     (s_icb_cmd_wdata[31:0] & write_mask[31:0]);
                default: begin end
            endcase
        end
    end

endmodule
