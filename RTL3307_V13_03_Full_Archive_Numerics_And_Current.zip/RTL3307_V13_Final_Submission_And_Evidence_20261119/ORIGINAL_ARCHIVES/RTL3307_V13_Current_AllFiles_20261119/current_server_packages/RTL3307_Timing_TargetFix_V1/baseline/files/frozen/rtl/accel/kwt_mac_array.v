// UG two-column arithmetic pipeline from registered products through requantization.
`timescale 1ns/1ps

module kwt_mac_array (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          in_valid,
    input  wire [1023:0] x_flat,
    input  wire [2047:0] w_flat,
    input  wire [79:0]   bias,
    input  wire [11:0]   shift,
    output wire          out_valid,
    output wire [31:0]   out_data,
    output wire [1:0]    sat
);

    reg [4:0] valid_pipe;
    genvar column;

    assign out_valid = valid_pipe[4];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            valid_pipe <= 5'b0;
        else
            valid_pipe <= {valid_pipe[3:0], in_valid};
    end

    generate
        for (column = 0; column < 2; column = column + 1) begin : g_column
            reg signed [39:0] bias_product;
            reg signed [39:0] bias_group;
            reg signed [39:0] bias_acc;
            reg [5:0] shift_product;
            reg [5:0] shift_group;
            reg [5:0] shift_acc;
            wire signed [37:0] acc;

            // Bias and shift follow the corresponding dot-product transaction.
            always @(posedge clk) begin
                bias_product <= bias[column * 40 +: 40];
                bias_group <= bias_product;
                bias_acc <= bias_group;
                shift_product <= shift[column * 6 +: 6];
                shift_group <= shift_product;
                shift_acc <= shift_group;
            end

            kwt_dot64 u_dot (
                .clk    (clk),
                .x_flat (x_flat),
                .w_flat (w_flat[column * 1024 +: 1024]),
                .acc    (acc)
            );

            kwt_post u_post (
                .clk      (clk),
                .acc      (acc),
                .bias     (bias_acc),
                .shift    (shift_acc),
                .out_data (out_data[column * 16 +: 16]),
                .sat      (sat[column])
            );
        end
    endgenerate

endmodule
