`timescale 1ns/1ps
// Participant loader frontend. All writes use the existing 32-bit System Bus
// master. Three credits use the original 2-entry command FIFO plus 1 active
// transaction; the original splitter still allows only one SRAM transaction.
module kwt_loader_dma (
    input wire clk, rst_n,
    input wire source_valid,
    output wire source_ready,
    input wire [31:0] source_addr, source_data,
    output wire idle,
    output reg error,
    output wire icb_cmd_valid,
    input wire icb_cmd_ready,
    output wire [31:0] icb_cmd_addr, icb_cmd_wdata,
    output wire icb_cmd_read,
    output wire [3:0] icb_cmd_wmask,
    input wire icb_rsp_valid,
    output wire icb_rsp_ready,
    input wire icb_rsp_err
);
    reg [1:0] pending;
    wire command_fire = icb_cmd_valid && icb_cmd_ready;
    wire response_fire = icb_rsp_valid && icb_rsp_ready;
    assign icb_cmd_valid = rst_n && source_valid && (pending < 3);
    assign source_ready = rst_n && icb_cmd_ready && (pending < 3);
    assign icb_cmd_addr = source_addr;
    assign icb_cmd_wdata = source_data;
    assign icb_cmd_wmask = 4'hf;
    assign icb_cmd_read = 1'b0;
    assign icb_rsp_ready = rst_n;
    assign idle = pending == 0 && !source_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pending <= 0;
            error <= 0;
        end else begin
            case ({command_fire, response_fire})
                2'b10: pending <= pending+1'b1;
                2'b01: pending <= pending-1'b1;
                default: pending <= pending;
            endcase
            if (response_fire && (icb_rsp_err || pending == 0)) error <= 1'b1;
        end
    end
endmodule
