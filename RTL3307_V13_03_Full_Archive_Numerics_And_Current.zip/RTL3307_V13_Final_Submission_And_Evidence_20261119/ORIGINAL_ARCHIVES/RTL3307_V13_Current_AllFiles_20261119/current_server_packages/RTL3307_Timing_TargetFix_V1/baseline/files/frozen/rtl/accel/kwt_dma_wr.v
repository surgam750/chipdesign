// KWT write ICB master. Every command writes all four bytes.
module kwt_dma_wr (
    input          clk,
    input          rst_n,
    input          req_valid,
    output         req_ready,
    input  [31:0]  req_addr,
    input  [31:0]  req_data,
    output         ret_valid,
    output [31:0]  ret_addr,
    output         ret_err,
    output         idle,
    output         icb_cmd_valid,
    input          icb_cmd_ready,
    output [31:0]  icb_cmd_addr,
    output         icb_cmd_read,
    output [31:0]  icb_cmd_wdata,
    output [3:0]   icb_cmd_wmask,
    input          icb_rsp_valid,
    output         icb_rsp_ready,
    input  [31:0]  icb_rsp_rdata,
    input          icb_rsp_err
);

    assign icb_cmd_read = 1'b0;
    assign icb_cmd_wmask = 4'hf;
    assign icb_rsp_ready = 1'b1;
    reg response_valid;
    reg response_error;
    assign ret_err = ret_valid & response_error;

    // Match the read master: error and valid cross the same register boundary.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            response_valid <= 1'b0;
            response_error <= 1'b0;
        end else begin
            response_valid <= icb_rsp_valid;
            if (icb_rsp_valid) response_error <= icb_rsp_err;
        end
    end

    // Write acknowledgements have no return-data consumer.
    kwt_dma_queue #(
        .PAYLOAD_WIDTH(64),
        .META_WIDTH(32)
    ) u_queue (
        .clk(clk),
        .rst_n(rst_n),
        .req_valid(req_valid),
        .req_ready(req_ready),
        .req_payload({req_addr, req_data}),
        .req_meta(req_addr),
        .cmd_valid(icb_cmd_valid),
        .cmd_ready(icb_cmd_ready),
        .cmd_payload({icb_cmd_addr, icb_cmd_wdata}),
        .rsp_valid(response_valid),
        .ret_valid(ret_valid),
        .ret_meta(ret_addr),
        .idle(idle)
    );
endmodule
