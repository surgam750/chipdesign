// Functional SRAM model for local simulation. Use the vendor view on the server.
`ifdef KWT_SRAM_BEHAV
module RAMSP128X16 (
    output wire [15:0] Q,
    input  wire        CLK,
    input  wire        CEN,
    input  wire [15:0] WEN,
    input  wire [6:0]  A,
    input  wire [15:0] D,
    input  wire [2:0]  EMA,
    input  wire [1:0]  EMAW,
    input  wire        GWEN,
    input  wire        RET1N
);

    reg [15:0] mem [0:127];
    reg [15:0] read_data;

    // Only an enabled read produces a valid Q. Invalidate other cycles to
    // catch accidental reliance on output hold behavior in the consumer.
    always @(posedge CLK) begin
        if ((RET1N === 1'b1) && (CEN === 1'b0) && (GWEN === 1'b1)) begin
            read_data <= mem[A];
        end else begin
            read_data <= 16'hxxxx;
        end
    end

    integer bit_index;
    always @(posedge CLK) begin
        if ((RET1N === 1'b1) && (CEN === 1'b0) && (GWEN === 1'b0)) begin
            for (bit_index = 0; bit_index < 16; bit_index = bit_index + 1) begin
                if (WEN[bit_index] === 1'b0) begin
                    mem[A][bit_index] <= D[bit_index];
                end
            end
        end
    end

    assign Q = read_data;
endmodule
`endif
