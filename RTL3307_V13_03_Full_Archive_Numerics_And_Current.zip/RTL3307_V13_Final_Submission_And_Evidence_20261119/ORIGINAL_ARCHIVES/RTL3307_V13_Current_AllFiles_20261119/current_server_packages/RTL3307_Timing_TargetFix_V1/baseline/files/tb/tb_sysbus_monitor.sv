`timescale 1ns/1ps
`define SOC tb_top.u_e203_soc_top
`define MAIN tb_top.u_e203_soc_top.u_e203_subsys_top.u_e203_subsys_main
module tb_sysbus_monitor;
    integer accepted=0, delivered=0, responses=0;
    integer contention_cycles=0, backpressure_cycles=0, master_stall_cycles=0;
    integer requester_count, queued=0, head=0, tail=0, max_queued=0;
    reg [31:0] address_q[0:2],data_q[0:2];
    reg [3:0] mask_q[0:2];
    reg read_q[0:2];
    reg pending=0;
    always @(posedge `SOC.kwt_clk) if (`SOC.kwt_rst_n===1'b1) begin
        requester_count=(`MAIN.mem_icb_cmd_valid?1:0)+(`SOC.kwt_m0_icb_cmd_valid?1:0)+
                        (`SOC.kwt_m1_icb_cmd_valid?1:0)+(`SOC.kwt_load_icb_cmd_valid?1:0);
        if(requester_count>1)contention_cycles=contention_cycles+1;
        if((`MAIN.mem_icb_cmd_valid&&!`MAIN.mem_icb_cmd_ready)||
           (`SOC.kwt_m0_icb_cmd_valid&&!`SOC.kwt_m0_icb_cmd_ready)||
           (`SOC.kwt_m1_icb_cmd_valid&&!`SOC.kwt_m1_icb_cmd_ready)||
           (`SOC.kwt_load_icb_cmd_valid&&!`SOC.kwt_load_icb_cmd_ready))
            master_stall_cycles=master_stall_cycles+1;
        if(`MAIN.bus_icb_cmd_valid&&!`MAIN.bus_icb_cmd_ready)
            backpressure_cycles=backpressure_cycles+1;
        if(`MAIN.bus_icb_cmd_valid&&`MAIN.bus_icb_cmd_ready&&
           `MAIN.bus_icb_cmd_addr>=32'hA0000000&&`MAIN.bus_icb_cmd_addr<32'hA0080000)begin
            if(queued>=3)$fatal(1,"native ingress queue capacity exceeded");
            address_q[tail]=`MAIN.bus_icb_cmd_addr;data_q[tail]=`MAIN.bus_icb_cmd_wdata;
            mask_q[tail]=`MAIN.bus_icb_cmd_wmask;read_q[tail]=`MAIN.bus_icb_cmd_read;
            tail=(tail+1)%3;queued=queued+1;accepted=accepted+1;
            if(queued>max_queued)max_queued=queued;
        end
        if(`SOC.sysmem_icb_cmd_valid&&`SOC.sysmem_icb_cmd_ready)begin
            if(pending)$fatal(1,"native SRAM single-outstanding limit exceeded");
            if(queued==0)$fatal(1,"command bypassed original System Bus");
            if(`SOC.sysmem_icb_cmd_addr!==address_q[head]||
               `SOC.sysmem_icb_cmd_read!==read_q[head]||
               (!read_q[head]&&(`SOC.sysmem_icb_cmd_wdata!==data_q[head]||
                 `SOC.sysmem_icb_cmd_wmask!==mask_q[head])))$fatal(1,"fabric corrupted/reordered command");
            head=(head+1)%3;queued=queued-1;delivered=delivered+1;pending=1;
        end
        if(`SOC.sysmem_icb_rsp_valid&&`SOC.sysmem_icb_rsp_ready)begin
            if(!pending)$fatal(1,"SRAM response without a transaction");
            if(`SOC.sysmem_icb_rsp_err)$fatal(1,"SRAM error");
            pending=0;responses=responses+1;
        end
    end
    final begin
        $display("KWT_FABRIC_COUNTS accepted=%0d delivered=%0d responses=%0d pending=%0d contention_cycles=%0d outlet_stall_cycles=%0d master_stall_cycles=%0d max_queued=%0d",
                 accepted,delivered,responses,pending,contention_cycles,backpressure_cycles,master_stall_cycles,max_queued);
        if(accepted!=delivered||delivered!=responses||pending||queued||!contention_cycles||!master_stall_cycles)
            $error("fabric accounting incomplete or contention not exercised");
    end
endmodule
`undef SOC
`undef MAIN
