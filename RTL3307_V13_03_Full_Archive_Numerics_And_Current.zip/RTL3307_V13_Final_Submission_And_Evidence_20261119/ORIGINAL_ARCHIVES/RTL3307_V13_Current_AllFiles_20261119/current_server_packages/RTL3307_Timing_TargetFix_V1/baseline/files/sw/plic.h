#ifndef KWT_PLIC_H
#define KWT_PLIC_H
#include <stdint.h>

#define KWT_PLIC_SOURCE 8u
void plic_init(void);
uint32_t plic_claim(void);
void plic_complete(uint32_t source);
#endif
