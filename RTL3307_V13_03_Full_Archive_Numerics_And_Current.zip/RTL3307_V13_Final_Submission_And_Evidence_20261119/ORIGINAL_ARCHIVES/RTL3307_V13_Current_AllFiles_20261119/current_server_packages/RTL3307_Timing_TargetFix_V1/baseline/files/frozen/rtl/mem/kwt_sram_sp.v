// High-active, full-word SRAM interface for the UG configuration.
module kwt_sram_sp #(
    parameter DEPTH = 128,
    parameter WIDTH = 16
) (
    input  wire             clk,
    input  wire             ce,
    input  wire             we,
    input  wire [6:0]       addr,
    input  wire [WIDTH-1:0] wdata,
    output wire [WIDTH-1:0] rdata
);

    generate
        if ((DEPTH == 128) && (WIDTH == 16)) begin : gen_ug
            wire macro_cen;
            wire macro_gwen;
            wire [15:0] macro_wen;

            assign macro_cen = ~ce;
            assign macro_gwen = ~we;
            assign macro_wen = {16{macro_gwen}};

            // Margin and retention defaults are provisional until vendor verification.
            RAMSP128X16 u_macro (
                .Q     (rdata),
                .CLK   (clk),
                .CEN   (macro_cen),
                .WEN   (macro_wen),
                .A     (addr),
                .D     (wdata),
                .EMA   (3'b000),
                .EMAW  (2'b00),
                .GWEN  (macro_gwen),
                .RET1N (1'b1)
            );
        end else begin : gen_unsupported
            // An unsupported configuration must fail elaboration.
            kwt_sram_sp_unsupported_configuration u_unsupported ();
        end
    endgenerate
endmodule
