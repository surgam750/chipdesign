# kwt_shared_sram specification

This synthesizable Verilog-2001 module supplies one 32-bit logical ICB slave
covering `0xA0000000..0xA007FFFF` (512 KiB). The base address is a project design
choice within the proposed original O4 route; server decoder acceptance is a
separate integration requirement. There are no parallel external bank ports.

| Port | Direction | Width | Meaning |
|---|---|---:|---|
| clk | in | 1 | Rising-edge clock |
| rst_n | in | 1 | Asynchronous active-low protocol reset |
| s_icb_cmd_valid / s_icb_cmd_ready | in / out | 1 each | Accept command only when both high |
| s_icb_cmd_read | in | 1 | One reads, zero writes |
| s_icb_cmd_addr | in | 32 | Byte address, word alignment required |
| s_icb_cmd_wdata | in | 32 | Write data |
| s_icb_cmd_wmask | in | 4 | Active-high byte enables, bit zero is data bits 7:0 |
| s_icb_rsp_valid / s_icb_rsp_ready | out / in | 1 each | Retire response only when both high |
| s_icb_rsp_rdata | out | 32 | Read value; zero for writes and rejected commands |
| s_icb_rsp_err | out | 1 | Rejected out-of-window or unaligned address |

## Storage and address mapping

Exactly 32 banks x 4096 words x 32 bits = 524288 bytes. Each bank consists of
two `RAMSP4096X16` instances. Bank index is address bits `[18:14]`, macro word
index is `[13:2]`, and bits `[1:0]` must be zero. Upper bits `[31:19]` must be
`13'h1400`. Byte masks expand to active-low per-bit WEN masks.

Native pins match the frozen `kwt_tcm_proxy.v`: Q, CLK, active-low CEN/GWEN/WEN,
A[11:0], D[15:0], EMA=011, EMAW=00, RET1N=1. Read uses GWEN=1, write uses
GWEN=0; only the selected bank's CEN asserts. Invalid commands never enable
any macro, even when write mask is nonzero. Zero write mask changes no data.

## Cycle timing and reset

At rising edge E0, valid and ready accept a request and perform its synchronous
macro read/write. State becomes CAPTURE. At E1, the read value is copied from
the retained bank's Q into the response register; state becomes RESPONSE and
response valid asserts. Thus the response is available after E1, one full
clock after acceptance. It may retire at E2 or any later edge when ready is
high. Command ready remains low through RESPONSE, including retirement, and
returns high after retirement. No same-edge request/response bypass exists.

The response register, error flag, and valid remain stable during backpressure.
Command input changes after E0 cannot affect the response. All command types,
including rejected requests, use the same response latency. Outputs are only
meaningful while their valid is asserted.

Reset immediately suppresses command ready and response valid and abandons an
outstanding response. It does not clear macro storage or Q. A write accepted
before reset is committed and is not rolled back even if its response is
abandoned. Reads of never-written memory are unspecified. A surrounding system
must reset/abort the outstanding upstream transaction consistently.

Timing diagram source (WaveJSON; renderer unavailable locally because pinned
`wavedrom@3.6.1` is absent; no rendered timing artifact is claimed):

```json
{"signal":[
 {"name":"clk","wave":"p......"},
 {"name":"cmd_valid","wave":"010...."},
 {"name":"cmd_ready","wave":"1.0...1"},
 {"name":"state","wave":"=.=.=.=","data":["IDLE","CAPTURE","RESPONSE","IDLE"]},
 {"name":"rsp_valid","wave":"0..1..0"},
 {"name":"rsp_ready","wave":"0....10"},
 {"name":"rsp_rdata","wave":"x..=...","data":["captured value"]}
]}
```

## Verification contract

`tb/models/ramsp4096x16_model.v` supplies a functional synchronous macro model
with native active-low semantics. `tests/tb_shared_sram.sv` checks all 32 banks' first and last words,
all 16 byte masks per endpoint, alternating writes/reads, changed command
inputs after acceptance, delayed response consumption, second-command refusal,
unaligned writes/reads, invalid-address alias pollution, reset in CAPTURE and
RESPONSE, accepted-write persistence over reset, every macro address bit at
interior addresses across banks, and response-ready high before acceptance. Results are actual data
comparisons, with a timeout and fatal failures.

The behavioral macro evidence does not establish native macro timing,
synthesis, original System Bus integration, server source identity, STA, GLS,
power or formal compliance. The strict skill gate result is recorded separately
and must not be inferred from simulation success.
