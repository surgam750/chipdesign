OUTPUT_ARCH(riscv)
ENTRY(_start)
MEMORY
{
    ITCM (rx) : ORIGIN = 0x80000000, LENGTH = 32K
    DTCM (rw) : ORIGIN = 0x90000000, LENGTH = 0xf00
}
SECTIONS
{
    .boot_header :
    {
        KEEP(*(.text.start))
        . = 0x86;
        KEEP(*(.text.kwt_end))
        . = 0x100;
    } > ITCM = 0

    .text :
    {
        KEEP(*(.text.boot))
        *(.text .text.*)
        . = ALIGN(4);
        /* Initialize the speculatively fetched ITCM tail. */
        FILL(0x13000000)
        . += 64;
    } > ITCM

    .rodata : { *(.rodata .rodata.* .srodata .srodata.*) } > ITCM
    .data : ALIGN(4)
    {
        __data_start = .;
        *(.data .data.* .sdata .sdata.*)
        . = ALIGN(4);
        __data_end = .;
    } > DTCM AT> ITCM
    __data_load = LOADADDR(.data);
    PROVIDE(__global_pointer$ = ORIGIN(DTCM) + 0x800);

    .bss (NOLOAD) : ALIGN(4)
    {
        __bss_start = .;
        *(.bss .bss.* .sbss .sbss.* COMMON)
        . = ALIGN(4);
        __bss_end = .;
    } > DTCM
    __stack_top = ORIGIN(DTCM) + LENGTH(DTCM);

    /DISCARD/ : { *(.comment .note.* .eh_frame .eh_frame.*) }
    ASSERT(kwt_end == 0x80000086, "wrong TB completion PC")
    ASSERT(boot == 0x80000100, "wrong startup body address")
    ASSERT(__bss_end + 1024 <= __stack_top, "firmware leaves less than 1 KiB stack")
}
