// KWT read ICB master. The response carries the original address and tag.
module kwt_dma_rd (
    input          clk,
    input          rst_n,
    input          req_valid,
    output         req_ready,
    input  [31:0]  req_addr,
    input  [15:0]  req_tag,
    output         ret_valid,
    output [31:0]  ret_data,
    output [31:0]  ret_addr,
    output [15:0]  ret_tag,
    output         ret_err,
    output         idle,
    output         icb_cmd_valid,
    input          icb_cmd_ready,
    output [31:0]  icb_cmd_addr,
    output         icb_cmd_read,
    output [31:0]  icb_cmd_wdata,
    output [3:0]   icb_cmd_wmask,
    input          icb_rsp_valid,
    output         icb_rsp_ready,
    input  [31:0]  icb_rsp_rdata,
    input          icb_rsp_err
);

    // Capture the bus payload before it can reach the X SRAM write ports.
    // Metadata is retired with the registered valid, including zero-cycle ICB.
    reg         response_valid;
    reg [31:0]  response_data;
    reg         response_error;

    assign icb_cmd_read = 1'b1;
    assign icb_cmd_wdata = 32'd0;
    assign icb_cmd_wmask = 4'd0;
    assign icb_rsp_ready = 1'b1;
    assign ret_data = response_data;
    assign ret_err = ret_valid & response_error;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            response_valid <= 1'b0;
            response_data <= 32'd0;
            response_error <= 1'b0;
        end else begin
            response_valid <= icb_rsp_valid;
            if (icb_rsp_valid) begin
                response_data <= icb_rsp_rdata;
                response_error <= icb_rsp_err;
            end
        end
    end

    kwt_dma_queue #(
        .PAYLOAD_WIDTH(32),
        .META_WIDTH(48)
    ) u_queue (
        .clk(clk),
        .rst_n(rst_n),
        .req_valid(req_valid),
        .req_ready(req_ready),
        .req_payload(req_addr),
        .req_meta({req_addr, req_tag}),
        .cmd_valid(icb_cmd_valid),
        .cmd_ready(icb_cmd_ready),
        .cmd_payload(icb_cmd_addr),
        .rsp_valid(response_valid),
        .ret_valid(ret_valid),
        .ret_meta({ret_addr, ret_tag}),
        .idle(idle)
    );
endmodule
