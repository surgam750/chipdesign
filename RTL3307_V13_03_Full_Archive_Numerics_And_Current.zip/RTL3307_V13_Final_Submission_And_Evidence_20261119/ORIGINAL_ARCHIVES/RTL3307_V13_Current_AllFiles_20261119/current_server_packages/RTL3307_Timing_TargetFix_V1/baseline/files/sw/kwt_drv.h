#ifndef KWT_DRV_H
#define KWT_DRV_H

#include <stdint.h>

#define KWT_BASE 0x10041000u
#define MMIO32(address) (*(volatile uint32_t *)(uintptr_t)(address))
#define KWT(offset) MMIO32(KWT_BASE + (offset))

enum {
    KWT_ID = 0x00, KWT_HWCFG = 0x04, KWT_CTRL = 0x08, KWT_IRQ_EN = 0x0c,
    KWT_STATUS = 0x10, KWT_OPCODE = 0x14, KWT_DIM_M = 0x18,
    KWT_DIM_K = 0x1c, KWT_DIM_N = 0x20, KWT_X_BASE = 0x24,
    KWT_W_BASE = 0x28, KWT_Y_BASE = 0x2c, KWT_X_STRIDE = 0x30,
    KWT_Y_STRIDE = 0x34, KWT_AUX_BASE = 0x38, KWT_AUX_CFG = 0x3c,
    KWT_PERF = 0x40, KWT_SAT_COUNT = 0x68
};
enum {
    KWT_START = 1u, KWT_ABORT = 2u,
    KWT_BUSY = 1u, KWT_DONE = 2u, KWT_ERR = 4u, KWT_START_IGNORED = 8u,
    KWT_IRQ = 1u << 16, KWT_W1C = KWT_DONE | KWT_ERR | KWT_START_IGNORED
};
typedef struct {
    uint32_t x_base, w_base, y_base, aux_base, aux_cfg;
    uint16_t m, k, n, x_stride, y_stride;
    uint8_t opcode;
} kwt_cfg_t;
typedef struct {
    uint32_t counters[8]; /* TOTAL, XLOAD, ISSUE, RD/WR_STALL, RD/WR_WORDS, STARVE */
    uint32_t sat;
} kwt_perf_t;

static inline void kwt_fence(void)
{
    __asm__ volatile ("fence iorw, iorw" ::: "memory");
}

int kwt_probe(void);
void kwt_irq_init(void);
void kwt_select_irq(int irq);
int kwt_start(const kwt_cfg_t *c);
int kwt_wait_irq(void);
int kwt_wait_poll(void);
void kwt_read_perf(kwt_perf_t *p);
void kwt_abort(void);
void kwt_isr(void);

#endif
