"""Create a checked KWT overlay from a fresh E203 reference tree."""

import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent.parent
SUBSYS = "rtl/e203/subsys/"
PERIPS = SUBSYS + "e203_subsys_perips.v"
MAIN = SUBSYS + "e203_subsys_main.v"
TOP = SUBSYS + "e203_subsys_top.v"
PLIC = SUBSYS + "e203_subsys_plic.v"
PLIC_TOP = "rtl/e203/perips/sirv_plic_top.v"
SOC = "rtl/e203/soc/e203_soc_top.v"
CONFIG = "rtl/e203/core/config.v"
TB = "tb/tb_top.v"
RUN = "vsim/bin/run.makefile"
INPUTS = (PERIPS, MAIN, TOP, PLIC, PLIC_TOP, SOC, CONFIG, TB, RUN)
TCM_INPUTS = ("rtl/e203/core/e203_itcm_ram.v", "rtl/e203/core/e203_dtcm_ram.v")
BOOT_INPUTS = ("rtl/e203/mems/sirv_mrom_top.v", "rtl/e203/mems/sirv_mrom.v")
CLOCK_INPUT = "rtl/e203/generic/GENERIC_RVT_SMIC.v"

ICB = (
    ("cmd_valid", "", "output"),
    ("cmd_ready", "", "input"),
    ("cmd_addr", "[31:0]", "output"),
    ("cmd_read", "", "output"),
    ("cmd_wdata", "[31:0]", "output"),
    ("cmd_wmask", "[3:0]", "output"),
    ("rsp_valid", "", "input"),
    ("rsp_ready", "", "output"),
    ("rsp_rdata", "[31:0]", "input"),
    ("rsp_err", "", "input"),
)
CLOCK_IRQ = (("kwt_clk", "output"), ("kwt_rst_n", "output"), ("ai_irq", "input"))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def within(path, parent):
    return path == parent or parent in path.parents


class Editor:
    def __init__(self, path, original):
        self.path = path
        self.newline = "\r\n" if b"\r\n" in original else "\n"
        self.text = original.decode("latin1").replace("\r\n", "\n")

    def match(self, pattern):
        matches = list(re.finditer(pattern, self.text, re.MULTILINE))
        if len(matches) != 1:
            context = [self.text[max(0, m.start()-45):m.start()+85] for m in matches[:3]]
            raise ValueError(f"{self.path}: expected one anchor {pattern!r}, "
                             f"found {len(matches)}; context {context!r}")
        return matches[0]

    def replace(self, pattern, replacement):
        match = self.match(pattern)
        value = replacement(match) if callable(replacement) else replacement
        self.text = self.text[:match.start()] + value + self.text[match.end():]

    def literal(self, anchor, replacement):
        self.replace(re.escape(anchor), replacement)

    def prepend_ports(self, module, ports):
        anchor = f"module {module}("
        self.literal(anchor, anchor + "\n" + "\n".join(ports))

    def bytes(self):
        return self.text.replace("\n", self.newline).encode("latin1")


def signal_ports(port_prefix, wire_prefix):
    return [f".{port_prefix}_icb_{suffix}({wire_prefix}_icb_{suffix})"
            for suffix, _, _ in ICB]


def add_connections(editor, instance_pattern, connections):
    editor.replace(instance_pattern, lambda m: m[0] + "\n    "
                   + ",\n    ".join(connections) + ",")


def add_irq_input(editor, module):
    if re.search(r"^\s*input\s+(?:wire\s+)?ai_irq\s*,", editor.text, re.MULTILINE):
        editor.match(r"^\s*input\s+(?:wire\s+)?ai_irq\s*,")
    else:
        editor.prepend_ports(module, ["  input ai_irq,"])


def patch_peripheral_path(editors):
    port_lines = [f"  {direction} {width + ' ' if width else ''}kwt_icb_{suffix},"
                  for suffix, width, direction in ICB]
    perips = editors[PERIPS]
    perips.prepend_ports("e203_subsys_perips", port_lines)
    perips.literal("  // * Here is an example AXI Peripheral\n  .O14_BASE_ADDR",
                   "  // * KWT accelerator register window\n  .O14_BASE_ADDR")
    perips.match(r"^  \.O14_BASE_ADDR +\(32'h1004_1000\),[ \t]*$")
    perips.match(r"^  \.O14_BASE_REGION_LSB +\(12\),$")
    for suffix, _, _ in ICB:
        perips.replace(rf"^  wire [^\n]*\bexpl_axi_icb_{suffix};[ \t]*\n", "")
        original = "1'b0 " if suffix == "rsp_err" else rf"expl_axi_icb_{suffix}[ ]*"
        perips.replace(rf"^(    \.o14_icb_{suffix} +\(){original}(\),)$",
                       lambda m: m[1] + f"kwt_icb_{suffix}" + m[2])
    perips.replace(
        r"^  // \* Here is an example AXI Peripheral\n  wire expl_axi_arvalid;\n"
        r"(?:(?!^  sirv_hclkgen_regs)[\s\S])*?"
        r"u_expl_axi_icb2axi\([\s\S]*?u_perips_expl_axi_slv \([\s\S]*?^  \);\n",
        "",
    )
    if "expl_axi_" in perips.text:
        raise ValueError(f"{PERIPS}: example AXI references remain")

    main = editors[MAIN]
    top = editors[TOP]
    for editor, module in ((main, "e203_subsys_main"), (top, "e203_subsys_top")):
        add_irq_input(editor, module)
        editor.prepend_ports(module, port_lines + ["  output kwt_clk,", "  output kwt_rst_n,"])
    ppi = signal_ports("kwt", "kwt")
    add_connections(main, r"^  e203_subsys_perips u_e203_subsys_perips \($", ppi)
    main.match(r"^    \.ls_clk +\(ls_clk  \),\n    \.clk +\(hfclk  \),\n"
               r"    \.bus_rst_n +\(bus_rst_n\),[ \t]*\n    \.rst_n +\(per_rst_n\)")
    main.literal("  wire bus_rst_n  = main_rst_n;",
                 "  wire bus_rst_n  = main_rst_n;\n"
                 "  assign kwt_clk = hfclk;\n"
                 "  assign kwt_rst_n = bus_rst_n;")
    add_connections(top, r"^  e203_subsys_main  u_e203_subsys_main\($",
                    ppi + [f".{wire}({wire})" for wire, _ in CLOCK_IRQ
                           if not re.search(rf"\.({wire})\s*\(", top.text)])

    plic = editors[PLIC]
    add_irq_input(plic, "e203_subsys_plic")
    if not re.search(r"\.ai_irq\s*\(", main.text):
        add_connections(main, r"^ e203_subsys_plic u_e203_subsys_plic\($", [".ai_irq(ai_irq)"])
    main.match(r"^ e203_subsys_plic u_e203_subsys_plic\([\s\S]*?\.ai_irq\s*\(\s*ai_irq\s*\)")
    plic.replace(r"^(  wire plic_irq_i_7 += )(?:qspi2_irq|ai_irq);$",
                 lambda m: m[1] + "ai_irq;")
    plic.match(r"^    \.io_devices_0_7 +\(plic_irq_i_7 \),$")
    editors[PLIC_TOP].match(r"^ +io_devices_0_7 +,\n +io_devices_0_6 +,")


def patch_soc(editor):
    # Measurement master reaches the actual external TCM ports; its mux is synthesized.
    host_ports = ["  input kwt_host_active,", "  output kwt_write_rsp_valid,",
                  "  output kwt_write_rsp_ready,", "  output kwt_write_rsp_err,"]
    for bank in ("itcm", "dtcm"):
        for suffix, width, direction in ICB:
            host_direction = "input" if direction == "output" else "output"
            host_ports.append(f"  {host_direction} {width + ' ' if width else ''}kwt_host_{bank}_{suffix},")
    editor.prepend_ports("e203_soc_top", host_ports)
    wires = ["  wire kwt_clk, kwt_rst_n, kwt_irq;"]
    for prefix in ("kwt", "kwt_m0", "kwt_m1", "ext2itcm", "ext2dtcm"):
        for suffix, width, _ in ICB:
            if suffix == "cmd_addr" and prefix.startswith("ext2"):
                width = f"[`E203_{prefix[4:].upper()}_ADDR_WIDTH-1:0]"
            wires.append(f"  wire {width + ' ' if width else ''}{prefix}_icb_{suffix};")
    accel = [".clk(kwt_clk)", ".rst_n(kwt_rst_n)", ".irq(kwt_irq)"]
    accel += signal_ports("s", "kwt")
    masters = signal_ports("m0", "kwt_m0") + signal_ports("m1", "kwt_m1")
    router = [".clk(kwt_clk)", ".rst_n(kwt_rst_n)"] + masters
    router += signal_ports("itcm", "router_itcm") + signal_ports("dtcm", "router_dtcm")
    for bank in ("itcm", "dtcm"):
        for suffix, width, direction in ICB:
            if suffix == "cmd_addr":
                width = f"[`E203_{bank.upper()}_ADDR_WIDTH-1:0]"
            wires.append(f"  wire {width + ' ' if width else ''}router_{bank}_icb_{suffix};")
            ext = f"ext2{bank}_icb_{suffix}"
            route = f"router_{bank}_icb_{suffix}"
            host = f"kwt_host_{bank}_{suffix}"
            forward = direction == "output"
            if forward:
                wires.append(f"  assign {ext} = kwt_host_active ? {host} : {route};")
            else:
                wires.append(f"  assign {host} = kwt_host_active ? {ext} : 0;")
                wires.append(f"  assign {route} = kwt_host_active ? 0 : {ext};")
    wires.extend(["  assign kwt_write_rsp_valid = kwt_m1_icb_rsp_valid;",
                  "  assign kwt_write_rsp_ready = kwt_m1_icb_rsp_ready;",
                  "  assign kwt_write_rsp_err = kwt_m1_icb_rsp_err;"])
    blocks = [
        "  kwt_accel_top #(\n"
        "    .WIN0_SIZE(32'd1 << `E203_ITCM_ADDR_WIDTH),\n"
        "    .WIN1_SIZE(32'd1 << `E203_DTCM_ADDR_WIDTH)\n"
        "  ) u_kwt_accel (\n    " + ",\n    ".join(accel + masters) + "\n  );",
        "  kwt_icb_router2x2 #(\n"
        "    .ITCM_AW(`E203_ITCM_ADDR_WIDTH),\n"
        "    .DTCM_AW(`E203_DTCM_ADDR_WIDTH)\n"
        "  ) u_kwt_router (\n    " + ",\n    ".join(router) + "\n  );",
    ]
    anchor = " e203_subsys_top u_e203_subsys_top("
    editor.literal(anchor, "\n".join(wires) + "\n\n" + "\n\n".join(blocks) + "\n\n" + anchor)
    add_connections(editor, r"^ e203_subsys_top u_e203_subsys_top\($",
                    signal_ports("kwt", "kwt") + [".kwt_clk(kwt_clk)", ".kwt_rst_n(kwt_rst_n)",
                                                  ".ai_irq(kwt_irq)"])
    defaults = {"cmd_valid": "1'b0", "cmd_read": "1'b0", "cmd_wdata": "32'b0",
                "cmd_wmask": "4'b0", "rsp_ready": "1'b0"}
    for tcm in ("itcm", "dtcm"):
        for suffix, _, _ in ICB:
            signal = f"ext2{tcm}_icb_{suffix}"
            expected = (f"`E203_{tcm.upper()}_ADDR_WIDTH'b0" if suffix == "cmd_addr"
                        else defaults.get(suffix, ""))
            editor.replace(rf"^(    \.{signal} +\(){re.escape(expected)}[ ]*\),$",
                           lambda m: m[1] + signal + "),")


def patch_config(editor, width):
    for tcm in ("ITCM", "DTCM"):
        pattern = rf"^(`define E203_CFG_{tcm}_ADDR_WIDTH +)(16|18)([ \t]*)$"
        match = editor.match(pattern)
        if width is not None and int(match[2]) != width:
            editor.replace(pattern, lambda m: m[1] + str(width) + m[3])


def patch_sim(editors, *, direct_vcs=False):
    tb = editors[TB]
    tb.literal("module tb_top();",
               "module tb_top();\n\n"
               "  kwt_tb_harness u_kwt();\n"
               "`ifdef ENABLE_TB_FORCE\n"
               '  initial $fatal(1, "ENABLE_TB_FORCE conflicts with KWT PLIC IRQ");\n'
               "`endif")
    host_connections = [".kwt_host_active(u_kwt.host_active)",
                        ".kwt_write_rsp_valid()", ".kwt_write_rsp_ready()", ".kwt_write_rsp_err()"]
    for bank in ("itcm", "dtcm"):
        host_connections.extend(f".kwt_host_{bank}_{suffix}(u_kwt.host_{bank}_{suffix})"
                                for suffix, _, _ in ICB)
    add_connections(tb, r"^e203_soc_top u_e203_soc_top\($", host_connections)
    tb.literal('`include "e203_defines.v"', '`timescale 1ns/1ps\n`include "e203_defines.v"')
    tb.literal("     #2 clk <= ~clk;",
               "`ifdef KWT_CLK_150M\n     #3.333 clk <= ~clk;\n"
               "`else\n     #2 clk <= ~clk;\n`endif")
    tb.literal("    #40000000",
               "    integer kwt_timeout_ns;\n"
               '    if (!$value$plusargs("KWT_TIMEOUT_NS=%d", kwt_timeout_ns))\n'
               "      kwt_timeout_ns = 40000000;\n"
               '    if (kwt_timeout_ns <= 0) $fatal(1, "KWT_TIMEOUT_NS must be positive");\n'
               "    #(kwt_timeout_ns)")
    if direct_vcs:
        return  # The runner supplies the sources, defines and timescale itself.
    run = editors[RUN]
    run.replace(r"^(SIM_OPTIONS +:= [^\n]* -timescale=)1ns/(?:10|1)ps$", lambda m: m[1] + "1ns/1ps")
    run.replace(r"^(SIM_OPTIONS +:= [^\n]* -full64 -timescale=1ns/1ps)$",
                lambda m: m[0] + "\nSIM_OPTIONS   += -f ../kwt_extra.f +define+KWT_CLK_150M\n"
                "ifeq ($(KWT_SRAM_BEHAV),1)\n"
                "SIM_OPTIONS   += +define+KWT_SRAM_BEHAV\n"
                "endif\n"
                "ifeq ($(KWT_COV),1)\n"
                "SIM_OPTIONS   += -cm line+cond+fsm+branch+tgl+assert\n"
                "KWT_RUN_ARGS  += -cm line+cond+fsm+branch+tgl+assert\n"
                "endif")
    run.replace(r"^(SIM_OPTIONS +:= -o vvp\.exec [^\n]*)$",
                lambda m: m[0] + " -f ../kwt_extra.f -DKWT_CLK_150M -gno-assertions\n"
                "ifeq ($(KWT_SRAM_BEHAV),1)\n"
                "SIM_OPTIONS   += -DKWT_SRAM_BEHAV\n"
                "endif")
    run.replace(r"^(ifeq \(\$\(SMIC130LL\),1\)[ \t]*\nSIM_OPTIONS)", lambda m:
                "ifeq ($(KWT_SAIF),1)\nKWT_RUN_ARGS  += +KWT_SAIF=1\nendif\n\n" + m[0])
    run.literal("${SIM_EXEC} +DUMPWAVE=", "${SIM_EXEC} ${KWT_RUN_ARGS} ${KWT_PLUSARGS} +DUMPWAVE=")
    run.literal("${SIM_TOOL} ${SIM_OPTIONS} ", "${SIM_TOOL} ${SIM_OPTIONS} ${KWT_SIM_OPTIONS} ")
    run.literal("compile.flg: ${RTL_V_FILES} ${TB_V_FILES}",
                "compile.flg: ${RTL_V_FILES} ${TB_V_FILES} ../kwt_extra.f $(wildcard ../../tb/kwt/*)")


def patch_tcm_proxy(editor, bank):
    # Bind before the real wrapper's FPGA/ASIC selection, not in an unused child.
    prefix = "`E203_" + bank.upper() + "_RAM_"
    branch = ("\n`ifdef KWT_TCM_MACRO\n"
              "  kwt_tcm_proxy #(\n"
              f"    .DP({prefix}DP), .DW({prefix}DW), .MW({prefix}MW), .AW({prefix}AW)\n"
              "  ) u_kwt_tcm (\n"
              "    .clk(clk), .rst_n(rst_n), .cs(cs), .we(we), .addr(addr),\n"
              "    .din(din), .wem(wem), .dout(dout)\n"
              "  );\n`else\n")
    editor.replace(rf"\bmodule\s+e203_{bank}_ram\s*\([\s\S]*?\n\s*\);",
                   lambda match: match[0] + branch)
    editor.replace(r"^[ \t]*endmodule[ \t]*$", "`endif\nendmodule")


def patch_boot_rom_logic(editor):
    # Select the supplied RTL ROM body locally; do not define global FPGA mode.
    condition = r"^([ \t]*`ifn?def)[ \t]+FPGA[ \t]*$"
    if re.search(condition, editor.text, re.MULTILINE):
        editor.replace(condition, lambda match:
                       "`ifdef KWT_TCM_MACRO\n`define KWT_ROM_LOGIC\n"
                       "`elsif FPGA\n`define KWT_ROM_LOGIC\n`endif\n" +
                       match[1] + " KWT_ROM_LOGIC")
        editor.replace(r"^[ \t]*endmodule[ \t]*$", "`undef KWT_ROM_LOGIC\nendmodule")
    else:
        # The public reference already instantiates only the supplied logic ROM.
        editor.match(r"\bsirv_mrom[ \t]*#\s*\(")
        if "ROM1KX32" in editor.text:
            raise ValueError("unsupported physical boot ROM selection")


def patch_clockgate_logic(editor):
    # Retarget only the supplied clock-gate wrapper's existing low-phase latch branch.
    pattern = r"^[ \t]*module[ \t]+GENERIC_CLOCKGATE_RVT\b[\s\S]*?^[ \t]*endmodule\b"
    original = editor.match(pattern)[0]
    if "CLKLANAQV4_8TR40" not in original:
        raise ValueError("reviewed clock-gate technology reference changed")
    block = Editor(editor.path + "::GENERIC_CLOCKGATE_RVT", original.encode("latin1"))
    block.replace(r"^([ \t]*`ifdef)[ \t]+FPGA([ \t]*(?://[^\n]*)?)$", lambda match:
                  "`ifdef KWT_TCM_MACRO\n`define KWT_CLOCKGATE_LOGIC\n"
                  "`elsif FPGA\n`define KWT_CLOCKGATE_LOGIC\n`endif\n" +
                  match[1] + " KWT_CLOCKGATE_LOGIC" + match[2])
    block.replace(r"^[ \t]*endmodule[ \t]*$", "`undef KWT_CLOCKGATE_LOGIC\nendmodule")
    editor.replace(pattern, block.text)


def additions():
    files = {"rtl/e203/kwt/kwt_tcm_proxy.v": (HERE / "kwt_tcm_proxy.v").read_bytes()}
    for directory in ("accel", "soc", "mem"):
        for path in sorted((PROJECT / "rtl" / directory).glob("*.v")):
            files[f"rtl/e203/kwt/{path.name}"] = path.read_bytes()
    extra = sorted((PROJECT / "rtl/mem/local_models").glob("*.v"))
    extra += sorted((PROJECT / "tb/soc").glob("*.sv"))
    for path in extra:
        files[f"tb/kwt/{path.name}"] = path.read_bytes()
    files["vsim/kwt_extra.f"] = "".join(f"../../tb/kwt/{p.name}\n" for p in extra).encode("ascii")
    return files


def report_text(src, dst, expect, before, after, memory_only=False):
    lines = [f"KWT E203 overlay\nsource: {src}\ndestination: {dst}\nexpected SHA-256: {expect}\n"]
    if memory_only:
        lines.extend(["Mode: memory-only area baseline; original SoC/peripheral/IRQ preserved.\n",
                      "Same TCM macro proxy, supplied RTL ROM and clock-gate selectors.\n",
                      "No accelerator, router, host adapter, testbench or Makefile patch.\n",
                      "Expected SRAM instances: RAMSP128X16=1088, RAMSP4096X16=64, RAMSP8KX32=8; synthesis must verify.\n\n"])
    else:
        lines.extend([
             "PPI14 (0x10041000) -> kwt_icb_* -> u_kwt_accel.s_icb_*\n",
             "KWT M0/M1 -> u_kwt_router -> ext2itcm_icb_*/ext2dtcm_icb_*\n",
             "u_kwt_accel.irq -> kwt_irq -> ai_irq (subsys_top/main/plic) -> "
             "plic_irq_i_7 -> io_devices_0_7 (PLIC source 8)\n",
             "u_kwt_accel/u_kwt_router use hfclk and bus_rst_n from e203_subsys_main\n\n"])
    for path, new in sorted(after.items()):
        old = before.get(path)
        old_hash = digest(old) if old is not None else "-"
        lines.append(f"{path}  {old_hash}  ->  {digest(new)}\n")
    lines.append("\n")
    for path, new in sorted(after.items()):
        old = before.get(path)
        if old == new:
            continue
        lines.extend(difflib.unified_diff(
            (old or b"").decode("utf-8", "replace").replace("\r\n", "\n").splitlines(keepends=True),
            new.decode("utf-8", "replace").replace("\r\n", "\n").splitlines(keepends=True),
            f"a/{path}" if old is not None else "/dev/null", f"b/{path}", lineterm="\n"))
    return "".join(lines)


def write_synthesis_inventory(dst):
    rtl = dst / "rtl/e203"
    sources = sorted(path.resolve() for path in rtl.rglob("*.v"))
    includes = [rtl / "core", rtl / "perips", rtl / "perips/apb_i2c"]
    with (dst / "soc_sources.f").open("x", encoding="ascii") as stream:
        stream.write("+define+KWT_TCM_MACRO\n")
        stream.writelines("+incdir+{}\n".format(path.resolve().as_posix()) for path in includes)
        stream.writelines(path.as_posix() + "\n" for path in sources)
    hashes = {str(path): digest(path.read_bytes()) for path in sources}
    with (dst / "source_hashes.json").open("x", encoding="ascii") as stream:
        stream.write(json.dumps(hashes, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--src", type=Path, required=True)
    parser.add_argument("--dst", type=Path, required=True)
    parser.add_argument("--tcm-aw", type=int, choices=(18,))
    parser.add_argument("--expect", type=Path, default=HERE / "public_e203_sha256.json")
    parser.add_argument("--report", type=Path, help="defaults to <dst>/patch_report.txt")
    parser.add_argument("--tcm-proxy", action="store_true", help="add reviewed physical TCM macro branch")
    parser.add_argument("--clockgate-rtl", action="store_true",
                        help="select supplied low-phase clock-gate RTL for target-library mapping")
    parser.add_argument("--memory-only", action="store_true",
                        help="same reviewed memory/ROM/clock baseline without accelerator/host/IRQ patches")
    parser.add_argument("--direct-vcs", action="store_true", help="leave the verified Makefile unchanged")
    args = parser.parse_args()
    src, dst = args.src.resolve(), args.dst.resolve()
    report = args.report.resolve() if args.report else dst / "patch_report.txt"
    try:
        if not src.is_dir():
            raise ValueError(f"Source is not a directory: {src}")
        if args.dst.is_symlink() or dst.exists() or within(dst, src):
            raise ValueError(f"Destination must be fresh and outside the source: {dst}")
        if report.exists() or within(report, src):
            raise ValueError(f"Report path must be fresh and outside the source: {report}")
        expected = json.loads(args.expect.read_text(encoding="utf-8"))
        if args.memory_only and not (args.tcm_proxy and args.clockgate_rtl):
            raise ValueError("--memory-only requires --tcm-proxy and --clockgate-rtl")
        if args.clockgate_rtl and not args.tcm_proxy:
            raise ValueError("--clockgate-rtl requires the explicit --tcm-proxy measurement configuration")
        inputs = (INPUTS + (TCM_INPUTS + BOOT_INPUTS if args.tcm_proxy else ()) +
                  ((CLOCK_INPUT,) if args.clockgate_rtl else ()))
        before = {path: (src / path).read_bytes() for path in inputs}
        for path, data in before.items():
            actual = digest(data)
            if expected.get(path) != actual:
                raise ValueError(f"{path}: SHA-256 mismatch, expected {expected.get(path)}, "
                                 f"found {actual}. Use a reviewed S0 --expect manifest for the official tree.")
        editors = {path: Editor(path, data) for path, data in before.items()}
        if args.memory_only:
            for bank in ("ITCM", "DTCM"):
                if not re.search(rf"`define\s+E203_CFG_{bank}_ADDR_WIDTH\s+18\b", editors[CONFIG].text):
                    raise ValueError("memory-only baseline requires the reviewed 18-bit TCM configuration")
        else:
            patch_peripheral_path(editors)
            patch_soc(editors[SOC])
        patch_config(editors[CONFIG], args.tcm_aw)
        if not args.memory_only:
            patch_sim(editors, direct_vcs=args.direct_vcs)
        if args.tcm_proxy:
            for path, bank in zip(TCM_INPUTS, ("itcm", "dtcm")):
                patch_tcm_proxy(editors[path], bank)
            patch_boot_rom_logic(editors[BOOT_INPUTS[0]])
        if args.clockgate_rtl:
            patch_clockgate_logic(editors[CLOCK_INPUT])
        new_files = ({"rtl/e203/kwt/kwt_tcm_proxy.v": (HERE / "kwt_tcm_proxy.v").read_bytes()}
                     if args.memory_only else additions())
        for path in new_files:
            if (src / path).exists() or (src / path).is_symlink() or dst / path == report:
                raise ValueError(f"Overlay file collides with existing file or report path: {path}")
        if within(report, dst) and (src / report.relative_to(dst)).exists():
            raise ValueError(f"Report would collide with copied source: {report}")
        after = {path: editor.bytes() for path, editor in editors.items()}
        after.update(new_files)
        audit = report_text(src, dst, args.expect, before, after, args.memory_only)
        def ignore_products(directory, names):
            exclude = {".git"}
            if Path(directory) == src / "vsim":
                exclude.update(("install", "run"))
            return exclude.intersection(names)

        shutil.copytree(src, dst, ignore=ignore_products)
        for path, data in before.items():
            if (dst / path).read_bytes() != data:
                raise ValueError(f"{path}: source changed during copy")
        for path, data in after.items():
            if before.get(path) != data:
                target = dst / path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        report.parent.mkdir(parents=True, exist_ok=True)
        with report.open("x", encoding="utf-8", newline="\n") as output:
            output.write(audit)
        if args.memory_only:
            write_synthesis_inventory(dst)
    except (OSError, ValueError, AttributeError) as error:
        parser.exit(1, f"patch_soc: {error}\n")
    print(f"KWT_SOC_PATCH_PASS destination={dst} report={report}")


if __name__ == "__main__":
    main()
