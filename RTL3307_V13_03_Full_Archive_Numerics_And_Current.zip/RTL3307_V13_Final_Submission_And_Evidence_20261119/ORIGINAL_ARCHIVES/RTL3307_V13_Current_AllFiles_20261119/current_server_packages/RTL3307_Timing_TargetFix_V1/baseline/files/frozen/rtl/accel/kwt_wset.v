// Two UG operand register sets. The controller owns their lifetime and validity.
module kwt_wset (
    input  wire          clk,
    input  wire          wr_en,
    input  wire          wr_set,
    input  wire [6:0]    wr_word,
    input  wire [31:0]   wr_data,
    input  wire          rd_set,
    output wire [2047:0] rd_weights,
    output wire [79:0]   rd_bias,
    output wire [11:0]   rd_shift
);

    wire [4095:0] stored_weights;
    wire [159:0] stored_bias;
    wire [23:0] stored_shift;

    genvar set_index;
    genvar lane;
    generate
        for (set_index = 0; set_index < 2; set_index = set_index + 1) begin : gen_set
            localparam SET_SELECT = (set_index != 0);
            wire set_write;
            reg [79:0] bias;
            reg [11:0] shift;

            assign set_write = wr_en & (wr_set == SET_SELECT);
            assign stored_bias[set_index*80 +: 80] = bias;
            assign stored_shift[set_index*12 +: 12] = shift;

            // Two header words per column: bias low, then bias high and shift.
            always @(posedge clk) begin
                if (set_write) begin
                    case (wr_word)
                        7'd0: bias[31:0] <= wr_data;
                        7'd1: {shift[5:0], bias[39:32]} <= wr_data[13:0];
                        7'd2: bias[71:40] <= wr_data;
                        7'd3: {shift[11:6], bias[79:72]} <= wr_data[13:0];
                        default: begin end
                    endcase
                end
            end

            // Forty-eight physical words hold 128 signed twelve-bit weights.
            wire [1535:0] packed_weights;
            for (lane = 0; lane < 48; lane = lane + 1) begin : gen_word
                localparam [6:0] WEIGHT_WORD = lane + 4;
                reg [31:0] weight_word;
                always @(posedge clk) begin
                    if (set_write && (wr_word == WEIGHT_WORD)) begin
                        weight_word <= wr_data;
                    end
                end
                assign packed_weights[lane*32 +: 32] = weight_word;
            end
            for (lane = 0; lane < 64; lane = lane + 1) begin : gen_lane
                wire signed [11:0] even_weight;
                wire signed [11:0] odd_weight;
                assign even_weight = packed_weights[lane*24 +: 12];
                assign odd_weight = packed_weights[lane*24 + 12 +: 12];
                // Sign-extension preserves the established MAC input interface.
                assign stored_weights[set_index*2048 + lane*16 +: 16] = even_weight;
                assign stored_weights[set_index*2048 + 1024 + lane*16 +: 16] = odd_weight;
            end
        end
    endgenerate

    // Each column occupies a contiguous slice of the selected operand set.
    assign rd_weights = rd_set ? stored_weights[4095:2048] : stored_weights[2047:0];
    assign rd_bias = rd_set ? stored_bias[159:80] : stored_bias[79:0];
    assign rd_shift = rd_set ? stored_shift[23:12] : stored_shift[11:0];
endmodule
