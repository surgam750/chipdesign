"""Capture receipts for the twelve RTL task windows. All reported times are integer ps."""
from decimal import Decimal
import hashlib
import json
import mmap
from pathlib import Path
import re


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def check(value, message):
    if not value:
        raise ValueError(message)


def windows(log):
    def ordered(pattern):
        rows = [list(map(int, row)) for row in re.findall(pattern, log, re.M)]
        check([r[0] for r in rows] == list(range(12)), 'Expected twelve ordered RTL window/task records')
        return rows
    markers = ordered(r'^KWT_RTL_ACTIVITY id=(\d+) start_ps=(\d+) stop_ps=(\d+) period_ps=(\d+) offset_ps=(\d+)\s*$')
    harness = ordered(r'^KWT_WINDOW id=(\d+) layer=(\d+) start_cycle=(\d+) end_cycle=(\d+) cycles=(\d+)\s*$')
    tasks = ordered(r'^KWT_TASK id=(\d+) layer=(\d+) cycles=(\d+) x_rsp=3168 w_rsp=6656 y_rsp=12672 checked=12672 mism=0 PASS\s*$')
    rows = []
    previous_stop = previous_cycle = -1
    for (i, start, stop, period, offset), (_, layer, first, last, cycles), (_, task_layer, task_cycles) in zip(markers, harness, tasks):
        check(layer == task_layer == i and last-first == cycles == task_cycles and cycles > 0,
              'Task layer or independent RTL cycle count mismatch')
        check(start > previous_stop and first > previous_cycle and 0 < offset < period and
              stop-start == cycles*period-offset, 'Overlapping or phase/duration-mismatched RTL windows')
        rows.append(dict(task=i, layer=layer, start_cycle=first, end_cycle=last, cycles=cycles,
                         start_ps=start, stop_ps=stop, duration_ps=stop-start, period_ps=period, offset_ps=offset))
        previous_stop, previous_cycle = stop, last
    return rows


def inspect_saif(path, duration_ps, period_ps):
    """Read two exact DUT-level witnesses without materializing the full RTL design."""
    scales = {'s': Decimal('1e12'), 'ms': Decimal('1e9'), 'us': Decimal('1e6'),
              'ns': Decimal('1e3'), 'ps': Decimal(1), 'fs': Decimal('1e-3')}
    targets = {'hfextclk', 'kwt_load_icb_cmd_valid'}
    path = Path(path)
    check(path.is_file() and not path.is_symlink() and path.stat().st_size, 'SAIF missing or empty: ' + str(path))
    with path.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
        header = data[:4096]
        scale = re.search(rb'\(TIMESCALE\s+([0-9.eE+-]+)\s*(s|ms|us|ns|ps|fs)\s*\)', header)
        duration = re.search(rb'\(DURATION\s+([0-9.eE+-]+)\s*\)', header)
        check(scale and duration, 'Native SAIF lacks timescale/duration')
        tick = Decimal(scale[1].decode()) * scales[scale[2].decode()]
        check(tick > 0 and Decimal(duration[1].decode())*tick == duration_ps,
              'SAIF duration differs from independently timed RTL boundaries')
        # Each stack entry describes an S-expression. Only copy sentinel fields at the DUT root.
        syntax = rb'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\(\s*("(?:\\.|[^"\\])*"|[^\s()]+)|\)'
        stack, instances, witnesses = [], [], {}
        for match in re.finditer(syntax, data):
            if match[0] == b')':
                check(stack, 'Unbalanced native SAIF')
                if stack.pop() == b'INSTANCE':
                    instances.pop()
                continue
            if match[1] is None:
                continue
            tag = match[1].strip(b'"')
            if tag == b'INSTANCE':
                name = re.match(rb'\s*("[^"]+"|[^\s()]+)', data[match.end():match.end()+1024])
                check(name, 'Missing SAIF instance name')
                instances.append(name[1].strip(b'"').decode('ascii'))
            if len(stack) and stack[-1] in (b'NET', b'PORT') and tag in (b'hfextclk', b'kwt_load_icb_cmd_valid'):
                scope = '/'.join(instances)
                if scope in ('tb_top/u_e203_soc_top', 'u_e203_soc_top'):
                    name = tag.decode()
                    check(name not in witnesses, 'Duplicate DUT SAIF sentinel ' + name)
                    sub = re.match(rb'(?:\s*\([A-Za-z0-9_]+\s+[0-9.eE+-]+\s*\))+\s*\)', data[match.end():match.end()+2048])
                    check(sub, 'Malformed SAIF scalar witness ' + name)
                    fields = dict((k.decode(), Decimal(v.decode())) for k, v in
                                  re.findall(rb'\(([A-Za-z0-9_]+)\s+([0-9.eE+-]+)\s*\)', sub[0]))
                    check(all(k in fields for k in ('T0','T1','TC')) and all(v.is_finite() and v >= 0 for v in fields.values()) and
                          sum(fields.get(k, 0) for k in ('T0','T1','TX','TZ'))*tick == duration_ps and
                          fields.get('TX',0) == fields.get('TZ',0) == 0 and fields['TC'] == int(fields['TC']) > 0,
                          'SAIF missing duration, unknowns or active transitions on ' + name)
                    if name == 'hfextclk':
                        check(abs(float(fields['TC'])-2.0*duration_ps/period_ps) <= 2,
                              'SAIF HF clock toggle count differs from measured task clock')
                    witnesses[name] = {k: int(v) if v == int(v) else float(v) for k,v in fields.items()}
                    if set(witnesses) == targets:
                        check(data[-128:].rstrip().endswith(b')'), 'SAIF ended prematurely')
                        return dict(strip_path=scope, tick_ps=str(tick), sentinels=witnesses)
            stack.append(tag)
    raise ValueError('Native SAIF lacks directly active hfextclk and loader command valid in the DUT root')


def capture(report, work):
    log = report/'simulation.log'
    rows = windows(log.read_text(errors='replace'))
    names = {'task_%02d.saif' % i for i in range(12)}
    check({p.name for p in work.glob('task_*.saif')} == names, 'Unexpected or incomplete task SAIF set')
    for row in rows:
        path = work/('task_%02d.saif' % row['task'])
        row.update(inspect_saif(path, row['duration_ps'], row['period_ps']))
        row.update(file=path.name, bytes=path.stat().st_size, sha256=sha(path))
    check(len({row['strip_path'] for row in rows}) == 1, 'Task SAIF DUT scope changed')
    return dict(schema=1, source='VCS_FUNCTIONAL_RTL_TASK_SAIF', hierarchy='tb_top.u_e203_soc_top',
                start='First streamed loader-source command assertion, including arbitration wait',
                end='12672th output write response at the rising edge, before verification reads',
                measured_clock='Actual simulated clock in ps; SDC nominal clock is retained separately',
                simulation_log_sha256=sha(log), monitor_sha256=sha(Path(__file__).with_name('task_activity.sv')),
                windows=rows)


def seal(report, work):
    path = report/'activity/manifest.json'
    path.parent.mkdir(exist_ok=False)
    data = capture(report, work)
    path.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    return path


def verified(report, work, expected):
    path = report/'activity/manifest.json'
    check(sha(path) == expected, 'RTL activity manifest changed')
    data = json.loads(path.read_text(encoding='utf-8'))
    check(data == capture(report, work), 'RTL task SAIF/log differs from its functional receipt')
    return data

