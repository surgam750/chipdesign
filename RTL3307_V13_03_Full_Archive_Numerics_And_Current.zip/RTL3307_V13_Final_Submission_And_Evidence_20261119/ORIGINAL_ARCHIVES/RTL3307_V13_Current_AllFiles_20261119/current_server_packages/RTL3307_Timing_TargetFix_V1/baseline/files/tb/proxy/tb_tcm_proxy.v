// Standalone functional check for kwt_tcm_proxy (128X16 row slicing).
//
//   vcs -full64 -sverilog -timescale=1ns/1ps +define+KWT_SRAM_BEHAV -o simv_proxy \
//       payload/native/support/kwt_tcm_proxy.v \
//       payload/tb/models/ramsp128x16_model.v \
//       payload/tb/proxy/tb_tcm_proxy.v
//   ./simv_proxy
//
// Expected output on success:  TCM_PROXY_PASS words=32768
// The whole 32K word space is exercised, so every bank, every one of the 32 row
// slices and every 16-bit group is covered; a wrong bank/row/byte mapping cannot
// pass. A shadow array records what was written, so the check does not depend on
// any bit-twiddling pattern function.
`timescale 1ns/1ps
module tb_tcm_proxy;
    localparam integer DP = 32768;
    localparam integer DW = 64;
    localparam integer MW = 8;
    localparam integer AW = 15;

    reg clk;
    reg rst_n;
    reg cs;
    reg we;
    reg [AW-1:0] addr;
    reg [DW-1:0] din;
    reg [MW-1:0] wem;
    wire [DW-1:0] dout;

    kwt_tcm_proxy #(.DP(DP), .DW(DW), .MW(MW), .AW(AW)) u_dut (
        .clk(clk), .rst_n(rst_n), .cs(cs), .we(we),
        .addr(addr), .din(din), .wem(wem), .dout(dout)
    );

    initial clk = 1'b0;
    always #3.333333 clk = ~clk;

    reg [DW-1:0] shadow [0:DP-1];
    integer errors;
    integer i;
    reg [AW-1:0] ia;   // avoid part-select of an integer; truncation is implicit
    reg [DW-1:0] got;
    reg [DW-1:0] want;
    reg [DW-1:0] data;

    task check(input [AW-1:0] a);
        begin
            got = dout;
            want = shadow[a];
            if (got !== want) begin
                errors = errors + 1;
                if (errors <= 8)
                    $display("MISMATCH a=%0d bank=%0d row=%0d got=%h want=%h",
                             a, u_dut.read_bank, u_dut.read_row, got, want);
            end
        end
    endtask

    initial begin
        errors = 0;
        cs = 1'b0; we = 1'b0;
        addr = {AW{1'b0}}; din = {DW{1'b0}}; wem = {MW{1'b0}};
        rst_n = 1'b0;
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        repeat (2) @(posedge clk);

        // Phase 1: write every word, one per cycle, all byte lanes enabled.
        for (i = 0; i < DP; i = i + 1) begin
            ia = i;
            data = {ia, ia, ia, ia[AW-1:4]};
            shadow[ia] = data;
            @(posedge clk);
            cs <= 1'b1; we <= 1'b1;
            addr <= ia; din <= data; wem <= {MW{1'b1}};
        end
        @(posedge clk);
        cs <= 1'b1; we <= 1'b0; addr <= {AW{1'b0}};
        @(posedge clk);

        // Phase 2: read back every word, one address at a time.
        //   edge N   : drive cs/addr
        //   edge N+1 : proxy latches addr, macro captures it, Q becomes valid
        //   edge N+2 : cs deasserted, retained indices still hold -> sample dout
        for (i = 0; i < DP; i = i + 1) begin
            ia = i;
            @(posedge clk);
            cs <= 1'b1; we <= 1'b0; addr <= ia;
            @(posedge clk);
            cs <= 1'b0;
            @(posedge clk);
            check(ia);
            if (i < 10)
                $display("TRACE a=%0d bank=%0d row=%0d got=%h want=%h",
                         ia, u_dut.read_bank, u_dut.read_row, dout, shadow[ia]);
        end

        // Phase 3: byte enables. Fill all ones, then clear only bytes 0..3.
        @(posedge clk);
        cs <= 1'b1; we <= 1'b1; addr <= 15'd100; din <= {DW{1'b1}}; wem <= {MW{1'b1}};
        @(posedge clk);
        cs <= 1'b1; we <= 1'b1; addr <= 15'd100; din <= {DW{1'b0}}; wem <= 8'b0000_1111;
        @(posedge clk);
        cs <= 1'b1; we <= 1'b0; addr <= 15'd100;
        @(posedge clk);
        cs <= 1'b0;
        @(posedge clk);
        got = dout;
        want = 64'hFFFFFFFF_00000000;
        $display("BYTE_MASK bank=%0d row=%0d got=%h want=%h",
                 u_dut.read_bank, u_dut.read_row, got, want);
        if (got !== want) errors = errors + 1;

        // Phase 4: same address twice in a row; the retained row index must hold.
        @(posedge clk);
        cs <= 1'b1; we <= 1'b0; addr <= 15'd4096;
        @(posedge clk);
        cs <= 1'b0;
        @(posedge clk);
        got = dout;
        want = shadow[15'd4096];
        $display("REPEAT bank=%0d row=%0d got=%h want=%h",
                 u_dut.read_bank, u_dut.read_row, got, want);
        if (got !== want) errors = errors + 1;

        if (errors == 0) $display("TCM_PROXY_PASS words=%0d", DP);
        else $display("TCM_PROXY_FAIL errors=%0d", errors);
        $finish;
    end

    initial begin
        #2000000;
        $display("TCM_PROXY_TIMEOUT");
        $finish;
    end
endmodule
