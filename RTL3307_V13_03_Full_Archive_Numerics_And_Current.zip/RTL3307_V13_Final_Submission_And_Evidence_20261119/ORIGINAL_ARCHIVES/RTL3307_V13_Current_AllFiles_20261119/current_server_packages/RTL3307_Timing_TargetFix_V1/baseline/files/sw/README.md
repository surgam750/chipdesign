# Shared-SystemBus firmware

Use `out/t_linear_irq.verilog` for the new harness. This image was rebuilt from
isolated C/assembly sources, not edited as hex. `mailbox.h` moves the mailbox to
`0xA0000F00`; the E203 driver, MMIO address `0x10041000`, PLIC source 8, trap,
WFI wake sequence, stack and private IRQ state are preserved. X/W/Y addresses
come from the mailbox (A0001000/A0010000/A0020000 supplied by the harness).
The DTCM remains the CPU's stack/private-data region, never task storage.

Build on Windows from this directory:

```powershell
./build.ps1 -ToolchainPrefix D:/Codex/FPGA_CNN/mcu_soc_20261019/trial/toolchain/gcc/bin/riscv64-unknown-elf-
```

Or use `make CROSS=/path/to/bin/riscv-none-elf-`. Toolchain must support
`rv32imac_zicsr`. Rebuild emits ELF, disassembly, byte image and SHA256 list.
`check_image.py` verifies entry/exit, ITCM bounds and the original stack symbol.

Source provenance is in `source_provenance.json`. The source workspace was
read only and dirty before this task; hashes identify the exact copied files.
The `t_regs` legacy diagnostic and polling variant are retained as source
context/build outputs only, and are not SystemBus acceptance tests. The new
harness always requests IRQ mode; no task reset occurs between GO requests.
