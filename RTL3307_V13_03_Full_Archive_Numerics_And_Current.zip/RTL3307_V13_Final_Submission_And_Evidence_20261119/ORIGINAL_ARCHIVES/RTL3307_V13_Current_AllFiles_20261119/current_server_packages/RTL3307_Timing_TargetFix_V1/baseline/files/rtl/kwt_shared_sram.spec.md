# Shared SRAM contract

The full same-name contract, port table, cycle timing, reset semantics and
verification limits are in [kwt_shared_sram_spec.md](kwt_shared_sram_spec.md).
This entry preserves the implementation plan's requested `.spec.md` filename.
