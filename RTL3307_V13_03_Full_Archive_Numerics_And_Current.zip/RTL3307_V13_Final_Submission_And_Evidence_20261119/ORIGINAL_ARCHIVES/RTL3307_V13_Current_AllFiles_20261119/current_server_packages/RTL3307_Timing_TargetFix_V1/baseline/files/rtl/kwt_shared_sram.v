// Single-port 512 KiB memory behind one 32-bit ICB slave.
// 32 banks contain two native 4096 x 16 macros each.
module kwt_shared_sram (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        s_icb_cmd_valid,
    output wire        s_icb_cmd_ready,
    input  wire        s_icb_cmd_read,
    input  wire [31:0] s_icb_cmd_addr,
    input  wire [31:0] s_icb_cmd_wdata,
    input  wire [3:0]  s_icb_cmd_wmask,
    output wire        s_icb_rsp_valid,
    input  wire        s_icb_rsp_ready,
    output wire [31:0] s_icb_rsp_rdata,
    output wire        s_icb_rsp_err
);
    // The macro performs its synchronous operation on command acceptance E0.
    // Its Q is available during E0->E1; the response is retired at E1 or later.
    // Preserve Q in a register after the first cycle if the response stalls.
    reg pending;
    reg captured;
    reg [4:0] read_bank;
    reg read_pending;
    reg access_error;
    reg [31:0] response_data;
    wire command_accept;
    wire address_valid;
    wire memory_enable;
    wire [1023:0] bank_data;
    wire [31:0] live_data = read_pending ? bank_data[read_bank*32 +: 32] : 32'b0;

    assign address_valid = (s_icb_cmd_addr[31:19] == 13'h1400) &&
                           (s_icb_cmd_addr[1:0] == 2'b00);
    assign s_icb_cmd_ready = rst_n && !pending;
    assign command_accept = s_icb_cmd_valid && s_icb_cmd_ready;
    assign memory_enable = command_accept && address_valid;
    // A synchronous write commits at command_accept. Its acknowledgement may
    // be accepted at that same edge, as supported by the original splitter.
    // If response-ready is low, retain the completion and do not repeat the write.
    wire write_response = command_accept && !s_icb_cmd_read;
    assign s_icb_rsp_valid = rst_n && (pending || write_response);
    assign s_icb_rsp_rdata = pending ? (captured ? response_data : live_data) : 32'b0;
    assign s_icb_rsp_err = pending ? access_error : !address_valid;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pending <= 1'b0;
            captured <= 1'b0;
            read_bank <= 5'b0;
            read_pending <= 1'b0;
            access_error <= 1'b0;
            response_data <= 32'b0;
        end else begin
            if (command_accept) begin
                pending <= s_icb_cmd_read || !s_icb_rsp_ready;
                captured <= 1'b0;
                read_bank <= s_icb_cmd_addr[18:14];
                read_pending <= s_icb_cmd_read && address_valid;
                access_error <= !address_valid;
            end
            if (pending) begin
                if (!captured) begin
                    response_data <= live_data;
                    captured <= 1'b1;
                end
                if (s_icb_rsp_ready) pending <= 1'b0;
            end
        end
    end


    genvar bank, lane;
    generate
        for (bank = 0; bank < 32; bank = bank + 1) begin : gen_bank
            wire bank_select;
            assign bank_select = memory_enable && (s_icb_cmd_addr[18:14] == bank);
            for (lane = 0; lane < 2; lane = lane + 1) begin : gen_lane
                wire [15:0] write_disable;
                assign write_disable = {{8{!s_icb_cmd_wmask[lane*2+1]}},
                                         {8{!s_icb_cmd_wmask[lane*2]}}};
                RAMSP4096X16 u_ram (
                    .Q(bank_data[bank*32+lane*16 +: 16]),
                    .CLK(clk),
                    .CEN(!bank_select),
                    .GWEN(s_icb_cmd_read),
                    .WEN(write_disable),
                    .A(s_icb_cmd_addr[13:2]),
                    .D(s_icb_cmd_wdata[lane*16 +: 16]),
                    .EMA(3'b011),
                    .EMAW(2'b00),
                    .RET1N(1'b1)
                );
            end
        end
    endgenerate
endmodule
