`timescale 1ns/1ps
`default_nettype none

// A 16-word pipeline queue. The controller reserves capacity before issuing.
module kwt_out_fifo (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        flush,
    input  wire        push,
    input  wire [31:0] push_data,
    input  wire        pop,
    output wire [31:0] pop_data,
    output wire        empty
);
    reg [3:0] write_index;
    reg [3:0] read_index;
    reg [4:0] count;
    wire [511:0] read_terms;
    reg [31:0] selected_data;
    integer entry;
    genvar slot;

    assign empty = count == 0;
    assign pop_data = selected_data;

    generate
        for (slot = 0; slot < 16; slot = slot + 1) begin : gen_slot
            reg [31:0] data;
            always @(posedge clk) begin
                if (push && !flush && write_index == slot[3:0])
                    data <= push_data;
            end
            assign read_terms[slot*32 +: 32] =
                (read_index == slot[3:0]) ? data : 32'b0;
        end
    endgenerate

    always @* begin
        selected_data = 32'b0;
        for (entry = 0; entry < 16; entry = entry + 1)
            selected_data = selected_data | read_terms[entry*32 +: 32];
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            write_index <= 0;
            read_index <= 0;
            count <= 0;
        end else if (flush) begin
            write_index <= 0;
            read_index <= 0;
            count <= 0;
        end else begin
            if (push) write_index <= write_index + 1'b1;
            if (pop) read_index <= read_index + 1'b1;
            case ({push, pop})
                2'b10: count <= count + 1'b1;
                2'b01: count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end
endmodule

`default_nettype wire
