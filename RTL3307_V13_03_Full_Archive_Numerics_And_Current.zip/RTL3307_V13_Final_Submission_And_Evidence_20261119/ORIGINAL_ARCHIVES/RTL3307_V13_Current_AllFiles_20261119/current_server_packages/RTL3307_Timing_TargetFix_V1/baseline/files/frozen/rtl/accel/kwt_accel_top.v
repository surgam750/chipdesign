`timescale 1ns/1ps
`default_nettype none

// Undergraduate PC16 accelerator, System Bus control and two ICB data masters.
module kwt_accel_top #(
    parameter [31:0] WIN0_BASE = 32'h8000_0000,
    parameter [31:0] WIN0_SIZE = 32'h0004_0000,
    parameter [31:0] WIN1_BASE = 32'h9000_0000,
    parameter [31:0] WIN1_SIZE = 32'h0004_0000
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        s_icb_cmd_valid,
    output wire        s_icb_cmd_ready,
    input  wire [31:0] s_icb_cmd_addr,
    input  wire        s_icb_cmd_read,
    input  wire [31:0] s_icb_cmd_wdata,
    input  wire [3:0]  s_icb_cmd_wmask,
    output wire        s_icb_rsp_valid,
    input  wire        s_icb_rsp_ready,
    output wire [31:0] s_icb_rsp_rdata,
    output wire        s_icb_rsp_err,
    output wire m0_icb_cmd_valid,
    input  wire m0_icb_cmd_ready,
    output wire [31:0] m0_icb_cmd_addr,
    output wire m0_icb_cmd_read,
    output wire [31:0] m0_icb_cmd_wdata,
    output wire [3:0] m0_icb_cmd_wmask,
    input  wire m0_icb_rsp_valid,
    output wire m0_icb_rsp_ready,
    input  wire [31:0] m0_icb_rsp_rdata,
    input  wire m0_icb_rsp_err,
    output wire m1_icb_cmd_valid,
    input  wire m1_icb_cmd_ready,
    output wire [31:0] m1_icb_cmd_addr,
    output wire m1_icb_cmd_read,
    output wire [31:0] m1_icb_cmd_wdata,
    output wire [3:0] m1_icb_cmd_wmask,
    input  wire m1_icb_rsp_valid,
    output wire m1_icb_rsp_ready,
    input  wire [31:0] m1_icb_rsp_rdata,
    input  wire m1_icb_rsp_err,
    output wire        irq
);
    wire start, abort, clr_perf, busy, done_event, error_event;
    wire [3:0] opcode, error_code;
    wire [6:0] dim_m, row_read, lane_count;
    wire [9:0] dim_k, dim_n;
    wire [31:0] x_base, w_base, y_base, x_stride, y_stride, error_addr;
    wire [31:0] unused_aux_base, unused_aux_cfg;
    wire [31:0] perf_total, perf_xload, perf_issue, perf_rd_stall, perf_wr_stall;
    wire [31:0] perf_rd_words, perf_wr_words, perf_starve, task_count, sat_count, cycle_now;
    wire rd_cmd_fire, wr_cmd_fire, rd_cmd_stall, wr_cmd_stall;
    wire rd_req_valid, rd_req_ready, rd_ret_valid, rd_ret_err, rd_idle;
    wire wr_req_valid, wr_req_ready, wr_ret_valid, wr_ret_err, wr_idle;
    wire [31:0] rd_req_addr, rd_ret_data, rd_ret_addr, wr_req_addr, wr_ret_addr;
    wire [15:0] rd_req_tag, rd_ret_tag;
    wire x_write, w_write, row_issue, x_capture, mac_valid, mac_set, mac_out_valid;
    wire x_write_raw, row_issue_raw;
    wire fifo_empty, fifo_push, fifo_pop, fifo_flush;
    wire [1023:0] raw_x, masked_x;
    reg  [1023:0] x_captured;
    wire [2047:0] raw_weights, masked_weights;
    wire [79:0] bias;
    wire [11:0] shift;
    wire [31:0] mac_out, fifo_data;
    wire [1:0] mac_sat;
    genvar lane;

    assign rd_cmd_fire = m0_icb_cmd_valid && m0_icb_cmd_ready;
    assign wr_cmd_fire = m1_icb_cmd_valid && m1_icb_cmd_ready;
    assign rd_cmd_stall = m0_icb_cmd_valid && !m0_icb_cmd_ready;
    assign wr_cmd_stall = m1_icb_cmd_valid && !m1_icb_cmd_ready;

    always @(posedge clk) begin
        if (x_capture) x_captured <= raw_x;
    end

    generate
        for (lane = 0; lane < 64; lane = lane + 1) begin : gen_lane_mask
            wire lane_enabled;
            assign lane_enabled = lane_count > lane[6:0];
            assign masked_x[lane*16 +: 16] =
                lane_enabled ? x_captured[lane*16 +: 16] : 16'b0;
            assign masked_weights[lane*16 +: 16] =
                lane_enabled ? raw_weights[lane*16 +: 16] : 16'b0;
            assign masked_weights[1024+lane*16 +: 16] =
                lane_enabled ? raw_weights[1024+lane*16 +: 16] : 16'b0;
        end
    endgenerate

    kwt_regs u_regs (
        .clk(clk),
        .rst_n(rst_n),
        .s_icb_cmd_valid(s_icb_cmd_valid),
        .s_icb_cmd_ready(s_icb_cmd_ready),
        .s_icb_cmd_addr(s_icb_cmd_addr),
        .s_icb_cmd_read(s_icb_cmd_read),
        .s_icb_cmd_wdata(s_icb_cmd_wdata),
        .s_icb_cmd_wmask(s_icb_cmd_wmask),
        .s_icb_rsp_valid(s_icb_rsp_valid),
        .s_icb_rsp_ready(s_icb_rsp_ready),
        .s_icb_rsp_rdata(s_icb_rsp_rdata),
        .s_icb_rsp_err(s_icb_rsp_err),
        .irq(irq),
        .start(start),
        .abort(abort),
        .clr_perf(clr_perf),
        .opcode(opcode),
        .dim_m(dim_m),
        .dim_k(dim_k),
        .dim_n(dim_n),
        .x_base(x_base),
        .w_base(w_base),
        .y_base(y_base),
        .x_stride(x_stride),
        .y_stride(y_stride),
        .aux_base(unused_aux_base),
        .aux_cfg(unused_aux_cfg),
        .busy(busy),
        .done_event(done_event),
        .error_event(error_event),
        .error_code(error_code),
        .error_addr(error_addr),
        .perf_total(perf_total),
        .perf_xload(perf_xload),
        .perf_issue(perf_issue),
        .perf_rd_stall(perf_rd_stall),
        .perf_wr_stall(perf_wr_stall),
        .perf_rd_words(perf_rd_words),
        .perf_wr_words(perf_wr_words),
        .perf_starve(perf_starve),
        .task_count(task_count),
        .sat_count(sat_count),
        .cycle_now(cycle_now)
    );

    kwt_ctrl #(
        .WIN0_BASE(WIN0_BASE), .WIN0_SIZE(WIN0_SIZE),
        .WIN1_BASE(WIN1_BASE), .WIN1_SIZE(WIN1_SIZE)
    ) u_ctrl (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .abort(abort),
        .clr_perf(clr_perf),
        .opcode(opcode),
        .dim_m(dim_m),
        .dim_k(dim_k),
        .dim_n(dim_n),
        .x_base(x_base),
        .w_base(w_base),
        .y_base(y_base),
        .x_stride(x_stride),
        .y_stride(y_stride),
        .busy(busy),
        .done_event(done_event),
        .error_event(error_event),
        .error_code(error_code),
        .error_addr(error_addr),
        .perf_total(perf_total),
        .perf_xload(perf_xload),
        .perf_issue(perf_issue),
        .perf_rd_stall(perf_rd_stall),
        .perf_wr_stall(perf_wr_stall),
        .perf_rd_words(perf_rd_words),
        .perf_wr_words(perf_wr_words),
        .perf_starve(perf_starve),
        .task_count(task_count),
        .sat_count(sat_count),
        .cycle_now(cycle_now),
        .rd_cmd_fire(rd_cmd_fire),
        .wr_cmd_fire(wr_cmd_fire),
        .rd_cmd_stall(rd_cmd_stall),
        .wr_cmd_stall(wr_cmd_stall),
        .rd_req_valid(rd_req_valid),
        .rd_req_ready(rd_req_ready),
        .rd_req_addr(rd_req_addr),
        .rd_req_tag(rd_req_tag),
        .rd_ret_valid(rd_ret_valid),
        .rd_ret_err(rd_ret_err),
        .rd_idle(rd_idle),
        .rd_ret_addr(rd_ret_addr),
        .rd_ret_data(rd_ret_data),
        .rd_ret_tag(rd_ret_tag),
        .wr_req_valid(wr_req_valid),
        .wr_req_ready(wr_req_ready),
        .wr_req_addr(wr_req_addr),
        .wr_ret_valid(wr_ret_valid),
        .wr_ret_err(wr_ret_err),
        .wr_idle(wr_idle),
        .wr_ret_addr(wr_ret_addr),
        .x_write(x_write),
        .w_write(w_write),
        .row_issue(row_issue),
        .x_write_raw(x_write_raw),
        .row_issue_raw(row_issue_raw),
        .row_read(row_read),
        .x_capture(x_capture),
        .mac_valid(mac_valid),
        .mac_set(mac_set),
        .lane_count(lane_count),
        .mac_out_valid(mac_out_valid),
        .mac_sat(mac_sat),
        .fifo_empty(fifo_empty),
        .fifo_push(fifo_push),
        .fifo_pop(fifo_pop),
        .fifo_flush(fifo_flush)
    );

    kwt_dma_rd u_reader (
        .clk(clk),
        .rst_n(rst_n),
        .req_valid(rd_req_valid),
        .req_ready(rd_req_ready),
        .req_addr(rd_req_addr),
        .req_tag(rd_req_tag),
        .ret_valid(rd_ret_valid),
        .ret_data(rd_ret_data),
        .ret_addr(rd_ret_addr),
        .ret_tag(rd_ret_tag),
        .ret_err(rd_ret_err),
        .idle(rd_idle),
        .icb_cmd_valid(m0_icb_cmd_valid),
        .icb_cmd_ready(m0_icb_cmd_ready),
        .icb_cmd_addr(m0_icb_cmd_addr),
        .icb_cmd_read(m0_icb_cmd_read),
        .icb_cmd_wdata(m0_icb_cmd_wdata),
        .icb_cmd_wmask(m0_icb_cmd_wmask),
        .icb_rsp_valid(m0_icb_rsp_valid),
        .icb_rsp_ready(m0_icb_rsp_ready),
        .icb_rsp_rdata(m0_icb_rsp_rdata),
        .icb_rsp_err(m0_icb_rsp_err)
    );

    kwt_dma_wr u_writer (
        .clk(clk),
        .rst_n(rst_n),
        .req_valid(wr_req_valid),
        .req_ready(wr_req_ready),
        .req_addr(wr_req_addr),
        .req_data(fifo_data),
        .ret_valid(wr_ret_valid),
        .ret_addr(wr_ret_addr),
        .ret_err(wr_ret_err),
        .idle(wr_idle),
        .icb_cmd_valid(m1_icb_cmd_valid),
        .icb_cmd_ready(m1_icb_cmd_ready),
        .icb_cmd_addr(m1_icb_cmd_addr),
        .icb_cmd_read(m1_icb_cmd_read),
        .icb_cmd_wdata(m1_icb_cmd_wdata),
        .icb_cmd_wmask(m1_icb_cmd_wmask),
        .icb_rsp_valid(m1_icb_rsp_valid),
        .icb_rsp_ready(m1_icb_rsp_ready),
        .icb_rsp_rdata(m1_icb_rsp_rdata),
        .icb_rsp_err(m1_icb_rsp_err)
    );

    kwt_xbuf u_xbuf (
        .clk(clk), .rst_n(rst_n), .wr_en(x_write_raw), .wr_row(rd_ret_tag[13:7]),
        .wr_pair(rd_ret_tag[4:0]), .wr_data(rd_ret_data),
        .rd_en(row_issue_raw), .rd_row(row_read), .rd_lanes(raw_x)
    );

    kwt_wset u_wset (
        .clk(clk), .wr_en(w_write), .wr_set(rd_ret_tag[14]),
        .wr_word(rd_ret_tag[6:0]), .wr_data(rd_ret_data),
        .rd_set(mac_set), .rd_weights(raw_weights), .rd_bias(bias), .rd_shift(shift)
    );

    kwt_mac_array u_mac (
        .clk(clk), .rst_n(rst_n), .in_valid(mac_valid), .x_flat(masked_x),
        .w_flat(masked_weights), .bias(bias), .shift(shift),
        .out_valid(mac_out_valid), .out_data(mac_out), .sat(mac_sat)
    );

    kwt_out_fifo u_fifo (
        .clk(clk), .rst_n(rst_n), .flush(fifo_flush), .push(fifo_push),
        .push_data(mac_out), .pop(fifo_pop), .pop_data(fifo_data), .empty(fifo_empty)
    );
endmodule

`default_nettype wire
