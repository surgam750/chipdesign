#include "mailbox.h"

static uint32_t read_mcycle(void)
{
    uint32_t n;
    __asm__ volatile ("csrr %0, mcycle" : "=r"(n) :: "memory");
    return n;
}

int main(void)
{
    if (kwt_probe()) {
        MB(MB_STATUS) = KWT(KWT_ID);
        kwt_fence();
        MB(MB_STATE) = MB_ERROR;
        return 2;
    }
#ifndef KWT_FORCE_POLL
    kwt_irq_init();
#endif
    MB(MB_STATE) = MB_READY;
    for (;;) {
        uint32_t state;
        do {
            state = MB(MB_STATE);
        } while (state != MB_GO && state != MB_EXIT);
        if (state == MB_EXIT)
            return 0;

        kwt_fence();
        MB(MB_MCYCLE_START) = read_mcycle();
        uint32_t dims = MB(MB_DIMS);
        uint32_t strides = MB(MB_STRIDES);
        kwt_cfg_t cfg = {
            .x_base = MB(MB_X_BASE), .w_base = MB(MB_W_BASE), .y_base = MB(MB_Y_BASE),
            .m = dims & 0x7f, .k = (dims >> 8) & 0x3ff, .n = (dims >> 18) & 0x3ff,
            .x_stride = strides & 0xffff, .y_stride = strides >> 16,
            .opcode = MB(MB_OPCODE)
        };
#ifdef KWT_FORCE_POLL
        int irq = 0;
#else
        int irq = MB(MB_MODE) & 1;
#endif
        kwt_select_irq(irq);
        if (kwt_start(&cfg)) {
            MB(MB_STATUS) = KWT(KWT_STATUS);
            kwt_fence();
            MB(MB_STATE) = MB_ERROR;
            return 3;
        }
        uint32_t status = irq ? kwt_wait_irq() : kwt_wait_poll();
        MB(MB_MCYCLE_END) = read_mcycle();
        kwt_perf_t perf;
        kwt_read_perf(&perf);
        for (unsigned i = 0; i < 8; ++i)
            MB(MB_PERF + 4 * i) = perf.counters[i];
        MB(MB_STATUS) = status;
        kwt_fence();
        /* A device ERR is a completed transaction with a diagnostic STATUS.
         * The harness decides whether it was expected and can submit again. */
        MB(MB_STATE) = MB_DONE;
    }
}
