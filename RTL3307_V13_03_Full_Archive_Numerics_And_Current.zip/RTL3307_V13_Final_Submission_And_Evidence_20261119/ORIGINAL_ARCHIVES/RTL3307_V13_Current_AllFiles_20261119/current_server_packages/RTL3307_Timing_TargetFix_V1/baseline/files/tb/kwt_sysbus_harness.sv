`timescale 1ns/1ps
`define KWT_SOC tb_top.u_e203_soc_top

// A single blocking ICB master drives all task data and mailbox accesses.
module kwt_sysbus_harness;
    localparam [31:0] MAILBOX = 32'hA000_0F00;
    localparam [31:0] X_BASE = 32'hA000_1000;
    localparam [31:0] W_BASE = 32'hA001_0000;
    localparam [31:0] Y_BASE = 32'hA002_0000;
    localparam integer X_WORDS = 3168, W_WORDS = 6656, Y_WORDS = 12672;
    reg host_load_cmd_valid = 0;
    wire load_cmd_ready;
    reg host_load_cmd_read = 0;
    reg [31:0] host_load_cmd_addr = 0, host_load_cmd_wdata = 0;
    reg [3:0] host_load_cmd_wmask = 0;
    wire load_rsp_valid;
    reg host_load_rsp_ready = 0;
    wire [31:0] load_rsp_rdata;
    wire load_rsp_err;
    reg bulk_active = 0, bulk_valid = 0;
    reg [31:0] bulk_addr = 0, bulk_data = 0;
    wire bulk_ready, bulk_idle, bulk_error;
    wire bulk_cmd_valid, bulk_cmd_read, bulk_rsp_ready;
    wire [31:0] bulk_cmd_addr, bulk_cmd_wdata;
    wire [3:0] bulk_cmd_wmask;
    wire load_cmd_valid = bulk_active ? bulk_cmd_valid : host_load_cmd_valid;
    wire load_cmd_read = bulk_active ? bulk_cmd_read : host_load_cmd_read;
    wire [31:0] load_cmd_addr = bulk_active ? bulk_cmd_addr : host_load_cmd_addr;
    wire [31:0] load_cmd_wdata = bulk_active ? bulk_cmd_wdata : host_load_cmd_wdata;
    wire [3:0] load_cmd_wmask = bulk_active ? bulk_cmd_wmask : host_load_cmd_wmask;
    wire load_rsp_ready = bulk_active ? bulk_rsp_ready : host_load_rsp_ready;
    kwt_loader_dma loader_dma (
        .clk(`KWT_SOC.kwt_clk), .rst_n(`KWT_SOC.kwt_rst_n),
        .source_valid(bulk_valid), .source_ready(bulk_ready),
        .source_addr(bulk_addr), .source_data(bulk_data), .idle(bulk_idle), .error(bulk_error),
        .icb_cmd_valid(bulk_cmd_valid), .icb_cmd_ready(bulk_active && load_cmd_ready),
        .icb_cmd_addr(bulk_cmd_addr), .icb_cmd_wdata(bulk_cmd_wdata),
        .icb_cmd_read(bulk_cmd_read), .icb_cmd_wmask(bulk_cmd_wmask),
        .icb_rsp_valid(bulk_active && load_rsp_valid), .icb_rsp_ready(bulk_rsp_ready),
        .icb_rsp_err(load_rsp_err));
    reg [31:0] x_image [0:X_WORDS-1];
    reg [31:0] w_image [0:W_WORDS-1];
    reg [31:0] y_golden [0:Y_WORDS-1];
    reg output_seen [0:Y_WORDS-1];
    string directories [0:11];
    integer layers [0:11];
    integer cycles = 0, start_cycle = 0, end_cycle = 0;
    integer loader_commands = 0, loader_responses = 0;
    integer x_responses = 0, w_responses = 0;
    integer output_commands = 0, output_responses = 0;
    integer current_task = -1, current_layer = -1;
    integer timeout_cycles = 2000000;
    integer task_timeout_cycles = 20000000;
    reg observe_outputs = 0, measure_active = 0;
    integer dma_count = 0, dma_head = 0, dma_tail = 0;
    integer dma_indices [0:2];
    wire dma_pending = dma_count != 0;
    integer dma_index = -1;
    reg harness_done = 0;

    // Commit one accepted DMA command to the single-entry scoreboard.
    task automatic accept_output_command;
        integer index;
        begin
                if (!observe_outputs) $fatal(1, "DMA write outside requested task");
                if (dma_count >= 3) $fatal(1, "output write queue exceeded native ingress bound");
                if (`KWT_SOC.kwt_m1_icb_cmd_read !== 1'b0 || `KWT_SOC.kwt_m1_icb_cmd_wmask !== 4'hf)
                    $fatal(1, "DMA output must write one full32bit word");
                if (`KWT_SOC.kwt_m1_icb_cmd_addr < Y_BASE ||
                    `KWT_SOC.kwt_m1_icb_cmd_addr >= Y_BASE + 4*Y_WORDS ||
                    `KWT_SOC.kwt_m1_icb_cmd_addr[1:0] !== 2'b00)
                    $fatal(1, "output write address outside full Y range: %08h", `KWT_SOC.kwt_m1_icb_cmd_addr);
                index = (`KWT_SOC.kwt_m1_icb_cmd_addr-Y_BASE)/4;
                if (output_seen[index]) $fatal(1, "duplicate output word %0d", index);
                dma_indices[dma_tail] = index;
                dma_tail = (dma_tail+1)%3;
                dma_count = dma_count+1;
                output_commands = output_commands + 1;
        end
    endtask

    // Monitor actual bus-clock transfers; no task touches an SRAM array.
    always @(posedge `KWT_SOC.kwt_clk) begin : count_bus_transfers
        reg had_pending;
        cycles = cycles + 1;
        if (`KWT_SOC.kwt_rst_n === 1'b1) begin
            if (load_cmd_valid && load_cmd_ready) loader_commands = loader_commands + 1;
            if (load_rsp_valid && load_rsp_ready) begin
                if (load_rsp_err !== 1'b0) $fatal(1, "loader response error addr=%08h", host_load_cmd_addr);
                loader_responses = loader_responses + 1;
                if (bulk_active) begin
                    if (x_responses < X_WORDS) x_responses = x_responses+1;
                    else w_responses = w_responses+1;
                end
                if (loader_responses > loader_commands) $fatal(1, "unsolicited loader response");
            end
            if (measure_active && cycles-start_cycle > task_timeout_cycles)
                $fatal(1, "task timeout id=%0d load=%0d/%0d output=%0d/%0d", current_task,
                       loader_commands, loader_responses, output_commands, output_responses);
            // With no old transaction, a command may own a zero-latency response.
            // With an old transaction, retire its response before FIFO turnover.
            had_pending = dma_pending;
            if (!had_pending && `KWT_SOC.kwt_m1_icb_cmd_valid && `KWT_SOC.kwt_m1_icb_cmd_ready)
                accept_output_command();
            if (`KWT_SOC.kwt_write_rsp_valid && `KWT_SOC.kwt_write_rsp_ready) begin
                if (!observe_outputs || !dma_pending) $fatal(1, "unsolicited DMA write response");
                if (`KWT_SOC.kwt_write_rsp_err !== 1'b0) $fatal(1, "DMA write error");
                dma_index = dma_indices[dma_head];
                if (output_seen[dma_index]) $fatal(1, "duplicate retired output");
                output_seen[dma_index] = 1;
                dma_head = (dma_head+1)%3;
                dma_count = dma_count-1;
                output_responses = output_responses + 1;
                if (output_responses == Y_WORDS) begin
                    end_cycle = cycles;
                    measure_active = 0;
                    $display("KWT_WINDOW id=%0d layer=%0d start_cycle=%0d end_cycle=%0d cycles=%0d",
                             current_task, current_layer, start_cycle, end_cycle, end_cycle-start_cycle);
                end
                if (output_responses > Y_WORDS) $fatal(1, "excess DMA output responses");
            end
            if (had_pending && `KWT_SOC.kwt_m1_icb_cmd_valid && `KWT_SOC.kwt_m1_icb_cmd_ready)
                accept_output_command();
        end else if (measure_active) $fatal(1, "reset during task");
    end

    // Drive at falling edges, sample at rising edges, hold one request until accepted.
    task automatic transfer(input bit read_access, input reg [31:0] address,
                            input reg [31:0] value, input reg [3:0] mask,
                            output reg [31:0] result);
        integer waited;
        begin
            @(negedge `KWT_SOC.kwt_clk);
            host_load_cmd_addr = address;
            host_load_cmd_wdata = value;
            host_load_cmd_wmask = mask;
            host_load_cmd_read = read_access;
            host_load_cmd_valid = 1;
            waited = 0;
            do begin
                @(posedge `KWT_SOC.kwt_clk);
                waited = waited + 1;
                if (waited > timeout_cycles) $fatal(1, "loader command timeout addr=%08h", address);
            end while (load_cmd_ready !== 1'b1);
            @(negedge `KWT_SOC.kwt_clk);
            host_load_cmd_valid = 0;
            host_load_rsp_ready = 1;
            waited = 0;
            do begin
                @(posedge `KWT_SOC.kwt_clk);
                waited = waited + 1;
                if (waited > timeout_cycles) $fatal(1, "loader response timeout addr=%08h", address);
            end while (load_rsp_valid !== 1'b1);
            if (load_rsp_err !== 1'b0) $fatal(1, "loader response error addr=%08h", address);
            result = load_rsp_rdata;
            @(negedge `KWT_SOC.kwt_clk);
            host_load_rsp_ready = 0;
        end
    endtask

    task automatic write_word(input reg [31:0] address, input reg [31:0] value);
        reg [31:0] unused_result;
        transfer(0, address, value, 4'hf, unused_result);
    endtask

    task automatic await_state(input reg [31:0] wanted);
        reg [31:0] state_word, error_word;
        integer begin_cycle;
        begin
            begin_cycle = cycles;
            state_word = 0;
            while (state_word !== wanted) begin
                if (wanted == 3) repeat (128) @(posedge `KWT_SOC.kwt_clk);
                transfer(1, MAILBOX, 0, 0, state_word);
                if (state_word === 32'he) begin
                    transfer(1, MAILBOX+96, 0, 0, error_word);
                    $fatal(1, "CPU firmware error status=%08h", error_word);
                end
                if (cycles-begin_cycle > task_timeout_cycles)
                    $fatal(1, "mailbox timeout wanted=%0d got=%08h", wanted, state_word);
            end
        end
    endtask

    // Exact file length and known bits prevent reusing a previous task's array tail.
    task automatic read_image(input string filename, input integer kind, input integer words);
        integer fd, index, items;
        reg [31:0] word_value;
        string extra;
        begin
            fd = $fopen(filename, "r");
            if (!fd) $fatal(1, "cannot open image %s", filename);
            for (index = 0; index < words; index = index + 1) begin
                items = $fscanf(fd, "%h", word_value);
                if (items != 1 || (^word_value) === 1'bx)
                    $fatal(1, "invalid or short image %s word=%0d", filename, index);
                case (kind)
                    0: x_image[index] = word_value;
                    1: w_image[index] = word_value;
                    2: y_golden[index] = word_value;
                    default: $fatal(1, "invalid image kind");
                endcase
            end
            items = $fscanf(fd, "%s", extra);
            if (items == 1) $fatal(1, "extra image content %s", filename);
            $fclose(fd);
        end
    endtask

    task automatic run_one(input string directory, input integer layer, input integer task_id,
                           output integer elapsed);
        integer index, mismatches, checked;
        reg [31:0] status, observed;
        begin
            read_image({directory,"/x.hex"}, 0, X_WORDS);
            read_image({directory,"/wpack.hex"}, 1, W_WORDS);
            read_image({directory,"/y_golden.hex"}, 2, Y_WORDS);
            current_task = task_id;
            current_layer = layer;
            output_commands = 0;
            output_responses = 0;
            x_responses = 0;
            w_responses = 0;
            end_cycle = 0;
            for (index = 0; index < Y_WORDS; index = index + 1) output_seen[index] = 0;
            // Align the window with first request assertion, including arbitration wait.
            @(negedge `KWT_SOC.kwt_clk);
            start_cycle = cycles;
            measure_active = 1;
            // transfer asserts the first request at the next falling edge.
            start_cycle = start_cycle + 1;
            // Assert first request at the same next falling edge used by baseline transfer.
            @(negedge `KWT_SOC.kwt_clk);
            bulk_active = 1;
            bulk_valid = 1;
            for (index = 0; index < X_WORDS+W_WORDS; index = index+1) begin
                if (index < X_WORDS) begin
                    bulk_addr = X_BASE+4*index;
                    bulk_data = x_image[index];
                end else begin
                    bulk_addr = W_BASE+4*(index-X_WORDS);
                    bulk_data = w_image[index-X_WORDS];
                end
                do @(posedge `KWT_SOC.kwt_clk); while (!bulk_ready);
                @(negedge `KWT_SOC.kwt_clk);
            end
            bulk_valid = 0;
            while (!bulk_idle) @(negedge `KWT_SOC.kwt_clk);
            if (bulk_error) $fatal(1, "stream loader write failure");
            bulk_active = 0;
            if (x_responses != X_WORDS || w_responses != W_WORDS)
                $fatal(1, "input response count mismatch");
            $display("KWT_LOAD id=%0d x_rsp=%0d w_rsp=%0d cycles=%0d", task_id,
                     x_responses, w_responses, cycles-start_cycle);
            write_word(MAILBOX+4, task_id);
            write_word(MAILBOX+8, 0);
            write_word(MAILBOX+12, {4'b0,10'd256,10'd64,1'b0,7'd99});
            write_word(MAILBOX+16, X_BASE);
            write_word(MAILBOX+20, W_BASE);
            write_word(MAILBOX+24, Y_BASE);
            write_word(MAILBOX+28, {16'd512,16'd128});
            write_word(MAILBOX+32, 1);
            observe_outputs = 1;
            write_word(MAILBOX, 2);
            await_state(3);
            transfer(1, MAILBOX+96, 0, 0, status);
            if (status[2:0] !== 3'b010 || output_responses != Y_WORDS ||
                output_commands != Y_WORDS || end_cycle == 0 || dma_pending)
                $fatal(1, "bad completion status=%08h output=%0d/%0d", status,
                       output_commands, output_responses);
            mismatches = 0;
            checked = 0;
            for (index = 0; index < Y_WORDS; index = index + 1) begin
                if (!output_seen[index]) $fatal(1, "unwritten output word %0d", index);
                transfer(1, Y_BASE+4*index, 0, 0, observed);
                checked = checked + 1;
                if (observed !== y_golden[index]) begin
                    if (mismatches < 3) $display("word=%0d expected=%08h got=%08h", index, y_golden[index], observed);
                    mismatches = mismatches + 1;
                end
            end
            if (mismatches || checked != Y_WORDS) $fatal(1, "full INT16 compare mismatch=%0d", mismatches);
            observe_outputs = 0;
            elapsed = end_cycle-start_cycle;
            $display("KWT_TASK id=%0d layer=%0d cycles=%0d x_rsp=%0d w_rsp=%0d y_rsp=%0d checked=%0d mism=0 PASS",
                     task_id, layer, elapsed, x_responses, w_responses, output_responses, checked);
        end
    endtask

    initial begin : initial_liveness
        #(64'd100000000);
        if (cycles == 0) $fatal(1, "no SystemBus clock");
        if (`KWT_SOC.kwt_rst_n !== 1'b1) $fatal(1, "SystemBus reset never released");
    end

    initial begin : run_harness
        string task_list, directory;
        integer fd, items, layer, count, index, prior, elapsed, total;
        integer expected_tasks;
        if (!$value$plusargs("KWT_TASKS=%s", task_list)) $fatal(1, "KWT_TASKS is required");
        if ($value$plusargs("KWT_TIMEOUT_CYCLES=%d", timeout_cycles)) begin end
        if ($value$plusargs("KWT_TASK_TIMEOUT_CYCLES=%d", task_timeout_cycles)) begin end
        if (timeout_cycles <= 0 || task_timeout_cycles <= 0) $fatal(1, "invalid timeouts");
        fd = $fopen(task_list, "r");
        if (!fd) $fatal(1, "cannot open task list %s", task_list);
        count = 0;
        items = $fscanf(fd, "%d %s", layer, directory);
        while (items == 2) begin
            if (count >= 12) $fatal(1, "more than twelve tasks");
            if (layer < 0 || layer > 11) $fatal(1, "invalid layer %0d", layer);
            for (prior = 0; prior < count; prior = prior + 1)
                if (layers[prior] == layer || directories[prior] == directory)
                    $fatal(1, "duplicate task layer or directory");
            layers[count] = layer;
            directories[count] = directory;
            count = count + 1;
            items = $fscanf(fd, "%d %s", layer, directory);
        end
        if (!$feof(fd) || (count != 1 && count != 12)) $fatal(1, "malformed task list or task count=%0d", count);
        if ($value$plusargs("KWT_EXPECT_TASKS=%d", expected_tasks))
            if (count != expected_tasks) $fatal(1, "task count differs from expected=%0d", expected_tasks);
        $fclose(fd);
        wait (`KWT_SOC.kwt_rst_n === 1'b1);
        await_state(1);
        total = 0;
        for (index = 0; index < count; index = index + 1) begin
            run_one(directories[index], layers[index], index, elapsed);
            total = total + elapsed;
        end
        if (loader_commands != loader_responses) $fatal(1, "unfinished loader transfer");
        write_word(MAILBOX, 4);
        // Let the CPU observe EXIT and retire its final shared-bus poll.
        repeat (128) @(posedge `KWT_SOC.kwt_clk);
        @(negedge `KWT_SOC.kwt_clk);
        harness_done = 1;
        $display("KWT_SOC_SUMMARY PASS tasks=%0d scalar_outputs=%0d cycles_sum=%0d placement=SYSTEMBUS32 mode=IRQ timing=LOAD_TO_LAST_WRITE_RSP loader_cmd=%0d loader_rsp=%0d",
                 count, count*Y_WORDS*2, total, loader_commands, loader_responses);
        $finish;
    end
endmodule
`undef KWT_SOC

