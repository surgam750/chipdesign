source [file join [file dirname [info script]] common.tcl]
finish {
    set stream [open [required liberty] r]
    set text [read $stream]
    close $stream
    if {[regexp -all {\mlibrary\s*\(} $text] != 1 ||
        ![regexp {\mlibrary\s*\(\s*(?:"([[:alnum:]_.-]+)"|([[:alnum:]_.-]+))\s*\)\s*\{} $text -> quoted bare]} {
        error "Liberty library declaration missing, malformed or ambiguous"
    }
    set lib "$quoted$bare"
    read_lib [required liberty]
    set cells [get_lib_cells -quiet "$lib/[required macro]"]
    if {[sizeof_collection $cells] != 1} {error "Liberty macro must resolve uniquely"}
    report_lib $lib > library.rpt
    write_lib $lib -format db -output [required destination]
    if {![file isfile [required destination]] || [file size [required destination]] == 0} {
        error "LC produced no nonempty DB"
    }
}
