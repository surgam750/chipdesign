`timescale 1ns/1ps
// Functional simulation only: synchronous output and native active-low controls.
// No foundry timing, power, retention or unknown-control behavior is represented.
module RAMSP4096X16 (
    output reg [15:0] Q,
    input CLK,
    input CEN,
    input GWEN,
    input [15:0] WEN,
    input [11:0] A,
    input [15:0] D,
    input [2:0] EMA,
    input [1:0] EMAW,
    input RET1N
);
    reg [15:0] memory [0:4095];
    integer bit_index;
    always @(posedge CLK) begin
        if (!CEN) begin
            if (!GWEN) begin
                for (bit_index = 0; bit_index < 16; bit_index = bit_index + 1)
                    if (!WEN[bit_index]) memory[A][bit_index] <= D[bit_index];
            end else begin
                Q <= memory[A];
            end
        end
    end
endmodule
