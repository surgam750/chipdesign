# kwt_sysbus_harness simulation contract

Task class: generate and validate a simulation-only harness. The mandated module
and filename are `kwt_sysbus_harness` and `tb/kwt_sysbus_harness.sv`.

There are no module ports. Parent wiring connects public internal `load_cmd_*`
and `load_rsp_*` to the loader input of the original SystemBus arbiter. Command
widths are address/data 32, mask 4. Only one request is outstanding. The harness
holds command fields stable until valid/ready, then enables response ready;
the slave must hold its response under backpressure. All writes use mask F;
reads use mask 0. Clock/reset are the actual `kwt_clk` / active-low `kwt_rst_n`.

The mailbox is A0000F00, X A0001000, W A0010000, Y A0020000. PC files are read
and validated before timing starts. Timing begins when the first X request is
asserted, includes loading, arbitration, CPU scheduling and compute, and ends
at the last successful DMA write response. Final readback is outside the timing
window. Each Y command is range/alignment checked, and each response commits
one unique output word. Every one of the 12672 words is checked through loader
reads, preserving both INT16 halves. Tasks are continuous and do not reset CPU.

`+KWT_TASKS=<file>` lists `layer directory` pairs, either one task or twelve
unique layers/directories, layer 0..11. `+KWT_EXPECT_TASKS=<n>` can bind an
externally selected count. File lengths must match 3168/6656/12672 words.
`+KWT_TIMEOUT_CYCLES` limits a transfer; `+KWT_TASK_TIMEOUT_CYCLES` limits mailbox
and full task waits. A physical-time initial watchdog detects missing clocks
or reset release. Errors, duplicate output addresses and missing writes fail.

Handshake timing (illustrative, variable wait/response latency):

```wavedrom
{ "signal": [
  { "name": "kwt_clk", "wave": "p......" },
  { "name": "cmd_valid", "wave": "01..0.." },
  { "name": "cmd_ready", "wave": "0..10.." },
  { "name": "rsp_valid", "wave": "0...1.0" },
  { "name": "rsp_ready", "wave": "0...1.0" }
] }
```

Verification cases: compile, delayed command ready and delayed response valid,
full task load/readback counts, duplicate DMA output rejection and DMA response
error rejection. Unit protocol fixture is not real CPU/accelerator acceptance.
Public skill matrix is retained in reports/loader/readable_gate.json; that gate
is blocked by its filename/role convention while the user-specified filename is
preserved. ModelSim compile/execution evidence is independent.
