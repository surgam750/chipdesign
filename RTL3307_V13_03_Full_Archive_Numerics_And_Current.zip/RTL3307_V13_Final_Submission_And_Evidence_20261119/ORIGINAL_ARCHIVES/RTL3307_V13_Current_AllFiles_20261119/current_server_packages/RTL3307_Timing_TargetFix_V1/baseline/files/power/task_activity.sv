`timescale 1ps/1ps
// Passive VCS SAIF observer. The existing SystemBus harness owns task acceptance.
module kwt_rtl_task_activity;
    integer next_task = 0;
    bit active = 0;
    time last_rise, period_ps, offset_ps, start_ps;

    initial begin
        $set_gate_level_monitoring("on");
        $set_toggle_region(tb_top.u_e203_soc_top);
    end

    always @(posedge tb_top.u_e203_soc_top.kwt_clk) begin
        period_ps = $time - last_rise;
        last_rise = $time;
    end

    always @(posedge tb_top.u_kwt.bulk_valid) begin
        if (active || !tb_top.u_kwt.measure_active || !tb_top.u_kwt.bulk_active ||
            tb_top.u_kwt.current_task != next_task || tb_top.u_kwt.current_layer != next_task ||
            tb_top.u_kwt.cycles != tb_top.u_kwt.start_cycle || period_ps == 0)
            $fatal(1, "RTL activity start does not match first loader command");
        active = 1;
        start_ps = $time;
        offset_ps = $time - last_rise;
        $toggle_reset;
        $toggle_start;
    end

    always @(negedge tb_top.u_kwt.measure_active) begin
        if (active) begin
            if (tb_top.u_kwt.output_responses != 12672 || tb_top.u_kwt.end_cycle != tb_top.u_kwt.cycles)
                $fatal(1, "RTL activity end does not match final write response");
            $toggle_stop;
            case (next_task)
                0: $toggle_report("task_00.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                1: $toggle_report("task_01.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                2: $toggle_report("task_02.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                3: $toggle_report("task_03.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                4: $toggle_report("task_04.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                5: $toggle_report("task_05.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                6: $toggle_report("task_06.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                7: $toggle_report("task_07.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                8: $toggle_report("task_08.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                9: $toggle_report("task_09.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                10: $toggle_report("task_10.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                11: $toggle_report("task_11.saif", 1.0e-12, "tb_top.u_e203_soc_top");
                default: $fatal(1, "Unexpected RTL activity task index");
            endcase
            $display("KWT_RTL_ACTIVITY id=%0d start_ps=%0d stop_ps=%0d period_ps=%0d offset_ps=%0d",
                     next_task, start_ps, $time, period_ps, offset_ps);
            active = 0;
            next_task = next_task + 1;
        end
    end
endmodule

bind tb_top kwt_rtl_task_activity u_task_activity();

