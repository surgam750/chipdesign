// UG activation buffer. Each lane has its own single-port SRAM bank.
//
// Hold-time closure (R11): every RAMSP128X16 input (CEN/GWEN/WEN/A/D) is
// launched from a falling-edge register. The macro samples on the next rising
// edge, so the SRAM sees exactly the same value in the same cycle as the
// previous direct connection (no latency or cycle-count change), while its
// hold check gains half a clock period (3.33 ns) against a 0.47 ns SRAM hold
// requirement at every PVT. Setup for these paths becomes half a period.
module kwt_xbuf (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          wr_en,
    input  wire [6:0]    wr_row,
    input  wire [4:0]    wr_pair,
    input  wire [31:0]   wr_data,
    input  wire          rd_en,
    input  wire [6:0]    rd_row,
    output wire [1023:0] rd_lanes
);

    // Rising-edge-domain decode, identical to the original connection.
    wire       read_cycle_d = rd_en & ~wr_en;
    wire [6:0] bank_addr_d  = wr_en ? wr_row : rd_row;

    // Falling-edge launch registers shared by all 64 banks.
    reg        n_read;
    reg        n_write;
    reg [4:0]  n_pair;
    reg [6:0]  n_addr;
    reg [31:0] n_wdata;

    always @(negedge clk or negedge rst_n) begin
        if (!rst_n) begin
            n_read  <= 1'b0;
            n_write <= 1'b0;
        end else begin
            n_read  <= read_cycle_d;
            n_write <= wr_en;
        end
    end

    // Data/address need no reset: they are ignored while CEN is inactive.
    always @(negedge clk) begin
        n_pair  <= wr_pair;
        n_addr  <= bank_addr_d;
        n_wdata <= wr_data;
    end

    genvar lane;
    generate
        for (lane = 0; lane < 64; lane = lane + 1) begin : gen_lane
            localparam [4:0] PAIR = lane / 2;
            localparam integer HALF_LSB = (lane % 2) * 16;
            wire bank_we;
            wire bank_ce;

            assign bank_we = n_write & (n_pair == PAIR);
            assign bank_ce = n_read | bank_we;

            kwt_sram_sp #(.DEPTH(128)) u_bank (
                .clk   (clk),
                .ce    (bank_ce),
                .we    (bank_we),
                .addr  (n_addr),
                .wdata (n_wdata[HALF_LSB +: 16]),
                .rdata (rd_lanes[lane*16 +: 16])
            );
        end
    endgenerate
endmodule
