// KWT DMA request stage and ordered ICB response metadata queue.
module kwt_dma_queue #(
    parameter PAYLOAD_WIDTH = 32,
    parameter META_WIDTH = 32
) (
    input                       clk,
    input                       rst_n,
    input                       req_valid,
    output                      req_ready,
    input  [PAYLOAD_WIDTH-1:0]  req_payload,
    input  [META_WIDTH-1:0]     req_meta,
    output                      cmd_valid,
    input                       cmd_ready,
    output [PAYLOAD_WIDTH-1:0]  cmd_payload,
    input                       rsp_valid,
    output                      ret_valid,
    output [META_WIDTH-1:0]     ret_meta,
    output                      idle
);

    // Two entries cut the cmd_ready -> req_ready combinational path.
    reg [PAYLOAD_WIDTH-1:0]     request_payload [0:1];
    reg [META_WIDTH-1:0]        request_meta [0:1];
    reg                         request_head;
    reg                         request_tail;
    reg [1:0]                   request_count;

    // Only commands accepted by ICB occupy the metadata ring.
    reg [META_WIDTH-1:0]        response_meta [0:7];
    reg [2:0]                   head;
    reg [2:0]                   tail;
    reg [3:0]                   outstanding;
    integer                     slot;

    wire                        empty;
    wire                        full;
    wire                        req_fire;
    wire                        cmd_fire;
    wire                        dequeue;

    assign empty = outstanding == 4'd0;
    assign full = outstanding == 4'd8;
    assign cmd_valid = (request_count != 2'd0) & ~full;
    assign cmd_payload = request_payload[request_head];
    assign cmd_fire = cmd_valid & cmd_ready;
    assign req_ready = rst_n & (request_count != 2'd2);
    assign req_fire = req_valid & req_ready;
    assign idle = empty & (request_count == 2'd0);

    // Both DMA wrappers register responses before this queue. Even a
    // zero-cycle ICB slave therefore returns after its metadata is stored.
    assign ret_valid = rsp_valid & ~empty;
    assign ret_meta = response_meta[head];
    assign dequeue = rsp_valid & ~empty;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            request_head <= 1'b0;
            request_tail <= 1'b0;
            request_count <= 2'd0;
            request_payload[0] <= {PAYLOAD_WIDTH{1'b0}};
            request_payload[1] <= {PAYLOAD_WIDTH{1'b0}};
            request_meta[0] <= {META_WIDTH{1'b0}};
            request_meta[1] <= {META_WIDTH{1'b0}};
        end else begin
            if (req_fire) begin
                request_payload[request_tail] <= req_payload;
                request_meta[request_tail] <= req_meta;
                request_tail <= ~request_tail;
            end
            if (cmd_fire) request_head <= ~request_head;
            case ({req_fire, cmd_fire})
                2'b10: request_count <= request_count + 2'd1;
                2'b01: request_count <= request_count - 2'd1;
                default: ;
            endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            head <= 3'd0;
            tail <= 3'd0;
            outstanding <= 4'd0;
            for (slot = 0; slot < 8; slot = slot + 1)
                response_meta[slot] <= {META_WIDTH{1'b0}};
        end else begin
            if (cmd_fire) begin
                response_meta[tail] <= request_meta[request_head];
                tail <= tail + 3'd1;
            end
            if (dequeue)
                head <= head + 3'd1;
            case ({cmd_fire, dequeue})
                2'b10: outstanding <= outstanding + 4'd1;
                2'b01: outstanding <= outstanding - 4'd1;
                default: ;
            endcase
        end
    end
`ifdef KWT_ASSERT
    // synthesis translate_off
    always @(posedge clk) begin
        if (rst_n && rsp_valid && empty)
            $fatal(1, "KWT_DMA_UNEXPECTED_RESPONSE: no outstanding command");
        if (rst_n && (request_count > 2 || outstanding > 8))
            $fatal(1, "KWT_DMA_QUEUE_OVERFLOW");
    end
    // synthesis translate_on
`endif
endmodule
