#!/usr/bin/env python3
"""Rebuild this isolated timing candidate's manifest and standalone entry.

Python 3.6+. Never edits another run, imports old results, or marks timing PASS.
"""
import base64
import hashlib
import difflib
import importlib.util
import io
import json
from pathlib import Path
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / 'payload'
CANDIDATE = 'RTL3307_TCM128_TARGETFIX_V1'
ENTRY = ROOT / 'r2rtl3307_tcm128_targetfix_v1.py'
FIXED_TIME = (2026, 11, 18, 0, 0, 0)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def delivery_verifier():
    path = ROOT / 'verification/check_delivery.py'
    spec = importlib.util.spec_from_file_location('bankwen_delivery_checks', str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def finalize_metadata(verifier):
    """Seal only the declared bank-WEN proxy/identity delta; never edit RTL."""
    baseline = verifier.baseline_manifest()
    before, after = verifier.check_proxy(baseline)
    verifier.check_controller(baseline)
    verifier.check_dc(baseline)
    core = verifier.expected_core_map(baseline)
    for rel in verifier.CORE_MAPS:
        save(PAYLOAD / rel, core)
    helpers = json.loads(verifier.baseline_bytes('native/support/hashes.json', baseline).decode('utf-8'))
    helpers['kwt_tcm_proxy.v'] = sha(PAYLOAD / verifier.PROXY)
    helpers['w12_core_sha256.json'] = sha(PAYLOAD / verifier.CORE_MAPS[1])
    save(PAYLOAD / 'native/support/hashes.json', helpers)
    files = verifier.payload_hashes()
    identity = verifier.expected_identity(files, baseline)
    save(PAYLOAD / 'source_identity.json', identity)
    files = verifier.payload_hashes()
    changed, protected = verifier.verify_source_delta(files)
    patch = ''.join(difflib.unified_diff(
        before.decode('utf-8').splitlines(True), after.decode('utf-8').splitlines(True),
        fromfile='GLOBSLEW025/' + verifier.PROXY, tofile='TARGETFIX/' + verifier.PROXY))
    (ROOT / 'changes').mkdir(exist_ok=True)
    (ROOT / 'changes/tcm_ag.patch').write_text(patch, encoding='utf-8')
    return identity, files, changed, protected


def main():
    verifier = delivery_verifier()
    identity, files, changed, protected = finalize_metadata(verifier)
    manifest = {
        'kind': 'RTL3307_FULL7_SERVER',
        'candidate_id': CANDIDATE,
        'parent_candidate_id': 'RTL3307_TCM128_GLOBSLEW025_V1',
        'source_archive_sha256': identity['source_archive_sha256'],
        'corners': ['FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT5', 'TT6'],
        'scope': ('GLOBSLEW025-parent wr/sat prefix counters, bank-qualified ITCM A/GWEN and setup/hold-first priority; inherited global DC 0.25ns and PT 0.30ns. '
                  'Native SS3-max/SS3-min synthesis and seven-corner STA require a new run. '
                  'No baseline area, power, slack or cycle receipt is a candidate result. '
                  'EDA_NOT_RUN_AT_PACKAGING; local checks are recorded separately.'),
        'files': files,
    }
    save(PAYLOAD / 'payload_manifest.json', manifest)
    members = dict(files)
    members['payload_manifest.json'] = sha(PAYLOAD / 'payload_manifest.json')
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
        for rel in sorted(members):
            info = zipfile.ZipInfo(rel, FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, (PAYLOAD / rel).read_bytes())
    raw = buffer.getvalue()
    encoded = base64.b64encode(raw).decode('ascii')
    literal = '\n'.join("    '%s'" % encoded[i:i+1500] for i in range(0, len(encoded), 1500))
    source = (ROOT / 'entry_template.py.in').read_text(encoding='utf-8')
    source = source.replace('@ZIP_SHA256@', hashlib.sha256(raw).hexdigest()).replace('@PAYLOAD@', literal)
    compile(source, ENTRY.name, 'exec')
    with ENTRY.open('w', encoding='utf-8', newline='\n') as stream:
        stream.write(source)
    receipt = {
        'candidate_id': CANDIDATE, 'parent_candidate_id': verifier.PARENT,
        'parent_manifest_sha256': verifier.PARENT_MANIFEST_SHA256, 'entry': ENTRY.name,
        'entry_sha256': sha(ENTRY), 'embedded_zip_sha256': hashlib.sha256(raw).hexdigest(),
        'embedded_files': len(members), 'native_timing_verified': False,
        'native_eda_status_at_packaging': 'NOT_RUN',
        'controller_sha256': sha(PAYLOAD / verifier.CTRL),
        'proxy_sha256': sha(PAYLOAD / verifier.PROXY),
        'changed_production_files': sorted(changed),
        'unchanged_parent_payload_files': len(protected),
        'local_exact_source_delta_verified': True,
    }
    (ROOT / 'reports').mkdir(exist_ok=True)
    save(ROOT / 'reports/build_receipt.json', receipt)
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
