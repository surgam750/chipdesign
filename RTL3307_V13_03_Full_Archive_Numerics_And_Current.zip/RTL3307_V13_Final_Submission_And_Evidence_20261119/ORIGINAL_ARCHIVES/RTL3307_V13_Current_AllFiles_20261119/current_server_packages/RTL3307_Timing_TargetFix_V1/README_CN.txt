TARGETFIX_V1 — 本轮独立时序修正候选

运行：进入本目录后执行
    python3 -B run_timing.py --jobs 4
包装器创建新 run，先 RTL，再以唯一 NEW_RUN 运行 LC/DC 和七角 STA；结束自动输出紧凑摘要。
不要覆盖旧 GLOB/GLOBBANKWEN 目录，不要向正在运行的 run 拷入此 payload。

直接父为 RTL3307_TCM128_GLOBSLEW025_V1，父 manifest：
732c526fb39b4ee51355bca27ce1b6ca529d92e523a89d2fb12535c301ec8da3
本次同时针对最新原生报告的三处修改，不把效果归因于单一变量：
1. accelerator controller：wr_words 旧值 +1 前缀；sat_count 保真 +0/+1/+2 P/G 前缀。
   rd_words 保持；原异步 reset、IDLE start/clear、busy、wr_cmd_fire/fifo_push 更新优先级及CSR周期保持。
2. ITCM 适配：仅 bank 匹配资格化 A/GWEN，未选中 bank 的这些引脚可不同；有效宏操作保持原语义。
   保持 D/WEN/CEN、DTCM、宏型号/数量/容量/实例层级。没有继承旧 BANKWEN 的 WEN 资格化。
3. DC 在原 single compile 前显式设置 cost priority 顺序为
   max_delay,min_delay,max_transition,max_fanout,max_capacitance，并在 compile 前后读取属性留证。
   这证明属性读回；不声称窥见或证明优化器内部执行。原工具运行错误守卫保留。
继承 GLOB 全局综合 max_transition 0.25 ns，原 PT 评价 SDC 仍 0.30 ns；时钟、I/O、角、宏库不变。
原 scope 仍名为 globslew025_scope.tsv，marker 仍为 GLOBSLEW025_SCOPE_VERIFIED。
SVF 由新运行原流程重新产生；不复用旧网表/旧 SVF/旧时序结果。

验证与限制
verification/controller 是实际冻结父 controller 与候选双实例有限 miter，包含真实 kwt_regs。
覆盖算术边界、确定种子随机、0/1/X/Z update guard、reset/clear/busy、三个CSR和有限自然序列。
算术等价域为已复位已知二值 count/mac_sat；任意 X 算术完全等价不作声明。
verification/tcm_ag 保存独立适配层双 Q 模式有限 miter；verification/priority 保存 Tcl 桩控制检查。
A/GWEN miter不证明本轮STA或D/WEN hold已修复，新增地址bank到A/GWEN路径仍需原生检查。
搬迁后复现实验请向runner显式传baseline/candidate/tool参数；日志中的原验证路径仅为溯源。
这些不等同于 SoC Formality、原生 DC/STA、功耗或时序签核。封包时 native EDA NOT_RUN。
本次只做精确 source/hash/入口验证、Python3.6语法及一正一错绑定摘要检查，没有重跑旧22项。
最终摘要须绑定全部原生结果与 pre/post cost_priority marker，给出七角数值、SS3/4分类、
ITCM A/GWEN/D/WEN 各 setup/hold 数量与最差值、首setup路径、SS4 slew及面积分组。
0条 marked row 不是 coverage PASS；min 不是一律 data hold；面积小计不是官方面积判定。

规则边界
controller 已核 Q4/Q10/Q12–18：不改变声明工况/评价SDC、MAC配置、32位接口、SystemBus/loader/共享SRAM通路。
本次适配及综合优化按用户后续接受范围实施，不宣称官方全面平台/宏适配认证或时序必过。
精度/吞吐/功耗/面积后续必须对应这一冻结候选，不能拿旧候选结果作本候选结果。
