#!/usr/bin/env python3
"""Print one compact, read-only summary of an exact TARGETFIX_V1 native run.

Python 3.6+, standard library only. No EDA, file writes, or latest-run lookup.
Marked-row counts are not unique paths. Exit 0 is not timing acceptance.
"""
from __future__ import print_function

import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import runpy
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CANDIDATE = 'RTL3307_TCM128_TARGETFIX_V1'
CORNERS = ('FF0', 'FF1', 'FF2', 'SS3', 'SS4', 'TT5', 'TT6')
PARSER_SHA = '1056fd9099c5dd572e0a2ca07bd3b1a9a944c6d6bb0c80c338d0262166e9427e'
PATH_HELPER_SHA = 'e897af80348af4f417eaedafa6fbe01c36a0b519f599536610543e74356ac9a4'
ITCM_MACRO = re.compile(r'^(?:[^/]+/)*u_e203_itcm_ram/u_kwt_tcm/g_bank\[(\d+)\]\.g_wide64\.g_row\[(\d+)\]\.g_slice\[(\d+)\]\.u_ram$')
WEN_TARGET = re.compile(r'^(?:[^/]+/)*u_e203_itcm_ram/u_kwt_tcm/g_bank\[\d+\]\.g_wide64\.g_row\[\d+\]\.g_slice\[\d+\]\.u_ram/WEN\[(?:[0-9]|1[0-5])\]$')


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def local_file(root, relative):
    path = root / relative
    require(path.resolve() == path.absolute(), 'Redirected file: ' + str(path))
    require(path.is_file(), 'Missing file: ' + str(path))
    return path


def bound_summary(run):
    run = Path(run).expanduser().resolve()
    require(run.is_dir() and run.name.startswith('R2RTL3307_TCM128_TARGETFIX_V1_'),
            'An exact TARGETFIX_V1 run directory is required')
    payload = run / 'payload'
    result = payload / 'result'
    manifest_path = local_file(payload, 'payload_manifest.json')
    require(sha(manifest_path) == sha(HERE / 'payload/payload_manifest.json'),
            'Run payload manifest differs from this delivery')
    manifest = load(manifest_path)
    require(manifest.get('candidate_id') == CANDIDATE, 'Candidate identity mismatch')
    for relative, digest in manifest['files'].items():
        require(sha(local_file(payload, relative)) == digest, 'Payload changed: ' + relative)
    state = load(local_file(result, 'state.json'))
    tracked = []
    for relative, key in (('metrics.json', 'metrics_sha256'),
                          ('prepared.json', 'prepared_sha256'),
                          ('resolved_config.json', 'resolved_config_sha256'),
                          ('receipts.json', 'receipts_sha256')):
        path = local_file(result, relative)
        require(sha(path) == state.get(key), 'Run-state binding mismatch: ' + relative)
        tracked.append((path, state[key]))
    metrics = load(result / 'metrics.json')
    require(metrics.get('candidate_id') == CANDIDATE, 'Metrics candidate mismatch')
    require(state.get('status') == metrics.get('status') ==
            'RTL3307_FULL7_REPORTS_COMPLETE_REVIEW_REQUIRED', 'Native sequence is incomplete')
    for relative, key in (('dc_soc/design.v', 'netlist_sha256'),
                          ('sysbus.sdc', 'sdc_sha256'),
                          ('soc/physical_view.json', 'source_manifest_sha256')):
        path = local_file(result, relative)
        require(sha(path) == metrics.get(key), 'Metrics input binding mismatch: ' + relative)
        tracked.append((path, metrics[key]))
    require(sha(result / 'sysbus.sdc') == sha(payload / 'native/sysbus.sdc'),
            'Result SDC differs from delivered SDC')
    receipts = load(result / 'receipts.json')
    receipt_files = {}
    for receipt in receipts:
        for name, digest in receipt['files'].items():
            require(name not in receipt_files or receipt_files[name] == digest,
                    'Conflicting native receipt: ' + name)
            receipt_files[name] = digest
    scope_path = local_file(result, 'dc_soc/globslew025_scope.tsv')
    dc_log = local_file(result, 'dc_soc/tool.log')
    for evidence in (scope_path, dc_log):
        require(sha(evidence) == receipt_files.get(str(evidence)), 'DC scope evidence binding mismatch')
        tracked.append((evidence, sha(evidence)))
    scope_lines = scope_path.read_text(encoding='utf-8').splitlines()
    require(len(scope_lines) == 5 and scope_lines[0] == 'status\tPRECHECKED_NOT_YET_APPLIED' and
            scope_lines[1] == 'top\te203_soc_top' and
            scope_lines[-1] == 'status\tAPPLIED_AND_READBACK_VERIFIED', 'DC global objective was not fully applied')
    before_row, after_row = [line.split('\t') for line in scope_lines[2:4]]
    require(len(before_row) == len(after_row) == 2 and before_row[0] == 'before' and after_row[0] == 'after', 'Invalid DC scope schema')
    before_value, after_value = float(before_row[1]), float(after_row[1])
    require(math.isfinite(before_value) and math.isfinite(after_value) and
            abs(before_value - 0.30) <= 1e-6 and abs(after_value - 0.25) <= 1e-6, 'Unexpected DC objective readback')
    log = dc_log.read_text(encoding='utf-8')
    markers = re.findall(r'^GLOBSLEW025_SCOPE_VERIFIED top=e203_soc_top before=(\S+) after=(\S+) receipt=(.+)$', log, re.M)
    require(markers == [(before_row[1], after_row[1], str(scope_path))] and
            sum(line.startswith('GLOBSLEW025_SCOPE_VERIFIED') for line in log.splitlines()) == 1,
            'Missing/ambiguous or mismatched native scope success marker')
    priority = re.findall(r'^TARGETFIX_COST_PRIORITY_READBACK phase=(pre_compile|post_compile) top=e203_soc_top order=(\S+) raw=\{(.*)\}$', log, re.M)
    expected_order = 'max_delay,min_delay,max_transition,max_fanout,max_capacitance'
    require(len(priority) == 2 and [item[0] for item in priority] == ['pre_compile', 'post_compile'] and
            all(item[1] == expected_order and item[2].strip() for item in priority) and
            sum(line.startswith('TARGETFIX_COST_PRIORITY_READBACK') for line in log.splitlines()) == 2,
            'Missing/ambiguous or mismatched native cost-priority attribute readback')
    cell_file = local_file(result, 'dc_soc/cells.tsv')
    require(sha(cell_file) == receipt_files.get(str(cell_file)), 'Cell inventory receipt mismatch')
    tracked.append((cell_file, sha(cell_file)))
    with cell_file.open(encoding='utf-8') as stream:
        rows = csv.DictReader(stream, delimiter='\t')
        require(rows.fieldnames == ['instance', 'reference', 'area_um2'], 'Unknown cell inventory schema')
        indices = [tuple(int(x) for x in ITCM_MACRO.fullmatch(row['instance']).groups()) for row in rows
                   if ITCM_MACRO.fullmatch(row['instance']) and row['reference'] == 'RAMSP128X16']
    mapped = sorted(indices) == [(b, r, s) for b in range(8) for r in range(32) for s in range(4)]
    parser_file = HERE / 'verification/support/sta_marked_rows.py'
    require(sha(parser_file) == PARSER_SHA, 'Read-only parser changed')
    parse = runpy.run_path(str(parser_file))['parse_text']
    path_file = HERE / 'verification/support/native_path_views.py'
    require(sha(path_file) == PATH_HELPER_SHA, 'Native path helper changed')
    native_paths = runpy.run_path(str(path_file))['native_paths']
    output = {'run': str(run), 'metrics': metrics, 'itcm_mapped_1024': mapped, 'dc_scope': {'before': before_value, 'after': after_value}, 'priority_readback': priority, 'corners': {}}
    for corner in CORNERS:
        row = metrics['timing'][corner]
        folder = result / 'sta' / corner
        for name in ('constraints.rpt', 'global.rpt', 'coverage.rpt', 'check_timing.rpt',
                     'units.rpt', 'clocks.rpt', 'setup.rpt', 'transition.rpt'):
            path = local_file(folder, name)
            digest = row['reports'].get(name)
            require(sha(path) == digest == receipt_files.get(str(path)),
                    'Native report binding mismatch: ' + corner + '/' + name)
            tracked.append((path, digest))
        parsed = parse((folder / 'constraints.rpt').read_text(encoding='utf-8'), str(folder))
        require(parsed['status'] != 'WRONG_REPORT_TYPE' and not parsed['unparsed_count'] and
                not parsed['unknown_section_count'] and parsed['marker_accounting_ok'] and
                parsed['all_violators_option_visible'] and not parsed['warnings'],
                'Incomplete all-violator parsing: ' + corner)
        require(parsed['raw_marker_count'] == row['constraint_violation_rows'],
                'Marked count differs from native metrics: ' + corner)
        records = [v for v in parsed['records'] if WEN_TARGET.fullmatch(v['object'])]
        counts = Counter(v['kind'] for v in parsed['records'])
        other = {k: v for k, v in counts.items() if k not in ('setup', 'hold', 'removal', 'transition')}
        units = (folder / 'units.rpt').read_text(encoding='utf-8')
        time_unit = re.search(r'^\s*Time_unit\s*:\s*(.+?)\s*$', units, re.M)
        require(time_unit is not None, 'Missing native time unit: ' + corner)
        require(all(math.isfinite(float(v)) for v in row['worst_ns'].values()),
                'Nonfinite native scalar: ' + corner)
        output['corners'][corner] = {'counts': counts, 'other': other, 'records': records,
                                     'time_unit': time_unit.group(1), 'all_records': parsed['records']}
        if corner == 'SS3':
            paths = native_paths((folder / 'setup.rpt').read_text(encoding='utf-8').splitlines())
            output['corners'][corner]['first_setup'] = paths[0] if paths else None
    for path, digest in tracked:
        require(sha(path) == digest, 'File changed while reading: ' + str(path))
    return output


def render(data):
    lines = ['TARGETFIX_BRIEF | exact run | READ_ONLY | NOT timing PASS',
             'RUN=' + Path(data['run']).name,
             'Bindings=MATCH; native DC top %.9g -> %.9g ns; PT remains 0.30ns. Rows are not unique paths.' % (data['dc_scope']['before'], data['dc_scope']['after'])]
    lines.append('COST_PRIORITY pre/post attribute readback=MATCH: max_delay,min_delay,max_transition,max_fanout,max_capacitance; not optimizer proof')
    metrics = data['metrics']
    for corner in CORNERS:
        row = metrics['timing'][corner]
        lines.append('%s max=%+.9g min=%+.9g marks=%s' % (corner, row['worst_ns']['max'], row['worst_ns']['min'], row['constraint_violation_rows']))
    for corner in ('SS3', 'SS4'):
        row = data['corners'][corner]; c = row['counts']
        lines.append('%s setup=%d hold=%d removal=%d transition=%d other=%s unit=%s' %
                     (corner, c['setup'], c['hold'], c['removal'], c['transition'], json.dumps(row['other'], sort_keys=True, separators=(',', ':')), row['time_unit']))
        for block in ('accelerator', 'itcm'):
            selected = [r for r in row['all_records'] if r['block'] == block]
            sets = [[r for r in selected if r['kind'] == kind] for kind in ('setup', 'hold')]
            values = [min(rs, key=lambda r: r['slack'])['slack_text'] if rs else 'NO_MARKED_ROW' for rs in sets]
            lines.append('%s %s setup_rows=%d worst=%s hold_rows=%d worst=%s' % (corner, block, len(sets[0]), values[0], len(sets[1]), values[1]))
        for kind in ('setup', 'hold'):
            families = {name: [] for name in ('A', 'GWEN', 'D', 'WEN', 'OTHER')}
            for record in row['all_records']:
                if record['block'] != 'itcm' or record['kind'] != kind:
                    continue
                macro_name = record['object'].rsplit('/', 1)[0]
                pin = re.search(r'/(A|GWEN|D|WEN)(?:\[\d+\])?$', record['object']) if ITCM_MACRO.fullmatch(macro_name) else None
                families[pin.group(1) if pin else 'OTHER'].append(record)
            items = []
            for name in ('A', 'GWEN', 'D', 'WEN', 'OTHER'):
                values = families[name]
                worst = min(values, key=lambda r: r['slack'])['slack_text'] if values else 'NONE'
                items.append('%s:%d/%s' % (name, len(values), worst))
            lines.append('%s ITCM_%s n/worst %s' % (corner, kind, ' '.join(items)))
        holds = [r for r in row['all_records'] if r['kind'] == 'hold']
        worst = min(holds, key=lambda r: r['slack'])['slack_text'] if holds else 'NO_MARKED_ROW'
        lines.append('%s DATA_HOLD worst_marked_native=%s [kind=hold only; not global min]' % (corner, worst))
    setup = [r for r in data['corners']['SS3']['all_records'] if r['kind'] == 'setup']
    lines.append('SS3 SETUP_BLOCK_ROWS=' + json.dumps(dict(Counter(r['block'] for r in setup)), sort_keys=True, separators=(',', ':')))
    accelerator = sorted((r for r in setup if r['block'] == 'accelerator'), key=lambda r: r['slack'])
    lines.append('SS3 ACCEL_SETUP shown=%d/%d marked rows:' % (min(3, len(accelerator)), len(accelerator)))
    for row in accelerator[:3]:
        lines.append('  L%d slack=%s %s' % (row['line'], row['slack_text'], row['object']))
    first = data['corners']['SS3'].get('first_setup')
    if first and first['status'] == 'COMPLETE':
        lines.append('SS3 FIRST_SETUP_START=' + first['start'])
        pin = first['pin']; shown_pin = 'END' + pin[len(first['end']):] if pin.startswith(first['end'] + '/') else pin
        lines.append('SS3 FIRST_SETUP_END=%s; actual_last_pin=%s' % (first['end'], shown_pin))
        lines.append('SS3 FIRST_NATIVE check=%s group=%s arrival=%s required=%s slack=%s' % (','.join(first['checks']) or 'UNKNOWN', first['group'], first['arrival'], first['required'], first['slack_text']))
    else:
        lines.append('SS3 FIRST_SETUP=UNKNOWN/' + (first['status'] if first else 'NO_STARTPOINT'))
    slew = [r for r in data['corners']['SS4']['all_records'] if r['kind'] == 'transition']
    lines.append('SS4 TRANSITION_BLOCK_ROWS=' + json.dumps(dict(Counter(r['block'] for r in slew)), sort_keys=True, separators=(',', ':')))
    if slew:
        row = min(slew, key=lambda r: r['slack'])
        lines.append('SS4 TRANSITION_WORST L%d slack=%s %s' % (row['line'], row['slack_text'], row['object']))
        lines.append('  native_numeric_columns=%s [Required/Actual slew per raw header; not data arrival]' % row['numeric_columns'])
    else:
        lines.append('SS4 TRANSITION_WORST=NO_MARKED_ROW; not a coverage verdict')
    groups = metrics.get('soc', {}).get('groups_um2', {})
    def av(key):
        value = groups.get(key)
        if value is None: return None
        value = float(value)
        require(math.isfinite(value) and value >= 0, 'Invalid area group: ' + key)
        return value
    def show(value):
        return 'UNKNOWN' if value is None else ('%.9g' % value)
    logic, sram = av('accelerator_logic'), av('accelerator_local_sram')
    subtotal = None if logic is None or sram is None else logic + sram
    lines.append('AREA_TT5 groups_um2 accel_logic=%s local_sram=%s SUBTOTAL=%s (mm2=%s)' % (show(logic), show(sram), show(subtotal), show(None if subtotal is None else subtotal / 1e6)))
    lines.append('AREA_TT5 groups_um2 new_arbiter=%s shared_glue=%s loader_dma=%s' % (show(av('new_systembus_arbiter')), show(av('shared_controller_glue')), show(av('loader_dma'))))
    lines.append('AREA_TT5 platform_including_modified_ppi_irq=%s; subtotal excludes unseparated interface logic; NOT official area verdict.' % show(av('platform_including_modified_ppi_irq')))
    lines.extend([
        'Parent=GLOBSLEW025; wr/sat prefixes + ITCM A/GWEN qualification + cost priority; DC0.25/PT0.30; NOT official certification.',
        'No marked row is not coverage PASS; max/min are query modes and min may be removal. LEC/power remain separate.',
        'BRIEF_COMPLETE: send these screens; complete native reports remain in this exact run.'
    ])
    return lines


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, help='Exact NEW_RUN from run_timing.py')
    args = parser.parse_args()
    for line in render(bound_summary(args.run)):
        print(line, flush=True)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as error:
        print('SUMMARY_REFUSED: ' + str(error), file=sys.stderr, flush=True)
        print('Existing EDA results were not modified; do not re-run EDA just for this summary.',
              file=sys.stderr, flush=True)
        sys.exit(2)
