#!/usr/bin/env python3
"""Run a NEW TARGETFIX_V1 candidate through RTL, then synthesis and seven-corner STA.

Python 3.6+, standard library. Uses the public entry CLI twice and passes the
exact NEW_RUN returned by the first call. Never chooses the latest run.
LEC and power are separate later stages. Exit 0 is not timing acceptance.
After synthesis/STA, a read-only summary uses that same exact run. Summary
failure returns 3 and does not restart any completed EDA stage.
"""
from __future__ import print_function

import argparse
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
CANDIDATE = "RTL3307_TCM128_TARGETFIX_V1"
ENTRY_NAME = "r2rtl3307_tcm128_targetfix_v1.py"
SUMMARY_NAME = "show_result.py"


def run_stage(command, capture_new_run=False):
    print("LAUNCH " + " ".join(command), flush=True)
    process = subprocess.Popen(command, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, universal_newlines=True,
                               bufsize=1)
    observed = []
    try:
        for line in process.stdout:
            print(line, end="", flush=True)
            if capture_new_run and line.startswith("NEW_RUN="):
                observed.append(line[len("NEW_RUN="):].strip())
        code = process.wait()
    finally:
        process.stdout.close()
    if code:
        raise RuntimeError("Stage exited %d; no later stage was started" % code)
    if capture_new_run:
        if len(observed) != 1:
            raise ValueError("Expected exactly one NEW_RUN; no synthesis started")
        folder = Path(observed[0])
        if not folder.is_absolute() or not folder.name.startswith("R2RTL3307_TCM128_TARGETFIX_V1_"):
            raise ValueError("Unexpected NEW_RUN identity; no synthesis started")
        manifest = folder / "payload" / "payload_manifest.json"
        with manifest.open("r", encoding="utf-8") as stream:
            metadata = json.load(stream)
        if metadata.get("candidate_id") != CANDIDATE:
            raise ValueError("NEW_RUN candidate mismatch; no synthesis started")
        return folder
    return None


def execute(entry, jobs):
    if jobs < 1:
        raise ValueError("jobs must be at least 1")
    entry = Path(entry).resolve()
    if not entry.is_file():
        raise ValueError("Missing candidate entry: " + str(entry))
    summary = entry.parent / SUMMARY_NAME
    if not summary.is_file():
        raise ValueError("Missing read-only result summary; no EDA started: " + str(summary))
    base = [sys.executable, "-B", "-u", str(entry)]
    folder = run_stage(base + ["run", "--stage", "rtl"], capture_new_run=True)
    print("BOUND_NEW_RUN=" + str(folder), flush=True)
    run_stage(base + ["run", "--stage", "synth", "--jobs", str(jobs),
                      "--run", str(folder)])
    print("TIMING_SEQUENCE_COMPLETE: reports require review; NOT timing PASS", flush=True)
    print("EXACT_RUN=" + str(folder), flush=True)
    print("LEC_AND_POWER_NOT_STARTED", flush=True)
    command = [sys.executable, "-B", str(summary), "--run", str(folder)]
    print("READ_ONLY_SUMMARY " + " ".join(command), flush=True)
    try:
        code = subprocess.call(command)
    except OSError as error:
        print("SUMMARY_FAILED: synthesis/STA already completed; existing results remain at " +
              str(folder) + "; no EDA stage restarted; " + str(error), file=sys.stderr, flush=True)
        return 3
    if code:
        print("SUMMARY_FAILED: exit %d; synthesis/STA already completed; existing results remain at %s; no EDA stage restarted" %
              (code, folder), file=sys.stderr, flush=True)
        return 3
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--jobs", type=int, default=4,
                        help="parallel LC/STA jobs passed to existing entry (default: 4)")
    args = parser.parse_args(argv)
    if args.jobs < 1:
        parser.error("--jobs must be at least 1")
    return execute(Path(__file__).resolve().parent / ENTRY_NAME, args.jobs)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nINTERRUPTED: no subsequent stage will be started", file=sys.stderr)
        sys.exit(130)
    except (OSError, ValueError, RuntimeError) as error:
        print("TIMING_SEQUENCE_STOPPED: " + str(error), file=sys.stderr, flush=True)
        sys.exit(1)
