"""W12 signed little-endian bitstream, two columns per block, four header words."""
import operator
import numpy as np

def _ints(values, lower, upper):
    values=np.asarray(values)
    if values.dtype.kind not in 'iu' or np.any(values<lower) or np.any(values>upper):
        raise ValueError('integer range violation')
    return values.astype(np.int64)

def pack_weights(weight,bias,shift):
    w=_ints(weight,-2048,2047); b=_ints(bias,-(1<<39),(1<<39)-1); s=_ints(shift,0,40)
    if w.ndim!=2: raise ValueError('W must be a matrix')
    k,n=w.shape
    if not 2<=k<=64 or k%2 or not 2<=n<=256 or n%2 or b.shape!=(n,) or s.shape!=(n,):
        raise ValueError('unsupported dimensions')
    count=(k*24+31)//32
    words=[]
    for col in range(0,n,2):
        for c in (col,col+1): words.extend([int(b[c])&0xffffffff,((int(b[c])>>32)&255)|(int(s[c])<<8)])
        stream=0
        for lane in range(k):
            stream|=(int(w[lane,col])&4095)<<(24*lane)
            stream|=(int(w[lane,col+1])&4095)<<(24*lane+12)
        words.extend((stream>>(32*i))&0xffffffff for i in range(count))
    return np.array(words,dtype=np.uint32)

def unpack_weights(words,k=64,n=256):
    k,n=operator.index(k),operator.index(n)
    if not 2<=k<=64 or k%2 or not 2<=n<=256 or n%2: raise ValueError('unsupported dimensions')
    words=_ints(words,0,0xffffffff); count=(k*24+31)//32
    if words.shape!=(n//2*(count+4),): raise ValueError('wrong packed length')
    w=np.zeros((k,n),dtype=np.int16); b=np.zeros(n,dtype=np.int64); s=np.zeros(n,dtype=np.int64)
    for block,cols in zip(words.reshape(-1,count+4),range(0,n,2)):
        for q in range(2):
            header=int(block[q*2+1])
            if header>>14 or header>>8>40: raise ValueError('invalid header')
            s[cols+q]=header>>8
            bias=int(block[q*2])|((header&255)<<32)
            b[cols+q]=(bias^(1<<39))-(1<<39)
        stream=sum(int(v)<<(32*i) for i,v in enumerate(block[4:]))
        if stream>>(k*24): raise ValueError('nonzero padding')
        for lane in range(k):
            for q in range(2):
                v=(stream>>(lane*24+q*12))&4095
                w[lane,cols+q]=(v^2048)-2048
    return w,b,s
