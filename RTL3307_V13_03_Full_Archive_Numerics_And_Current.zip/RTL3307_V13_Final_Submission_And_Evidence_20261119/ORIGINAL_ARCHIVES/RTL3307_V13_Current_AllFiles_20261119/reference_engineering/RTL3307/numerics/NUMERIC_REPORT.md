# X16 / W12 packed candidate — 2026-11-10

Status: implemented and locally verified in this isolated numeric directory. Original PC16 engineering remains the fallback. This candidate changes the encoded weight format and numerical values; always use its matching parameter files, packer, RTL and goldens together.

## Measured precision

Original float model, original train1200 and validation600, no training. The train/validation/model SHA256 values were rechecked against the original PC16 calibration receipt. X16 calibration margin and output margin remain1.25. Only the signed weight range changes. Training fits the scale/shift; validation selects width; the held-out600 testing set is evaluated exactly once after FORMAT_FREEZE.json.

|Weight bits|Validation maximum layer nRMSE|Validation clipping/saturation|
|---|---:|---|
|8|0.51718149%|0 / 0|
|12 selected|0.03338505%|0 / 0|
|14|0.01182917%|0 / 0|
|16 reference|0.00882640%|0 / 0|

Frozen W12 held-out testing maximum layer nRMSE: **0.033317850017%**, zero clipping and saturation across12layers ×600samples ×99rows ×256outputs. This is isolated FFN-layer numerical error against original float traces, not end-to-end classification accuracy or private committee evaluation. The discussed precision score formula10−error_percent/0.3 gives9.88894 for this measured public set; it is not an awarded score. See format_comparison.json, FORMAT_FREEZE.json, testing_started.json and testing_result.json.

## Implemented transport and arithmetic

- Input/output remain signed16bits. Bias remains signed40bits; shifts0..40 and postprocessing remain unchanged.
- Weight scale per output column = max_abs_original_weight/2047, not lossless truncation of PC16 coefficients. Packer rejects outside[-2048,2047].
- A two-column weight block has4unchanged header words followed by a little-endian bitstream. Lane0column0 occupies bits0..11, lane0column1 bits12..23, lane1column0 bits24..35, etc. Blocks are32bit-word aligned with zero tail padding.
- For arbitrary supported evenK2..64, payload words=ceil(24*K/32)=ceil(3*K/4). ForK64:48payload+4header=52words per column pair; N256 gives6656words/26624bytes instead of8704words/34816bytes: **23.5294% less Wpack transfer/storage**.
- kwt_wset physically stores48words per bank instead of64; total weight register storage3072bits instead of4096bits. Static bit slices cross word boundaries and sign-extend back to the unchanged2048bit operand interface.
- kwt_dot64 uses signed16×12 multiplication,28bit product registers,31bit8-product groups and34bit final sum. Its38bit output and3stage latency are preserved. Two columns still use128multipliers. Area/timing benefit requires native synthesis; no measured area saving is claimed here.
- X SRAM remains64×RAMSP128X16; no macro was removed. Read-DMA ordering, bank lifetime, abort drain, ranges, dimensions, MMIO, firmware, clock150MHz and completion at final write response are unchanged.

## Source changes and integration

Exactly8existing files changed, listed with before/after hashes in final_provenance.json:

1. source_snapshot/R2BIU_packet/rtl/accel/{kwt_ctrl.v,kwt_dot64.v,kwt_wset.v}.
2. Their source_snapshot/local_compile/rtl/e203/kwt mirrors.
3. source_snapshot/R2BIU_packet/tb/soc/kwt_tb_harness.sv and source_snapshot/local_compile/tb/kwt/kwt_tb_harness.sv: W_WORDS=6656.

SOURCE_MANIFEST.json is retained unchanged. VARIANT_MANIFEST.json binds original manifest hash and each changed/current source hash. Supplemental same-name module specs and JSON timing contracts are supplied separately.

Forserver/combined integration, bind validation_tasks/manifest.json and all meta/file hashes, replace anyoldPC16 taskdirectory with validation_tasks contents, and adjust expected accelerator read count to **3168+6656=9824**, write count12672. B host loading also uses6656weight words. Keep the B window from real first load to final output response.

Firmware requires no change: kwt_drv.c:kwt_start programs dimensions/bases/strides only; sw/tests/t_linear.c reads mailbox configuration and waits/reports counters. Neither computes Wpack bytes or DMA wordcount. The unchanged IRQ firmware hash d0dc44b20197f2336410b07fd70e144791332cb53f084bfa57248543abef4909 passed both SoC modes.

## Verification

- software_checks.json: every evenK2..64 pack/unpack roundtrip; out-of-range rejection;304128outputs checked with independent exact scalar MAC, ties-to-even and saturation.
- unit/simulation.log: NUMERIC_PACK_DOT_PASS,12cases; signed extrema; actual cross-word unpack; partialK2/6/10/62/64; alternating banks; load gaps; the existing top-level lane mask is retained in the fixture. Initial fixture failures came from omitting that mask and declaration order; final RTL needed no workaround.
- engine_regression/summary.json: NUMERIC_ENGINE_PASS. 12fulltasks,10random/boundaryshapes,18errors,3reset stages,poison/fullreload,SINGLE/DUAL,minshape and directedabort→minimumrestart. Protocol/backpressure/final-response checks remain enabled. Synthetic shape goldens use the inherited independent integer scalar evaluator and correctly packed W12 bytes; invalid/range assertions were preserved.
- engine/numeric_soc_local/summary.json: LOCAL_AB_W12_VALIDATION_TASKS_PASS. Each mode checks12tasks/304128outputs. A=203304cycles (16942each); B=363014cycles (30253first,30251thereafter). Original baseline replay was A250944/B459877cycles, but those baseline tasks are publictesting while this candidate RTL replay usesvalidation tasks; compare as fixed-shape traces, not same numerical inputs.

Entrypoints: evaluate_formats.py; export_numeric.py; evaluate_frozen.py (exclusive one-time marker); make_unit.py; run_numeric_regression.py; engine/run_numeric_soc.py. Use installed D:\dev c++\python.exe -B for numpy/scipy numeric work; no dependencies were installed. Example fresh SoC run:

```powershell
& 'D:\dev c++\python.exe' -B 'D:\Codex\ChipDesign\optimization_20261110\numeric\engine\run_numeric_soc.py' --output-name numeric_soc_recheck
```

The engine regression runner intentionally refuses an existing engine_regression output directory. Run it in a fresh copied variant directory when repeating or integrating, then set its source/manifest/tasks to the combined candidate. For combinedprefetch use+EXPECT_PREFETCH=1; numeric-only uses0. Entry: run_numeric_regression.py; helpers: regression_helpers/run_engine.py and run_arithmetic.py; fixture: tb_kwt_engine_numeric.v; packer:wpack12.py.

## Evidence limits

Actual ModelSim compilation and execution pass. Strict readable-verilog-generator gates for compile/AST/readability/comment/naming/profile fail on inherited style and formatter/parser constraints; original Wset review also fails. Testbench/toolchain are not_requested in that static tool report; separate actual ModelSim results above provide external evidence. Reports are retained for all3modified modules. No strict-gate pass is claimed, and unrelated project restyling was not performed. The governed spec writer failed because its renderer executable is unavailable; manual companion Markdown/JSON/WaveDrom contracts are provided, no renderedSVG claimed.

Official SRAM-macro GLS/SDF, native synthesis,150MHz STA, leakage/dynamicpower and physical area are unrun. This is a numerically controlled candidate with real packing and locally measured cycles, pending those checks before submission replacement.

## Matched comparison update — 2026-11-10

The differently-sampled baseline limitation above is superseded by MATCHED_PC16_REPORT.md and matched_pc16_comparison.json. The unchanged PC16 baseline passed the exact same12validation samples with byte-identical X.hex: A250944/B459877cycles. W12-only A203304/B363014 reduces cycles18.984315%/21.062806%. The separately merged ITCM3+W12+prefetch candidate has measured A193524/B273396cycles; see combined/engine/combined_soc/summary.json. All remain local behavioral evidence; officialEDA is unrun.
