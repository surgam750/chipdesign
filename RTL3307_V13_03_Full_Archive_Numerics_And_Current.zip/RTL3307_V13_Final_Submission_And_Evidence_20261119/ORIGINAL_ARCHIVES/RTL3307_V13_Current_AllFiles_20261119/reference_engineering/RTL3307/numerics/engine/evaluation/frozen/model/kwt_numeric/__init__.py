"""Bit-exact numeric contract for the KWT-1 undergraduate linear operator."""
