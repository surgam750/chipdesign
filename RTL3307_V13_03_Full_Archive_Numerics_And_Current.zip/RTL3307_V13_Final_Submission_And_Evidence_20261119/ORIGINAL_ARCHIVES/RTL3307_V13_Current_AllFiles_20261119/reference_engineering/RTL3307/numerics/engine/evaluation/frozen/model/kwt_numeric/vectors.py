"""Export PC16 testbench images and verify results with Python integers."""

import hashlib
import json
from pathlib import Path

import numpy as np

from .wpack import _checked_int, pack_weights


def _matrix_words(values, name):
    values = _checked_int(values, name, -32768, 32767)
    if values.ndim != 2 or not values.size or values.shape[1] % 2:
        raise ValueError(f"{name} must be a nonempty matrix with even row width")
    halves = (values & 0xFFFF).astype(np.uint32)
    return (halves[:, ::2] | (halves[:, 1::2] << 16)).reshape(-1)


def write_task(out, *, layer, sample_id, split, x, w, b, sh, y,
               model_sha256, calibration_sha256):
    """Write contiguous row-major X and Y images, Wpack, and their metadata."""
    x, w, y = np.asarray(x), np.asarray(w), np.asarray(y)
    images = {
        "x.hex": _matrix_words(x, "X"),
        "wpack.hex": pack_weights(w, b, sh),
        "y_golden.hex": _matrix_words(y, "Y"),
    }
    m, k = x.shape
    n = w.shape[1]
    if w.shape[0] != k or y.shape != (m, n):
        raise ValueError("Task shapes must be X[M,K], W[K,N], and Y[M,N]")
    metadata = {
        "layer": int(layer),
        "sample_id": sample_id,
        "split": split,
        "M": m,
        "K": k,
        "N": n,
        "model_sha256": model_sha256,
        "calibration_sha256": calibration_sha256,
        "files": {},
    }
    payloads = {}
    for name, words in images.items():
        payload = "".join(f"{word:08x}\n" for word in words).encode("ascii")
        payloads[name] = payload
        metadata["files"][name] = {
            "words": len(words),
            "sha256": hashlib.sha256(payload).hexdigest(),
        }
    manifest = (json.dumps(metadata, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    for name, payload in payloads.items():
        (out / name).write_bytes(payload)
    (out / "meta.json").write_bytes(manifest)
    return metadata


def scalar_verify(x, w, b, sh, y):
    """Check every Y element by exact scalar MAC, ties-to-even, and saturation."""
    x = _checked_int(x, "X", -32768, 32767)
    w = _checked_int(w, "W", -32768, 32767)
    b = _checked_int(b, "B", -(1 << 39), (1 << 39) - 1)
    sh = _checked_int(sh, "SH", 0, 40)
    y = _checked_int(y, "Y", -32768, 32767)
    if x.ndim != 2 or w.ndim != 2:
        raise ValueError("X and W must be matrices")
    m, k = x.shape
    n = w.shape[1]
    if w.shape[0] != k or y.shape != (m, n) or b.shape != (n,) or sh.shape != (n,):
        raise ValueError("Scalar check received incompatible task dimensions")

    columns = w.T.tolist()
    biases = b.tolist()
    divisors = [2 ** shift for shift in sh.tolist()]
    for row_index, (row, actual_row) in enumerate(zip(x.tolist(), y.tolist())):
        for col_index, (col, bias, divisor, actual) in enumerate(
            zip(columns, biases, divisors, actual_row)
        ):
            total = bias + sum(a * weight for a, weight in zip(row, col))
            rounded, remainder = divmod(total, divisor)
            if 2 * remainder > divisor or (2 * remainder == divisor and rounded % 2):
                rounded += 1
            expected = max(-32768, min(32767, rounded))
            if actual != expected:
                raise ValueError(
                    f"Y[{row_index},{col_index}] is {actual}, scalar expected {expected}"
                )
    return m * n
