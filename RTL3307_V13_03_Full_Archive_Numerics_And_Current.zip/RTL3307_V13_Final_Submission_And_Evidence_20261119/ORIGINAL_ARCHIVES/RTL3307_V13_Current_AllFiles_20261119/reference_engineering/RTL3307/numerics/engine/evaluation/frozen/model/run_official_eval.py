"""Run the frozen undergraduate KWT-1 PC16 numerical evaluation."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import wave

import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
if __package__ in (None, ""):
    sys.path.insert(0, str(ROOT))

from model.kwt_numeric.cli import evaluate_features, load_contract, write_json
from model.kwt_numeric.extract import sha256
from model.speech_features_reference import OfficialSpeechFeatures, load_audio, safe_archive_path

VENDOR = ROOT / "model/third_party/kwt_speech_features"
OFFICIAL_COMMIT = "237e4097afd4f6851e0b82f0a8d65c2dfe8eae30"
LIMIT = 0.03
BATCH = 16
ZERO_PCM_SHA256 = hashlib.sha256(bytes(32000)).hexdigest()


def read_mfcc(path, final):
    with np.load(path, allow_pickle=False) as archive:
        mfcc = archive["mfcc"]
        split = str(archive["split"].item()) if "split" in archive else "external"
        check_split(split, final)
    return mfcc, {"type": "mfcc_npz", "split": split, "sha256": sha256(path)}


def check_split(split, final):
    if split in ("testing", "evaluation") and not final:
        raise ValueError("testing/evaluation requires --final")


def wav_rows(path, final):
    if path.suffix.lower() == ".json":
        manifest = json.loads(path.read_text(encoding="utf-8-sig"))
        split = manifest.get("split", "external")
        rows = manifest["samples"]
        if manifest.get("count", len(rows)) != len(rows):
            raise ValueError("WAV manifest count differs from its sample list")
    else:
        split = "external"
        rows = [{"sample_id": name, "path": name, "kind": "wav"}
                for line in path.read_text(encoding="utf-8-sig").splitlines()
                if (name := line.strip())]
    check_split(split, final)
    ids = set()
    for row in rows:
        sample_id = row["sample_id"]
        if not isinstance(sample_id, str) or not sample_id or sample_id in ids:
            raise ValueError(f"empty or duplicate WAV sample ID: {sample_id!r}")
        ids.add(sample_id)
        if row.get("split", split) != split:
            raise ValueError(f"WAV sample split differs from its manifest: {sample_id}")
    if not rows:
        raise ValueError("WAV list is empty")
    return rows, split


def read_wavs(path, audio_root, final):
    rows, split = wav_rows(path, final)
    provenance = json.loads((VENDOR / "source_manifest.json").read_text(encoding="utf-8"))
    if provenance["commit"] != OFFICIAL_COMMIT:
        raise ValueError("unexpected SpeechFeatures source commit")
    for name, expected in provenance["sha256"].items():
        if sha256(safe_archive_path(VENDOR, name)) != expected:
            raise ValueError(f"SpeechFeatures digest mismatch: {name}")
    flags = json.loads((VENDOR / "flags.json").read_text(encoding="utf-8"))
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
    os.environ["TF_USE_LEGACY_KERAS"] = "1"
    extractor = OfficialSpeechFeatures(VENDOR, flags)
    batches = []
    source_digests = []
    for start in range(0, len(rows), BATCH):
        audio = []
        for row in rows[start:start + BATCH]:
            if row["kind"] == "zero_pcm" and row.get("path") is None:
                digest = ZERO_PCM_SHA256
                signal = load_audio(silence=True)
            elif row["kind"] == "wav" and row.get("path"):
                wav = safe_archive_path(audio_root, row["path"])
                digest = sha256(wav)
                signal = load_audio(wav)
            else:
                raise ValueError(f"invalid WAV sample: {row['sample_id']}")
            if row.get("source_sha256", digest) != digest:
                raise ValueError(f"audio digest mismatch: {row['sample_id']}")
            source_digests.append(digest)
            audio.append(signal)
        batches.append(extractor(np.stack(audio)))
    return np.concatenate(batches), {
        "type": "wav_list", "split": split, "sha256": sha256(path),
        "ordered_audio_digests_sha256": hashlib.sha256("".join(source_digests).encode("ascii")).hexdigest(),
        "speech_features_commit": OFFICIAL_COMMIT,
        "speech_features_manifest_sha256": sha256(VENDOR / "source_manifest.json"),
        "tensorflow": extractor.tf.__version__,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--mfcc-npz", type=Path)
    inputs.add_argument("--wav-list", type=Path, help="JSON manifest or text list of relative WAV paths")
    parser.add_argument("--audio-root", type=Path, help="WAV base directory (default: list directory)")
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--calibration", type=Path, required=True)
    parser.add_argument("--params-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True, help="JSON results")
    parser.add_argument("--final", action="store_true", help="permit a declared testing/evaluation split")
    args = parser.parse_args()
    if args.audio_root and not args.wav_list:
        parser.error("--audio-root requires --wav-list")
    start = perf_counter()
    try:
        weights, params = load_contract(args)
        if args.mfcc_npz:
            mfcc, source = read_mfcc(args.mfcc_npz, args.final)
        else:
            mfcc, source = read_wavs(args.wav_list, args.audio_root or args.wav_list.parent, args.final)
        if (mfcc.dtype.kind != "f" or mfcc.ndim != 3 or mfcc.shape[1:] != (98, 40)
                or len(mfcc) == 0 or not np.isfinite(mfcc).all()):
            raise ValueError("mfcc must be a nonempty finite floating-point [N,98,40] array")
        result = evaluate_features(mfcc, weights, params)
        passed = result["max_nrmse"] <= LIMIT
        write_json(args.out, {
            "status": "pass" if passed else "target_not_met",
            "profile": "undergraduate_pc16",
            "input": source,
            "mfcc_dtype": mfcc.dtype.str,
            "mfcc_values_sha256": hashlib.sha256(mfcc.tobytes()).hexdigest(),
            "weights_sha256": sha256(args.weights),
            "calibration_sha256": sha256(args.calibration),
            "python": sys.version.split()[0], "numpy": np.__version__, "scipy": scipy.__version__,
            "elapsed_seconds": perf_counter() - start,
            "nrmse_limit": LIMIT,
            "full_top1": {"status": "unavailable", "reason": "FULL fixed-point encoder is not implemented"},
            **result,
        })
    except (OSError, ImportError, KeyError, TypeError, ValueError, wave.Error) as error:
        parser.exit(2, f"Evaluation error: {error}\n")
    for row in result["layers"]:
        print(f"layer={row['layer']:02d} nrmse_pct={100 * row['nrmse']:.8f}")
    print(f"PC16_EVAL split={source['split']} samples={result['samples']} "
          f"max_nrmse_pct={100 * result['max_nrmse']:.8f} report={args.out}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
