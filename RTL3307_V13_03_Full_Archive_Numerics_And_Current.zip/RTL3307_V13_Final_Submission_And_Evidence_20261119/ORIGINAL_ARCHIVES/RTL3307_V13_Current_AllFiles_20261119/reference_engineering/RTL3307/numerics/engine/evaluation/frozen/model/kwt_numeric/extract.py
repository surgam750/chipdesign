"""Read partitioned MFCC inputs and obtain the KWT-1 FFN reference tensors."""

import hashlib
from pathlib import Path

import numpy as np

from model.kwt_full_reference import kwt_full_reference, load_kwt_weights

LAYERS = 12


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_features(path, split=None):
    with np.load(path, allow_pickle=False) as archive:
        features = archive["mfcc"]
        labels = archive["labels"]
        sample_ids = archive["sample_ids"].astype(str)
        observed_split = str(archive["split"].item())
    if split is not None and split != observed_split:
        raise ValueError(f"{path}: expected {split!r}, received {observed_split!r}")
    size = len(features)
    if (size == 0 or features.shape != (size, 98, 40) or
            not np.isfinite(features).all() or labels.shape != (size,) or
            sample_ids.shape != (size,) or len(set(sample_ids)) != size):
        raise ValueError(f"{path}: invalid or duplicated MFCC records")
    return features, labels, sample_ids, observed_split


def weights_for_layer(weights, layer):
    layer = weights[f"layer_{layer}"]
    return (layer["ffn_in_kernel"].astype(np.float64),
            layer["ffn_in_bias"].astype(np.float64))


def extract_layer(mfcc, weights, layer):
    _, trace = kwt_full_reference(mfcc, weights, return_intermediates=True)
    tensors = trace["layers"][f"layer_{layer}"]
    return tensors["attention_normalized"], tensors["ffn_hidden_linear"]


def collect_inputs(features, weights):
    """Cache only X; each float reference is X @ W + B from the same graph."""
    inputs = np.empty((LAYERS, len(features), 99, 64), dtype=np.float64)
    max_replay_difference = 0.0
    for index, mfcc in enumerate(features):
        _, trace = kwt_full_reference(mfcc, weights, return_intermediates=True)
        for layer in range(LAYERS):
            tensors = trace["layers"][f"layer_{layer}"]
            inputs[layer, index] = tensors["attention_normalized"]
            if index in (0, len(features) // 2, len(features) - 1):
                w, b = weights_for_layer(weights, layer)
                reconstructed = inputs[layer, index] @ w + b
                difference = np.max(np.abs(reconstructed - tensors["ffn_hidden_linear"]))
                max_replay_difference = max(max_replay_difference, float(difference))
    if max_replay_difference > 1e-12:
        raise AssertionError(f"float FFN trace replay differs by {max_replay_difference}")
    return inputs, max_replay_difference
