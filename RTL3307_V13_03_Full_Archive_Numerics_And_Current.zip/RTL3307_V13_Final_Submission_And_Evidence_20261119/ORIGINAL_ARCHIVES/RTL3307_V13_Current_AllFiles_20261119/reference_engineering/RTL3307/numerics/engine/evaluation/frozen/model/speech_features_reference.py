"""官方KWT@237e4097音频输入与SpeechFeatures包装；不以通用MFCC替代。"""
import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import sys
from types import SimpleNamespace
import wave
import numpy as np

LABELS = ('_silence_', '_unknown_', 'yes', 'no', 'up', 'down', 'left', 'right', 'on', 'off', 'stop', 'go')


def which_set(filename):
    """复现官方SHA1/_nohash_说话人分组，validation=10%、testing=10%。"""
    name = re.sub(r'_nohash_.*$', '', Path(filename).name)
    percentage = (int(hashlib.sha1(name.encode('utf-8')).hexdigest(), 16) % (2**27)) * (100.0/(2**27-1))
    return 'validation' if percentage < 10 else ('testing' if percentage < 20 else 'training')


def safe_archive_path(root, name):
    """仅接受目标目录内的相对POSIX路径，阻断Windows盘符和目录穿越。"""
    pure = PurePosixPath(name)
    if pure.is_absolute() or '..' in pure.parts or '\\' in name or ':' in name:
        raise ValueError(f'unsafe archive member: {name}')
    root = Path(root).resolve()
    result = root.joinpath(*pure.parts).resolve()
    if result != root and root not in result.parents:
        raise ValueError(f'archive member escapes root: {name}')
    return result


def load_audio(path=None, silence=False):
    """与16位PCM decode_wav一致地缩放、截断或补零至1秒。"""
    if silence:
        return np.zeros(16000, dtype=np.float32)
    with wave.open(str(path), 'rb') as source:
        if (source.getframerate(), source.getnchannels(), source.getsampwidth()) != (16000, 1, 2):
            raise ValueError('expected mono 16-bit PCM at 16000 Hz')
        samples = np.frombuffer(source.readframes(16000), dtype='<i2').astype(np.float32) / np.float32(32768.0)
    result = np.zeros(16000, dtype=np.float32)
    result[:len(samples)] = samples
    return result


class OfficialSpeechFeatures:
    """延迟加载固定提交的官方实现，CPU推理，无随机增强。"""
    def __init__(self, source_root, flags):
        source_root = Path(source_root).resolve()
        source = source_root/'kws_streaming/layers/speech_features.py'
        if not source.is_file():
            raise FileNotFoundError(f'official SpeechFeatures source missing: {source}')
        # oneDNN在纯正弦低能频带会产生批次相关舍入；冻结已验证的CPU执行路径。
        if 'tensorflow' in sys.modules and os.environ.get('TF_ENABLE_ONEDNN_OPTS') != '0':
            raise RuntimeError('set TF_ENABLE_ONEDNN_OPTS=0 before importing TensorFlow')
        os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
        os.environ.setdefault('TF_USE_LEGACY_KERAS', '1')
        sys.path.insert(0, str(source_root))
        import tensorflow as tf
        from kws_streaming.layers import speech_features, modes
        if Path(speech_features.__file__).resolve() != source:
            raise RuntimeError('a different kws_streaming installation was imported')
        self.tf = tf
        self.flags = dict(flags)
        self.overrides = dict(training=False, time_shift_ms=0.0, sp_time_shift_ms=0.0,
                              resample=0.0, sp_resample=0.0, volume_resample=0.0,
                              use_spec_augment=0, use_spec_cutout=0)
        self.flags.update(self.overrides)
        params = speech_features.SpeechFeatures.get_params(SimpleNamespace(**self.flags))
        self.layer = speech_features.SpeechFeatures(params, mode=modes.Modes.NON_STREAM_INFERENCE,
                                                   inference_batch_size=1, noise_scale=0.0)
        self.source_sha256 = {str(path.relative_to(source_root)): hashlib.sha256(path.read_bytes()).hexdigest()
                              for path in sorted((source_root/'kws_streaming/layers').glob('*.py'))}

    def __call__(self, audio):
        audio = np.asarray(audio, dtype=np.float32)
        if audio.ndim != 2 or audio.shape[1] != 16000 or not np.isfinite(audio).all():
            raise ValueError('audio must be finite [batch,16000] float32')
        result = self.layer(self.tf.constant(audio)).numpy()
        if result.shape != (len(audio), 98, 40) or not np.isfinite(result).all():
            raise ValueError(f'official MFCC output invalid: {result.shape}')
        return result
