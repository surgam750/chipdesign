"""Select the PC16 margin using training fit and validation-only metrics."""

from itertools import product

import numpy as np

from . import pc16
from .extract import LAYERS, collect_inputs, weights_for_layer
from .metrics import ErrorTotals

X_MARGINS = (1.0, 1.25, 1.5)
Y_MARGINS = (1.25, 1.5, 2.0)
SATURATION_LIMIT = 1e-6
NRMSE_TARGET = 0.0002
BATCH = 24


def evaluate_layer(inputs, w, b, params):
    metric = ErrorTotals()
    saturated = 0
    clipped = {"x": 0, "w": 0, "b": 0}
    for start in range(0, len(inputs), BATCH):
        rows = inputs[start:start + BATCH]
        x_int, w_int, b_int, counts = pc16.encode_layer(rows, w, b, params)
        y, sat_count = pc16.requantize(
            pc16.accumulate(x_int, w_int, b_int, exact_blas=True), params.shift
        )
        metric.update(pc16.decode(y, params), rows @ w + b)
        saturated += sat_count
        clipped["x"] += counts["x"]
        clipped["w"], clipped["b"] = counts["w"], counts["b"]
    return _record(metric, saturated, clipped, params)


def _record(metric, saturated, clipped, params):
    return {"nrmse": metric.result(), "elements": metric.count,
            "saturated": saturated, "saturation_ratio": saturated / metric.count,
            "clipped": clipped, "ex": int(params.ex),
            "shift_min": int(np.min(params.shift)), "shift_max": int(np.max(params.shift))}


def _evaluate_shifts(x, w, b, ex, weight_lsb, shifts):
    metrics = [ErrorTotals() for _ in shifts]
    sat = [0] * len(shifts)
    clipped = {"x": 0, "w": 0, "b": 0}
    params = [pc16.LayerParams(ex, weight_lsb, shift) for shift in shifts]
    for start in range(0, len(x), BATCH):
        rows = x[start:start + BATCH]
        x_int, w_int, b_int, counts = pc16.encode_layer(rows, w, b, params[0])
        total = pc16.accumulate(x_int, w_int, b_int, exact_blas=True)
        reference = rows @ w + b
        clipped["x"] += counts["x"]
        clipped["w"], clipped["b"] = counts["w"], counts["b"]
        for index, layer_params in enumerate(params):
            output, sat_count = pc16.requantize(total, layer_params.shift)
            metrics[index].update(pc16.decode(output, layer_params), reference)
            sat[index] += sat_count
    return params, [_record(m, s, clipped, p) for m, s, p in zip(metrics, sat, params)]


def fit_grid(train_features, validation_features, weights, *, progress=print):
    train, train_replay = collect_inputs(train_features, weights)
    progress(f"training traces ready: {len(train_features)}", flush=True)
    validation, validation_replay = collect_inputs(validation_features, weights)
    progress(f"validation traces ready: {len(validation_features)}", flush=True)
    candidates = {key: {"x_margin": key[0], "y_margin": key[1], "layers": []}
                  for key in product(X_MARGINS, Y_MARGINS)}
    params = {key: [] for key in candidates}
    for layer in range(LAYERS):
        w, b = weights_for_layer(weights, layer)
        w_lsb = pc16.weight_lsb_for(w)
        cache = {}
        for x_margin in X_MARGINS:
            ex = pc16.input_exponent(train[layer], x_margin)
            if ex not in cache:
                temporary = pc16.LayerParams(ex, w_lsb, np.zeros(pc16.N, dtype=np.int64))
                peak = np.zeros(pc16.N, dtype=np.int64)
                for start in range(0, len(train_features), BATCH):
                    rows = train[layer, start:start + BATCH]
                    a, k, offset, _ = pc16.encode_layer(rows, w, b, temporary)
                    total = pc16.accumulate(a, k, offset, exact_blas=True)
                    peak = np.maximum(peak, np.abs(total).reshape(-1, pc16.N).max(axis=0))
                shifts = [pc16.shift_for_peak(peak, y_margin) for y_margin in Y_MARGINS]
                cache[ex] = _evaluate_shifts(validation[layer], w, b, ex, w_lsb, shifts)
            fitted, records = cache[ex]
            for y_margin, layer_params, record in zip(Y_MARGINS, fitted, records):
                key = (x_margin, y_margin)
                params[key].append(layer_params)
                candidates[key]["layers"].append({"layer": layer, **record})
        progress(f"PC16 grid: layer {layer:02d}/11 complete", flush=True)
    for row in candidates.values():
        row["max_nrmse"] = max(layer["nrmse"] for layer in row["layers"])
        row["max_layer_saturation_ratio"] = max(layer["saturation_ratio"] for layer in row["layers"])
        row["saturation_ratio"] = sum(layer["saturated"] for layer in row["layers"]) / sum(
            layer["elements"] for layer in row["layers"]
        )
    eligible = [key for key, row in candidates.items()
                if row["max_layer_saturation_ratio"] <= SATURATION_LIMIT]
    best = min(eligible, key=lambda key: (candidates[key]["max_nrmse"], -key[0], -key[1]),
               default=None)
    report = {"training_examples": len(train_features), "validation_examples": len(validation_features),
              "float_trace_max_abs_diff": max(train_replay, validation_replay),
              "saturation_limit_per_layer": SATURATION_LIMIT, "nrmse_target": NRMSE_TARGET,
              "selected": candidates[best] if best is not None else None,
              "candidates": list(candidates.values())}
    return report, params[best] if best is not None else []
