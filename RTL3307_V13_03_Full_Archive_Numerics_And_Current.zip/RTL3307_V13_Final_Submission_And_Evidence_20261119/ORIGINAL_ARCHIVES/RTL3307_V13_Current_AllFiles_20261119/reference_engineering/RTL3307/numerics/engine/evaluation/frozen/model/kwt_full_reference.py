"""Official KWT-1 MFCC-to-logits floating reference; inference only.

NPZ keys are flat (``layer_0.q_kernel``); the public loader returns nested
``weights['layer_0']['q_kernel']`` and six named global tensors.
"""
from pathlib import Path
import importlib.util
import sys
import types

import numpy as np

from model.encoder_reference import WEIGHT_SHAPES, encoder_reference

GLOBAL_SHAPES = {
    'patch_proj_kernel': (40, 64), 'patch_proj_bias': (64,),
    'class_emb': (1, 1, 64), 'pos_emb': (1, 99, 64),
    'head_kernel': (64, 12), 'head_bias': (12,),
}
NPZ_SHAPES = dict(GLOBAL_SHAPES, **{
    f'layer_{i}.{name}': shape
    for i in range(12) for name, shape in WEIGHT_SHAPES.items()
})


def load_kwt_weights(path):
    """Validate the complete 162-tensor export, without pickle or defaults."""
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != set(NPZ_SHAPES):
            raise ValueError('NPZ must contain exactly the 162 named KWT-1 tensors')
        flat = {}
        for key, shape in NPZ_SHAPES.items():
            value = archive[key]
            if value.shape != shape or value.dtype != np.float32:
                raise ValueError(f'{key}: expected float32 {shape}, got {value.dtype} {value.shape}')
            if not np.isfinite(value).all():
                raise ValueError(f'{key}: nonfinite weights')
            flat[key] = value.copy()
    result = {name: flat[name] for name in GLOBAL_SHAPES}
    result.update({f'layer_{i}': {
        name: flat[f'layer_{i}.{name}'] for name in WEIGHT_SHAPES
    } for i in range(12)})
    return result


def kwt_full_reference(mfcc, weights, *, return_intermediates=False):
    """Evaluate one (98,40) MFCC matrix, returning 12 unnormalized logits.

The trace's patch_input already includes class token and position embedding.
Its layers field uses encoder_reference's existing layer trace names.
"""
    mfcc = np.asarray(mfcc, dtype=np.float64)
    if mfcc.shape != (98, 40) or not np.isfinite(mfcc).all():
        raise ValueError('mfcc must be finite with shape (98,40)')
    expected = set(GLOBAL_SHAPES) | {f'layer_{i}' for i in range(12)}
    if set(weights) != expected:
        raise ValueError('weights must contain six globals and layer_0 through layer_11')
    globals_ = {}
    for name, shape in GLOBAL_SHAPES.items():
        value = np.asarray(weights[name], dtype=np.float64)
        if value.shape != shape or not np.isfinite(value).all():
            raise ValueError(f'{name}: expected finite {shape}')
        globals_[name] = value
    projected = mfcc @ globals_['patch_proj_kernel'] + globals_['patch_proj_bias']
    tokens = np.concatenate((globals_['class_emb'][0], projected), axis=0)
    patch_input = tokens + globals_['pos_emb'][0]
    layers = {f'layer_{i}': weights[f'layer_{i}'] for i in range(12)}
    encoded = encoder_reference(patch_input, layers, return_intermediates=return_intermediates)
    if return_intermediates:
        encoded, layer_traces = encoded
    class_features = encoded[0]
    logits = class_features @ globals_['head_kernel'] + globals_['head_bias']
    if not np.isfinite(logits).all():
        raise ValueError('nonfinite logits')
    if return_intermediates:
        return logits, {'patch_projected': projected, 'patch_input': patch_input,
                        'layers': layer_traces, 'class_features': class_features,
                        'encoder_output': encoded, 'logits': logits}
    return logits


def build_official_tf_reference(source_dir, checkpoint_prefix):
    """Restore original ARM classes independently from the checkpoint.

Requires TF_USE_LEGACY_KERAS=1 before TensorFlow import. The upstream source is
not edited. Modern Python lacks the historical TFA wheel: only the stateless
TFA GELU layer is adapted to tf.nn.gelu with the identical approximate flag.
This is explicitly a compatibility execution, not the original TF 2.4 runtime.
Returns (model, transformer, head, restoration_status).
"""
    import tensorflow as tf

    class ExactGELU(tf.keras.layers.Layer):
        def __init__(self, approximate=False, **kwargs):
            super().__init__(**kwargs)
            self.approximate = approximate

        def call(self, inputs):
            return tf.nn.gelu(inputs, approximate=self.approximate)

    # Restrict the temporary shim to loading this source module. No installed
    # package or official file is modified, and no other Addons API is supplied.
    shim = types.ModuleType('tensorflow_addons')
    shim.layers = types.SimpleNamespace(GELU=ExactGELU)
    previous = sys.modules.get('tensorflow_addons')
    sys.modules['tensorflow_addons'] = shim
    try:
        path = Path(source_dir) / 'kws_streaming/models/transformer_utils.py'
        spec = importlib.util.spec_from_file_location('_kwt_official_transformer', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop('tensorflow_addons', None)
        else:
            sys.modules['tensorflow_addons'] = previous
    transformer = module.KWSTransformer(
        num_patches=98, num_layers=12, num_classes=12, d_model=64,
        num_heads=1, mlp_dim=256, dropout=0.0, prenorm=False,
        distill_token=False, approximate_gelu=False)
    head = tf.keras.Sequential([tf.keras.layers.Dense(12)])
    inputs = tf.keras.Input(shape=(98, 40), dtype=tf.float32)
    model = tf.keras.Model(inputs, head(transformer(inputs, training=False)))
    status = model.load_weights(str(checkpoint_prefix))
    status.assert_nontrivial_match()
    status.assert_existing_objects_matched()
    status.expect_partial()  # The training optimizer is intentionally unused.
    if model.count_params() != 607308:
        raise AssertionError('unexpected restored model parameter count')
    return model, transformer, head, status
