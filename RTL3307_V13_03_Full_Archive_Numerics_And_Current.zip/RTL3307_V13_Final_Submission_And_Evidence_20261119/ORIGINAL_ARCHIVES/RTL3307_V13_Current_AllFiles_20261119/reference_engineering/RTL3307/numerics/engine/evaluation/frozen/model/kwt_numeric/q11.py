"""Q11 compatibility mode with Q22 bias and RNE output."""

import numpy as np

from . import pc16

PARAMS = pc16.LayerParams(11, np.full(pc16.N, 2.0 ** -11),
                          np.full(pc16.N, 11, dtype=np.int64))


def encode(x, w, b):
    return pc16.encode_layer(x, w, b, PARAMS)


def run(x, w, b):
    return pc16.run_layer_int(x, w, b, PARAMS.shift)


def decode(y):
    return pc16.decode(y, PARAMS)
