"""Streaming per-layer nRMSE across all evaluated output elements."""

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class ErrorTotals:
    error_square: float = 0.0
    ref_square: float = 0.0
    count: int = 0

    def update(self, actual, expected):
        actual = np.asarray(actual, dtype=np.float64)
        expected = np.asarray(expected, dtype=np.float64)
        if (actual.shape != expected.shape or not np.isfinite(actual).all()
                or not np.isfinite(expected).all()):
            raise ValueError("metric inputs must be finite with matching shapes")
        self.error_square += float(np.sum(np.square(actual - expected)))
        self.ref_square += float(np.sum(np.square(expected)))
        self.count += expected.size

    def result(self):
        if self.count == 0:
            raise ValueError("empty metric")
        return math.sqrt(self.error_square / self.count) / max(
            math.sqrt(self.ref_square / self.count), 1e-8
        )
