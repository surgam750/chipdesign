"""PC16 weight package used by the accelerator and its testbench."""

import operator

import numpy as np


def _checked_int(values, name, minimum, maximum):
    values = np.asarray(values)
    if values.dtype.kind not in "iu" or np.any(values < minimum) or np.any(values > maximum):
        raise ValueError(f"{name} must contain integers in [{minimum}, {maximum}]")
    return values.astype(np.int64, copy=False)


def _check_dimensions(k, n):
    if k <= 0 or n <= 0 or n % 2:
        raise ValueError("Wpack requires positive K and positive even N")


def pack_weights(weight, bias, shift):
    """Pack W[K,N], signed 40-bit B[N], and SH[N] into flat uint32 words."""
    weight = _checked_int(weight, "W", -32768, 32767)
    bias = _checked_int(bias, "B", -(1 << 39), (1 << 39) - 1)
    shift = _checked_int(shift, "SH", 0, 40)
    if weight.ndim != 2:
        raise ValueError("W must have shape (K, N)")
    k, n = weight.shape
    _check_dimensions(k, n)
    if bias.shape != (n,) or shift.shape != (n,):
        raise ValueError("B and SH must both have shape (N,)")

    blocks = np.empty((n // 2, k + 4), dtype=np.uint32)
    blocks[:, 0:4:2] = (bias & 0xFFFFFFFF).reshape(-1, 2)
    blocks[:, 1:4:2] = (((bias >> 32) & 0xFF) | (shift << 8)).reshape(-1, 2)
    halves = (weight & 0xFFFF).astype(np.uint32)
    blocks[:, 4:] = (halves[:, ::2] | (halves[:, 1::2] << 16)).T
    return blocks.reshape(-1)


def unpack_weights(words, k=64, n=256):
    """Return signed W (int16), B (int64), and SH (int64)."""
    k, n = operator.index(k), operator.index(n)
    _check_dimensions(k, n)
    words = _checked_int(words, "Wpack words", 0, 0xFFFFFFFF)
    if words.shape != (n // 2 * (k + 4),):
        raise ValueError("Wpack must be flat with exactly N/2 * (K+4) words")
    blocks = words.reshape(n // 2, k + 4)
    headers = blocks[:, 1:4:2].reshape(-1)
    if np.any(headers >> 14):
        raise ValueError("Wpack header has nonzero reserved bits")
    shift = headers >> 8
    if np.any(shift > 40):
        raise ValueError("Wpack SH exceeds 40")

    bias = blocks[:, 0:4:2].reshape(-1) | ((headers & 0xFF) << 32)
    bias = (bias ^ (1 << 39)) - (1 << 39)
    weight_words = blocks[:, 4:].T
    weight = np.empty((k, n), dtype=np.int16)
    weight[:, ::2] = (weight_words & 0xFFFF).astype(np.int16)
    weight[:, 1::2] = (weight_words >> 16).astype(np.int16)
    return weight, bias, shift
