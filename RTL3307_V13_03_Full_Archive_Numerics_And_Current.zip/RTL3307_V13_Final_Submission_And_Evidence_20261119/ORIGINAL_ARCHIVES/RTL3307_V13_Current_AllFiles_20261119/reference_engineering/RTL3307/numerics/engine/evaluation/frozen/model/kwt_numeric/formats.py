"""Signed conversion and integer round-to-nearest, ties-to-even."""

import numpy as np


def saturate(value, bits):
    limit = 1 << (bits - 1)
    value = np.asarray(value)
    return np.clip(value, -limit, limit - 1), int(
        np.count_nonzero((value < -limit) | (value >= limit))
    )


def quantize(value, lsb, bits):
    value = np.asarray(value, dtype=np.float64)
    lsb = np.asarray(lsb, dtype=np.float64)
    if not np.isfinite(value).all() or not np.isfinite(lsb).all() or np.any(lsb <= 0):
        raise ValueError("quantization requires finite inputs and positive finite scales")
    with np.errstate(over="ignore"):
        rounded = np.rint(value / lsb)
    clipped, count = saturate(rounded, bits)
    return clipped.astype(np.int64), count


def rne_shift_scalar(value, shift):
    if not 0 <= shift <= 40:
        raise ValueError("shift must be in [0, 40]")
    divisor = 1 << shift
    quotient, remainder = divmod(int(value), divisor)
    return quotient + int(2 * remainder > divisor or
                          (2 * remainder == divisor and quotient % 2 == 1))


def rne_shift(value, shift):
    value = np.asarray(value, dtype=np.int64)
    shift = np.asarray(shift)
    if not np.issubdtype(shift.dtype, np.integer) or np.any((shift < 0) | (shift > 40)):
        raise ValueError("shift must contain integers in [0, 40]")
    shift = shift.astype(np.int64)
    quotient = value >> shift
    remainder = value - (quotient << shift)
    half = np.int64(1) << np.maximum(shift - 1, 0)
    up = (shift != 0) & ((remainder > half) |
                         ((remainder == half) & ((quotient & 1) != 0)))
    return quotient + up
