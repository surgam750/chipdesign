"""KWT-1 十二层 PostNorm 编码器的 float64 软件参考，不包含音频前端或分类头。

数学合同来自 ARM-software/keyword-transformer@237e4097。
只接收显式参数；不生成、补全或下载权重。矩阵方向为 Keras 的 input x output。
"""
from collections.abc import Mapping
import numpy as np
from scipy.special import erf

INPUT_SHAPE = (99, 64)
LAYERS = 12
EPSILON = 1e-6
WEIGHT_SHAPES = {
    'q_kernel': (64, 64), 'k_kernel': (64, 64), 'v_kernel': (64, 64),
    'combine_kernel': (64, 64), 'combine_bias': (64,),
    'ln1_gamma': (64,), 'ln1_beta': (64,),
    'ffn_in_kernel': (64, 256), 'ffn_in_bias': (256,),
    'ffn_out_kernel': (256, 64), 'ffn_out_bias': (64,),
    'ln2_gamma': (64,), 'ln2_beta': (64,),
}


def _array(value, shape, name):
    """拒绝错误维度、非实数和非有限值，然后提升到 float64。"""
    array = np.asarray(value)
    if array.shape != shape:
        raise ValueError(f'{name}: expected shape {shape}, got {array.shape}')
    if array.dtype.kind not in 'fiu':
        raise ValueError(f'{name}: real numeric array required')
    array = np.asarray(array, dtype=np.float64)
    if not np.isfinite(array).all():
        raise ValueError(f'{name}: all values must be finite')
    return array


def _weights(weights, name):
    """检查完整参数集合，不允许带偏置的 Q/K/V 悄悄进入合同。"""
    if not isinstance(weights, Mapping):
        raise ValueError(f'{name}: explicit weight mapping required')
    expected = set(WEIGHT_SHAPES)
    supplied = set(weights)
    if supplied != expected:
        raise ValueError(f'{name}: missing={sorted(expected-supplied)}, '
                         f'unexpected={sorted(supplied-expected, key=str)}')
    return {key: _array(weights[key], shape, f'{name}.{key}')
            for key, shape in WEIGHT_SHAPES.items()}


def _normalize(value, gamma, beta):
    """最后一个维度上的总体方差，epsilon 加在平方根内部。"""
    mean = np.mean(value, axis=-1, keepdims=True)
    variance = np.mean(np.square(value - mean), axis=-1, keepdims=True)
    normalized = (value - mean) / np.sqrt(variance + EPSILON)
    return normalized * gamma + beta, mean, variance


def _forward(inputs, weights):
    """单头注意力、两次后归一化与 erf GELU 的明确计算图。"""
    trace = {'input': inputs.copy()}
    trace['q'] = inputs @ weights['q_kernel']
    trace['k'] = inputs @ weights['k_kernel']
    trace['v'] = inputs @ weights['v_kernel']
    trace['attention_scores'] = (trace['q'] @ trace['k'].T) / np.sqrt(64.0)
    shifted = trace['attention_scores'] - np.max(trace['attention_scores'], axis=-1, keepdims=True)
    exponentials = np.exp(shifted)
    trace['attention_probs'] = exponentials / np.sum(exponentials, axis=-1, keepdims=True)
    trace['attention_context'] = trace['attention_probs'] @ trace['v']
    trace['attention_projected'] = trace['attention_context'] @ weights['combine_kernel'] + weights['combine_bias']
    trace['attention_residual'] = inputs + trace['attention_projected']
    trace['attention_normalized'], trace['ln1_mean'], trace['ln1_variance'] = _normalize(
        trace['attention_residual'], weights['ln1_gamma'], weights['ln1_beta'])
    trace['ffn_hidden_linear'] = trace['attention_normalized'] @ weights['ffn_in_kernel'] + weights['ffn_in_bias']
    hidden = trace['ffn_hidden_linear']
    trace['ffn_hidden_gelu'] = 0.5 * hidden * (1.0 + erf(hidden / np.sqrt(2.0)))
    trace['ffn_output'] = trace['ffn_hidden_gelu'] @ weights['ffn_out_kernel'] + weights['ffn_out_bias']
    trace['ffn_residual'] = trace['attention_normalized'] + trace['ffn_output']
    trace['output'], trace['ln2_mean'], trace['ln2_variance'] = _normalize(
        trace['ffn_residual'], weights['ln2_gamma'], weights['ln2_beta'])
    for name, value in trace.items():
        if not np.isfinite(value).all():
            raise ValueError(f'{name}: non-finite intermediate result')
    return trace


def encoder_layer(inputs, weights, *, return_intermediates=False):
    """计算一层，返回 (99,64) 或 (输出, 中间张量字典)。

    weights 必须完整提供 WEIGHT_SHAPES 中的全部十三项参数。
    运算采用 float64；溢出显式报错。不会改写调用者输入或权重。
    """
    inputs = _array(inputs, INPUT_SHAPE, 'inputs')
    weights = _weights(weights, 'weights')
    try:
        with np.errstate(over='raise', invalid='raise', divide='raise', under='ignore'):
            trace = _forward(inputs, weights)
    except FloatingPointError as error:
        raise ValueError(f'encoder arithmetic overflow or invalid operation: {error}') from error
    return (trace['output'], trace) if return_intermediates else trace['output']


def encoder_reference(inputs, layer_weights, *, return_intermediates=False):
    """按 layer_0 至 layer_11 顺序执行十二层，禁止隐式权重补全。

    layer_weights 为外层字典，各值为一层完整参数字典。开启中间结果时返回
    (最终输出, {'layer_0': {...}, ..., 'layer_11': {...}})，可直接导出每层张量。
    输入已经包含 patch 投影、class token 和位置编码；本函数不重复添加它们。
    """
    inputs = _array(inputs, INPUT_SHAPE, 'inputs')
    names = [f'layer_{index}' for index in range(LAYERS)]
    if not isinstance(layer_weights, Mapping) or set(layer_weights) != set(names):
        raise ValueError('layer_weights must contain exactly layer_0 through layer_11')
    # 先验证全部参数，避免执行到中途才发现后续层缺权重。
    validated = {name: _weights(layer_weights[name], name) for name in names}
    traces = {}
    try:
        with np.errstate(over='raise', invalid='raise', divide='raise', under='ignore'):
            for name in names:
                trace = _forward(inputs, validated[name])
                inputs = trace['output']
                if return_intermediates:
                    traces[name] = trace
    except FloatingPointError as error:
        raise ValueError(f'encoder arithmetic overflow or invalid operation: {error}') from error
    return (inputs, traces) if return_intermediates else inputs
