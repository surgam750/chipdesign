"""Reproducible PC16 calibration, evaluation, and task-image commands."""

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import scipy

from . import pc16
from .calibration import NRMSE_TARGET, evaluate_layer, fit_grid
from .extract import (LAYERS, collect_inputs, extract_layer, load_features,
                      load_kwt_weights, sha256, weights_for_layer)
from .formats import quantize, rne_shift, rne_shift_scalar
from .metrics import ErrorTotals
from .vectors import scalar_verify, write_task
from .wpack import pack_weights, unpack_weights


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                    encoding="utf-8", newline="\n")


def _sources():
    root = Path(__file__).parent
    sources = sorted(root.glob("*.py")) + [
        root.parent / "encoder_reference.py", root.parent / "kwt_full_reference.py"
    ]
    return {path.name: sha256(path) for path in sources}


def calibrate_cmd(args):
    train, train_labels, train_ids, _ = load_features(args.training, "training")
    val, val_labels, val_ids, _ = load_features(args.validation, "validation")
    _, class_counts = np.unique(train_labels, return_counts=True)
    if len(class_counts) != 12 or min(class_counts) < 100:
        raise ValueError("each of the 12 training classes needs at least 100 examples")
    if len(val) != 600 or len(np.unique(val_labels)) != 12 or set(train_ids) & set(val_ids):
        raise ValueError("expected 600 validation examples in 12 classes, disjoint from training IDs")
    weights = load_kwt_weights(args.weights)
    report, fitted = fit_grid(train, val, weights)
    report.update({
        "model_sha256": sha256(args.weights),
        "training_mfcc_sha256": sha256(args.training),
        "validation_mfcc_sha256": sha256(args.validation),
        "training_manifest_sha256": sha256(args.manifest),
        "training_class_counts": class_counts.tolist(),
        "sources": _sources(),
        "command": [sys.executable, "-m", "model.kwt_numeric.cli", *sys.argv[1:]],
        "python": sys.version.split()[0], "numpy": np.__version__, "scipy": scipy.__version__,
    })
    with np.load(args.training, allow_pickle=False) as archive:
        if str(archive["manifest_sha256"].item()) != report["training_manifest_sha256"]:
            raise ValueError("training MFCC and manifest hashes disagree")
    selected = report["selected"]
    if selected is not None:
        report["max_validation_nrmse"] = selected["max_nrmse"]
    passed = selected is not None and selected["max_nrmse"] <= NRMSE_TARGET
    report["status"] = "pass" if passed else "target_not_met"
    if passed:
        report["params"] = {}
        for layer, layer_params in enumerate(fitted):
            name = f"pc16_layer_{layer:02d}.json"
            path = args.params_dir / name
            write_json(path, {"layer": layer, **layer_params.to_dict()})
            report["params"][name] = sha256(path)
    write_json(args.report, report)
    if not passed:
        print(f"PC16_CALIBRATION_TARGET_NOT_MET report={args.report}")
        return 1
    print("PC16_CALIBRATION_PASS "
          f"nrmse_pct={100*selected['max_nrmse']:.8f} "
          f"worst_saturation={selected['max_layer_saturation_ratio']:.8g} "
          f"mx={selected['x_margin']} my={selected['y_margin']}")
    return 0


def load_contract(args):
    report = json.loads(args.calibration.read_text(encoding="utf-8"))
    if report["status"] != "pass" or sha256(args.weights) != report["model_sha256"]:
        raise ValueError("PC16 calibration has not passed or weights do not match")
    params = []
    for layer in range(LAYERS):
        name = f"pc16_layer_{layer:02d}.json"
        path = args.params_dir / name
        if sha256(path) != report["params"][name]:
            raise ValueError(f"PC16 parameter digest mismatch: {name}")
        params.append(pc16.LayerParams.from_dict(json.loads(path.read_text(encoding="utf-8"))))
    return load_kwt_weights(args.weights), params


def evaluate_features(mfcc, weights, params):
    inputs, replay = collect_inputs(mfcc, weights)
    layers = [{"layer": layer, **evaluate_layer(inputs[layer], *weights_for_layer(weights, layer),
                                               params[layer])}
              for layer in range(LAYERS)]
    return {"samples": len(mfcc), "float_trace_max_abs_diff": replay, "layers": layers,
            "max_nrmse": max(row["nrmse"] for row in layers)}


def eval_cmd(args):
    if args.split == "testing" and not args.final:
        raise ValueError("testing is reserved for the final frozen evaluation")
    weights, params = load_contract(args)
    features, _, _, split = load_features(args.mfcc, args.split)
    result = evaluate_features(features, weights, params)
    write_json(args.out, {"split": split, "mfcc_sha256": sha256(args.mfcc),
                          "calibration_sha256": sha256(args.calibration), **result})
    print(f"PC16_EVAL split={split} max_nrmse_pct={100*result['max_nrmse']:.8f}")
    return 0 if result["max_nrmse"] <= 0.03 else 1


def _task(args, weights, params, layer, x, reference, label, sample_id, split, out):
    w, b = weights_for_layer(weights, layer)
    contract = params[layer]
    x_int, w_int, b_int, clipped = pc16.encode_layer(x, w, b, contract)
    y, sat = pc16.run_layer_int(x_int, w_int, b_int, contract.shift)
    checked = scalar_verify(x_int, w_int, b_int, contract.shift, y)
    metadata = write_task(out, layer=layer, sample_id=sample_id, split=split,
                          x=x_int, w=w_int, b=b_int, sh=contract.shift, y=y,
                          model_sha256=sha256(args.weights),
                          calibration_sha256=sha256(args.calibration))
    metric = ErrorTotals()
    metric.update(pc16.decode(y, contract), reference)
    metadata.update({"label": label, "nrmse": metric.result(), "scalar_checked": checked,
                     "saturated": sat, "clipped": clipped, "ex": int(contract.ex),
                     "accum_lsb": contract.accum_lsb.tolist(), "shift": contract.shift.tolist()})
    write_json(out / "meta.json", metadata)
    return metadata


def export_suite_cmd(args):
    if args.split == "testing" and not args.final:
        raise ValueError("testing vectors are reserved for the final frozen evaluation")
    weights, params = load_contract(args)
    features, labels, ids, split = load_features(args.mfcc, args.split)
    classes = np.unique(labels)
    if len(classes) != LAYERS:
        raise ValueError("a balanced task suite needs 12 labels")
    tasks = []
    for layer, label in enumerate(classes):
        index = int(np.flatnonzero(labels == label)[0])
        folder = f"task_{layer:02d}_{index:04d}"
        x, reference = extract_layer(features[index], weights, layer)
        task = _task(args, weights, params, layer, x, reference, label.item(), str(ids[index]),
                     split, args.out / folder)
        tasks.append({"directory": folder, "meta_sha256": sha256(args.out / folder / "meta.json"),
                      "layer": layer, "nrmse": task["nrmse"],
                      "scalar_checked": task["scalar_checked"]})
    summary = {"split": split, "mfcc_sha256": sha256(args.mfcc),
               "tasks": tasks, "scalar_checked": sum(t["scalar_checked"] for t in tasks),
               "max_task_nrmse": max(t["nrmse"] for t in tasks)}
    write_json(args.out / "manifest.json", summary)
    print(f"PC16_TASKS scalar_checked={summary['scalar_checked']} "
          f"max_task_nrmse_pct={100*summary['max_task_nrmse']:.8f}")
    return 0 if summary["max_task_nrmse"] <= 0.03 else 1


def export_task_cmd(args):
    weights, params = load_contract(args)
    x = np.load(args.from_float, allow_pickle=False)
    if x.shape != (99, 64) or x.dtype.kind != "f":
        raise ValueError("task requires a floating-point [99,64] NumPy array")
    w, b = weights_for_layer(weights, args.layer)
    _task(args, weights, params, args.layer, x, x @ w + b, None,
          args.from_float.stem, "external", args.out)
    return 0


def selftest_cmd(args):
    exact = [
        (-5, 1, -2), (-3, 1, -2), (-1, 1, 0), (1, 1, 0), (3, 1, 2), (5, 1, 2),
        (-(1 << 41), 40, -2), ((1 << 41) - 1, 40, 2), (15, 0, 15),
    ]
    for value, shift, expected in exact:
        assert rne_shift_scalar(value, shift) == int(rne_shift(value, shift)) == expected
    rng = np.random.default_rng(20261104)
    values = rng.integers(-(1 << 41), 1 << 41, size=1_000_000, dtype=np.int64)
    shifts = rng.integers(0, 41, size=len(values), dtype=np.int64)
    expected = np.fromiter((rne_shift_scalar(v, int(s)) for v, s in zip(values, shifts)),
                           dtype=np.int64, count=len(values))
    np.testing.assert_array_equal(rne_shift(values, shifts), expected)
    np.testing.assert_array_equal(quantize([-32769, -2.5, 2.5, 32768], 1.0, 16)[0],
                                  [-32768, -2, 2, 32767])
    x = rng.integers(-32768, 32768, size=(99, 64), dtype=np.int64)
    w = rng.integers(-32768, 32768, size=(64, 256), dtype=np.int64)
    b = rng.integers(-(1 << 39), 1 << 39, size=256, dtype=np.int64)
    s = rng.integers(0, 41, size=256, dtype=np.int64)
    x[0], w[:, 0] = -32768, -32768
    np.testing.assert_array_equal(pc16.accumulate(x, w, b, exact_blas=True), pc16.accumulate(x, w, b))
    words = pack_weights(w, b, s)
    assert len(words) == 8704
    for actual, original in zip(unpack_weights(words), (w, b, s)):
        np.testing.assert_array_equal(actual, original)
    y, saturated = pc16.run_layer_int(x, w, b, s)
    checked = scalar_verify(x, w, b, s, y)
    assert 0 < saturated < checked
    p = pc16.LayerParams(12, np.ones(256), s)
    expected = np.array([int(v) * 2.0 ** (int(shift) - 12) for v, shift in zip(y[0], s)])
    np.testing.assert_array_equal(pc16.decode(y[0], p), expected)
    report = {"status": "pass", "rne_scalar_vector": len(values), "rne_directed": len(exact),
              "scalar_matrix_outputs": checked, "saturated": saturated, "wpack_words": len(words),
              "sources": _sources(),
              "command": [sys.executable, "-m", "model.kwt_numeric.cli", *sys.argv[1:]]}
    write_json(args.report, report)
    print(f"PC16_SELFTEST_PASS shifts={len(values)} outputs={checked} wpack={len(words)}")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    fit = actions.add_parser("calibrate")
    for name in ("training", "validation", "manifest", "weights"):
        fit.add_argument(f"--{name}", type=Path, required=True)
    fit.add_argument("--params-dir", type=Path, default=Path("params"))
    fit.add_argument("--report", type=Path, default=Path("reports/numeric/pc16_calibration.json"))
    fit.set_defaults(handler=calibrate_cmd)
    test = actions.add_parser("selftest")
    test.add_argument("--report", type=Path, default=Path("reports/numeric/selftest.json"))
    test.set_defaults(handler=selftest_cmd)
    for command, handler in (("eval", eval_cmd), ("export-suite", export_suite_cmd),
                             ("export-task", export_task_cmd)):
        action = actions.add_parser(command)
        action.add_argument("--weights", type=Path, required=True)
        action.add_argument("--calibration", type=Path,
                            default=Path("reports/numeric/pc16_calibration.json"))
        action.add_argument("--params-dir", type=Path, default=Path("params"))
        action.add_argument("--out", type=Path, required=True)
        if command == "export-task":
            action.add_argument("--layer", type=int, required=True, choices=range(LAYERS))
            action.add_argument("--from-float", type=Path, required=True)
        else:
            action.add_argument("--mfcc", type=Path, required=True)
            action.add_argument("--split", choices=("validation", "testing"), default="validation")
            action.add_argument("--final", action="store_true")
        action.set_defaults(handler=handler)
    args = parser.parse_args()
    return args.handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
