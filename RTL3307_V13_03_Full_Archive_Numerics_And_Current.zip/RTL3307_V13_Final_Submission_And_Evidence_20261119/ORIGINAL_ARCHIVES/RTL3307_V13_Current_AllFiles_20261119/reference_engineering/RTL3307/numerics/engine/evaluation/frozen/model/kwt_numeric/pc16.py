"""PC16 calibration, encoding, integer evaluation and decoding."""

import math
from dataclasses import dataclass

import numpy as np

from .formats import quantize, rne_shift, saturate

K, N = 64, 256


@dataclass(frozen=True)
class LayerParams:
    ex: int
    weight_lsb: np.ndarray
    shift: np.ndarray

    def __post_init__(self):
        weight_lsb = np.array(self.weight_lsb, dtype=np.float64, copy=True)
        shift = np.array(self.shift, copy=True)
        if weight_lsb.shape != (N,) or shift.shape != (N,):
            raise ValueError("PC16 scales and shifts must have 256 entries")
        if not np.isfinite(weight_lsb).all() or np.any(weight_lsb <= 0):
            raise ValueError("weight LSBs must be positive and finite")
        if not isinstance(self.ex, (int, np.integer)) or not -120 <= self.ex <= 120:
            raise ValueError("input exponent must be an integer in [-120, 120]")
        if not np.issubdtype(shift.dtype, np.integer) or np.any((shift < 0) | (shift > 40)):
            raise ValueError("output shift must be an integer in [0, 40]")
        weight_lsb.setflags(write=False)
        shift.setflags(write=False)
        object.__setattr__(self, "weight_lsb", weight_lsb)
        object.__setattr__(self, "shift", shift)

    @property
    def accum_lsb(self):
        return np.ldexp(self.weight_lsb, -int(self.ex))

    def to_dict(self):
        return {"ex": int(self.ex), "weight_lsb": self.weight_lsb.tolist(),
                "accum_lsb": self.accum_lsb.tolist(), "shift": self.shift.tolist()}

    @classmethod
    def from_dict(cls, data):
        return cls(data["ex"], data["weight_lsb"], data["shift"])


def input_exponent(x, margin):
    peak = float(np.max(np.abs(x)))
    if not math.isfinite(peak) or not math.isfinite(margin) or margin < 1:
        raise ValueError("invalid input peak or margin")
    return math.floor(math.log2(32767.0 / (margin * peak))) if peak else 0


def weight_lsb_for(w):
    w = np.asarray(w, dtype=np.float64)
    if w.shape != (K, N) or not np.isfinite(w).all():
        raise ValueError("expected finite [64, 256] weights")
    scale = np.max(np.abs(w), axis=0) / 32767.0
    return np.where(scale > 0, scale, 1.0)


def shift_for_peak(peak, margin):
    peak = np.asarray(peak, dtype=np.float64)
    if (not np.isfinite(peak).all() or np.any(peak < 0) or
            not math.isfinite(margin) or margin < 1):
        raise ValueError("invalid accumulator peak or margin")
    return np.ceil(np.log2(np.maximum(1.0, peak * margin / 32767.0))).astype(np.int64)


def encode_layer(x, w, b, params):
    if np.shape(x)[-1:] != (K,) or np.shape(w) != (K, N) or np.shape(b) != (N,):
        raise ValueError("expected X[...,64], W[64,256] and B[256]")
    x_int, x_clip = quantize(x, math.ldexp(1.0, -int(params.ex)), 16)
    w_int, w_clip = quantize(w, params.weight_lsb, 16)
    b_int, b_clip = quantize(b, params.accum_lsb, 40)
    return x_int, w_int, b_int, {"x": x_clip, "w": w_clip, "b": b_clip}


def _signed(value, bits):
    value = np.asarray(value)
    limit = 1 << (bits - 1)
    if (not np.issubdtype(value.dtype, np.signedinteger) or
            np.any((value < -limit) | (value >= limit))):
        raise ValueError(f"expected signed {bits}-bit integer values")
    return value.astype(np.int64, copy=False)


def accumulate(x, w, b, *, exact_blas=False):
    x, w, b = _signed(x, 16), _signed(w, 16), _signed(b, 40)
    if x.shape[-1:] != (K,) or w.shape != (K, N) or b.shape != (N,):
        raise ValueError("expected X[...,64], W[64,256] and B[256]")
    if exact_blas:
        # All products and partial sums of the 64 terms are exact in binary64.
        shape = (*x.shape[:-1], N)
        dot = x.reshape(-1, K).astype(np.float64) @ w.astype(np.float64)
        dot = dot.astype(np.int64).reshape(shape)
    else:
        dot = x @ w
    total = dot + b
    if np.any((total < -(1 << 41)) | (total >= (1 << 41))):
        raise OverflowError("accumulator exceeds signed 42 bits")
    return total


def requantize(total, shift):
    clipped, count = saturate(rne_shift(_signed(total, 42), shift), 16)
    return clipped.astype(np.int16), count


def run_layer_int(x, w, b, shift):
    return requantize(accumulate(x, w, b), shift)


def decode(y, params):
    return _signed(y, 16) * np.ldexp(params.accum_lsb, params.shift.astype(np.int32))


def calibrate(x, w, b, x_margin=1.25, y_margin=1.25):
    ex = input_exponent(x, x_margin)
    w_lsb = weight_lsb_for(w)
    temporary = LayerParams(ex, w_lsb, np.zeros(N, dtype=np.int64))
    x_int, w_int, b_int, _ = encode_layer(x, w, b, temporary)
    total = accumulate(x_int, w_int, b_int, exact_blas=True)
    return LayerParams(ex, w_lsb, shift_for_peak(
        np.abs(total).reshape(-1, N).max(axis=0), y_margin
    ))
