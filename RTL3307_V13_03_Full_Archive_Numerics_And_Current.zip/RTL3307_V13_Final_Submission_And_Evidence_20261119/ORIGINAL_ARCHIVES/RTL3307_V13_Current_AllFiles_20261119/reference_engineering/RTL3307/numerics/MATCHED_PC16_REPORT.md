# Matched-sample baseline comparison

All12validation sample IDs and X.hex files match the W12 fixtures byte-for-byte. PC16 parameters are original frozen values, hash-checked against the existing calibration receipt; no fitting or testing-set selection occurred. PC16 goldens passed304128independent scalar comparisons.

Original baseline source copy passed all SOURCE_MANIFEST checks before and after A/Bsimulation. Both modes passed12tasks/304128outputs, same unchanged firmware hash as W12.

|Mode|Matched PC16 cycles|W12 cycles|Reduction|
|---|---:|---:|---:|
|A|250944|203304|18.984315%|
|B|459877|363014|21.062806%|

Fixtures: matched_pc16_validation_tasks/manifest.json.
Fixture identity receipt: matched_pc16_receipt.json.
Baseline exact cycle receipt: matched_pc16_engine/matched_pc16_soc/summary.json.
Comparison bindings: matched_pc16_comparison.json.
Entry: matched_pc16_engine/run_matched_pc16_soc.py --output-name <fresh_name>.
This receipt supersedes the differently-sampled baseline comparison limitation in NUMERIC_REPORT.md.
Local behavioral evidence only; officialmacroGLS, synthesis, STA and power remain unrun.
