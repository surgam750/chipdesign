"""Replay RTL3307 numerical vectors or export its frozen W12 parameters."""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys

for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"

ROOT = Path(__file__).resolve().parent
FROZEN = ROOT / "engine/evaluation/frozen"
sys.path.insert(0, str(FROZEN))

import numpy as np
from model.kwt_numeric import pc16, vectors
from model.kwt_numeric.extract import extract_layer, load_features, load_kwt_weights, weights_for_layer
from model.kwt_numeric.formats import quantize
from wpack12 import pack_weights, unpack_weights

TASKS = ROOT.parent / "synthesis_tt_fix1/payload/frozen/data/tasks/validation"
RTL = ROOT.parent / "synthesis_tt_fix1/payload"
WEIGHTS = FROZEN / "data/export_kwt1_float.npz"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def params(layer):
    path = ROOT / "params_w12" / f"layer_{layer:02d}.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    freeze = json.loads((ROOT / "FORMAT_FREEZE.json").read_text(encoding="utf-8"))
    if freeze["selected"] != "X16_W12_PACKED" or data["weight_bits"] != 12:
        raise ValueError("Expected the frozen W12 format")
    if sha(path) != freeze["params"][path.name]:
        raise ValueError("Frozen parameter file changed: " + str(path))
    return pc16.LayerParams.from_dict(data)


def export_weights(out):
    out.mkdir(parents=True, exist_ok=False)
    weights = load_kwt_weights(WEIGHTS)
    records = []
    for layer in range(12):
        p = params(layer)
        w, bias = weights_for_layer(weights, layer)
        # pc16.encode_layer uses INT16 weights; W12 must explicitly use 12 here.
        w_int, w_clip = quantize(w, p.weight_lsb, 12)
        b_int, b_clip = quantize(bias, p.accum_lsb, 40)
        if w_clip or b_clip:
            raise ValueError(f"Unexpected clipping in frozen layer {layer}")
        words = pack_weights(w_int, b_int, p.shift)
        folder = out / f"layer_{layer:02d}"
        folder.mkdir()
        path = folder / "wpack.hex"
        path.write_bytes("".join(f"{int(word):08x}\n" for word in words).encode("ascii"))
        records.append({"layer": layer, "path": path.relative_to(out).as_posix(),
                        "words": len(words), "sha256": sha(path)})
    report = {"format": "X16_W12_PACKED", "model_sha256": sha(WEIGHTS),
              "format_freeze_sha256": sha(ROOT / "FORMAT_FREEZE.json"), "layers": records}
    save(out / "conversion_manifest.json", report)
    return report


def read_words(path):
    tokens = path.read_text(encoding="ascii").split()
    if any(len(token) != 8 for token in tokens):
        raise ValueError("Expected eight hexadecimal digits per word: " + str(path))
    values = [int(token, 16) for token in tokens]
    if any(not 0 <= value <= 0xffffffff for value in values):
        raise ValueError("Word outside UINT32 range")
    return np.array(values, dtype=np.uint32)


def read_matrix(path, rows, columns):
    words = read_words(path)
    if len(words) != rows * columns // 2:
        raise ValueError("Wrong packed matrix size: " + str(path))
    values = np.empty(len(words) * 2, dtype=np.int64)
    values[0::2] = words & 0xffff
    values[1::2] = words >> 16
    values = (values ^ 0x8000) - 0x8000
    return values.reshape(rows, columns)


def verify(out):
    out.mkdir(parents=True, exist_ok=False)
    converted = export_weights(out / "converted_weights")
    core_hashes = json.loads((RTL / "tools/w12_core_sha256.json").read_text())
    generated = ROOT.parent / "project/ChipDesign/w12_sysbus_rebuild_20261113/work/optimized_soc"
    for rel, expected in core_hashes.items():
        if sha(RTL / "frozen" / rel) != expected:
            raise ValueError("Server numerical core changed: " + rel)
        if sha(generated / "rtl/e203/kwt" / Path(rel).name) != expected:
            raise ValueError("RTL3307 generated core changed: " + rel)
    features, _, sample_ids, _ = load_features(ROOT / "data/validation_mfcc.npz", "validation")
    sample_index = {name: index for index, name in enumerate(sample_ids.tolist())}
    weights = load_kwt_weights(WEIGHTS)
    task_manifest = json.loads((TASKS / "manifest.json").read_text())
    if len(task_manifest["tasks"]) != 12:
        raise ValueError("Expected twelve frozen tasks")
    results = []
    for task in task_manifest["tasks"]:
        folder = TASKS / task["directory"]
        if sha(folder / "meta.json") != task["meta_sha256"]:
            raise ValueError("Task metadata changed")
        meta = json.loads((folder / "meta.json").read_text())
        for filename, item in meta["files"].items():
            if sha(folder / filename) != item["sha256"]:
                raise ValueError("Task data changed: " + filename)
        if meta["model_sha256"] != sha(WEIGHTS) or meta["calibration_sha256"] != sha(ROOT / "FORMAT_FREEZE.json"):
            raise ValueError("Model/format identity differs from the RTL task")
        layer = meta["layer"]
        m, k, n = meta["M"], meta["K"], meta["N"]
        x = read_matrix(folder / "x.hex", m, k)
        golden = read_matrix(folder / "y_golden.hex", m, n)
        packed = read_words(folder / "wpack.hex")
        w, bias, shifts = unpack_weights(packed, k, n)
        replay, saturated = pc16.run_layer_int(x, w, bias, shifts)
        mismatches = int(np.count_nonzero(replay != golden))
        if mismatches:
            raise ValueError(f"Layer {layer}: {mismatches} golden mismatches")
        scalar_checked = vectors.scalar_verify(x, w, bias, shifts, golden)
        exported = out / "converted_weights" / f"layer_{layer:02d}" / "wpack.hex"
        if exported.read_bytes() != (folder / "wpack.hex").read_bytes():
            raise ValueError(f"Layer {layer}: parameter conversion differs from RTL image")
        floats, _ = extract_layer(features[sample_index[meta["sample_id"]]], weights, layer)
        p = params(layer)
        x_from_float, clipped = quantize(floats, math.ldexp(1.0, -p.ex), 16)
        if clipped or not np.array_equal(x_from_float, x):
            raise ValueError(f"Layer {layer}: float-to-X16 conversion differs")
        results.append({"layer": layer, "scalar_outputs_checked": scalar_checked,
                        "mismatches": mismatches, "saturated": int(saturated),
                        "wpack_byte_identical": True, "float_to_x16_identical": True})
        print(f"NUMERIC_LAYER_PASS layer={layer} outputs={scalar_checked}", flush=True)
    report = {"status": "NUMERIC_REPLAY_AND_CONVERSION_PASS", "numpy_version": np.__version__,
              "core_files_verified": len(core_hashes), "task_manifest_sha256": sha(TASKS / "manifest.json"),
              "format_freeze_sha256": converted["format_freeze_sha256"],
              "model_sha256": converted["model_sha256"],
              "total_scalar_outputs": sum(row["scalar_outputs_checked"] for row in results),
              "layers": results,
              "scope": "Software numerical replay and frozen parameter conversion; not a new RTL or gate simulation"}
    save(out / "numeric_verification.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("verify", "export"))
    parser.add_argument("--out", type=Path, required=True, help="Fresh output directory; existing directories are refused")
    args = parser.parse_args()
    result = verify(args.out.resolve()) if args.command == "verify" else export_weights(args.out.resolve())
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
