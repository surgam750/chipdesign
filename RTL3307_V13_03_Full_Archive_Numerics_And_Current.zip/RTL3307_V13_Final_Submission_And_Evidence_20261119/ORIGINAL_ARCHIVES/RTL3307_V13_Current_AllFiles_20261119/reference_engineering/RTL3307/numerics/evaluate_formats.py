"""Train-only calibration and validation-only format comparison; no model training."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import sys, json, math, hashlib
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parent
FROZEN = ROOT / 'engine/evaluation/frozen'
sys.path.insert(0, str(FROZEN))
from model.kwt_numeric import pc16
from model.kwt_numeric.extract import load_features, load_kwt_weights, collect_inputs, weights_for_layer, sha256
from model.kwt_numeric.formats import quantize
from model.kwt_numeric.metrics import ErrorTotals
DATA = Path('D:/Codex/ChipDesign/kwt_accelerator/assets/speech_commands_v2')

def encoded(x, w, b, p, bits):
    a, ac = quantize(x, math.ldexp(1., -p.ex), 16)
    k, kc = quantize(w, p.weight_lsb, bits)
    c, cc = quantize(b, p.accum_lsb, 40)
    return a,k,c,{'x':ac,'w':kc,'b':cc}

def main():
    train,tl,ti,_ = load_features(Path('D:/Codex/ChipDesign/kwt_soc/data/calibration_mfcc.npz'),'training')
    val,vl,vi,_ = load_features(DATA/'validation_mfcc.npz','validation')
    assert len(train)==1200 and len(val)==600 and not set(ti)&set(vi)
    assert min(np.bincount(tl)) >= 100 and len(np.unique(vl))==12
    weights = load_kwt_weights(FROZEN/'data/export_kwt1_float.npz')
    report={'scope':'Training fit, validation selection only. No training, no testing data.', 'sources':{str(p):sha256(p) for p in (Path('D:/Codex/ChipDesign/kwt_soc/data/calibration_mfcc.npz'),DATA/'validation_mfcc.npz',FROZEN/'data/export_kwt1_float.npz',FROZEN/'params/calibration_manifest.json')},'candidates':[]}
    with np.load(Path('D:/Codex/ChipDesign/kwt_soc/data/calibration_mfcc.npz'),allow_pickle=False) as z:
        assert str(z['manifest_sha256'].item()) == sha256(FROZEN/'params/calibration_manifest.json')
    train_inputs,_=collect_inputs(train,weights)
    print('TRAIN_TRACE_READY',flush=True)
    val_inputs,_=collect_inputs(val,weights)
    print('VALIDATION_TRACE_READY',flush=True)
    for bits in (8,12,14,16):
        candidate={'weight_bits':bits,'x_bits':16,'layers':[]}
        out=ROOT/f'params_w{bits}'
        out.mkdir(exist_ok=True)
        for layer in range(12):
            w,b=weights_for_layer(weights,layer)
            ex=pc16.input_exponent(train_inputs[layer],1.25)
            peak=np.max(np.abs(w),axis=0)
            lsb=np.where(peak>0,peak/((1<<(bits-1))-1),1.)
            temporary=pc16.LayerParams(ex,lsb,np.zeros(256,dtype=np.int64))
            maximum=np.zeros(256,dtype=np.int64)
            for start in range(0,1200,24):
                a,k,c,clipped=encoded(train_inputs[layer,start:start+24],w,b,temporary,bits)
                assert not any(clipped.values()),clipped
                total=pc16.accumulate(a,k,c,exact_blas=True)
                maximum=np.maximum(maximum,np.abs(total).reshape(-1,256).max(axis=0))
            p=pc16.LayerParams(ex,lsb,pc16.shift_for_peak(maximum,1.25))
            metric=ErrorTotals(); sat=0; clips={'x':0,'w':0,'b':0}
            for start in range(0,600,24):
                rows=val_inputs[layer,start:start+24]
                a,k,c,counts=encoded(rows,w,b,p,bits)
                y,n=pc16.requantize(pc16.accumulate(a,k,c,exact_blas=True),p.shift)
                metric.update(pc16.decode(y,p),rows@w+b); sat+=n
                for name in clips: clips[name]+=counts[name]
            row={'layer':layer,'nrmse':metric.result(),'nrmse_percent':metric.result()*100,'saturated':sat,'elements':metric.count,'clipped':clips,'ex':ex,'shift_min':int(p.shift.min()),'shift_max':int(p.shift.max())}
            candidate['layers'].append(row)
            (out/f'layer_{layer:02d}.json').write_text(json.dumps({'weight_bits':bits,**p.to_dict()},indent=2)+'\n')
            print(f'W{bits} layer{layer} nrmse_pct={100*metric.result():.8f} sat={sat}',flush=True)
        candidate['max_nrmse_percent']=max(x['nrmse_percent'] for x in candidate['layers'])
        candidate['precision_score_proxy']=10-candidate['max_nrmse_percent']/0.3
        report['candidates'].append(candidate)
        (ROOT/'format_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    print('FORMAT_COMPARISON_COMPLETE',flush=True)
if __name__=='__main__': main()

