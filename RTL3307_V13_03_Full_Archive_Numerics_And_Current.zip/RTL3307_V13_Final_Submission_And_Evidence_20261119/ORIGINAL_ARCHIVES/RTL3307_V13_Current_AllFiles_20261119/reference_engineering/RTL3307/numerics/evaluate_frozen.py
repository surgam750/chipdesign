"""One held-out evaluation of the already frozen W12 candidate; no selection."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import json,sys
from pathlib import Path
import numpy as np
from evaluate_formats import ROOT,FROZEN,encoded
from model.kwt_numeric import pc16
from model.kwt_numeric.extract import load_features,load_kwt_weights,collect_inputs,weights_for_layer,sha256
from model.kwt_numeric.metrics import ErrorTotals
freeze_path=ROOT/'FORMAT_FREEZE.json';freeze=json.loads(freeze_path.read_text())
assert freeze['selected']=='X16_W12_PACKED' and freeze['testing_used_for_selection'] is False
assert freeze['comparison_sha256']==sha256(ROOT/'format_comparison.json')
for name,digest in freeze['params'].items():assert sha256(ROOT/'params_w12'/name)==digest
marker=ROOT/'testing_started.json'
with marker.open('x') as f:json.dump({'format_freeze_sha256':sha256(freeze_path),'evaluator_sha256':sha256(Path(__file__))},f)
features,labels,ids,_=load_features(FROZEN/'data/evaluation_mfcc.npz','testing')
assert len(features)==600
weights=load_kwt_weights(FROZEN/'data/export_kwt1_float.npz')
inputs,replay=collect_inputs(features,weights)
report={'scope':'One post-freeze public held-out testing evaluation, no tuning, not private committee data or full-model classification','samples':600,'float_replay_error':replay,'format_freeze_sha256':sha256(freeze_path),'testing_mfcc_sha256':sha256(FROZEN/'data/evaluation_mfcc.npz'),'layers':[]}
for layer in range(12):
    p=pc16.LayerParams.from_dict(json.loads((ROOT/f'params_w12/layer_{layer:02d}.json').read_text()))
    w,b=weights_for_layer(weights,layer);metric=ErrorTotals();sat=0;clips={'x':0,'w':0,'b':0}
    for start in range(0,600,24):
        rows=inputs[layer,start:start+24];a,k,c,counts=encoded(rows,w,b,p,12)
        y,n=pc16.requantize(pc16.accumulate(a,k,c,exact_blas=True),p.shift)
        metric.update(pc16.decode(y,p),rows@w+b);sat+=n
        for key in clips:clips[key]+=counts[key]
    row={'layer':layer,'nrmse':metric.result(),'nrmse_percent':100*metric.result(),'saturated':sat,'elements':metric.count,'clipped':clips};report['layers'].append(row)
    print(row,flush=True)
report['max_nrmse_percent']=max(r['nrmse_percent'] for r in report['layers'])
report['status']='PASS' if report['max_nrmse_percent']<3 and not any(r['saturated'] or any(r['clipped'].values()) for r in report['layers']) else 'FAIL'
(ROOT/'testing_result.json').write_text(json.dumps(report,indent=2)+'\n')
print('FROZEN_W12_TESTING_'+report['status'],flush=True)
