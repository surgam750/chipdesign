"""Freeze W12 selection and export validation-only RTL replay tasks."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[key]='1'
import json,sys,hashlib
from pathlib import Path
import numpy as np
from evaluate_formats import ROOT,FROZEN,DATA,encoded
from wpack12 import pack_weights,unpack_weights
from model.kwt_numeric import pc16,vectors
from model.kwt_numeric.extract import load_features,load_kwt_weights,weights_for_layer,extract_layer,sha256

def main():
    report=json.loads((ROOT/'format_comparison.json').read_text())
    assert len(report['candidates'])==4
    selected=next(c for c in report['candidates'] if c['weight_bits']==12)
    assert selected['max_nrmse_percent']<0.1 and not any(r['saturated'] or any(r['clipped'].values()) for r in selected['layers'])
    freeze={'selected':'X16_W12_PACKED','rationale':'0.033385% validation nRMSE, conservative relative to W8 0.517181%; 23.529% packed transfer reduction; no retraining.', 'comparison_sha256':sha256(ROOT/'format_comparison.json'),'params':{p.name:sha256(p) for p in sorted((ROOT/'params_w12').glob('*.json'))},'frozen_before_testing':True,'testing_used_for_selection':False}
    (ROOT/'FORMAT_FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n')
    rng=np.random.default_rng(20261110)
    for k in range(2,65,2):
        w=rng.integers(-2048,2048,size=(k,256));b=rng.integers(-(1<<39),1<<39,size=256);s=rng.integers(0,41,size=256)
        back=unpack_weights(pack_weights(w,b,s),k,256)
        assert all(np.array_equal(a,z) for a,z in zip((w,b,s),back))
    for bad in (-2049,2048):
        try: pack_weights(np.full((2,2),bad),np.zeros(2,dtype=int),np.zeros(2,dtype=int))
        except ValueError: pass
        else: raise AssertionError('out-of-range weight accepted')
    features,labels,ids,_=load_features(DATA/'validation_mfcc.npz','validation')
    weights=load_kwt_weights(FROZEN/'data/export_kwt1_float.npz')
    vectors.pack_weights=pack_weights
    out=ROOT/'validation_tasks'; cases=[]
    for layer in range(12):
        index=layer*50
        x,_=extract_layer(features[index],weights,layer)
        w,b=weights_for_layer(weights,layer)
        p=pc16.LayerParams.from_dict(json.loads((ROOT/f'params_w12/layer_{layer:02d}.json').read_text()))
        a,k,c,clipped=encoded(x,w,b,p,12)
        assert not any(clipped.values())
        y,sat=pc16.run_layer_int(a,k,c,p.shift)
        assert sat==0
        assert vectors.scalar_verify(a,k,c,p.shift,y)==25344
        folder=out/f'layer_{layer:02d}'
        vectors.write_task(folder,layer=layer,sample_id=str(ids[index]),split='validation',x=a,w=k,b=c,sh=p.shift,y=y,model_sha256=sha256(FROZEN/'data/export_kwt1_float.npz'),calibration_sha256=sha256(ROOT/'FORMAT_FREEZE.json'))
        assert all(np.array_equal(z,q) for z,q in zip((k,c,p.shift),unpack_weights(pack_weights(k,c,p.shift))))
        cases.append({'directory':folder.name,'layer':layer,'meta_sha256':sha256(folder/'meta.json')})
    (out/'manifest.json').write_text(json.dumps({'format':'X16_W12_PACKED','split':'validation','format_freeze_sha256':sha256(ROOT/'FORMAT_FREEZE.json'),'tasks':cases},indent=2)+'\n')
    (ROOT/'software_checks.json').write_text(json.dumps({'pack_roundtrip_even_k_2_to_64':'PASS','range_rejection':'PASS','scalar_checked_outputs':12*25344,'tasks_manifest_sha256':sha256(out/'manifest.json')},indent=2)+'\n')
    print('NUMERIC_SOFTWARE_PASS outputs=304128')
if __name__=='__main__':main()
